"""Accounting tests for the rank-parameterized driver; no census is run."""
import copy
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import run as driver


class DriverAccountingTests(unittest.TestCase):
    def setUp(self):
        self.previous_rank = driver.RANK
        driver.RANK = 44
        self.spec = {'rank': 43, 'sha256': 'a'*64,
                     'tasks': [{'q': 3, 'B': 2, 'm': 1}]}
        self.receipt = {
            'index': 0, 'manifest_sha256': 'a'*64,
            'nodes': 17, 'native': 0, 'handoffs': 0, 'exact_rows': 0,
            'profiles': 0, 'seconds': 0.01, 'native_exit': 0,
            'exact_continuations_exhausted': True,
            'survivors': [], 'excluded': {},
            'raw_ledger': 'rows/000000.jsonl.gz',
            'raw_records_sha256': 'b'*64,
            'native_completion': 'rank 43, q 3, B 2, multiplicity 1, nodes 17, candidates 0, exact 0',
        }

    def tearDown(self):
        driver.RANK = self.previous_rank

    def test_receipt_uses_its_own_rank(self):
        self.assertEqual(driver.check_receipt(self.receipt, self.spec), 0)

    def test_wrong_rank_in_native_trailer_rejected(self):
        rec = copy.deepcopy(self.receipt)
        rec['native_completion'] = rec['native_completion'].replace('rank 43', 'rank 44')
        with self.assertRaises(ValueError):
            driver.check_receipt(rec, self.spec)

    def test_unexhausted_handoff_is_never_complete(self):
        rec = copy.deepcopy(self.receipt)
        rec['exact_continuations_exhausted'] = False
        with self.assertRaises(ValueError):
            driver.check_receipt(rec, self.spec)

    def test_unaccounted_exclusion_rejected(self):
        rec = copy.deepcopy(self.receipt)
        rec['excluded'] = {'prime_square_trace': 1}
        with self.assertRaises(ValueError):
            driver.check_receipt(rec, self.spec)


if __name__ == '__main__':
    unittest.main()
