UNIFORM RECOMPUTATION THROUGH RANK 44
===================================

Purpose and mathematical scope
------------------------------
This package computes necessary degree-type conditions for every requested
rank from 1 through 44, in the manuscript's nonpointed based-simple integral
rotation-admissible modular setting. The extra algebraic rotation hypotheses
are part of that scope. Retaining a type is not a construction of fusion rules
or modular matrices.

The new prime_square.py test is uniform: it uses actual prime-square rows,
or detects a forced equal-degree block and applies the same trace argument
to its effective row. It checks the gcd and prime support of all available
nonunit degrees that can carry nonzero trace. It contains no saved candidate
types, rank-44 lookup table, or dimension-specific exceptions.

The earlier rank-bounded packet, support, and phase reductions remain
available with their stated ranges. The fresh preparation regenerates the
structural arithmetic that the enumeration uses. Native fixed-width searches
hand unfinished branches to exact Python integer continuations.

Requirements
------------
Linux or WSL2, Python 3.9 or later, and a C++17 compiler. No third-party
Python packages are needed. On Ubuntu, if these tools are not installed:

  sudo apt install python3 g++ unzip

Commands
--------
From the directory containing run.py:

  python3 run.py --through 44 --jobs 8

This computes every rank 1,...,44 from zero and writes rank-work/.
Use a new work directory to repeat a fresh computation:

  python3 run.py --through 44 --jobs 8 --work fresh-all-ranks

For rank 44 alone:

  python3 run.py --rank 44 --jobs 8 --work fresh-rank44

The jobs argument is the maximum number of workers; the runner caps it
at the machine's available logical CPUs. Use --jobs 10 on a 12-CPU laptop
if desired. Compilation and shared structural preparation occur once per
batch. Every rank uses the same driver and the same uniform terminal test.

No earlier census, saved degree list, result archive, or completed task is
used as an input to a fresh run. The exact rank partitions are regenerated
from the distributed source.

Output
------
The file to retain or send back is:

  rank-work/rank-results.zip

With a custom --work path, it is rank-results.zip in that path.
Its summary.json must say "status": "complete" and completed must equal
tasks. The requested_ranks field records precisely which ranks were run.
A partial archive is never a proof for its unfinished ranks.

The result ZIP contains the code once under source/, shared preparation,
and per-rank manifests, counts, elapsed times, raw degree ledgers, and
completed-task receipts. Every emitted row and its disposition is bound to
the receipts by canonical SHA-256 hashes. No individual retained-type
exceptions are part of the implementation.

To reproduce a distributed result ZIP, extract it, enter source/, and run
one of the fresh commands above. This produces a new work directory;
the archived results are not loaded by that computation.

Interruption and verification
-----------------------------
Ctrl+C saves completed work and marks unfinished tasks as incomplete.
Resume the same source, rank selection, and work directory with:

  python3 run.py --through 44 --jobs 8 --resume

An unfinished task is restarted from its beginning. Sources, task partitions,
receipt accounting, native completion lines, and exact-continuation
exhaustion are checked before a task is accepted as complete.

To regenerate all partitions and verify an existing local work directory:

  python3 run.py --through 44 --verify --recheck

Use the original --rank or --through and --work options when different.
Verification does not substitute an old result for a fresh enumeration.
Do not use Python -O or -OO: proof assertions must remain enabled.

Testing and proof
-----------------
Run the mathematical regression checks with:

  python3 -m unittest discover -s tests -v

Prime-square-criterion.tex states the uniform theorem, its proof dependencies,
the conservative forced-block detector, and the safe prefix implications.
The arithmetic checker verifies the theorem's numerical premises; it does
not construct the hypothetical character table or machine-verify the proof.

Optional work-limited necessary tests retain a profile when their budget is
exhausted. Errors, native crashes, invalid arithmetic, missing completion
lines, and interrupted exact continuations are failures, never exclusions.
