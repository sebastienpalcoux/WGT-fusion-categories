"""Independent pair-first exhaustive fixed-space completion audit.

This uses neither the target DFS nor its dimension/trace/correlation bounds.
It enumerates all required pair cliques and then every required SD subset
in their common neighbourhood. Exact Galois-embedding sums calculate the
pairings. Completeness of the supplied row pool is audited separately.
"""
from pathlib import Path
from functools import lru_cache
from itertools import combinations
from math import gcd
from collections import Counter
import argparse
import hashlib
import json
import sys

REVISION = Path(__file__).resolve().parent.parent
BACKEND = REVISION / "local_explorer"
sys.path.insert(0, str(BACKEND))
from audit_target_pair_graph import audit_pair_graph
from orbit_exact import field_from_metadata


def audit(pool):
    pair_report = audit_pair_graph(pool)
    target = pool["target"]
    D, F = target["dimension"], target["matrix_codegree"]
    need_sd = target["selfdual"] - 1
    fields = [field_from_metadata(o) for o in pool["orbits"]]
    embedding_reps = []
    for field in fields:
        remaining = {u for u in range(field.conductor) if gcd(u, field.conductor) == 1}
        representatives = []
        while remaining:
            u = min(remaining)
            representatives.append(u)
            remaining.difference_update((u * h) % field.conductor for h in field.subgroup)
        assert len(representatives) == field.degree
        embedding_reps.append(representatives)

    @lru_cache(None)
    def explicit_trace(j, value):
        field = fields[j]
        trace = [0] * field.ambient_degree
        for exponent in embedding_reps[j]:
            image = field.auto(value, exponent)
            for k, coefficient in enumerate(image):
                trace[k] += coefficient
        assert not any(trace[1:])
        return trace[0]

    by_id = {row["id"]: row for row in pool["rows"]}
    pair_rows = [by_id[ids[0]] for ids in pair_report["pair_class_members"]]
    sd_groups = {}
    for row in pool["rows"]:
        if row["selfdual"]:
            values = tuple(field.value(v) for field, v in zip(fields, row["values"]))
            assert all(field.conjugate(value) == value for field, value in zip(fields, values))
            key = (row["dimension"], row["matrix_trace"], values)
            sd_groups.setdefault(key, []).append(row)
    sd_classes = [(key, sorted(rows, key=lambda row: row["id"])) for key, rows in sorted(sd_groups.items())]
    sd_rows = [rows[0] for key, rows in sd_classes]
    all_rows = [pool["unit"]] + pair_rows + sd_rows

    @lru_cache(None)
    def gram(i, j):
        if i > j:
            return gram(j, i)
        x, y = all_rows[i], all_rows[j]
        answer = 2 * x["dimension"] * y["dimension"] + (D // F) * x["matrix_trace"] * y["matrix_trace"]
        for k, (field, orbit) in enumerate(zip(fields, pool["orbits"])):
            a = field.value(x["values"][k])
            b = field.value(y["values"][k])
            twice_fixed_b = field.add(b, field.conjugate(b))
            answer += (D // orbit["formal_codegree"]) * explicit_trace(k, field.mul(a, twice_fixed_b))
        return answer

    for i, row in enumerate(all_rows):
        assert gram(i, i) == (2 * D if row["selfdual"] else D)
        if i:
            assert gram(0, i) == 0
    pair_count = len(pair_rows)
    for i in range(pair_count):
        for j in range(pair_count):
            assert gram(1 + i, 1 + j) == pair_report["scaled_fixed_gram"][i][j]
    sd_offset = 1 + pair_count
    cases = []
    histogram = Counter()
    sd_subsets = 0
    full_cliques = []
    for pair_clique in pair_report["required_cliques"]:
        common_sd = [i for i in range(len(sd_rows))
                     if all(gram(sd_offset + i, 1 + p) == 0 for p in pair_clique)]
        histogram[len(common_sd)] += 1
        case = dict(pair_classes=pair_clique, common_selfdual_classes=common_sd,
                    required_selfdual_count=need_sd)
        if len(common_sd) < need_sd:
            case["reason"] = "TOO_FEW_COMMON_SELFDUAL_CLASSES"
        else:
            failures = []
            for selected in combinations(common_sd, need_sd):
                sd_subsets += 1
                bad = next(((i, j) for i, j in combinations(selected, 2)
                            if gram(sd_offset + i, sd_offset + j) != 0), None)
                if bad is None:
                    full_cliques.append(dict(pair_classes=pair_clique, selfdual_classes=list(selected)))
                else:
                    failures.append(dict(selfdual_classes=list(selected),
                                         nonorthogonal_pair=list(bad),
                                         scaled_pairing=gram(sd_offset + bad[0], sd_offset + bad[1])))
            case["reason"] = "ALL_SELFDUAL_SUBSETS_CHECKED"
            case["nonorthogonality_witnesses"] = failures
        cases.append(case)
    return dict(status="PASS_INDEPENDENT_FIXED_CLIQUE_COMPLETION_AUDIT",
                target=target,
                scope="only the supplied complete-or-partial row pool; no row-generation completeness is inferred",
                input_pool_claims_complete=pool.get("completeness", {}).get("complete") is True,
                pair_graph_audit=pair_report,
                selfdual_fixed_classes=len(sd_classes),
                selfdual_class_members=[[row["id"] for row in rows] for key, rows in sd_classes],
                common_selfdual_count_histogram=dict(sorted(histogram.items())),
                exact_selfdual_subsets_checked=sd_subsets,
                pair_completion_cases=cases, full_fixed_cliques=full_cliques,
                no_full_fixed_clique=not full_cliques,
                dimension_trace_or_correlation_bounds_used=False,
                source_sha256={
                    "backend_independent_audits/audit_fixed_clique_completion.py": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    **{"local_explorer/" + name: hashlib.sha256((BACKEND / name).read_bytes()).hexdigest()
                       for name in ("audit_target_pair_graph.py", "orbit_exact.py", "verifier.py")}})


def main():
    if not __debug__:
        raise RuntimeError("Run this independent audit with assertions enabled")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pool", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = audit(json.loads(args.pool.read_text()))
    report["input_file_sha256"] = hashlib.sha256(args.pool.read_bytes()).hexdigest()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: report[k] for k in ("status", "selfdual_fixed_classes", "common_selfdual_count_histogram",
                                           "exact_selfdual_subsets_checked", "no_full_fixed_clique")}, indent=2))


if __name__ == "__main__":
    main()
