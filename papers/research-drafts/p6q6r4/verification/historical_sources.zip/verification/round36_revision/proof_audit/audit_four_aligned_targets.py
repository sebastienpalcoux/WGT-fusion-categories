#!/usr/bin/env python3
"""Replay all four Round 36 aligned-row exclusions with independent audits.

The row audit uses the frozen original moment-row kernel and explicit full
integral bases, not the new row-pool lifting implementation.  The graph audit
uses explicit Galois-embedding sums and exhaustive pair-first completion,
not the optimized DFS or its dimension, trace, and correlation bounds.

This is exact Python verification, not proof-assistant formalization.
"""
from pathlib import Path
import argparse
import hashlib
import importlib
import importlib.util
import json
import sys
import time

STATES = (836343, 47412, 461210, 1284815)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError("Run with assertions enabled; do not use python -O")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True,
                        help="Round36 revision root containing local_explorer and target_batch_first3_audit_inputs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    vendor = root / "local_explorer/vendor/rank16"
    sys.path.insert(0, str(vendor))
    original = importlib.import_module("fixed_field_rows_original")
    optimized = importlib.import_module("fixed_field_rows")
    contexts = importlib.import_module("context16")
    audit_dir = root / "backend_independent_audits"
    row_auditor = load_module("r36_four_independent_rows", audit_dir / "audit_complete_small_field_pools.py")
    clique_auditor = load_module("r36_four_independent_cliques", audit_dir / "audit_fixed_clique_completion.py")
    row_auditor.audit_basis_embeddings()
    results = []
    expected_orbits = {
        836343: ((6,"Q"),(6,"Q"),(8,"quadratic_disc=-4"),(9,"real_cubic_conductor9"),
                 (27,"Q"),(120,"Q"),(450,"quadratic_disc=-15")),
        47412: ((6,"Q"),(6,"Q"),(6,"Q"),(6,"Q(sqrt(-3))"),(24,"Q"),
                (25,"Q"),(27,"Q"),(50,"Q"),(180,"quadratic_disc=-3")),
        461210: ((6,"Q"),(6,"Q"),(6,"Q"),(8,"Q"),(9,"real_cubic_conductor9"),
                 (90,"Q"),(108,"Q"),(450,"quadratic_disc=-15")),
        1284815: ((8,"Q"),(8,"quadratic_disc=-4"),(9,"Q"),(9,"Q"),
                  (9,"real_cubic_conductor9"),(135,"quadratic_disc=-3"),(225,"Q")),
    }
    expected_counts = {
        836343: (66,99,65,34,11,4,5),
        47412: (205,369,260,109,25,26,5),
        461210: (158,340,123,217,44,126,4),
        1284815: (87,145,78,67,12,5,5),
    }
    for state in STATES:
        row_report = row_auditor.audit_one(root,state,original,optimized,contexts)
        pool_path = root / "target_batch_first3_audit_inputs" / str(state) / "pool.json"
        pool = json.loads(pool_path.read_text())
        assert tuple((o["formal_codegree"],o["label"]) for o in pool["orbits"]) == expected_orbits[state]
        clique_report = clique_auditor.audit(pool)
        clique_report["input_file_sha256"] = sha(pool_path)
        assert clique_report["input_pool_claims_complete"]
        assert clique_report["no_full_fixed_clique"]
        graph = clique_report["pair_graph_audit"]
        actual_counts = (row_report["moment_rows"],row_report["exact_rows"],
                         row_report["selfdual_rows"],row_report["nonselfdual_rows"],
                         graph["fixed_pair_classes"],len(graph["orthogonality_edges"]),
                         graph["required_pair_count"])
        assert actual_counts == expected_counts[state]
        if state in (836343,1284815):
            assert graph["clique_counts_by_size"].get(3,graph["clique_counts_by_size"].get("3")) == 0
        elif state == 47412:
            assert graph["clique_counts_by_size"].get(4,graph["clique_counts_by_size"].get("4")) == 0
        else:
            assert len(graph["required_cliques"]) == 64
            assert clique_report["common_selfdual_count_histogram"] == {6:22,8:42}
            assert clique_report["exact_selfdual_subsets_checked"] == 336
        (output / f"rows_{state}.json").write_text(json.dumps(row_report,indent=2)+"\n")
        (output / f"fixed_clique_{state}.json").write_text(json.dumps(clique_report,indent=2)+"\n")
        results.append(dict(state=state,matrix_codegree=pool["target"]["matrix_codegree"],
                            status="EXCLUDED_BY_COMPLETE_INDEPENDENT_FIXED_SPACE_AUDIT",
                            moment_rows=row_report["moment_rows"],exact_rows=row_report["exact_rows"],
                            selfdual_rows=row_report["selfdual_rows"],nonselfdual_rows=row_report["nonselfdual_rows"],
                            fixed_pair_classes=graph["fixed_pair_classes"],
                            orthogonality_edges=len(graph["orthogonality_edges"]),
                            required_pair_count=graph["required_pair_count"],
                            pair_clique_counts=graph["clique_counts_by_size"],
                            complete_pair_cliques=len(graph["required_cliques"]),
                            common_selfdual_count_histogram=clique_report["common_selfdual_count_histogram"],
                            selfdual_subsets_checked=clique_report["exact_selfdual_subsets_checked"],
                            no_full_fixed_clique=True,pool_sha256=sha(pool_path)))
    report = dict(status="PASS_FOUR_COMPLETE_ALIGNED_TARGET_EXCLUSIONS",states=results,
                  formal_proof_assistant_verification=False,
                  scope="four specified symplectic rank-sixteen full-field assignments under the inherited source hypotheses",
                  independence=["Original inherited moment-row kernel retained unchanged",
                                "Full integral-basis lifts independent of target_pool and orbit_exact",
                                "Pairings from explicit Galois embeddings",
                                "Exhaustive pair-first completion independent of target_search pruning"],
                  source_sha256={
                      "audit_four_aligned_targets.py":sha(Path(__file__)),
                      "original_moment_kernel":sha(Path(original.__file__)),
                      "independent_pool_audit":sha(audit_dir/"audit_complete_small_field_pools.py"),
                      "independent_clique_audit":sha(audit_dir/"audit_fixed_clique_completion.py")},
                  seconds=time.monotonic()-started)
    (output/"four_aligned_targets_audit.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
