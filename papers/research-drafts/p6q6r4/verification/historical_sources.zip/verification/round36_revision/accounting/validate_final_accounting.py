#!/usr/bin/env python3
"""Independently audit the Round 36 revision union and export its final remainder.

Only Python's standard library is used. The supplied base and revision trees
are read-only. This validates identity, coverage and completed certificate
metadata; it does not rerun the mathematical row or local-corner proofs.

Example (paths may be adapted to the release layout):
  python -B -S validate_final_accounting.py --base /path/to/original_round36 \
      --revision /path/to/round36_revision --output /path/to/accounting

ID digests are SHA-256 of ascending decimal state IDs, one per LF-terminated
line. JSONL exports preserve authoritative input bytes. Gzip mtime is zero.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import ExitStack
import gzip
import hashlib
import json
from pathlib import Path
import time

ALIGNED_EXCLUSIONS = (47412, 461210, 836343)
NEW_ALIGNED_EXCLUSION = 1284815
IDENTITY_KEYS = ("state", "index", "double_degree", "assignment_index", "kind")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def verify_manifest(base, mapping_path=None):
    mapping = None
    if mapping_path is not None:
        mapping = load_json(mapping_path)
        require(mapping.get("schema") == "fusion5400.initial_round36_payload_mapping.v1",
                "Unrecognized original-release mapping schema")
        manifest_rel = Path(mapping["original_manifest_path"])
        require(not manifest_rel.is_absolute() and ".." not in manifest_rel.parts,
                "Unsafe original manifest path")
        manifest = base / manifest_rel
        require(digest_file(manifest) == mapping["original_manifest_sha256"],
                "Mapped original manifest digest differs")
        retained = mapping["mapping"]
        require(len({item["original_path"] for item in retained}) == len(retained),
                "Duplicate mapped original payload")
        retained = {item["original_path"]: item["retained_path"] for item in retained}
    else:
        manifest = base / "SHA256SUMS.txt"
    seen = set()
    mismatches = []
    missing = []
    byte_count = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        require(len(expected) == 64 and name not in seen, "Malformed or duplicate manifest entry")
        rel = Path(name)
        require(not rel.is_absolute() and ".." not in rel.parts, "Unsafe manifest path")
        seen.add(name)
        if mapping is not None:
            require(name in retained, "Original manifest payload is absent from explicit mapping")
            rel = Path(retained[name])
            require(not rel.is_absolute() and ".." not in rel.parts, "Unsafe retained payload path")
        path = base / rel
        require(path.resolve().is_relative_to(base), "Original payload escapes release root")
        require(not path.is_symlink(), "Mapped original payload must be a regular retained file")
        if not path.is_file():
            missing.append(name)
            continue
        actual = digest_file(path)
        byte_count += path.stat().st_size
        if actual != expected:
            mismatches.append({"file": name, "expected": expected, "actual": actual})
    if mapping is not None:
        require(set(retained) == seen, "Original manifest and payload mapping have different scopes")
        require(len(set(retained.values())) == len(retained), "Two original payloads share a retained path")
        extras = []
    else:
        extras = sorted(str(p.relative_to(base)) for p in base.rglob("*")
                        if p.is_file() and str(p.relative_to(base)) not in seen
                        and p != manifest)
    report = {
        "status": "PASS" if not missing and not mismatches and not extras else "FAIL",
        "manifest_sha256": digest_file(manifest), "manifest_payloads": len(seen),
        "verified_payload_bytes": byte_count, "missing": missing,
        "mismatches": mismatches, "unmanifested_files": extras,
    }
    require(len(seen) == 3473, "Original R36 manifest does not contain 3,473 payloads")
    if mapping is not None:
        report.update(layout="original payloads retained at explicit current/historical paths",
                      payload_mapping_sha256=digest_file(mapping_path),
                      current_release_extras_outside_original_scope=True)
    return report


class JsonlStream:
    def __init__(self, paths, expected=None):
        self.paths = list(paths)
        self.expected = expected or {}
        self.raw_hash = hashlib.sha256()
        self.id_hash = hashlib.sha256()
        self.count = 0
        self.last_state = -1
        self.file_reports = []
        self.generator = self._read()
        self.current = next(self.generator, None)

    def _read(self):
        for path in self.paths:
            wanted = self.expected.get(path.name)
            if wanted:
                require(digest_file(path) == wanted["sha256"], "Compressed digest mismatch: " + str(path))
            local_hash = hashlib.sha256()
            records = 0
            with gzip.open(path, "rb") as f:
                for raw in f:
                    require(raw.endswith(b"\n"), "Missing final LF: " + str(path))
                    row = json.loads(raw)
                    state = row["state"]
                    require(type(state) is int and state > self.last_state,
                            "State IDs are duplicated or not strictly ascending: " + str(path))
                    self.last_state = state
                    self.raw_hash.update(raw)
                    self.id_hash.update(f"{state}\n".encode("ascii"))
                    local_hash.update(raw)
                    self.count += 1
                    records += 1
                    yield row, raw
            if wanted:
                require(records == wanted["records"], "Chunk record count mismatch: " + str(path))
                require(local_hash.hexdigest() == wanted["uncompressed_sha256"],
                        "Uncompressed digest mismatch: " + str(path))
            self.file_reports.append({"file": path.name, "records": records,
                                      "uncompressed_sha256": local_hash.hexdigest()})

    def take(self):
        value = self.current
        require(value is not None, "Unexpected end of state stream")
        self.current = next(self.generator, None)
        return value

    def matches(self, state):
        if self.current is None:
            return False
        require(self.current[0]["state"] >= state, "Unconsumed earlier state in a certificate stream")
        return self.current[0]["state"] == state

    def report(self):
        require(self.current is None, "Stream not exhausted")
        return {"records": self.count, "uncompressed_sha256": self.raw_hash.hexdigest(),
                "state_ids_sha256": self.id_hash.hexdigest()}


class Stats:
    def __init__(self):
        self.kinds = Counter()
        self.profiles = set()
        self.placements = set()
        self.codegrees = Counter()
        self.id_hash = hashlib.sha256()

    def add(self, row):
        self.kinds[row["kind"]] += 1
        profile = tuple(row["profile"])
        self.profiles.add(profile)
        self.placements.add((profile, row["double_degree"]))
        require(5400 % row["double_degree"] == 0, "Nonintegral matrix formal codegree")
        self.codegrees[(5400 // row["double_degree"], row["kind"])] += 1
        self.id_hash.update(f'{row["state"]}\n'.encode("ascii"))

    def report(self):
        return {"records": sum(self.kinds.values()), "counts_by_kind": dict(sorted(self.kinds.items())),
                "canonical_profiles": len(self.profiles), "matrix_placements": len(self.placements),
                "state_ids_sha256": self.id_hash.hexdigest(),
                "counts_by_matrix_formal_codegree_and_kind": [
                    {"f": f, "kind": kind, "states": n}
                    for (f, kind), n in sorted(self.codegrees.items())]}


class Export:
    def __init__(self, output, name, stack):
        self.name = name
        self.final = output / name
        self.temporary = output / (name + ".tmp")
        raw = stack.enter_context(self.temporary.open("wb"))
        self.handle = stack.enter_context(gzip.GzipFile(filename="", fileobj=raw,
                                                       mode="wb", compresslevel=6, mtime=0))
        self.h = hashlib.sha256()
        self.count = 0

    def write(self, raw):
        self.handle.write(raw)
        self.h.update(raw)
        self.count += 1

    def finish(self):
        self.temporary.replace(self.final)
        return {"file": self.name, "records": self.count, "bytes": self.final.stat().st_size,
                "sha256": digest_file(self.final), "uncompressed_sha256": self.h.hexdigest()}


def same_identity(a, b):
    require(all(a[k] == b[k] for k in IDENTITY_KEYS),
            "Identity mismatch for state " + str(a["state"]))
    if "open_index" in b:
        require(a["open_index"] == b["open_index"], "OPEN-index mismatch")


def aligned_certificate_metadata(revision):
    pool_audit_path = revision / "backend_independent_audits/complete_small_field_pool_audit.json"
    pool_audit = load_json(pool_audit_path)
    require(pool_audit["status"] == "PASS_COMPLETE_SMALL_FIELD_ROW_POOLS", "Missing row-pool audit")
    audited = {r["state"]: r for r in pool_audit["targets"]}
    reports = []
    for state in ALIGNED_EXCLUSIONS:
        name = (f"target_{state}/search_result.json" if state != 836343 else
                "target_836343/target_search_independent_result.json")
        path = revision / name
        r = load_json(path)
        require(r["status"] == "EXCLUDED_POOL" and r["complete"], "Incomplete target exclusion")
        require(r["input_pool_claims_complete"] and r["complete_traversal_performed_in_this_call"],
                "Incomplete supplied-pool traversal")
        require(not r["prior_chunk_history_required"] and not r["solutions"], "Unsupported target history")
        require(r["target"]["state_id"] == state and r["target"]["kind"] == "symplectic",
                "Target identity mismatch")
        require(state in audited and audited[state]["unliftable_moment_rows"] == 0,
                "Missing complete row-lift audit")
        reports.append({"state": state, "matrix_codegree": r["target"]["matrix_codegree"],
                        "search_report": name, "search_report_sha256": digest_file(path),
                        "audited_row_counts": {k: audited[state][k] for k in
                            ("moment_rows", "exact_rows", "selfdual_rows", "nonselfdual_rows")}})
    return reports, {"file": "backend_independent_audits/complete_small_field_pool_audit.json",
                     "sha256": digest_file(pool_audit_path)}


def additional_certificate_metadata(evidence):
    row_path = evidence / "small_field_pool_1284815.json"
    fixed_path = evidence / "fixed_clique_1284815.json"
    record_path, pool_path = evidence / "record.json", evidence / "pool.json"
    row, fixed, record = load_json(row_path), load_json(fixed_path), load_json(record_path)
    require(row["state"] == record["state"] == NEW_ALIGNED_EXCLUSION,
            "Fourth row-pool audit identity mismatch")
    require(row["status"] == "PASS_ORIGINAL_KERNEL_AND_INDEPENDENT_INTEGRAL_BASIS_LIFTS" and
            row["unliftable_moment_rows"] == 0, "Fourth complete row-pool audit failed")
    require(row["pool_sha256"] == digest_file(pool_path) and row["record_sha256"] == digest_file(record_path),
            "Fourth row-pool audit is not bound to the supplied inputs")
    require(fixed["status"] == "PASS_INDEPENDENT_FIXED_CLIQUE_COMPLETION_AUDIT" and
            fixed["input_pool_claims_complete"] and fixed["no_full_fixed_clique"],
            "Fourth independent fixed-space audit failed")
    require(fixed["target"]["state_id"] == NEW_ALIGNED_EXCLUSION and
            fixed["target"]["kind"] == "symplectic" and
            fixed["input_file_sha256"] == digest_file(pool_path), "Fourth fixed-space input mismatch")
    return {"state": NEW_ALIGNED_EXCLUSION, "matrix_codegree": fixed["target"]["matrix_codegree"],
            "row_pool_audit_sha256": digest_file(row_path), "fixed_space_audit_sha256": digest_file(fixed_path),
            "pool_sha256": digest_file(pool_path), "record_sha256": digest_file(record_path),
            "audited_row_counts": {k: row[k] for k in
                ("moment_rows", "exact_rows", "selfdual_rows", "nonselfdual_rows")}}, record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--revision", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--base-map", type=Path,
                        help="Explicit original-to-retained payload mapping for the revised release layout.")
    parser.add_argument("--additional-evidence", type=Path,
                        default=Path(__file__).resolve().parent / "fourth_exclusion")
    args = parser.parse_args()
    base, rev, output = args.base.resolve(), args.revision.resolve(), args.output.resolve()
    require(output != base and output != rev and rev not in output.parents,
            "Output must not modify a frozen input tree")
    if args.base_map is None:
        require(base not in output.parents, "Output must not modify the original input tree")
    else:
        for frozen in (base / "verification", base / "provenance", base / "integration"):
            require(output != frozen and frozen not in output.parents,
                    "Output must be outside frozen payload directories")
    output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    base_integrity = verify_manifest(base, args.base_map.resolve() if args.base_map else None)
    write_json(output / "base_integrity_report.json", base_integrity)
    require(base_integrity["status"] == "PASS", "Original release integrity failed; inspect base_integrity_report.json")
    print("Original release: 3,473 payload hashes verified.", flush=True)

    normalized_dir = rev / "corner/normalized_open"
    normalized_manifest = load_json(normalized_dir / "manifest.json")
    chunks = normalized_manifest["chunks"]
    require([c["start"] for c in chunks] == [0] + [c["stop"] for c in chunks[:-1]],
            "Normalized chunk coverage is not consecutive")
    original = JsonlStream([base / "verification/round36/one_matrix16/rank16_open_state_ids.jsonl.gz"])
    normalized = JsonlStream([normalized_dir / c["file"] for c in chunks],
                             {c["file"]: c for c in chunks})
    corner_excluded = JsonlStream([rev / "corner/full_sweep/incremental_exclusions.jsonl.gz"])
    corner_remaining = JsonlStream([rev / "corner/full_sweep/remaining_open_ids.jsonl.gz"])
    frob_excluded = JsonlStream([rev / "corner/frobenius_sweep/incremental_exclusions.jsonl.gz"])
    frob_remaining = JsonlStream([rev / "corner/frobenius_sweep/remaining_open_ids.jsonl.gz"])
    streams = {"original_OPEN": original, "normalized_OPEN": normalized,
               "corner_excluded": corner_excluded, "corner_remaining": corner_remaining,
               "frobenius_excluded": frob_excluded, "frobenius_remaining": frob_remaining}

    target_path = rev / "corner/frobenius_sweep/symplectic_target_records.jsonl.gz"
    target_manifest = load_json(rev / "corner/frobenius_sweep/symplectic_target_manifest.json")
    require(digest_file(target_path) == target_manifest["sha256"], "Symplectic input digest mismatch")
    target_stream = JsonlStream([target_path])
    targets = {}
    while target_stream.current is not None:
        row, raw = target_stream.take()
        targets[row["state"]] = (row, raw)
    require(len(targets) == target_manifest["records"] == 1492, "Wrong pre-aligned target count")
    require(target_stream.report()["uncompressed_sha256"] == target_manifest["uncompressed_sha256"],
            "Symplectic uncompressed digest mismatch")
    aligned_meta, aligned_audit = aligned_certificate_metadata(rev)
    additional_meta, additional_record = additional_certificate_metadata(args.additional_evidence.resolve())
    stats = {name: Stats() for name in ("base", "after_corner", "after_frobenius", "restored_final", "final")}
    terminal = Counter()
    found_aligned = {}
    found_symplectic = set()
    with ExitStack() as stack:
        id_export = Export(output, "remaining600558_state_ids.jsonl.gz", stack)
        full_export = Export(output, "remaining600558_full_records.jsonl.gz", stack)
        sym_export = Export(output, "symplectic_target_records.jsonl.gz", stack)
        excluded_export = Export(output, "aligned_excluded_four_records.jsonl.gz", stack)
        text_path = output / "remaining600558_state_ids.txt.tmp"
        text_ids = stack.enter_context(text_path.open("wb"))
        while normalized.current is not None:
            n, nraw = normalized.take()
            state = n["state"]
            require(n["open_index"] == stats["base"].kinds.total(), "Normalized OPEN ordinal mismatch")
            old, _ = original.take()
            same_identity(n, old)
            require(len(n["profile"]) == 13 and sum(n["profile"]) == 5399,
                    "Canonical profile normalization mismatch")
            require(n["profile"].count(n["double_degree"]) >= 2, "Invalid doubled placement")
            stats["base"].add(n)
            ce, cr = corner_excluded.matches(state), corner_remaining.matches(state)
            require(ce != cr, "Corner excluded/remainder partition is not disjoint and complete")
            if ce:
                cert, _ = corner_excluded.take()
                same_identity(n, cert)
                require(hashlib.sha256(nraw).hexdigest() == cert["normalized_input_sha256"],
                        "Corner certificate binds a different normalized record")
                require(not frob_excluded.matches(state) and not frob_remaining.matches(state),
                        "Corner exclusion overlaps a later-stage input")
                terminal["corner_screen"] += 1
                continue
            record, _ = corner_remaining.take()
            same_identity(n, record)
            stats["after_corner"].add(n)
            fe, fr = frob_excluded.matches(state), frob_remaining.matches(state)
            require(fe != fr, "Frobenius excluded/remainder partition is not disjoint and complete")
            if fe:
                cert, _ = frob_excluded.take()
                same_identity(n, cert)
                require(hashlib.sha256(nraw).hexdigest() == cert["normalized_input_sha256"],
                        "Frobenius certificate binds a different normalized record")
                require(cert["stage"] in ("Frobenius_cycle_matching", "singleton_Brauer_descent"),
                        "Unrecognized Frobenius terminal stage")
                terminal[cert["stage"]] += 1
                continue
            record, rraw = frob_remaining.take()
            same_identity(n, record)
            stats["after_frobenius"].add(n)
            if n["kind"] == "symplectic":
                require(state in targets, "Final symplectic state absent from target catalogue")
                target, traw = targets[state]
                for key in target:
                    if key != "scope_index":
                        require(n.get(key) == target[key], "Target/normalized record mismatch: " + str(key))
                found_symplectic.add(state)
            if state in ALIGNED_EXCLUSIONS:
                require(n["kind"] == "symplectic", "Aligned exclusion has wrong involution")
                found_aligned[state] = {"state": state, "kind": n["kind"], "index": n["index"],
                                        "double_degree": n["double_degree"],
                                        "matrix_codegree": 5400 // n["double_degree"],
                                        "assignment_index": n["assignment_index"],
                                        "record_sha256": hashlib.sha256(nraw).hexdigest(),
                                        "profile": n["profile"]}
                excluded_export.write(nraw)
                terminal["complete_aligned_row_exclusion"] += 1
                continue
            stats["restored_final"].add(n)
            if state == NEW_ALIGNED_EXCLUSION:
                require(n["kind"] == "symplectic", "Fourth aligned exclusion has wrong involution")
                for key in additional_record:
                    if key != "scope_index":
                        require(n.get(key) == additional_record[key], "Fourth audited record identity mismatch")
                found_aligned[state] = {"state": state, "kind": n["kind"], "index": n["index"],
                                        "double_degree": n["double_degree"],
                                        "matrix_codegree": 5400 // n["double_degree"],
                                        "assignment_index": n["assignment_index"],
                                        "record_sha256": hashlib.sha256(nraw).hexdigest(),
                                        "profile": n["profile"]}
                excluded_export.write(nraw)
                terminal["additional_independently_audited_aligned_exclusion"] += 1
                continue
            stats["final"].add(n)
            id_export.write(rraw)
            full_export.write(nraw)
            text_ids.write(f"{state}\n".encode("ascii"))
            if n["kind"] == "symplectic":
                sym_export.write(targets[state][1])
        require(set(found_aligned) == set(ALIGNED_EXCLUSIONS) | {NEW_ALIGNED_EXCLUSION},
                "One or more aligned exclusions absent from Frobenius remainder")
        require(found_symplectic == set(targets), "Symplectic target catalogue is not exact")
        for stream in streams.values():
            require(stream.current is None, "An input stream has unaccounted records")
    exports = {e.name: e.finish() for e in (id_export, full_export, sym_export, excluded_export)}
    text_final = output / "remaining600558_state_ids.txt"
    text_path.replace(text_final)
    exports[text_final.name] = {"file": text_final.name, "records": stats["final"].kinds.total(),
                                "bytes": text_final.stat().st_size, "sha256": digest_file(text_final)}
    stream_reports = {k: v.report() for k, v in streams.items()}
    require(stream_reports["normalized_OPEN"]["uncompressed_sha256"] ==
            normalized_manifest["normalized_uncompressed_sha256"], "Normalized aggregate digest mismatch")
    require(stream_reports["original_OPEN"]["uncompressed_sha256"] ==
            normalized_manifest["original_uncompressed_sha256"]["OPEN"], "Original OPEN digest mismatch")
    corner_summary = load_json(rev / "corner/full_sweep/summary.json")
    frob_summary = load_json(rev / "corner/frobenius_sweep/summary.json")
    for prefix, summary in (("corner", corner_summary), ("frobenius", frob_summary)):
        for kind in ("excluded", "remaining"):
            require(stream_reports[prefix + "_" + kind]["uncompressed_sha256"] ==
                    summary[kind + "_uncompressed_sha256"], "Recorded stream digest mismatch")
    stages = {k: v.report() for k, v in stats.items()}
    require([stages[k]["records"] for k in ("base", "after_corner", "after_frobenius", "restored_final", "final")] ==
            [976867, 611949, 600562, 600559, 600558], "Unexpected exact stage cardinalities")
    require(stages["final"]["counts_by_kind"] == {"orthogonal": 599070, "symplectic": 1488},
            "Unexpected final involution counts")
    require(stages["after_corner"]["canonical_profiles"] == corner_summary["remaining_canonical_profiles"] and
            stages["after_corner"]["matrix_placements"] == corner_summary["remaining_matrix_placements"],
            "Corner profile/placement counts differ")
    require(stages["after_frobenius"]["canonical_profiles"] == frob_summary["remaining_canonical_profiles"] and
            stages["after_frobenius"]["matrix_placements"] == frob_summary["remaining_matrix_placements"],
            "Frobenius profile/placement counts differ")
    sym_counts = [x for x in stages["final"]["counts_by_matrix_formal_codegree_and_kind"]
                  if x["kind"] == "symplectic"]
    sym_manifest = {
        "status": "PASS_EXACT_FINAL_SYMPLECTIC_TARGET_CATALOGUE", "records": 1488,
        "scope": "After the corner, Frobenius/Brauer, three restored aligned-row exclusions, and one additional independently audited aligned-row exclusion.",
        "original_record_schema_preserved": True,
        "excluded_reference_states": list(ALIGNED_EXCLUSIONS) + [NEW_ALIGNED_EXCLUSION],
        "graph_exclusions_applied": 4,
        "counts_by_matrix_formal_codegree": [{"f": x["f"], "states": x["states"]} for x in sym_counts],
        **exports[sym_export.name],
        "input_target_manifest_sha256": digest_file(rev / "corner/frobenius_sweep/symplectic_target_manifest.json"),
        "validator_sha256": digest_file(Path(__file__)),
    }
    sym_ids = hashlib.sha256()
    for state in sorted(set(targets) - set(ALIGNED_EXCLUSIONS) - {NEW_ALIGNED_EXCLUSION}):
        sym_ids.update(f"{state}\n".encode("ascii"))
    sym_manifest["state_ids_sha256"] = sym_ids.hexdigest()
    write_json(output / "symplectic_target_manifest.json", sym_manifest)
    report = {
        "status": "PASS_INDEPENDENT_FINAL_R36_UNION_ACCOUNTING",
        "scope": "Exact identity/coverage/union verification; mathematical certificate calculations are separately audited.",
        "base_integrity": base_integrity,
        "stages": stages, "terminal_disjoint_exclusions": dict(sorted(terminal.items())),
        "incremental_excluded_states": stages["base"]["records"] - stages["final"]["records"],
        "aligned_exclusions_membership": [found_aligned[s] for s in (*ALIGNED_EXCLUSIONS, NEW_ALIGNED_EXCLUSION)],
        "aligned_exclusions_certificate_metadata": aligned_meta, "complete_row_pool_audit": aligned_audit,
        "additional_independent_exclusion": additional_meta,
        "stream_digests": stream_reports, "exports": exports,
        "normalization_manifest_sha256": digest_file(normalized_dir / "manifest.json"),
        "corner_summary_sha256": digest_file(rev / "corner/full_sweep/summary.json"),
        "frobenius_summary_sha256": digest_file(rev / "corner/frobenius_sweep/summary.json"),
        "validator_sha256": digest_file(Path(__file__)),
        "original_frozen_payloads_modified": False,
        "seconds": round(time.monotonic() - started, 3),
    }
    write_json(output / "final_accounting_report.json", report)
    print(json.dumps({"status": report["status"], "final": stages["final"],
                      "incremental_excluded_states": report["incremental_excluded_states"],
                      "output": str(output)}, sort_keys=True, indent=2), flush=True)


if __name__ == "__main__":
    main()
