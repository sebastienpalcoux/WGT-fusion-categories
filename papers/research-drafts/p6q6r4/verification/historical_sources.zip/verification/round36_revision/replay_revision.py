#!/usr/bin/env python3
"""Fresh portable verification of the completed Round 36 revision.

Replays complete input normalization, the corner and Frobenius negative
certificates, the independent short F=60 proof, all four complete aligned
row-pool/fixed-space exclusions, and exact final-union accounting.  Original
Round 36 payloads are authenticated through an explicit historical mapping.

All generated work is written under --output, outside frozen directories.
The full 600,558-record remainder is reconstructed there; its published
digest is checked even when this redundant large stream is omitted from the
frozen package. Exact Python verification is not proof-assistant checking.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def run(script, log_path, *arguments):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env.pop("PYTHONOPTIMIZE", None)
    for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
        env[name] = "1"
    started = time.monotonic()
    print("RUN", script.name, flush=True)
    with log_path.open("w", encoding="utf-8") as log:
        subprocess.run([sys.executable, "-B", "-S", str(script), *map(str, arguments)],
                       cwd=script.parent, env=env, stdout=log,
                       stderr=subprocess.STDOUT, check=True)
    elapsed = time.monotonic() - started
    print("PASS", script.name, f"({elapsed:.2f}s)", flush=True)
    return elapsed


def verify_text_bindings(revision):
    bindings = []
    corner = revision / "corner"
    for name in ("corner_mathematical_review.json", "frobenius_corner_mathematical_review.json"):
        record = read(corner / name)
        require(record["status"] == "PASS", "Mathematical text review is not PASS")
        require(sha(corner / record["proof_file"]) == record["proof_sha256"],
                "Text review binds a different proof fragment")
        for dependency, expected in record.get("dependency_sha256", {}).items():
            require(sha(corner / dependency) == expected, "Text review dependency changed")
        bindings.append({"review": name, "review_sha256": sha(corner / name),
                         "proof": record["proof_file"], "proof_sha256": record["proof_sha256"]})
    return {"status": "PASS_SOURCE_BINDINGS", "bindings": bindings,
            "scope": "Recorded mathematical reviews bound to exact proof text, not formal proof checking."}


def compare_final_accounting(fresh, frozen, accounting):
    """Compare exact payloads; valid zlib versions may encode gzip differently."""
    require(fresh["status"] == "PASS_INDEPENDENT_FINAL_R36_UNION_ACCOUNTING", "Final union audit failed")
    for key in ("stages", "terminal_disjoint_exclusions", "incremental_excluded_states",
                "aligned_exclusions_membership", "stream_digests"):
        require(fresh[key] == frozen[key], "Regenerated final union differs: " + key)
    require(set(fresh["exports"]) == set(frozen["exports"]), "Final export scope differs")
    encoding_matches = {}
    for name, expected in frozen["exports"].items():
        actual = fresh["exports"][name]
        require(actual["records"] == expected["records"], "Regenerated export count differs: " + name)
        if "uncompressed_sha256" in expected:
            require(actual["uncompressed_sha256"] == expected["uncompressed_sha256"],
                    "Regenerated uncompressed payload differs: " + name)
            encoding_matches[name] = (actual["sha256"] == expected["sha256"] and
                                      actual["bytes"] == expected["bytes"])
        else:
            require(actual["sha256"] == expected["sha256"] and actual["bytes"] == expected["bytes"],
                    "Regenerated uncompressed file differs: " + name)
        retained = accounting / name
        if retained.exists():
            require(sha(retained) == expected["sha256"], "Frozen compact final export differs: " + name)
    return {"status": "PASS_EXACT_REGENERATED_PAYLOAD_HASHES",
            "hash_scope": "LF-terminated exact uncompressed bytes; frozen gzip containers separately authenticated",
            "compressed_bytes_identical_to_published": encoding_matches}


def main():
    require(__debug__, "Do not use python -O or PYTHONOPTIMIZE")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=HERE.parents[1], help="Complete revised release root")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    revision = root / "verification/round36_revision"
    original_matrix = root / "verification/round36/one_matrix16"
    require(output != root, "Output cannot be the release root")
    for frozen in (root / "verification", root / "provenance", root / "integration"):
        require(output != frozen and frozen not in output.parents,
                "Output must be outside frozen payload directories")
    output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    results = {"mathematical_review_bindings": verify_text_bindings(revision)}
    runtime = output / "runtime"
    if runtime.exists():
        require(not runtime.is_symlink(), "Replay runtime must not be a symlink")
        shutil.rmtree(runtime)
    corner_runtime = runtime / "corner"
    corner_runtime.mkdir(parents=True)
    for name in ("audit_normalization.py", "audit_corner_sweep.py", "audit_frobenius_sweep.py",
                 "corner_gate.py", "corner_extension.py"):
        shutil.copy2(revision / "corner" / name, corner_runtime / name)
    corner = revision / "corner"
    timing = {}

    timing["normalization"] = run(corner_runtime / "audit_normalization.py", output / "normalization.log",
                                  "--inputs", corner / "normalized_open", "--base", original_matrix,
                                  "--output", output / "normalization.json")
    normalization = read(output / "normalization.json")
    require(normalization["status"] == "PASS_INDEPENDENT_EXACT_R36_OPEN_NORMALIZATION",
            "Original-to-normalized equality failed")
    results["normalization"] = {"status": normalization["status"],
                                "normalized_records": normalization["normalized_records"],
                                "original_states": normalization["original_states"],
                                "original_placements": normalization["original_placements"]}

    timing["corner"] = run(corner_runtime / "audit_corner_sweep.py", output / "corner.log",
                            "--inputs", corner / "normalized_open", "--sweep", corner / "full_sweep",
                            "--base", original_matrix,
                            "--output", corner_runtime / "independent_full_audit.json")
    local = read(corner_runtime / "independent_full_audit.json")
    require(local["status"] == "PASS_INDEPENDENT_COMPLETE_CORNER_REPLAY", "Complete corner audit failed")
    shutil.copy2(corner_runtime / "independent_full_audit.json", output / "corner.json")
    results["corner"] = {"status": local["status"], "report_sha256": sha(output / "corner.json")}

    timing["frobenius"] = run(corner_runtime / "audit_frobenius_sweep.py", output / "frobenius.log",
                               "--inputs", corner / "normalized_open", "--baseline", corner / "full_sweep",
                               "--sweep", corner / "frobenius_sweep", "--output", output / "frobenius.json")
    frobenius = read(output / "frobenius.json")
    require(frobenius["status"] == "PASS_INDEPENDENT_COMPLETE_FROBENIUS_CORNER_REPLAY",
            "Complete Frobenius audit failed")
    results["frobenius"] = {"status": frobenius["status"], "records": frobenius["records"],
                            "statuses": frobenius["statuses"],
                            "terminal_incremental_stages": frobenius["terminal_incremental_stages"]}

    short = runtime / "short_codegree60"
    short.mkdir()
    shutil.copy2(revision / "target_836343/verify_fixed_projection.py", short / "verify_fixed_projection.py")
    timing["short_codegree60"] = run(short / "verify_fixed_projection.py", output / "short_codegree60.log")
    short_report = read(short / "fixed_projection_audit.json")
    require(short_report["status"] == "PASS_INDEPENDENT_FIXED_PROJECTION_EXCLUSION",
            "Independent codegree-sixty short proof failed")
    shutil.copy2(short / "fixed_projection_audit.json", output / "short_codegree60.json")
    results["short_codegree60"] = {"status": short_report["status"],
                                    "report_sha256": sha(output / "short_codegree60.json")}

    four_script = revision / "proof_audit/audit_four_aligned_targets.py"
    timing["four_aligned_targets"] = run(four_script, output / "four_aligned_targets.log",
                                          "--root", revision, "--output", output / "four_aligned_targets")
    four = read(output / "four_aligned_targets/four_aligned_targets_audit.json")
    require(four["status"] == "PASS_FOUR_COMPLETE_ALIGNED_TARGET_EXCLUSIONS",
            "Four complete independent aligned-target audits failed")
    require({x["state"] for x in four["states"]} == {47412, 461210, 836343, 1284815},
            "Aligned-target audit scope differs")
    results["four_aligned_targets"] = {"status": four["status"], "states": four["states"]}

    accounting = revision / "accounting"
    timing["accounting"] = run(accounting / "validate_final_accounting.py", output / "accounting.log",
                                "--base", root, "--base-map", accounting / "initial_round36_payload_mapping.json",
                                "--revision", revision, "--output", output / "accounting")
    fresh = read(output / "accounting/final_accounting_report.json")
    frozen = read(accounting / "final_accounting_report.json")
    export_comparison = compare_final_accounting(fresh, frozen, accounting)
    final_catalogue = read(output / "accounting/symplectic_target_manifest.json")
    frozen_catalogue = read(accounting / "symplectic_target_manifest.json")
    for key in ("records", "excluded_reference_states", "graph_exclusions_applied",
                "counts_by_matrix_formal_codegree", "uncompressed_sha256", "state_ids_sha256"):
        require(final_catalogue[key] == frozen_catalogue[key], "Final target catalogue differs: " + key)
    results["original_round36_integrity"] = fresh["base_integrity"]
    results["final_accounting"] = {"status": fresh["status"],
                                    "stages": fresh["stages"],
                                    "incremental_excluded_states": fresh["incremental_excluded_states"],
                                    "regenerated_export_hashes_match": True,
                                    "export_comparison": export_comparison,
                                    "final_symplectic_targets": final_catalogue["records"],
                                    "final_symplectic_state_ids_sha256": final_catalogue["state_ids_sha256"]}
    results.update(status="PASS_COMPLETE_ROUND36_REVISION_REPLAY", stage_seconds=timing,
                   seconds=time.monotonic() - started, frozen_payloads_modified=False,
                   formal_proof_assistant_verification=False,
                   source_sha256={"replay_revision.py": sha(Path(__file__)),
                                  "validate_final_accounting.py": sha(accounting / "validate_final_accounting.py"),
                                  "audit_four_aligned_targets.py": sha(four_script)})
    write(output / "revision_replay_summary.json", results)
    print(json.dumps({"status": results["status"], "stage_seconds": timing,
                      "final_states": fresh["stages"]["final"]["records"],
                      "final_symplectic_targets": final_catalogue["records"],
                      "seconds": results["seconds"]}, sort_keys=True, indent=2), flush=True)


if __name__ == "__main__":
    main()
