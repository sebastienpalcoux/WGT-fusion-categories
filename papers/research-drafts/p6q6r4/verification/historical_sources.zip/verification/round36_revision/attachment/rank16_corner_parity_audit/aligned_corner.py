"""Local corner test on a supplied aligned linear-character table.
Residue columns must already be normalized over ONE common residue field.
Hashable tuples may represent elements of F_(p^d). The characteristic-zero
linear fields must all embed into the chosen finite unramified extension.
"""
from collections import defaultdict
from base import val

def allowed_rank_totals(codegrees,F,residue_columns,N,p,division_after_base_change=False):
 assert len(codegrees)==len(residue_columns)
 assert all(N%f==0 for f in codegrees) and N%F==0
 assert len({len(c) for c in residue_columns})<=1
 groups=defaultdict(list)
 for i,c in enumerate(residue_columns):groups[tuple(c)].append(i)
 M=p**val(N,p)[0];a=N//F;t=val(F,p)[0]
 ranks=(0,2) if division_after_base_change else(0,1,2)
 possible={0}
 for S in groups.values():
  v=[val(codegrees[i],p)[0] for i in S]
  if len(S)>1 and 0 in v:return []
  if any((codegrees[i]+codegrees[j])%(p*p) for ii,i in enumerate(S) for j in S[ii+1:]):return []
  if len(S)>=3 and any(x<2 for x in v):return []
  A=sum(N//codegrees[i] for i in S)
  permitted=[k for k in ranks if(A+k*a)%M==0 and(sum(v)+k*t)%2==0]
  possible={s+k for s in possible for k in permitted if s+k<=2}
  if not possible:return []
 return sorted(s for s in possible if(2-s)%(p**t)==0 and((2-s)*t)%2==0 and(not division_after_base_change or 2-s in(0,2)))

if __name__=='__main__':
 # Rational group algebra S3: two linears of f=6 and one degree-two of F=3.
 cols=[(1,1,1,1,1,1),(1,-1,-1,-1,1,1)]
 for p in(2,3,5):
  normalized=[tuple(x%p for x in c) for c in cols]
  assert allowed_rank_totals([6,6],3,normalized,6,p)
 normalized=[tuple(x%3 for x in c) for c in cols]
 assert allowed_rank_totals([6,6],3,normalized,6,3)==[2]
 assert allowed_rank_totals([6,6],3,normalized,6,3,True)==[]
 print('Aligned S3 corner and post-base-change division checks passed')
