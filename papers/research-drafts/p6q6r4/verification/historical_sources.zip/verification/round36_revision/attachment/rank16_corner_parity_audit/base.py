from functools import lru_cache
from collections import Counter
N=5400
PALT=tuple(a for a in range(10,901) if N%a==0 and sum(a%p==0 for p in (2,3,5))>=2)
def profiles(total=5399,slots=13,cap=len(PALT)-1):
 if slots==0:
  if total==0:yield ()
  return
 for i in range(cap,-1,-1):
  a=PALT[i]
  if slots*a<total:break
  if total-a<(slots-1)*PALT[0]:continue
  for tail in profiles(total-a,slots-1,i):yield (a,)+tail
@lru_cache(None)
def val(n,p):
 e=0
 while n%p==0:n//=p;e+=1
 return e,n
@lru_cache(None)
def data(a,p):
 f=N//a;e=val(f,p)[0]
 return e,(f//p)%p if e==1 else 0

def counts(a,p):return Counter(u for x in a if (e_u:=data(x,p))[0]==1 for u in (e_u[1],))
def balanced(c,p):return not(c[1]%2) if p==2 else all(c[s]==c[-s%p] for s in range(1,p))
def original(c,F,p):
 t=val(F,p)[0];U=c[1]%2 if p==2 else sum(abs(c[s]-c[p-s]) for s in range(1,(p+1)//2))
 return U<=(0 if t==0 else 4 if t==1 else 2)
def sharp(c,F,p):
 if balanced(c,p):return True
 t=val(F,p)[0];options=[]
 for k in (1,2):
  vk=val(k,p)[0]
  if t!=1+vk:continue
  ku=k//p**vk;v=F//p**t
  for u,n in c.items():
   if n and (v+ku*u)%p==0:options.append((u,k))
 for u,k in options:
  cc=c.copy();cc[u]-=1
  if balanced(cc,p):return True
  if k==1:
   for v,l in options:
    if l!=1 or not cc[v]:continue
    dd=cc.copy();dd[v]-=1
    if balanced(dd,p):return True
 return False

def corner_resource(c,F,p):
 if balanced(c,p):return True
 if val(F,p)[0]!=1:return False
 u=(-(F//p))%p
 for take in (1,2):
  if c[u]<take:continue
  cc=c.copy();cc[u]-=take
  if balanced(cc,p):return True
 return False
