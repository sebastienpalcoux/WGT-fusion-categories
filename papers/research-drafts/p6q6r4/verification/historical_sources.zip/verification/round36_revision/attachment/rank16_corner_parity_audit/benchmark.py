from base import *
from cheap_gates import all_cheap
import json,time
start=time.monotonic();C=Counter();per={s:Counter() for s in('old','sharp','corner')};surv=[];extra=[]
for profile in profiles():
 C['profiles']+=1
 for a,k in Counter(profile).items():
  if k<2:continue
  linear=list(profile);linear.remove(a);linear.remove(a);linear=(1,)+tuple(linear);F=N//a;C['raw']+=1
  pp={s:[] for s in per}
  for p in (2,3,5):
   c=counts(linear,p)
   for name,fun in (('old',original),('sharp',sharp),('corner',corner_resource)):
    v=fun(c,F,p);pp[name].append(v);per[name][p]+=v
  o,s,t=map(lambda k:all(pp[k]),('old','sharp','corner'))
  assert not t or s;assert not s or o
  C['old']+=o;C['sharp']+=s;C['corner']+=t
  if s:
   cheap=all_cheap(linear,a)
   C['sharp_no10']+=a!=10 and 10 not in linear
   C['corner_no10']+=t and a!=10 and 10 not in linear
   C['sharp_plus_cheap']+=cheap;C['corner_plus_cheap']+=t and cheap
   if not t:extra.append([a,*linear])
  if t:surv.append([a,*linear])
assert(C['raw'],C['old'],C['sharp'],C['sharp_plus_cheap'])==(1224166,185252,52876,12544)
print(json.dumps(dict(counts=dict(C),per_prime_survival={s:dict(v) for s,v in per.items()},seconds=time.monotonic()-start),indent=2))
json.dump(surv,open('combined_survivors.json','w'));json.dump(extra,open('new_corner_exclusions.json','w'))
