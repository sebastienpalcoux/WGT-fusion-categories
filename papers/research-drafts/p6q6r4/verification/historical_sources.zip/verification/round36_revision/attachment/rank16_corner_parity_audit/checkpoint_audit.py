"""Reproduce the weaker checkpoint class-integrality/parity screen exactly.
Pairs here are NOT additionally required to satisfy pair-column orthogonality.
All groups containing no valuation-one linear are left unconstrained.
"""
from base import *
from functools import lru_cache
import json,time

@lru_cache(None)
def allowed_signature(aM,t,M,items):
 # items=(canonical degree mod M, valuation parity, valuation-one flag).
 # The state keeps labelled resources, even when signatures repeat.
 v1=sum((1<<i) for i,x in enumerate(items) if x[2])
 @lru_cache(None)
 def rec(mask,budget):
  V=mask&v1
  if not V:return True
  i=(V&-V).bit_length()-1;rest=mask^(1<<i);ai,vi,_=items[i]
  for k in range(budget+1):
   if (ai+k*aM)%M==0 and (vi+k*t)%2==0 and rec(rest,budget-k):return True
   for j in range(len(items)):
    if rest>>j&1:
     aj,vj,_=items[j]
     if (ai+aj+k*aM)%M==0 and (vi+vj+k*t)%2==0 and rec(rest^(1<<j),budget-k):return True
  return False
 return rec((1<<len(items))-1,2)

def checkpoint(linear,a,p):
 M=p**val(N,p)[0];t=val(N//a,p)[0]
 items=tuple(sorted((x%M,val(N//x,p)[0]%2,val(N//x,p)[0]==1) for x in linear))
 return allowed_signature(a%M,t%2,M,items)

start=time.monotonic();C=Counter();rej=Counter();oldper=Counter();examples=[]
for a in PALT:
 F=N//a
 for lin in profiles(total=5399-2*a,slots=11):
  linear=(1,)+lin
  if not all(original(counts(linear,p),F,p) for p in(2,3,5)):continue
  C['old']+=1
  cp=[checkpoint(linear,a,p) for p in(2,3,5)]
  sh=all(sharp(counts(linear,p),F,p) for p in(2,3,5))
  cr=all(corner_resource(counts(linear,p),F,p) for p in(2,3,5))
  for p,b in zip((2,3,5),cp):rej[p]+=not b
  q=all(cp);C['checkpoint']+=q;C['stronger']+=sh;C['combined']+=cr
  C['checkpoint_and_stronger']+=q and sh
  C['checkpoint_pass_stronger_fail']+=q and not sh
  C['stronger_pass_checkpoint_fail']+=sh and not q
  assert not cr or(q and sh)
print(json.dumps(dict(counts=dict(C),per_prime_rejections_within_old=dict(rej),cache=allowed_signature.cache_info()._asdict(),seconds=time.monotonic()-start),indent=2))
