from base import N,val
from math import gcd
from itertools import combinations
P=(2,3,5)
def determinant(linear):return all(sum(val(N//a,p)[0] for a in linear)%2==0 for p in P)
def residue(linear,a):
 constituents=[(x,1) for x in linear[1:]]+[(a,2)]
 for i,(d,m) in enumerate(constituents):
  g=gcd(*(nn*dd for j,(dd,nn) in enumerate(constituents) if j!=i));r=d-m;c=gcd(m*d,g)
  if r%c:return False
  mod=g//c
  root=((-r//c)*pow((m*d)//c,-1,mod))%mod if mod>1 else 0
  if min(root,mod-root)>=r:return False
 return True

def twochar(linear,a):
 for i,j in combinations(range(1,len(linear)),2):
  M=gcd(N,a,*(x for k,x in enumerate(linear) if k not in(0,i,j)))
  if M==1:continue
  for ai,aj in((linear[i],linear[j]),(linear[j],linear[i])):
   Q=1
   for p in P:
    k=val(M,p)[0];alpha=val(ai,p)[0];beta=val(aj,p)[0]
    Q*=p**min(k,beta+(max(0,k-alpha-beta)+1)//2)
   if Q>=2*(ai-1):return False
 return True

def all_cheap(linear,a):return a!=10 and 10 not in linear and determinant(linear) and residue(linear,a) and twochar(linear,a)
