#!/usr/bin/env python3
"""Apply the exact gate to every authenticated completed Round 36 OPEN state."""
from collections import Counter
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import resource
import time
from corner_gate import corner_gate, RULE_VERSION

HERE=Path(__file__).resolve().parent


def canonical(obj):
    return (json.dumps(obj,sort_keys=True,separators=(",",":"))+"\n").encode()


def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--inputs",type=Path,default=HERE/"normalized_open")
    ap.add_argument("--output",type=Path,default=HERE/"full_sweep")
    args=ap.parse_args()
    inputs=args.inputs.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((inputs/"manifest.json").read_text())
    assert manifest["status"]=="PASS_COMPLETE_AUTHENTICATED_R36_OPEN_NORMALIZATION"
    assert manifest["records"]==976867
    proof=sha(HERE/"corner_gate.py")
    assert proof==manifest["gate_sha256"]
    start=time.monotonic();counts=Counter();prime_counts=Counter();by_kind=Counter()
    by_f=Counter();remaining_profiles=set();remaining_placements=set()
    rational_placements=set();rational_excluded_placements=set();all_h=hashlib.sha256()
    excluded_h=hashlib.sha256();remaining_h=hashlib.sha256();ordinal=0;previous_state=-1
    split_only_counts=Counter();context_extra=Counter();field_kind=Counter();examples=[]
    def stream(name):
        raw=(out/name).open("wb")
        return raw,gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0)
    eraw,eout=stream("incremental_exclusions.jsonl.gz")
    rraw,rout=stream("remaining_open_ids.jsonl.gz")
    for chunk in manifest["chunks"]:
        path=inputs/chunk["file"];assert sha(path)==chunk["sha256"]
        ch=hashlib.sha256();n=0
        assert chunk["start"]==ordinal
        with gzip.open(path,"rb") as f:
            for line in f:
                ch.update(line);all_h.update(line);n+=1
                rec=json.loads(line)
                assert rec["open_index"]==ordinal and rec["state"]>previous_state
                previous_state=rec["state"];ordinal+=1
                result=corner_gate(rec)
                relaxation=dict(rec,matrix_ramification_classes=[[]])
                split_result=corner_gate(relaxation)
                assert split_result["status"]!="EXCLUDED" or result["status"]=="EXCLUDED"
                counts[result["status"]]+=1;split_only_counts[split_result["status"]]+=1
                fmatrix=5400//rec["double_degree"]
                by_kind[(rec["kind"],result["status"])]+=1
                by_f[(fmatrix,rec["kind"],result["status"])]+=1
                all_rational=all(label=="Q" for block in rec["assignment"]["fields"]
                                 for label in block["fields"])
                fk="all_rational" if all_rational else "mixed_fields"
                field_kind[(fk,result["status"])]+=1
                if all_rational:rational_placements.add((rec["index"],rec["double_degree"]))
                for p in result["eligible_primes"]:prime_counts[p]+=1
                if result["status"]=="EXCLUDED":
                    excluded=dict(state=rec["state"],open_index=rec["open_index"],
                                  index=rec["index"],double_degree=rec["double_degree"],
                                  assignment_index=rec["assignment_index"],kind=rec["kind"],
                                  normalized_input_sha256=hashlib.sha256(line).hexdigest(),
                                  gate_sha256=proof,eligible_primes=result["eligible_primes"],
                                  certificate=result["witness"],
                                  division_refinement_needed=(split_result["status"]!="EXCLUDED"))
                    data=canonical(excluded);eout.write(data);excluded_h.update(data)
                    if len(examples)<5:examples.append(excluded)
                    if all_rational:rational_excluded_placements.add((rec["index"],rec["double_degree"]))
                    if excluded["division_refinement_needed"]:
                        context_extra[(fmatrix,rec["kind"])]+=1
                else:
                    data=canonical(dict(state=rec["state"],open_index=rec["open_index"],
                                        index=rec["index"],double_degree=rec["double_degree"],
                                        assignment_index=rec["assignment_index"],kind=rec["kind"]))
                    rout.write(data);remaining_h.update(data)
                    remaining_profiles.add(rec["index"])
                    remaining_placements.add((rec["index"],rec["double_degree"]))
                if rec["state"]==836343:
                    (out/"state_836343_result.json").write_text(json.dumps(
                        dict(input=rec,result=result),indent=2)+"\n")
        assert n==chunk["records"] and ordinal==chunk["stop"]
        assert ch.hexdigest()==chunk["uncompressed_sha256"]
        print("screened",ordinal,"counts",dict(counts),"seconds",
              round(time.monotonic()-start,2),flush=True)
    eout.close();eraw.close();rout.close();rraw.close()
    assert ordinal==manifest["records"] and all_h.hexdigest()==manifest["normalized_uncompressed_sha256"]
    assert proof==sha(HERE/"corner_gate.py")
    report=dict(status="PASS_COMPLETE_INCREMENTAL_CORNER_SWEEP",rule_version=RULE_VERSION,
                input_states=ordinal,incremental_exclusions=counts["EXCLUDED"],
                remaining_states=ordinal-counts["EXCLUDED"],statuses=dict(counts),
                split_relaxation_statuses=dict(split_only_counts),
                additional_division_context_exclusions=sum(context_extra.values()),
                division_additional_by_codegree_kind=[dict(f=f,kind=k,states=n)
                    for(f,k),n in sorted(context_extra.items())],
                eligible_state_counts_by_prime=dict(sorted(prime_counts.items())),
                counts_by_kind_status=[dict(kind=k,status=s,states=n)
                    for(k,s),n in sorted(by_kind.items())],
                counts_by_codegree_kind_status=[dict(f=f,kind=k,status=s,states=n)
                    for(f,k,s),n in sorted(by_f.items())],
                counts_by_field_scope_status=[dict(field_scope=k,status=s,states=n)
                    for(k,s),n in sorted(field_kind.items())],
                all_rational_OPEN_placements=len(rational_placements),
                all_rational_incrementally_excluded_placements=len(rational_excluded_placements),
                remaining_canonical_profiles=len(remaining_profiles),
                remaining_matrix_placements=len(remaining_placements),
                input_manifest_sha256=sha(inputs/"manifest.json"),
                gate_sha256=proof,producer_sha256=sha(Path(__file__)),
                input_uncompressed_sha256=all_h.hexdigest(),
                excluded_uncompressed_sha256=excluded_h.hexdigest(),
                remaining_uncompressed_sha256=remaining_h.hexdigest(),
                excluded_gzip_sha256=sha(out/"incremental_exclusions.jsonl.gz"),
                remaining_gzip_sha256=sha(out/"remaining_open_ids.jsonl.gz"),
                examples=examples,seconds=time.monotonic()-start,
                maximum_resident_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    (out/"summary.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k not in
        ("examples","counts_by_codegree_kind_status")},indent=2),flush=True)


if __name__=="__main__":main()
