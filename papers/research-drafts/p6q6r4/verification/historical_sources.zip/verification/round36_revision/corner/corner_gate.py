"""Exact local corner-parity necessary gate for actual rank-sixteen inputs.

No character field is silently replaced by Q.  Every embedding of every
listed full field contributes a separate linear character.  A prime is
eligible only if all listed fields are unramified there.  Matrix ramification
alternatives in normalized inputs are independently derived from the frozen
Round 36 trace-form classifier; a raw input without those alternatives uses
the split relaxation, except for the proved orthogonal codegree-six case.

All arithmetic is in the Python standard library.  OPEN is a necessary-data
status, not a realization or a common aligned character table.
"""
from collections import Counter
from functools import lru_cache
from math import gcd, lcm
import re

DIMENSION = 5400
PRIMES = (2, 3, 5)
RULE_VERSION = "unramified-corner-parity-v1"


def valuation(n, p):
    if not isinstance(n, int) or isinstance(n, bool) or n <= 0:
        raise ValueError("Valuations require a positive integer.")
    e = 0
    while n % p == 0:
        n //= p
        e += 1
    return e


@lru_cache(maxsize=None)
def units(c):
    return tuple(a for a in range(c) if gcd(a, c) == 1)


@lru_cache(maxsize=None)
def field_descriptor(label):
    if label == "Q":
        return ("rational", 1, 1, ())
    if label == "Q(sqrt(-3))":
        return ("quadratic", 2, -3, ())
    m = re.fullmatch(r"quadratic_disc=(-?\d+)", label)
    if m:
        d = int(m.group(1))
        if d in (0, 1) or d % 4 not in (0, 1):
            raise ValueError("Invalid quadratic discriminant label.")
        squarefree = d if d % 4 == 1 else d // 4
        if d % 4 == 0 and squarefree % 4 not in (2, 3):
            raise ValueError("The quadratic discriminant is not fundamental.")
        n = abs(squarefree)
        q = 2
        while q * q <= n:
            if n % (q * q) == 0:
                raise ValueError("The quadratic discriminant is not fundamental.")
            q += 1
        return ("quadratic", 2, d, ())
    if label == "real_cubic_conductor9":
        return ("cyclotomic_fixed", 3, 9, (1, 8))
    m = re.fullmatch(r"zeta(\d+):H=(\d+(?:,\d+)*)", label)
    if not m:
        raise ValueError("Unsupported exact field label: " + repr(label))
    c = int(m.group(1))
    h = tuple(map(int, m.group(2).split(",")))
    if c < 3 or tuple(sorted(set(h))) != h or 1 not in h:
        raise ValueError("Invalid cyclotomic subgroup label.")
    g = set(units(c))
    hs = set(h)
    if not hs <= g or any(a * b % c not in hs for a in h for b in h):
        raise ValueError("The supplied H is not a subgroup of cyclotomic units.")
    if len(g) % len(h):
        raise ValueError("Invalid fixed-field degree.")
    return ("cyclotomic_fixed", len(g) // len(h), c, h)


def field_degree(label):
    return field_descriptor(label)[1]


@lru_cache(maxsize=None)
def _local_tuple(label, p):
    """Return (degree, ramification index, residue degree, conductor, inertia)."""
    kind, degree, parameter, h = field_descriptor(label)
    if kind == "rational":
        return (1, 1, 1, 1, ())
    if kind == "quadratic":
        d = parameter
        if d % p == 0:
            return (2, 2, 1, abs(d), ())
        if p == 2:
            if d % 8 not in (1, 5):
                raise ValueError("Odd quadratic discriminant has invalid 2-adic class.")
            f = 1 if d % 8 == 1 else 2
        else:
            f = 1 if pow(d % p, (p - 1) // 2, p) == 1 else 2
        return (2, 1, f, abs(d), ())
    c = parameter
    q = p ** valuation(c, p)
    m = c // q
    g = units(c)
    inertia = tuple(a for a in g if (a - 1) % m == 0)
    hs = set(h)
    intersection = sum(a in hs for a in inertia)
    e = len(inertia) // intersection
    # On the prime-to-p roots Frobenius is p; its p-power coordinate is
    # irrelevant modulo inertia.  Choose that coordinate equal to one.
    frob = next(a for a in g if (a - p) % m == 0 and (a - 1) % q == 0)
    hi = {a * b % c for a in h for b in inertia}
    power = frob
    f = 1
    while power not in hi:
        power = power * frob % c
        f += 1
        if f > degree:
            raise ArithmeticError("Frobenius order exceeds fixed-field degree.")
    if degree % (e * f):
        raise ArithmeticError("Local degrees do not divide global degree.")
    return (degree, e, f, c, inertia)


def field_local_data(label, p):
    if p not in PRIMES:
        raise ValueError("This task's nontrivial local primes are 2, 3 and 5.")
    degree, e, f, conductor, inertia = _local_tuple(label, p)
    return dict(label=label, prime=p, degree=degree, ramification_index=e,
                residue_degree=f, unramified=(e == 1),
                cyclotomic_conductor=conductor,
                ambient_inertia=list(inertia))


def linear_data(record):
    a = record["double_degree"]
    if not isinstance(a, int) or a <= 0 or DIMENSION % a:
        raise ValueError("Invalid doubled canonical degree.")
    codegrees = [DIMENSION]  # Perron linear character.
    labels = []
    for block in record["assignment"]["fields"]:
        f = block["formal_codegree"]
        if not isinstance(f, int) or f <= 0 or DIMENSION % f:
            raise ValueError("Invalid linear formal codegree.")
        for label in block["fields"]:
            labels.append(label)
            codegrees.extend([f] * field_degree(label))
    if len(codegrees) != 12:
        raise ValueError("The one-M2 rank-sixteen input needs twelve linears.")
    if sum(DIMENSION // f for f in codegrees) + 2 * a != DIMENSION:
        raise ValueError("The canonical dimension identity fails.")
    if "profile" in record:
        expanded = sorted([DIMENSION // f for f in codegrees[1:]] + [a, a],
                          reverse=True)
        if expanded != list(record["profile"]):
            raise ValueError("Full-field multiplicities disagree with the profile.")
    return tuple(codegrees), tuple(sorted(set(labels))), DIMENSION // a


def residue_counts(codegrees, p):
    return tuple(sum(valuation(f, p) == 1 and f // p % p == u
                     for f in codegrees) for u in range(1, p))


def balanced(counts, p):
    if p == 2:
        return counts[0] % 2 == 0
    return all(counts[u - 1] == counts[p - u - 1]
               for u in range(1, p))


def rank_one_deletions(counts, F, p, division=False):
    """All admissible aggregate singleton counts, with exact rank budget two."""
    t = valuation(F, p)
    allowed = []
    if balanced(counts, p):
        allowed.append(0)
    if t == 1 and not division:
        u = (-(F // p)) % p
        for k in (1, 2):
            if counts[u - 1] < k:
                continue
            remaining = list(counts)
            remaining[u - 1] -= k
            if balanced(remaining, p):
                allowed.append(k)
    return tuple(allowed)


def eligibility(record):
    codegrees, labels, F = linear_data(record)
    result = []
    for p in PRIMES:
        locals_ = tuple(_local_tuple(label, p) for label in labels)
        blocked = [label for label, data in zip(labels, locals_) if data[1] != 1]
        result.append(dict(prime=p, eligible=not blocked,
                           blocking_fields=blocked,
                           common_unramified_degree=(lcm(*(x[2] for x in locals_))
                                                      if not blocked else None)))
    return result


def _matrix_classes(record, F):
    provided = record.get("matrix_ramification_classes")
    if provided is not None:
        classes = tuple(tuple(c) for c in provided)
        if not classes or tuple(sorted(set(classes))) != classes:
            raise ValueError("Matrix alternatives must be nonempty, unique and sorted.")
        if any(tuple(sorted(set(c))) != c or any(p not in PRIMES for p in c)
               for c in classes):
            raise ValueError("Invalid matrix ramification alternatives.")
        return classes, "authenticated_R36_complete_trace_form_alternatives"
    if F == 6 and record.get("kind") == "orthogonal":
        return ((2, 3),), "R36_Theorem_9.245_orthogonal_codegree_six"
    return ((),), "split_relaxation_no_matrix_context_supplied"


def corner_gate(record):
    codegrees, labels, F = linear_data(record)
    local = eligibility(record)
    eligible = [r for r in local if r["eligible"]]
    classes, context_source = _matrix_classes(record, F)
    common = dict(rule_version=RULE_VERSION,
                  eligible_primes=[r["prime"] for r in eligible],
                  eligibility=local,
                  counters={"linear_embeddings":len(codegrees),
                            "full_field_labels":len(labels),
                            "matrix_alternatives":len(classes)},
                  matrix_context_source=context_source)
    if not eligible:
        return dict(common, status="NOT_APPLICABLE", witness=None)
    failures = []
    surviving = []
    for ram in classes:
        failed = None
        for item in eligible:
            p = item["prime"]
            h = item["common_unramified_degree"]
            division = p in ram and h % 2 == 1
            counts = residue_counts(codegrees, p)
            permitted = rank_one_deletions(counts, F, p, division)
            if not permitted:
                failed = dict(matrix_ramification=list(ram), prime=p,
                              common_unramified_degree=h,
                              division_after_base_change=division,
                              matrix_codegree=F,
                              matrix_codegree_valuation=valuation(F,p),
                              valuation_one_bins=list(counts),
                              singleton_residue=((-(F // p)) % p
                                                 if valuation(F,p)==1 else None),
                              admissible_singleton_counts=[])
                break
        if failed is None:
            surviving.append(list(ram))
        else:
            failures.append(failed)
    if surviving:
        return dict(common, status="OPEN", witness=None,
                    surviving_matrix_ramification_classes=surviving)
    return dict(common, status="EXCLUDED",
                witness=dict(kind="complete_matrix_context_corner_failure",
                             failures=failures, linear_codegrees=list(codegrees),
                             full_field_labels=list(labels)))

