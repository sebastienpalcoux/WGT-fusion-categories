#!/usr/bin/env python3
"""Independent exact audit: inertia orbits and labelled class/rank recursion.

The gate module is deliberately not imported.  This checker rebuilds local
field data by permutations of G/H, checks complete inherited matrix contexts,
and uses labelled singletons/pairs with trace and determinant conditions,
rather than the producer's residue-bin deletion rule.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
from math import gcd, lcm
import argparse
import gzip
import hashlib
import json
import re
import resource
import sys
import time

HERE=Path(__file__).resolve().parent
N=5400
PRIMES=(2,3,5)


def val(n,p):
    answer=0
    while n%p==0:n//=p;answer+=1
    return answer


def canonical(obj):
    return (json.dumps(obj,sort_keys=True,separators=(",",":"))+"\n").encode()


def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()


def symbol(discriminant,denominator):
    """Kronecker symbol by prime factorization of a positive denominator."""
    answer=1;q=2
    while q*q<=denominator:
        e=0
        while denominator%q==0:denominator//=q;e+=1
        if e%2:
            if q==2:
                assert discriminant%2
                answer*=1 if discriminant%8 in(1,7)else-1
            else:
                r=pow(discriminant%q,(q-1)//2,q)
                assert r in(1,q-1)
                answer*=1 if r==1 else-1
        q+=1
    if denominator>1:
        q=denominator
        if q==2:
            assert discriminant%2
            answer*=1 if discriminant%8 in(1,7)else-1
        else:
            r=pow(discriminant%q,(q-1)//2,q)
            assert r in(1,q-1)
            answer*=1 if r==1 else-1
    return answer


def cyclotomic_model(label):
    if label=="Q":return 1,(0,),(0,)
    if label=="Q(sqrt(-3))":d=-3
    elif label.startswith("quadratic_disc="):d=int(label.split("=",1)[1])
    else:d=None
    if d is not None:
        c=abs(d);g=tuple(a for a in range(c)if gcd(a,c)==1)
        h=tuple(a for a in g if symbol(d,a)==1)
        assert len(g)==2*len(h)
        return c,g,h
    if label=="real_cubic_conductor9":return 9,(1,2,4,5,7,8),(1,8)
    m=re.fullmatch(r"zeta(\d+):H=(\d+(?:,\d+)*)",label);assert m,label
    c=int(m.group(1));g=tuple(a for a in range(c)if gcd(a,c)==1)
    h=tuple(map(int,m.group(2).split(",")));assert 1 in h and set(h)<=set(g)
    assert all(a*b%c in h for a in h for b in h)
    return c,g,h


@lru_cache(None)
def local_orbit_data(label,p):
    c,g,h=cyclotomic_model(label)
    if c==1:return(1,1,1)
    cosets=sorted({tuple(sorted(a*b%c for b in h))for a in g})
    which={a:i for i,coset in enumerate(cosets)for a in coset}
    prime_power=1
    while c%(prime_power*p)==0:prime_power*=p
    coprime=c//prime_power
    inertia=[a for a in g if(a-1)%coprime==0]
    remaining=set(range(len(cosets)));orbits=[]
    while remaining:
        seed=min(remaining)
        orbit={which[a*cosets[seed][0]%c]for a in inertia}
        assert orbit<=remaining
        remaining-=orbit;orbits.append(tuple(sorted(orbit)))
    sizes={len(o)for o in orbits};assert len(sizes)==1
    e=sizes.pop();orbit_of={i:j for j,o in enumerate(orbits)for i in o}
    frob=next(a for a in g if(a-p)%coprime==0 and(a-1)%prime_power==0)
    permutation={j:orbit_of[which[frob*cosets[o[0]][0]%c]]
                 for j,o in enumerate(orbits)}
    remaining=set(permutation);lengths=[]
    while remaining:
        seed=min(remaining);x=seed;cycle=[]
        while x not in cycle:
            cycle.append(x);x=permutation[x]
        assert x==seed and set(cycle)<=remaining
        remaining-=set(cycle);lengths.append(len(cycle))
    assert len(set(lengths))==1
    f=lengths[0]
    assert len(cosets)==e*f*len(lengths)
    return(len(cosets),e,f)


@lru_cache(maxsize=32768)
def labelled_possible(F,p,codegrees,division=False,use_parity=True):
    """Exact labelled v=1 class partition, with unrestricted other classes."""
    m=p**val(N,p);a=N//F;t=val(F,p)
    ranks=(0,2)if division else(0,1,2)
    @lru_cache(None)
    def rec(mask,budget):
        if not mask:return True
        bit=mask&-mask;i=bit.bit_length()-1;rest=mask^bit;fi=codegrees[i]
        for k in ranks:
            if k>budget:continue
            if(N//fi+k*a)%m==0 and(not use_parity or(1+k*k*t)%2==0):
                if rec(rest,budget-k):return True
        for j,fj in enumerate(codegrees):
            if not(rest>>j&1)or(fi+fj)%(p*p):continue
            for k in ranks:
                if k>budget:continue
                if(N//fi+N//fj+k*a)%m==0 and(not use_parity or(2+k*k*t)%2==0):
                    if rec(rest^(1<<j),budget-k):return True
        return False
    return rec((1<<len(codegrees))-1,2)


def independent_decision(record):
    F=N//record["double_degree"];codegrees=[N];labels=set()
    for block in record["assignment"]["fields"]:
        for label in block["fields"]:
            degree=local_orbit_data(label,2)[0]
            codegrees.extend([block["formal_codegree"]]*degree);labels.add(label)
    assert len(codegrees)==12 and sum(N//f for f in codegrees)+2*N//F==N
    locals_=[]
    for p in PRIMES:
        data=[local_orbit_data(label,p)for label in labels]
        if all(e==1 for degree,e,f in data):
            h=lcm(*(f for degree,e,f in data))
            v1=tuple(sorted(f for f in codegrees if val(f,p)==1))
            locals_.append((p,h,v1))
    if not locals_:return"NOT_APPLICABLE",False,False,[],codegrees
    previous=any(not labelled_possible(F,p,v1,False,False)for p,h,v1 in locals_)
    split=any(not labelled_possible(F,p,v1,False,True)for p,h,v1 in locals_)
    failures=[];survivor=False
    for ram in record["matrix_ramification_classes"]:
        bad=[]
        for p,h,v1 in locals_:
            division=p in ram and h%2==1
            if not labelled_possible(F,p,v1,division,True):bad.append(p)
        if not bad:survivor=True
        failures.append((tuple(ram),bad))
    result="OPEN"if survivor else"EXCLUDED"
    assert not previous or split
    assert not split or result=="EXCLUDED"
    return result,previous,split,failures,codegrees


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--inputs",type=Path,default=HERE/"normalized_open")
    ap.add_argument("--sweep",type=Path,default=HERE/"full_sweep")
    ap.add_argument("--base",type=Path,default=HERE.parents[1]/"round36"/"deliverable"/
                    "p6q6r4_Round36"/"verification"/"round36"/"one_matrix16")
    ap.add_argument("--output",type=Path,default=HERE/"independent_full_audit.json")
    args=ap.parse_args();start=time.monotonic();inputs=args.inputs;sweep=args.sweep
    manifest=json.loads((inputs/"manifest.json").read_text());summary=json.loads((sweep/"summary.json").read_text())
    assert sha(inputs/"manifest.json")==summary["input_manifest_sha256"]
    assert sha(sweep/"incremental_exclusions.jsonl.gz")==summary["excluded_gzip_sha256"]
    inventory=json.loads((inputs/"field_local_inventory.json").read_text());local_checks=0
    assert sha(inputs/"field_local_inventory.json")==manifest["field_local_inventory_sha256"]
    for item in inventory:
        for old in item["local"]:
            d,e,f=local_orbit_data(item["label"],old["prime"])
            assert(d,e,f)==(item["degree"],old["ramification_index"],old["residue_degree"])
            assert old["unramified"]==(e==1);local_checks+=1
    # Authenticate every inherited context source before using its exact forms.
    for name,digest in manifest["context_source_sha256"].items():
        assert sha(args.base/name)==digest
    sys.path.insert(0,str(args.base.resolve()))
    import context16
    import matrix_spectral_filter
    import trace_rank16
    contexts=json.loads(gzip.decompress((inputs/"matrix_context_inventory.json.gz").read_bytes()))
    assert sha(inputs/"matrix_context_inventory.json.gz")==manifest["matrix_context_inventory_sha256"]
    for key,item in contexts.items():
        assignment=dict(fields=item["fields"],q=item["q"])
        f=N//item["double_degree"]
        if item["kind"]=="orthogonal":
            assignment["orthogonal_delta"]=item["skew_squareclass"]
            assignment["orthogonal_skew_diagonals"]=list(trace_rank16.skew_diagonal_values(
                item["skew_squareclass"],f,item["q"]+1))
        direct=matrix_spectral_filter.context(assignment,item["double_degree"],item["kind"])
        assert [list(c)for c in direct[3]]==item["ramification_classes"]
        assert direct[2]==item["skew_squareclass"]
        w,m=context16.form_data(assignment)
        assert list(w)==item["whole_signature"] and list(m)==item["minus_signature"]
        assert key==hashlib.sha256(canonical(dict(whole=w,minus=m,q=item["q"],
                    kind=item["kind"],double_degree=item["double_degree"]))).hexdigest()
    certs=gzip.open(sweep/"incremental_exclusions.jsonl.gz","rb")
    cert_hash=hashlib.sha256();remain_hash=hashlib.sha256();input_hash=hashlib.sha256()
    def next_certificate():
        line=certs.readline()
        if not line:return None
        cert_hash.update(line);return json.loads(line)
    current=next_certificate();ordinal=0;last_state=-1;counts=Counter();stage=Counter()
    rational_stage=Counter();by_kind=Counter();first_stage_examples={}
    for chunk in manifest["chunks"]:
        path=inputs/chunk["file"];assert sha(path)==chunk["sha256"]
        ch=hashlib.sha256();assert chunk["start"]==ordinal
        with gzip.open(path,"rb")as f:
            for line in f:
                ch.update(line);input_hash.update(line);rec=json.loads(line)
                assert rec["open_index"]==ordinal and rec["state"]>last_state
                ordinal+=1;last_state=rec["state"]
                # Recompute actual field signatures, never just trust a supplied
                # ramification tag or context-inventory key.
                w,m=context16.form_data(rec["assignment"])
                key=hashlib.sha256(canonical(dict(whole=w,minus=m,q=rec["assignment"]["q"],
                    kind=rec["kind"],double_degree=rec["double_degree"]))).hexdigest()
                assert key==rec["matrix_context_key"]
                assert contexts[key]["ramification_classes"]==rec["matrix_ramification_classes"]
                result,previous,split,failures,codegrees=independent_decision(rec)
                counts[result]+=1;by_kind[(rec["kind"],result)]+=1
                reason=("previous_pair_resource"if previous else
                        "corner_parity_additional"if split else
                        "division_context_additional"if result=="EXCLUDED"else result)
                stage[reason]+=1
                rational=all(label=="Q"for b in rec["assignment"]["fields"]for label in b["fields"])
                if rational:rational_stage[reason]+=1
                if result=="EXCLUDED":
                    assert current is not None and current["state"]==rec["state"]
                    assert current["open_index"]==rec["open_index"]
                    assert current["normalized_input_sha256"]==hashlib.sha256(line).hexdigest()
                    assert current["gate_sha256"]==summary["gate_sha256"]
                    assert current["division_refinement_needed"]==(not split)
                    certificate=current["certificate"]
                    assert certificate["linear_codegrees"]==codegrees
                    assert len(certificate["failures"])==len(failures)
                    for claim,(ram,bad_primes)in zip(certificate["failures"],failures):
                        assert tuple(claim["matrix_ramification"])==ram
                        p=claim["prime"];assert p in bad_primes
                        h=lcm(*(local_orbit_data(label,p)[2]for b in rec["assignment"]["fields"]for label in b["fields"]))
                        assert claim["common_unramified_degree"]==h
                        assert claim["division_after_base_change"]==(p in ram and h%2==1)
                        bins=[sum(val(f,p)==1 and f//p%p==u for f in codegrees)for u in range(1,p)]
                        assert claim["valuation_one_bins"]==bins
                        assert claim["matrix_codegree"]==N//rec["double_degree"]
                    first_stage_examples.setdefault(reason,dict(state=rec["state"],open_index=rec["open_index"],
                        index=rec["index"],double_degree=rec["double_degree"],kind=rec["kind"],
                        all_rational=rational,certificate=certificate))
                    current=next_certificate()
                else:
                    assert current is None or current["state"]>rec["state"]
                    remain_hash.update(canonical({k:rec[k]for k in("state","open_index","index","double_degree","assignment_index","kind")}))
        assert ordinal==chunk["stop"] and ch.hexdigest()==chunk["uncompressed_sha256"]
        print("independently checked",ordinal,"counts",dict(counts),"seconds",
              round(time.monotonic()-start,2),flush=True)
    assert current is None and next_certificate()is None
    certs.close()
    assert ordinal==976867 and input_hash.hexdigest()==manifest["normalized_uncompressed_sha256"]
    assert counts==Counter(summary["statuses"])
    assert cert_hash.hexdigest()==summary["excluded_uncompressed_sha256"]
    assert remain_hash.hexdigest()==summary["remaining_uncompressed_sha256"]
    actual_remaining=hashlib.sha256()
    with gzip.open(sweep/"remaining_open_ids.jsonl.gz","rb")as f:
        for block in iter(lambda:f.read(1048576),b""):actual_remaining.update(block)
    assert actual_remaining.hexdigest()==remain_hash.hexdigest()
    report=dict(status="PASS_INDEPENDENT_COMPLETE_CORNER_REPLAY",records=ordinal,
        statuses=dict(counts),terminal_incremental_stages=dict(stage),
        all_rational_terminal_stages=dict(rational_stage),
        counts_by_kind_status=[dict(kind=k,status=s,states=n)for(k,s),n in sorted(by_kind.items())],
        independently_checked_field_prime_pairs=local_checks,
        independently_checked_complete_matrix_contexts=len(contexts),
        labelled_recursion_cache=labelled_possible.cache_info()._asdict(),
        input_manifest_sha256=sha(inputs/"manifest.json"),
        producer_summary_sha256=sha(sweep/"summary.json"),
        normalized_uncompressed_sha256=input_hash.hexdigest(),
        excluded_uncompressed_sha256=cert_hash.hexdigest(),
        remaining_uncompressed_sha256=remain_hash.hexdigest(),
        auditor_sha256=sha(Path(__file__)),first_stage_examples=first_stage_examples,
        seconds=time.monotonic()-start,maximum_resident_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    args.output.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items()if k!="first_stage_examples"},indent=2),flush=True)


if __name__=="__main__":main()
