#!/usr/bin/env python3
"""Small exact controls for noncentral corners, dyadic lifting and alignment."""
from pathlib import Path
from fractions import Fraction
from itertools import product
import hashlib,json
from aligned_gate import aligned_corner_gate

HERE=Path(__file__).resolve().parent


def matmul(a,b):return[[sum(x*y for x,y in zip(row,col))for col in zip(*b)]for row in a]
def transpose(a):return[list(c)for c in zip(*a)]
def add(a,b):return[[x+y for x,y in zip(r,s)]for r,s in zip(a,b)]
def scale(n,a):return[[n*x for x in row]for row in a]
def reduce(a,n):return[[x%n for x in row]for row in a]
def tr(a):return sum(a[i][i]for i in range(len(a)))
I=[[1,0],[0,1]]
B=[[[1,0],[0,0]],[[0,1],[0,0]],[[0,0],[1,0]],[[0,0],[0,1]]]
G=[[tr(matmul(a,b))for b in B]for a in B]


def main():
    corners=0;lifts=0;determinants=0
    for x,y in product(range(-3,4),repeat=2):
        s=[[1,x],[y,1+x*y]];inv=[[1+x*y,-x],[-y,1]]
        e=matmul(matmul(s,B[0]),inv);assert matmul(e,e)==e and tr(e)==1
        cols=[sum(matmul(matmul(e,b),e),[])for b in B];P=transpose(cols)
        assert matmul(P,P)==P and matmul(transpose(P),G)==matmul(G,P)
        assert tr(matmul(e,e))==1;corners+=1
        for p in(2,3,5):
            for error in(B[0],B[1],add(B[2],B[3])):
                modulus=p**8;z=reduce(add(e,scale(p,error)),modulus)
                for iteration in range(4):
                    delta=reduce(add(matmul(z,z),scale(-1,z)),modulus)
                    u=reduce(add(scale(2,z),scale(-1,I)),modulus)
                    det=(u[0][0]*u[1][1]-u[0][1]*u[1][0])%modulus
                    inverse=reduce(scale(pow(det,-1,modulus),
                        [[u[1][1],-u[0][1]],[-u[1][0],u[0][0]]]),modulus)
                    z=reduce(add(z,scale(-1,matmul(delta,inverse))),modulus)
                assert reduce(matmul(z,z),modulus)==z
                assert reduce(z,p)==reduce(e,p);lifts+=1
    for a,b in product((-5,-3,-2,-1,1,2,3,5),repeat=2):
        gram_diagonal=(2,2*a,2*b,-2*a*b)
        det=1
        for q in gram_diagonal:det*=q
        assert det==-(4*a*b)**2
        for p in(2,3,5):
            v=0;n=abs(det)
            while n%p==0:n//=p;v+=1
            assert v%2==0
        determinants+=1
    # Actual integral group-algebra S3 character columns are positive controls.
    columns=[(1,1,1,1,1,1),(1,-1,-1,-1,1,1)]
    alignments=[]
    for p in(2,3,5):
        cols=[tuple(x%p for x in c)for c in columns]
        r=aligned_corner_gate([6,6],3,cols,6,p,
            unramified_eligibility_certified=True)
        assert r["status"]=="OPEN";alignments.append(dict(prime=p,result=r))
    assert alignments[1]["result"]["admissible_rank_totals"]==[2]
    assert alignments[2]["result"]["admissible_rank_totals"]==[0]
    false_division=aligned_corner_gate([6,6],3,
        [tuple(x%3 for x in c)for c in columns],6,3,
        division_after_base_change=True,unramified_eligibility_certified=True)
    assert false_division["status"]=="EXCLUDED"
    missing=aligned_corner_gate([6,6],3,columns,6,3)
    assert missing["status"]=="NOT_APPLICABLE"and not missing["source_state_excluded"]
    r=dict(status="PASS_EXACT_CORNER_CONTROLS",noncentral_integral_idempotents=corners,
        modular_Newton_lifts=lifts,quaternion_trace_determinants=determinants,
        S3_aligned_positive_controls=alignments,post_base_change_division_negative_control=false_division,
        eligibility_missing_control=missing,
        source_sha256={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()
            for name in("audit_corner_controls.py","aligned_gate.py","r36_corner_parity.tex")})
    (HERE/"corner_controls_audit.json").write_text(json.dumps(r,indent=2)+"\n")
    print(json.dumps({k:v for k,v in r.items()if k not in("S3_aligned_positive_controls",
        "post_base_change_division_negative_control","eligibility_missing_control")},indent=2))


if __name__=="__main__":main()
