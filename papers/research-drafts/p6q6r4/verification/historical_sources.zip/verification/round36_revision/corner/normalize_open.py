#!/usr/bin/env python3
"""Derive deterministic, bounded chunks of every completed R36 OPEN input.

This adapter only reads the immutable release.  It independently compares
both inherited matrix-context implementations for every encountered context.
The final manifest is written only after both complete original input hashes,
the source-state identities and all expected counts have been checked.
"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
import resource
import sys
import time

HERE = Path(__file__).resolve().parent
EXPECTED_OPEN = 976867
EXPECTED_STATES = 1325156
OPEN_SHA = "2c68e87f386ac42dd4f45ed7c3e2ca2b9a2b36c245fa1ad98c8ca17638a39688"
TRACE_SHA = "8e6d5f73c00bcb828e68c14a8f49522a99f77b7a75e4f1bc4adecd3326758383"


def encoded(obj):
    return (json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n").encode()


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as inp:
        for block in iter(lambda: inp.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, default=HERE.parents[1] / "round36" /
                    "deliverable" / "p6q6r4_Round36" / "verification" /
                    "round36" / "one_matrix16")
    ap.add_argument("--output", type=Path, default=HERE / "normalized_open")
    ap.add_argument("--chunk-size", type=int, default=10000)
    args = ap.parse_args()
    base = args.base.resolve()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if list(out.glob("open_*.jsonl.gz")) or (out / "manifest.json").exists():
        raise SystemExit("Output already has completed chunks; choose a fresh directory.")
    sys.path.insert(0, str(base))
    import context16
    import run_rows16
    from corner_gate import field_local_data, field_degree, linear_data
    proof = run_rows16.source_digest()
    assert proof == "ad8bcc6a325493b6a04633ff6aba73ff333996e11bac2f38f9950ff0d4226280"
    source_files = {name:sha(base/name) for name in run_rows16.PROOF_FILES}
    source_files["symplectic_profiles.json"] = sha(base/"symplectic_profiles.json")
    opened = gzip.open(base / "rank16_open_state_ids.jsonl.gz", "rb")
    trace = gzip.open(base / "rank16_trace_complete.jsonl.gz", "rb")
    oh = hashlib.sha256()
    th = hashlib.sha256()
    sh = hashlib.sha256()
    source_manifest = []
    counts = Counter()
    fields = set()
    context_inventory = {}
    chunks = []
    raw = gz = None
    chunk_hash = None
    chunk_start = None
    chunk_path = None
    start = time.monotonic()

    def next_open():
        line = opened.readline()
        if not line:
            return None
        oh.update(line)
        return json.loads(line)

    def close_chunk(stop):
        nonlocal raw, gz, chunk_hash, chunk_start, chunk_path
        if gz is None:
            return
        gz.close()
        raw.close()
        target = out / f"open_{chunk_start:06d}_{stop:06d}.jsonl.gz"
        chunk_path.replace(target)
        chunks.append(dict(file=target.name, start=chunk_start, stop=stop,
                           records=stop-chunk_start, sha256=sha(target),
                           uncompressed_sha256=chunk_hash.hexdigest(),
                           bytes=target.stat().st_size))
        raw = gz = None

    current = next_open()
    state = 0
    index = 0
    for line in trace:
        th.update(line)
        case = json.loads(line)
        counts["trace_placements"] += 1
        for ai, assignment in enumerate(case["surviving_assignments"]):
            for kind in assignment["duality_types"]:
                if current is not None and current["state"] < state:
                    raise AssertionError("OPEN identities are not in source order.")
                if current is not None and current["state"] == state:
                    identity = dict(state=state,index=case["index"],
                                    double_degree=case["double_degree"],
                                    assignment_index=ai,kind=kind)
                    assert identity == current
                    rec = dict(identity,profile=case["profile"],assignment=assignment)
                    linear_data(rec)
                    ctx = context16.context(assignment,case["double_degree"],kind,audit=True)
                    record_hash = hashlib.sha256(encoded(rec)).hexdigest()
                    rec.update(open_index=index,
                               source_record_sha256=record_hash,
                               matrix_ramification_classes=[list(c) for c in ctx[3]],
                               matrix_skew_squareclass=ctx[2])
                    whole, minus = context16.form_data(assignment)
                    context_key = hashlib.sha256(encoded(dict(whole=whole,minus=minus,
                                      q=assignment["q"],kind=kind,
                                      double_degree=case["double_degree"]))).hexdigest()
                    context_inventory.setdefault(context_key,dict(
                        fields=assignment["fields"],whole_signature=whole,
                        minus_signature=minus,q=assignment["q"],kind=kind,
                        double_degree=case["double_degree"],
                        ramification_classes=[list(c) for c in ctx[3]],
                        skew_squareclass=ctx[2]))
                    # The per-state context is fully reproduced above; the shared
                    # inventory is a compact independent replay index.
                    rec["matrix_context_key"] = context_key
                    if gz is None:
                        chunk_start = index
                        chunk_path = out / f"open_{index:06d}.partial"
                        raw = chunk_path.open("wb")
                        gz = gzip.GzipFile(filename="", mode="wb", fileobj=raw,
                                           compresslevel=6, mtime=0)
                        chunk_hash = hashlib.sha256()
                    data = encoded(rec)
                    gz.write(data)
                    chunk_hash.update(data)
                    sh.update(data)
                    counts[kind] += 1
                    for b in assignment["fields"]:
                        fields.update(b["fields"])
                    index += 1
                    if index % args.chunk_size == 0:
                        close_chunk(index)
                        print("normalized",index,"source",state,"seconds",
                              round(time.monotonic()-start,2),"rss_kib",
                              resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                              flush=True)
                    current = next_open()
                state += 1
    close_chunk(index)
    assert current is None and next_open() is None
    opened.close()
    trace.close()
    assert state == EXPECTED_STATES and index == EXPECTED_OPEN
    assert oh.hexdigest() == OPEN_SHA and th.hexdigest() == TRACE_SHA
    assert counts["orthogonal"] == 974802 and counts["symplectic"] == 2065
    assert counts["trace_placements"] == 1224166
    assert proof == run_rows16.source_digest()
    inventory = [dict(label=label,degree=field_degree(label),
                      local=[field_local_data(label,p) for p in (2,3,5)])
                 for label in sorted(fields)]
    field_file = out / "field_local_inventory.json"
    field_file.write_text(json.dumps(inventory,indent=2)+"\n")
    context_file = out / "matrix_context_inventory.json.gz"
    with context_file.open("wb") as file:
        with gzip.GzipFile(filename="",mode="wb",fileobj=file,mtime=0) as stream:
            stream.write(encoded(context_inventory))
    report = dict(status="PASS_COMPLETE_AUTHENTICATED_R36_OPEN_NORMALIZATION",
                  records=index,original_field_duality_states=state,
                  counts=dict(counts),chunk_size=args.chunk_size,chunks=chunks,
                  normalized_uncompressed_sha256=sh.hexdigest(),
                  original_uncompressed_sha256=dict(OPEN=oh.hexdigest(),trace=th.hexdigest()),
                  matrix_context_proof_sha256=proof,
                  context_source_sha256=source_files,
                  context_count=len(context_inventory),
                  field_local_inventory_sha256=sha(field_file),
                  matrix_context_inventory_sha256=sha(context_file),
                  normalizer_sha256=sha(Path(__file__)),
                  gate_sha256=sha(HERE/"corner_gate.py"),
                  maximum_resident_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  seconds=time.monotonic()-start)
    (out/"manifest.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items()
                      if k not in ("chunks","context_source_sha256")},indent=2),flush=True)


if __name__ == "__main__":
    main()
