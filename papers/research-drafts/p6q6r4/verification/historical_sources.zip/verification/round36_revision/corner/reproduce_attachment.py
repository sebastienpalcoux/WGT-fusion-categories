#!/usr/bin/env python3
"""Replay or audit the supplied arithmetic benchmarks without editing them."""
from pathlib import Path
import argparse,gzip,hashlib,importlib.util,json,shutil,subprocess,sys

HERE=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--attachment",type=Path,default=HERE.parent/"attachment"/"rank16_corner_parity_audit")
    ap.add_argument("--replay",type=Path,default=HERE/"attachment_replay")
    ap.add_argument("--output",type=Path,default=HERE/"benchmark_reproduction_audit.json")
    ap.add_argument("--extra-placements",type=Path,default=HERE/"all_rational_900_extra_placements.jsonl.gz")
    ap.add_argument("--fresh",action="store_true")
    args=ap.parse_args();a=args.attachment.resolve();r=args.replay.resolve()
    if r==a:raise SystemExit("The replay directory must differ from the attachment.")
    source={p.name:sha(p)for p in sorted(a.glob("*.py"))}
    if args.fresh:
        r.mkdir(parents=True,exist_ok=True)
        for name in source:shutil.copy2(a/name,r/name)
        for program,output in[("benchmark.py","reproduced_summary.json"),
                               ("checkpoint_audit.py","reproduced_checkpoint_summary.json")]:
            with(r/output).open("w")as out:
                subprocess.run([sys.executable,"-B",program],cwd=r,stdout=out,check=True)
    for name,h in source.items():assert sha(r/name)==h
    comparisons=[]
    for expected,actual in[("summary.json","reproduced_summary.json"),
                           ("checkpoint_summary.json","reproduced_checkpoint_summary.json")]:
        x=json.loads((a/expected).read_text());y=json.loads((r/actual).read_text())
        x.pop("seconds");y.pop("seconds");assert x==y
        comparisons.append(dict(expected=expected,reproduced=actual,
            expected_sha256=sha(a/expected),reproduced_sha256=sha(r/actual)))
    for name in("combined_survivors.json","new_corner_exclusions.json"):
        assert(r/name).read_bytes()==(a/name).read_bytes()
        comparisons.append(dict(file=name,sha256=sha(a/name),byte_identical=True,
            records=len(json.loads((a/name).read_text()))))
    sys.path.insert(0,str(r))
    from cheap_gates import all_cheap
    records=[x for x in json.loads((r/"new_corner_exclusions.json").read_text())
             if all_cheap(tuple(x[1:]),x[0])]
    assert len(records)==900
    p=args.extra_placements;p.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256()
    with p.open("wb")as raw:
        with gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0)as out:
            for row in records:
                line=(json.dumps(row,separators=(",",":"))+"\n").encode();out.write(line);h.update(line)
    report=dict(status="PASS_EXACT_ATTACHMENT_BENCHMARK_REPRODUCTION",source_sha256=source,
        comparisons=comparisons,all_rational_selected_baseline=12544,
        all_rational_selected_after_corner=11644,all_rational_incremental_placements=900,
        incremental_900_gzip_sha256=sha(p),incremental_900_uncompressed_sha256=h.hexdigest(),
        auditor_sha256=sha(Path(__file__)),
        scope="All-rational canonical placements under the listed selected cheap gates; not the completed R36 full field-duality state universe.")
    args.output.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":main()
