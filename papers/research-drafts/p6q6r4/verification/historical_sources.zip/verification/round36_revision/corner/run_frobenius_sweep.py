#!/usr/bin/env python3
"""Separate incremental Frobenius stage on the frozen corner remainder."""
from collections import Counter
from pathlib import Path
import argparse,gzip,hashlib,json,time,resource
from corner_extension import corner_extension,RULE_VERSION

HERE=Path(__file__).resolve().parent


def canonical(x):return(json.dumps(x,sort_keys=True,separators=(",",":"))+"\n").encode()
def sha(path):
    h=hashlib.sha256()
    with path.open("rb")as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--inputs",type=Path,default=HERE/"normalized_open")
    ap.add_argument("--baseline",type=Path,default=HERE/"full_sweep")
    ap.add_argument("--output",type=Path,default=HERE/"frobenius_sweep")
    args=ap.parse_args();inp=args.inputs;old=args.baseline;out=args.output;out.mkdir(parents=True,exist_ok=True)
    m=json.loads((inp/"manifest.json").read_text());baseline=json.loads((old/"summary.json").read_text())
    assert baseline["remaining_states"]==611949
    assert sha(inp/"manifest.json")==baseline["input_manifest_sha256"]
    proof={name:sha(HERE/name)for name in("corner_gate.py","corner_extension.py")}
    assert proof["corner_gate.py"]==baseline["gate_sha256"]
    start=time.monotonic();counts=Counter();by_kind=Counter();by_f=Counter();stages=Counter()
    ih=hashlib.sha256();bh=hashlib.sha256();eh=hashlib.sha256();rh=hashlib.sha256()
    selected=gzip.open(old/"remaining_open_ids.jsonl.gz","rb")
    def next_selected():
        line=selected.readline()
        if not line:return None
        bh.update(line);return json.loads(line)
    current=next_selected();visited=0;total=0;remaining_profiles=set();remaining_placements=set()
    eraw=(out/"incremental_exclusions.jsonl.gz").open("wb");rraw=(out/"remaining_open_ids.jsonl.gz").open("wb")
    eo=gzip.GzipFile(filename="",mode="wb",fileobj=eraw,mtime=0);ro=gzip.GzipFile(filename="",mode="wb",fileobj=rraw,mtime=0)
    for chunk in m["chunks"]:
        p=inp/chunk["file"];assert sha(p)==chunk["sha256"];ch=hashlib.sha256()
        with gzip.open(p,"rb")as f:
            for line in f:
                ch.update(line);ih.update(line);record=json.loads(line);assert record["open_index"]==total;total+=1
                if current is None or record["state"]<current["state"]:continue
                identity={k:record[k]for k in("state","open_index","index","double_degree","assignment_index","kind")}
                assert identity==current;visited+=1
                decision=corner_extension(record)
                # Attribute the descent improvement separately from cycle matching
                # with only the old common-extension division restriction.
                from corner_extension import cycle_bins,allowed_deletions
                ordinary_survivor=False
                for ram in record["matrix_ramification_classes"]:
                    ok=True
                    for loc in decision["eligibility"]:
                        if not loc["eligible"]:continue
                        p=loc["prime"];h=loc["common_unramified_degree"]
                        # If B splits over the common extension, do not apply the
                        # new singleton descent prohibition in this comparison.
                        base_ramified=p in ram and h%2==1
                        if not allowed_deletions(cycle_bins(record,p),5400//record["double_degree"],p,base_ramified):ok=False;break
                    if ok:ordinary_survivor=True;break
                counts[decision["status"]]+=1;by_kind[(record["kind"],decision["status"])]+=1
                by_f[(5400//record["double_degree"],record["kind"],decision["status"])]+=1
                if decision["status"]=="EXCLUDED":
                    stage="singleton_Brauer_descent"if ordinary_survivor else"Frobenius_cycle_matching"
                    stages[stage]+=1
                    cert=dict(identity,normalized_input_sha256=hashlib.sha256(line).hexdigest(),
                        stage=stage,source_sha256=proof,certificate=decision["witness"])
                    data=canonical(cert);eo.write(data);eh.update(data)
                else:
                    data=canonical(identity);ro.write(data);rh.update(data)
                    remaining_profiles.add(record["index"]);remaining_placements.add((record["index"],record["double_degree"]))
                if record["state"]==836343:
                    assert decision["status"]=="NOT_APPLICABLE"
                    (out/"state_836343_result.json").write_text(json.dumps(dict(input=record,result=decision),indent=2)+"\n")
                current=next_selected()
        assert ch.hexdigest()==chunk["uncompressed_sha256"]
        print("Frobenius screened",visited,"of",total,"counts",dict(counts),"seconds",round(time.monotonic()-start,2),flush=True)
    eo.close();eraw.close();ro.close();rraw.close();selected.close()
    assert current is None and visited==611949 and total==976867
    assert ih.hexdigest()==m["normalized_uncompressed_sha256"]
    assert bh.hexdigest()==baseline["remaining_uncompressed_sha256"]
    assert all(sha(HERE/name)==h for name,h in proof.items())
    report=dict(status="PASS_COMPLETE_INCREMENTAL_FROBENIUS_CORNER_SWEEP",rule_version=RULE_VERSION,
        baseline_remaining_states=visited,incremental_exclusions=counts["EXCLUDED"],
        remaining_states=visited-counts["EXCLUDED"],statuses=dict(counts),
        terminal_incremental_stages=dict(stages),
        counts_by_kind_status=[dict(kind=k,status=s,states=n)for(k,s),n in sorted(by_kind.items())],
        counts_by_codegree_kind_status=[dict(f=f,kind=k,status=s,states=n)for(f,k,s),n in sorted(by_f.items())],
        remaining_canonical_profiles=len(remaining_profiles),remaining_matrix_placements=len(remaining_placements),
        baseline_summary_sha256=sha(old/"summary.json"),input_manifest_sha256=sha(inp/"manifest.json"),
        source_sha256=proof,producer_sha256=sha(Path(__file__)),
        baseline_remaining_uncompressed_sha256=bh.hexdigest(),
        excluded_uncompressed_sha256=eh.hexdigest(),remaining_uncompressed_sha256=rh.hexdigest(),
        excluded_gzip_sha256=sha(out/"incremental_exclusions.jsonl.gz"),
        remaining_gzip_sha256=sha(out/"remaining_open_ids.jsonl.gz"),
        state836343_retained=True,seconds=time.monotonic()-start,
        maximum_resident_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    (out/"summary.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items()if k!="counts_by_codegree_kind_status"},indent=2),flush=True)


if __name__=="__main__":main()
