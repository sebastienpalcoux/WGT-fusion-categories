"""Corner constraints for one supplied complete aligned residue table.

A rejection concerns only that supplied alignment.  It is not a rejection of
its underlying R36 state unless a separate exhaustive alignment search proves
that every alignment has failed.  The caller must certify that all linear
values embed into the chosen common unramified local field.
"""
from collections import defaultdict


def valuation(n,p):
    if n<=0:raise ValueError("Positive codegrees are required.")
    e=0
    while n%p==0:n//=p;e+=1
    return e


def aligned_corner_gate(codegrees,F,residue_columns,N,p,
                        division_after_base_change=False,
                        unramified_eligibility_certified=False):
    scope="supplied_complete_aligned_residue_table"
    if not unramified_eligibility_certified:
        return dict(status="NOT_APPLICABLE",exclusion_scope=scope,
                    source_state_excluded=False,
                    reason="A common unramified field has not been certified.")
    if p not in(2,3,5)or N<=0 or F<=0 or N%F:
        raise ValueError("Invalid dimension, matrix codegree or local prime.")
    if len(codegrees)!=len(residue_columns)or not codegrees:
        raise ValueError("Every linear embedding needs a residue column.")
    if any(f<=0 or N%f for f in codegrees):
        raise ValueError("Every formal codegree must divide N.")
    if len({len(c)for c in residue_columns})!=1:
        raise ValueError("The columns must share one full source basis.")
    classes=defaultdict(list)
    for i,c in enumerate(residue_columns):classes[tuple(c)].append(i)
    modulus=p**valuation(N,p);a=N//F;t=valuation(F,p)
    ranks=(0,2)if division_after_base_change else(0,1,2)
    options=[];reachable={0};failure=None
    for members in classes.values():
        vals=[valuation(codegrees[i],p)for i in members]
        pair_fail=[(i,j)for ii,i in enumerate(members)for j in members[ii+1:]
                   if(codegrees[i]+codegrees[j])%(p*p)]
        reasons=[]
        if len(members)>1 and 0 in vals:reasons.append("unit_codegree_not_isolated")
        if pair_fail:reasons.append("pair_column_orthogonality")
        if len(members)>=3 and any(v<2 for v in vals):reasons.append("triple_column_orthogonality")
        mass=sum(N//codegrees[i]for i in members)
        # A p-unit linear's integral primitive central idempotent supplies
        # this singleton corner with matrix rank zero.  It can be included
        # first when lifting the complete orthogonal collection.
        class_ranks=(0,)if 0 in vals else ranks
        permitted=[] if reasons else[k for k in class_ranks
                if(mass+k*a)%modulus==0 and(sum(vals)+k*k*t)%2==0]
        options.append(dict(linear_indices=members,canonical_sum=mass,
                            valuation_sum=sum(vals),permitted_ranks=permitted,
                            column_failures=reasons))
        reachable={old+k for old in reachable for k in permitted if old+k<=2}
        if not reachable and failure is None:failure=len(options)-1
    allowed=[]
    for total in sorted(reachable):
        rest=2-total
        if rest%(p**t)==0 and(rest*rest*t)%2==0 and(
                not division_after_base_change or rest in(0,2)):
            allowed.append(total)
    return dict(status="OPEN"if allowed else"EXCLUDED",exclusion_scope=scope,
                source_state_excluded=False,prime=p,
                division_after_base_change=division_after_base_change,
                class_options=options,reachable_class_rank_totals=sorted(reachable),
                admissible_rank_totals=allowed,first_empty_prefix=failure,
                complementary_corner_checked=True)
