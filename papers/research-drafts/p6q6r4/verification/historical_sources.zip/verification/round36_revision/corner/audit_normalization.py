#!/usr/bin/env python3
"""Independent streaming equality of normalized states and original R36 inputs."""
from pathlib import Path
import argparse,gzip,hashlib,json,time

HERE=Path(__file__).resolve().parent


def canonical(obj):return(json.dumps(obj,sort_keys=True,separators=(",",":"))+"\n").encode()


def sha(path):
    h=hashlib.sha256()
    with path.open("rb")as f:
        for block in iter(lambda:f.read(1048576),b""):h.update(block)
    return h.hexdigest()


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--inputs",type=Path,default=HERE/"normalized_open")
    ap.add_argument("--base",type=Path,default=HERE.parents[1]/"round36"/"deliverable"/
        "p6q6r4_Round36"/"verification"/"round36"/"one_matrix16")
    ap.add_argument("--output",type=Path,default=HERE/"normalization_independent_audit.json")
    args=ap.parse_args();start=time.monotonic();m=json.loads((args.inputs/"manifest.json").read_text())
    nh=hashlib.sha256();oh=hashlib.sha256();th=hashlib.sha256()
    def normalized():
        ordinal=0
        for c in m["chunks"]:
            p=args.inputs/c["file"];assert sha(p)==c["sha256"];h=hashlib.sha256();assert c["start"]==ordinal
            with gzip.open(p,"rb")as f:
                for line in f:
                    h.update(line);nh.update(line);x=json.loads(line);assert x["open_index"]==ordinal
                    ordinal+=1;yield x
            assert ordinal==c["stop"]and h.hexdigest()==c["uncompressed_sha256"]
        assert ordinal==m["records"]
    normalized_iter=normalized();count=0;state=0;placements=0
    with gzip.open(args.base/"rank16_open_state_ids.jsonl.gz","rb")as ids:
        def next_id():
            line=ids.readline()
            if not line:return None
            oh.update(line);return json.loads(line)
        current=next_id()
        with gzip.open(args.base/"rank16_trace_complete.jsonl.gz","rb")as source:
            for line in source:
                th.update(line);case=json.loads(line);placements+=1
                for ai,assignment in enumerate(case["surviving_assignments"]):
                    for kind in assignment["duality_types"]:
                        assert current is None or current["state"]>=state
                        if current is not None and current["state"]==state:
                            identity=dict(state=state,index=case["index"],double_degree=case["double_degree"],
                                          assignment_index=ai,kind=kind)
                            assert identity==current
                            old=dict(identity,profile=case["profile"],assignment=assignment)
                            new=next(normalized_iter)
                            assert{key:new[key]for key in old}==old
                            assert new["source_record_sha256"]==hashlib.sha256(canonical(old)).hexdigest()
                            count+=1;current=next_id()
                        state+=1
        assert current is None and next_id()is None
    assert next(normalized_iter,None)is None
    assert count==976867 and state==1325156 and placements==1224166
    assert nh.hexdigest()==m["normalized_uncompressed_sha256"]
    assert oh.hexdigest()=="2c68e87f386ac42dd4f45ed7c3e2ca2b9a2b36c245fa1ad98c8ca17638a39688"
    assert th.hexdigest()=="8e6d5f73c00bcb828e68c14a8f49522a99f77b7a75e4f1bc4adecd3326758383"
    r=dict(status="PASS_INDEPENDENT_EXACT_R36_OPEN_NORMALIZATION",normalized_records=count,
        original_states=state,original_placements=placements,input_manifest_sha256=sha(args.inputs/"manifest.json"),
        normalized_uncompressed_sha256=nh.hexdigest(),original_OPEN_uncompressed_sha256=oh.hexdigest(),
        original_trace_uncompressed_sha256=th.hexdigest(),auditor_sha256=sha(Path(__file__)),seconds=time.monotonic()-start)
    args.output.write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r,indent=2))


if __name__=="__main__":main()
