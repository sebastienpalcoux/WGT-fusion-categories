#!/usr/bin/env python3
"""Independent explicit equivariant-matching replay of the Frobenius stage.

The new producer and its cycle-bin balance function are not imported.  This
checker expands labelled Frobenius cycles, enumerates invariant singleton
sets, and forces complete Frobenius orbits of proposed matching edges.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
from math import lcm
import argparse,gzip,hashlib,json,time,resource
from audit_corner_sweep import local_orbit_data

HERE=Path(__file__).resolve().parent
N=5400


def val(n,p):
    e=0
    while n%p==0:n//=p;e+=1
    return e
def canonical(x):return(json.dumps(x,sort_keys=True,separators=(",",":"))+"\n").encode()
def sha(path):
    h=hashlib.sha256()
    with path.open("rb")as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()


@lru_cache(maxsize=32768)
def equivariant_matching_possible(F,p,cycles,base_ramified):
    """cycles is a tuple of (actual formal codegree, Frobenius length)."""
    codegrees=[];sigma=[];orbits=[]
    for f,length in cycles:
        start=len(codegrees);codegrees.extend([f]*length)
        sigma.extend(start+(i+1)%length for i in range(length))
        orbits.append((sum(1<<(start+i)for i in range(length)),length))
    full=(1<<len(codegrees))-1
    t=val(F,p);modulus=p**val(N,p)
    singleton_masks={0}
    for orbit,length in orbits:
        # A rank-one singleton corner is defined over this orbit's
        # unramified degree-length field.  Ramification forces even length.
        if length>2 or(base_ramified and length%2):continue
        members=[i for i in range(len(codegrees))if orbit>>i&1]
        if any((N//codegrees[i]+N//F)%modulus or(1+t)%2 for i in members):continue
        singleton_masks|={mask|orbit for mask in tuple(singleton_masks)
                          if not(mask&orbit)and(mask|orbit).bit_count()<=2}
    @lru_cache(None)
    def matching(mask):
        if mask==0:return True
        i=(mask&-mask).bit_length()-1
        for j in range(i+1,len(codegrees)):
            if not(mask>>j&1)or(codegrees[i]+codegrees[j])%(p*p):continue
            pairs={};a=i;b=j;seen=set();valid=True
            while(a,b)not in seen:
                seen.add((a,b))
                if a==b or not(mask>>a&1 and mask>>b&1):valid=False;break
                if a in pairs and pairs[a]!=b:valid=False;break
                if b in pairs and pairs[b]!=a:valid=False;break
                pairs[a]=b;pairs[b]=a;a=sigma[a];b=sigma[b]
            if not valid:continue
            removed=sum(1<<x for x in pairs)
            if matching(mask^removed):return True
        return False
    return any(matching(full^mask)for mask in sorted(singleton_masks))


def independent_prime_data(record):
    labels={x for b in record["assignment"]["fields"]for x in b["fields"]}
    local=[]
    for p in(2,3,5):
        data=[local_orbit_data(label,p)for label in labels]
        if any(e!=1 for d,e,f in data):continue
        h=lcm(*(f for d,e,f in data));cycles=[]
        for block in record["assignment"]["fields"]:
            f=block["formal_codegree"]
            if val(f,p)!=1:continue
            for label in block["fields"]:
                d,e,length=local_orbit_data(label,p)
                assert e==1 and d%length==0
                cycles.extend([(f,length)]*(d//length))
        local.append((p,h,tuple(sorted(cycles))))
    return local


def independent_decision(record):
    local=independent_prime_data(record);F=N//record["double_degree"]
    if not local:return"NOT_APPLICABLE",None,[],local
    failures=[];new_survivor=False;old_survivor=False
    for ram in record["matrix_ramification_classes"]:
        bad=[];old_bad=False
        for p,h,cycles in local:
            if not equivariant_matching_possible(F,p,cycles,p in ram):bad.append(p)
            if not equivariant_matching_possible(F,p,cycles,p in ram and h%2==1):old_bad=True
        if not bad:new_survivor=True
        if not old_bad:old_survivor=True
        failures.append((tuple(ram),bad))
    if new_survivor:return"OPEN",None,failures,local
    return"EXCLUDED",("singleton_Brauer_descent"if old_survivor else"Frobenius_cycle_matching"),failures,local


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--inputs",type=Path,default=HERE/"normalized_open")
    ap.add_argument("--baseline",type=Path,default=HERE/"full_sweep")
    ap.add_argument("--sweep",type=Path,default=HERE/"frobenius_sweep")
    ap.add_argument("--output",type=Path,default=HERE/"frobenius_independent_audit.json")
    args=ap.parse_args();start=time.monotonic();inp=args.inputs;old=args.baseline;s=args.sweep
    m=json.loads((inp/"manifest.json").read_text());summary=json.loads((s/"summary.json").read_text())
    baseline=json.loads((old/"summary.json").read_text());base_audit=json.loads((HERE/"independent_full_audit.json").read_text())
    assert base_audit["status"]=="PASS_INDEPENDENT_COMPLETE_CORNER_REPLAY"
    assert base_audit["auditor_sha256"]==sha(HERE/"audit_corner_sweep.py")
    assert base_audit["producer_summary_sha256"]==sha(old/"summary.json")==summary["baseline_summary_sha256"]
    assert sha(inp/"manifest.json")==base_audit["input_manifest_sha256"]==summary["input_manifest_sha256"]
    for name,digest in summary["source_sha256"].items():assert sha(HERE/name)==digest
    assert sha(s/"incremental_exclusions.jsonl.gz")==summary["excluded_gzip_sha256"]
    old_ids=gzip.open(old/"remaining_open_ids.jsonl.gz","rb")
    certificates=gzip.open(s/"incremental_exclusions.jsonl.gz","rb")
    bh=hashlib.sha256();eh=hashlib.sha256();rh=hashlib.sha256();ih=hashlib.sha256()
    def next_old():
        line=old_ids.readline()
        if not line:return None
        bh.update(line);return json.loads(line)
    def next_cert():
        line=certificates.readline()
        if not line:return None
        eh.update(line);return json.loads(line)
    current=next_old();certificate=next_cert();count=0;total=0;counts=Counter();stages=Counter();by_kind=Counter()
    for chunk in m["chunks"]:
        p=inp/chunk["file"];assert sha(p)==chunk["sha256"];ch=hashlib.sha256()
        with gzip.open(p,"rb")as f:
            for line in f:
                ih.update(line);ch.update(line);r=json.loads(line);assert r["open_index"]==total;total+=1
                if current is None or r["state"]<current["state"]:continue
                identity={k:r[k]for k in("state","open_index","index","double_degree","assignment_index","kind")}
                assert identity==current;count+=1
                result,stage,failures,local=independent_decision(r)
                counts[result]+=1;by_kind[(r["kind"],result)]+=1
                if result=="EXCLUDED":
                    assert certificate is not None and all(certificate[k]==v for k,v in identity.items())
                    assert certificate["normalized_input_sha256"]==hashlib.sha256(line).hexdigest()
                    assert certificate["source_sha256"]==summary["source_sha256"]
                    assert certificate["stage"]==stage;stages[stage]+=1
                    claims=certificate["certificate"]["failures"];assert len(claims)==len(failures)
                    for claim,(ram,bad)in zip(claims,failures):
                        assert tuple(claim["matrix_ramification"])==ram and claim["prime"]in bad
                        p=claim["prime"];lp=next(x for x in local if x[0]==p)
                        assert claim["common_unramified_degree"]==lp[1]
                        assert claim["quaternion_ramified_over_Qp"]==(p in ram)
                        bins=Counter(((f//p)%p,length)for f,length in lp[2])
                        expected=[[u,length,n]for(u,length),n in sorted(bins.items())]
                        assert claim["valuation_one_frobenius_cycles"]==expected
                        assert claim["matrix_codegree"]==N//r["double_degree"]
                    certificate=next_cert()
                else:
                    assert certificate is None or certificate["state"]>r["state"]
                    rh.update(canonical(identity))
                current=next_old()
        assert ch.hexdigest()==chunk["uncompressed_sha256"]
        print("equivariant matchings replayed",count,"counts",dict(counts),"seconds",round(time.monotonic()-start,2),flush=True)
    assert current is None and next_old()is None and certificate is None and next_cert()is None
    old_ids.close();certificates.close();assert count==611949 and total==976867
    assert counts==Counter(summary["statuses"])and stages==Counter(summary["terminal_incremental_stages"])
    assert ih.hexdigest()==m["normalized_uncompressed_sha256"]
    assert bh.hexdigest()==baseline["remaining_uncompressed_sha256"]
    assert eh.hexdigest()==summary["excluded_uncompressed_sha256"]and rh.hexdigest()==summary["remaining_uncompressed_sha256"]
    actual=hashlib.sha256()
    with gzip.open(s/"remaining_open_ids.jsonl.gz","rb")as f:
        for b in iter(lambda:f.read(1048576),b""):actual.update(b)
    assert actual.hexdigest()==rh.hexdigest()
    report=dict(status="PASS_INDEPENDENT_COMPLETE_FROBENIUS_CORNER_REPLAY",records=count,statuses=dict(counts),
        terminal_incremental_stages=dict(stages),
        counts_by_kind_status=[dict(kind=k,status=st,states=n)for(k,st),n in sorted(by_kind.items())],
        matching_cache=equivariant_matching_possible.cache_info()._asdict(),
        input_manifest_sha256=sha(inp/"manifest.json"),producer_summary_sha256=sha(s/"summary.json"),
        base_independent_audit_sha256=sha(HERE/"independent_full_audit.json"),
        excluded_uncompressed_sha256=eh.hexdigest(),remaining_uncompressed_sha256=rh.hexdigest(),
        source_sha256={name:sha(HERE/name)for name in("audit_frobenius_sweep.py","audit_corner_sweep.py")},
        seconds=time.monotonic()-start,maximum_resident_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    args.output.write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2),flush=True)


if __name__=="__main__":main()
