"""Frobenius-equivariant corner matching with singleton Brauer descent.

This is a separate refinement of the frozen unramified corner gate.  A
singleton reduction-class orbit of length l has its rank-one idempotent over
the unramified degree-l field.  Hence a quaternion ramified over Q_p requires
l even, even if a larger common extension happens to split it.
"""
from collections import Counter
from corner_gate import (linear_data, eligibility, valuation, _local_tuple,
                         _matrix_classes)

RULE_VERSION="frobenius-corner-descent-v1"


def cycle_bins(record,p):
    counts=Counter()
    for block in record["assignment"]["fields"]:
        f=block["formal_codegree"]
        if valuation(f,p)!=1:continue
        u=(f//p)%p
        for label in block["fields"]:
            degree,e,length,conductor,inertia=_local_tuple(label,p)
            if e!=1:raise ValueError("Cycle matching requires an eligible prime.")
            assert degree%length==0
            counts[(u,length)]+=degree//length
    return tuple((u,length,n)for(u,length),n in sorted(counts.items()))


def cycles_balanced(bins,p):
    if p==2:
        return all(length%2==0 or n%2==0 for(u,length),n in bins.items())
    return all(n==bins.get((p-u,length),0)for(u,length),n in bins.items())


def allowed_deletions(bins,F,p,base_ramified=False):
    """Invariant singleton sets have size0,1,2: whole cycles only."""
    counts={(u,length):n for u,length,n in bins}
    allowed=[]
    if cycles_balanced(counts,p):allowed.append(())
    if valuation(F,p)!=1:return tuple(allowed)
    u=(-(F//p))%p
    # Each entry below specifies (cycle length, number of deleted cycles).
    possibilities=[(2,1)]
    if not base_ramified:possibilities=[(1,1),(1,2)]+possibilities
    for length,multiplicity in possibilities:
        if counts.get((u,length),0)<multiplicity:continue
        rest=dict(counts);rest[(u,length)]-=multiplicity
        if cycles_balanced(rest,p):allowed.append(((u,length,multiplicity),))
    return tuple(allowed)


def corner_extension(record,base_decision=None):
    if base_decision is not None and base_decision["status"]=="EXCLUDED":
        raise ValueError("This incremental extension is applied after the base gate.")
    codegrees,labels,F=linear_data(record)
    local=eligibility(record);eligible=[x for x in local if x["eligible"]]
    classes,source=_matrix_classes(record,F)
    common=dict(gate=RULE_VERSION,rule_version=RULE_VERSION,
        eligible_primes=[x["prime"]for x in eligible],eligibility=local,
        matrix_context_source=source,
        counters=dict(linear_embeddings=len(codegrees),matrix_alternatives=len(classes)))
    if not eligible:return dict(common,status="NOT_APPLICABLE",witness=None)
    cycles={x["prime"]:cycle_bins(record,x["prime"])for x in eligible}
    failures=[];surviving=[]
    for ram in classes:
        failure=None
        for item in eligible:
            p=item["prime"];bins=cycles[p]
            permitted=allowed_deletions(bins,F,p,p in ram)
            if not permitted:
                failure=dict(matrix_ramification=list(ram),prime=p,
                    common_unramified_degree=item["common_unramified_degree"],
                    quaternion_ramified_over_Qp=(p in ram),matrix_codegree=F,
                    matrix_codegree_valuation=valuation(F,p),
                    valuation_one_frobenius_cycles=[list(x)for x in bins],
                    admissible_invariant_singleton_deletions=[])
                break
        if failure is None:surviving.append(list(ram))
        else:failures.append(failure)
    if surviving:return dict(common,status="OPEN",witness=None,
        surviving_matrix_ramification_classes=surviving)
    return dict(common,status="EXCLUDED",witness=dict(
        kind="frobenius_equivariant_corner_failure",failures=failures,
        full_field_labels=list(labels)))
