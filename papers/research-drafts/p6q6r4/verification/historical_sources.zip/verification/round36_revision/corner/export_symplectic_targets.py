#!/usr/bin/env python3
"""Export original complete R36 records for every corner-surviving S state."""
from pathlib import Path
from collections import Counter
import argparse,gzip,hashlib,json

HERE=Path(__file__).resolve().parent


def sha(path):
    h=hashlib.sha256()
    with path.open("rb")as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--sweep",type=Path,default=HERE/"full_sweep")
    ap.add_argument("--base",type=Path,default=HERE.parents[1]/"round36"/"deliverable"/
        "p6q6r4_Round36"/"verification"/"round36"/"one_matrix16")
    args=ap.parse_args();s=args.sweep;summary=json.loads((s/"summary.json").read_text())
    selected=set();rh=hashlib.sha256()
    with gzip.open(s/"remaining_open_ids.jsonl.gz","rb")as f:
        for line in f:
            rh.update(line);x=json.loads(line)
            if x["kind"]=="symplectic":selected.add(x["state"])
    assert len(selected)==1565 and 836343 in selected
    assert rh.hexdigest()==summary["remaining_uncompressed_sha256"]
    source=args.base/"rank16_symplectic_input.jsonl.gz"
    target=s/"symplectic_target_records.jsonl.gz";ih=hashlib.sha256();oh=hashlib.sha256();ids=hashlib.sha256()
    found=set();counts=Counter();original_count=0
    with target.open("wb")as raw:
        with gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0)as out:
            with gzip.open(source,"rb")as inp:
                for line in inp:
                    ih.update(line);r=json.loads(line);original_count+=1
                    if r["state"]not in selected:continue
                    assert r["kind"]=="symplectic"and r["state"]not in found
                    found.add(r["state"]);counts[5400//r["double_degree"]]+=1
                    out.write(line);oh.update(line);ids.update((str(r["state"])+"\n").encode())
    assert original_count==67041 and found==selected
    assert ih.hexdigest()=="e2e0613c754334877d7c83ef1f7489b61d5b2f7bd63cdc688b5949f241e37d7e"
    report=dict(status="PASS_COMPLETE_CORNER_SURVIVING_SYMPLECTIC_TARGETS",
        records=len(found),scope="After the complete corner sweep; before the separate state836343 graph exclusion.",
        original_record_schema_preserved=True,state836343_included=True,
        counts_by_matrix_formal_codegree=[dict(f=f,states=n)for f,n in sorted(counts.items())],
        file=target.name,bytes=target.stat().st_size,sha256=sha(target),
        uncompressed_sha256=oh.hexdigest(),state_ids_sha256=ids.hexdigest(),
        original_symplectic_records=original_count,
        original_symplectic_input_gzip_sha256=sha(source),
        original_symplectic_input_uncompressed_sha256=ih.hexdigest(),
        corner_remaining_uncompressed_sha256=rh.hexdigest(),
        corner_summary_sha256=sha(s/"summary.json"),producer_sha256=sha(Path(__file__)))
    (s/"symplectic_target_manifest.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":main()
