"""Exact one-M2 reconstruction and bounded finite-pool character alignment.

The formulas are Theorem 9.172 (label r34:one-matrix-reconstruction) and
its codegree/volume corollaries in the immutable Round36 manuscript.

The central API accepts rational moments of COMPLETE Galois orbits, not
only rational individual characters. A separate exact field backend may
produce these moments. The convenience character-row and finite-pool
frontends currently accept rational individual values only. Unsupported
algebraic entries remain OPEN; they never produce an exclusion.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
from itertools import combinations
import json
from math import isfinite, isqrt, prod
from pathlib import Path
import re
import time
from typing import Any

from verifier import canonical_sha256, validate_basis, verify_table

THEOREM = "Round36 Theorem 9.172; r34:one-matrix-reconstruction"
RATIONAL = re.compile(r"[+-]?\d+(?:/[+-]?\d+)?\Z")


class UnsupportedField(ValueError):
    pass


def rational(value: Any) -> Fraction:
    if type(value) is int:
        return Fraction(value)
    if isinstance(value, str) and RATIONAL.fullmatch(value):
        try:
            return Fraction(value)
        except (ValueError, ZeroDivisionError) as exc:
            raise ValueError("Invalid exact rational") from exc
    if (isinstance(value, dict) and set(value) == {"numerator", "denominator"}
            and type(value["numerator"]) is int and type(value["denominator"]) is int):
        try:
            return Fraction(value["numerator"], value["denominator"])
        except ZeroDivisionError as exc:
            raise ValueError("Zero denominator") from exc
    if isinstance(value, (str, dict, list)):
        raise UnsupportedField("Use exact complete orbit moments for algebraic character values")
    raise ValueError("An exact rational must be an integer or a p/q string; floats are not exact input")


def exact_json(x: Fraction | int) -> int | str:
    x = Fraction(x)
    return x.numerator if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def _result(status: str, reason: str, witness: dict | None = None, **extra) -> dict:
    return {"schema": "one-m2-reconstruction-v1", "status": status,
            "reason": reason, "theorem": THEOREM,
            "scope": "the specified complete aligned character or moment data only",
            "global_dimension_or_type_exclusion": False,
            "categorification_established": False,
            "witness": witness or {}, **extra}


def _parse_error(exc: Exception) -> dict:
    if isinstance(exc, UnsupportedField):
        return _result("OPEN_UNSUPPORTED_FIELD", "EXACT_FIELD_BACKEND_REQUIRED",
                       {"detail": str(exc)}, search_complete=False,
                       retained_for_future_field_backend=True)
    return _result("INVALID_INPUT", "MALFORMED_EXACT_INPUT", {"detail": str(exc)})


def _rank(matrix: list[list[Fraction]]) -> int:
    if not matrix:
        return 0
    a = [list(map(Fraction, row)) for row in matrix]
    row = 0
    for col in range(len(a[0])):
        pivot = next((i for i in range(row, len(a)) if a[i][col]), None)
        if pivot is None:
            continue
        a[row], a[pivot] = a[pivot], a[row]
        scale = a[row][col]
        a[row] = [x / scale for x in a[row]]
        for i in range(row + 1, len(a)):
            if a[i][col]:
                scale = a[i][col]
                a[i] = [x - scale * y for x, y in zip(a[i], a[row])]
        row += 1
        if row == len(a):
            break
    return row


def _det3(a: list[list[Fraction]]) -> Fraction:
    return (a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
            - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
            + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]))


def _inverse3(a: list[list[Fraction]]) -> list[list[Fraction]]:
    determinant = _det3(a)
    if not determinant:
        raise ValueError("Singular three-dimensional Gram block")
    answer = [[Fraction(0) for _ in range(3)] for _ in range(3)]
    for i in range(3):
        for j in range(3):
            rows = [r for r in range(3) if r != j]
            cols = [c for c in range(3) if c != i]
            minor = a[rows[0]][cols[0]] * a[rows[1]][cols[1]] - a[rows[0]][cols[1]] * a[rows[1]][cols[0]]
            answer[i][j] = ((-1) ** (i + j)) * minor / determinant
    return answer


def _matrix(value: Any, n: int, label: str) -> list[list[Fraction]]:
    if not isinstance(value, list) or len(value) != n:
        raise ValueError(f"{label} must have shape {n} by {n}")
    if any(not isinstance(row, list) or len(row) != n for row in value):
        raise ValueError(f"{label} must have shape {n} by {n}")
    return [[rational(x) for x in row] for row in value]


def reconstruct_from_moments(payload: Any, *, target_dimension: int | None = 5400,
                             require_fusion_simple: bool = True,
                             min_nonunit_dimension: int | None = 3) -> dict:
    """Reconstruct from complete rational linear-character orbit moments.

    P[X][Y] = sum_lambda lambda(X) conjugate(lambda(Y)) / f_lambda.
    T[X][Y][Z] = sum_lambda lambda(X)lambda(Y)conjugate(lambda(Z))/f_lambda.
    The sum includes every linear character, including Perron, exactly once.
    JSON entries are integers or exact p/q strings. No field-degree assumption
    is made in this API. Its provenance must supply complete orbit sums.
    """
    basis, error = validate_basis(payload)
    if error:
        error["scope"] = "the specified aligned source basis only"
        return error
    assert basis is not None
    n, unit = basis["rank"], basis["unit"]
    star, dims = basis["duality"], basis["dimensions"]
    if n < 5:
        return _result("EXCLUDED", "ONE_M2_REQUIRES_A_PERRON_LINEAR_COMPONENT",
                       {"rank": n})
    try:
        P = _matrix(payload.get("linear_pair_moments"), n, "linear_pair_moments")
        raw_T = payload.get("linear_triple_moments")
        if not isinstance(raw_T, list) or len(raw_T) != n:
            raise ValueError("linear_triple_moments must have shape n by n by n")
        T = [_matrix(x, n, "linear_triple_moments slice") for x in raw_T]
        supplied_f = (rational(payload["matrix_codegree"])
                      if payload.get("matrix_codegree") is not None else None)
    except (ValueError, ZeroDivisionError) as exc:
        return _parse_error(exc)
    for i in range(n):
        for j in range(n):
            if P[i][j] != P[j][i] or P[star[i]][star[j]] != P[i][j]:
                return _result("EXCLUDED", "PAIR_MOMENT_SYMMETRY_OR_DUALITY",
                               {"indices": [i, j]})
            square = sum(P[i][a] * P[a][j] for a in range(n))
            if square != P[i][j]:
                return _result("EXCLUDED", "LINEAR_PROJECTOR_NOT_IDEMPOTENT",
                               {"indices": [i, j], "square": exact_json(square),
                                "entry": exact_json(P[i][j])})
        perron = sum(P[i][j] * dims[j] for j in range(n))
        if perron != dims[i]:
            return _result("EXCLUDED", "PERRON_VECTOR_NOT_IN_LINEAR_SUBSPACE",
                           {"index": i, "projected": exact_json(perron),
                            "required": dims[i]})
    linear_rank = _rank(P)
    if linear_rank != n - 4:
        return _result("EXCLUDED", "WRONG_LINEAR_PROJECTOR_RANK",
                       {"actual": linear_rank, "required": n - 4})
    denominator = 1 - P[unit][unit]
    if denominator <= 0:
        return _result("EXCLUDED", "NONPOSITIVE_MATRIX_CODEGREE_DENOMINATOR",
                       {"denominator": exact_json(denominator)})
    f = 2 / denominator
    if f.denominator != 1 or f <= 0:
        return _result("EXCLUDED", "MATRIX_CODEGREE_NOT_POSITIVE_INTEGER",
                       {"recovered": exact_json(f)})
    if supplied_f is not None and supplied_f != f:
        return _result("EXCLUDED", "MATRIX_CODEGREE_MISMATCH",
                       {"supplied": exact_json(supplied_f), "recovered": exact_json(f)})
    # These are necessary identities of the complete linear-orbit moments.
    # They are checked exactly; no numerical orthogonality tolerance is used.
    for i in range(n):
        for j in range(n):
            if T[unit][i][j] != P[i][j]:
                return _result("EXCLUDED", "TRIPLE_MOMENT_UNIT_IDENTITY",
                               {"indices": [i, j]})
            for k in range(n):
                value = T[i][j][k]
                if (value != T[j][i][k]
                        or value != T[star[i]][star[j]][star[k]]
                        or value != T[star[i]][k][j]
                        or value != T[k][star[j]][i]):
                    return _result("EXCLUDED", "TRIPLE_MOMENT_SYMMETRY_OR_RECIPROCITY",
                                   {"indices": [i, j, k]})
                projected = sum(P[i][a] * T[a][j][k] for a in range(n))
                if projected != value:
                    return _result("EXCLUDED", "TRIPLE_MOMENT_OUTSIDE_LINEAR_SUBSPACE",
                                   {"indices": [i, j, k], "projected": exact_json(projected),
                                    "value": exact_json(value)})
    K = [[f * (int(i == j) - P[i][j]) for j in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            if K[i][j].denominator != 1:
                return _result("EXCLUDED", "NONINTEGRAL_MATRIX_GRAM",
                               {"indices": [i, j], "value": exact_json(K[i][j])})
    s = [K[i][unit] for i in range(n)]
    H = [[2 * K[i][star[j]] - s[i] * s[j] for j in range(n)] for i in range(n)]
    rank_K, rank_H = _rank(K), _rank(H)
    if rank_K != 4 or rank_H != 3:
        return _result("EXCLUDED", "MATRIX_OR_PURE_GRAM_RANK",
                       {"rank_K": rank_K, "rank_H": rank_H})
    triple = None
    block = None
    for indices in combinations(range(n), 3):
        block = [[H[i][j] for j in indices] for i in indices]
        if _det3(block):
            triple = indices
            break
    if triple is None or block is None:
        return _result("EXCLUDED", "NO_NONSINGULAR_PURE_TRIPLE", {})
    radicand = -_det3(block)
    if radicand.denominator != 1 or radicand <= 0:
        return _result("EXCLUDED", "VOLUME_SQUARE_NOT_POSITIVE_INTEGER",
                       {"basis_triple": list(triple), "negative_determinant": exact_json(radicand)})
    q = isqrt(radicand.numerator)
    if q * q != radicand:
        return _result("EXCLUDED", "VOLUME_SQUARE_NOT_SQUARE",
                       {"basis_triple": list(triple), "negative_determinant": exact_json(radicand)})
    inverse = _inverse3(block)
    coordinates = [[sum(inverse[a][b] * H[triple[b]][i] for b in range(3))
                    for a in range(3)] for i in range(n)]
    volumes = {}
    for indices in combinations(range(n), 3):
        omega = q * _det3([coordinates[i] for i in indices])
        # Omega/(2f) is N_XY^{Z*} - N_YX^{Z*}, hence integral for
        # any possible integer reconstruction in either orientation.
        commutator = omega / (2 * f)
        if commutator.denominator != 1:
            return _result("EXCLUDED", "NONINTEGRAL_COMMUTATOR_VOLUME",
                           {"indices": list(indices), "omega": exact_json(omega),
                            "omega_over_2f": exact_json(commutator)})
        volumes[indices] = omega

    def volume(i: int, j: int, k: int) -> Fraction:
        if i == j or i == k or j == k:
            return Fraction(0)
        sign = -1 if ((i > j) + (i > k) + (j > k)) % 2 else 1
        return sign * volumes[tuple(sorted((i, j, k)))]

    table = [[[0] * n for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                z = star[k]
                nonlinear = (s[i] * s[j] * s[z] + s[i] * H[j][z]
                             + s[j] * H[i][z] + s[z] * H[i][j]
                             + volume(i, j, z)) / (4 * f)
                coefficient = T[i][j][k] + nonlinear
                if coefficient.denominator != 1 or coefficient < 0:
                    return _result("EXCLUDED", "RECONSTRUCTED_COEFFICIENT_NOT_NONNEGATIVE_INTEGER",
                                   {"indices": [i, j, k], "linear_part": exact_json(T[i][j][k]),
                                    "matrix_part": exact_json(nonlinear),
                                    "coefficient": exact_json(coefficient)},
                                   orientations_tested=1,
                                   other_orientation_is_transposed_multiplication=True)
                table[i][j][k] = coefficient.numerator
    candidate = {"unit": unit, "duality": star, "dimensions": dims,
                 "labels": basis["labels"], "multiplication": table}
    verification = verify_table(candidate, target_dimension=target_dimension,
                                require_fusion_simple=require_fusion_simple,
                                min_nonunit_dimension=min_nonunit_dimension)
    result = _result(verification["status"],
                     "ONE_M2_TABLE_RECONSTRUCTED_AND_CHECKED" if verification["status"] == "VERIFIED"
                     else "RECONSTRUCTED_TABLE_FAILED_VERIFIER_OR_TARGET",
                     verification.get("witness", {}),
                     input_kind="complete rational linear-orbit moments",
                     matrix_codegree=exact_json(f), linear_character_count=n - 4,
                     rank_K=rank_K, rank_H=rank_H,
                     volume_basis=list(triple), volume_on_basis=q,
                     orientations_tested=1,
                     other_orientation_is_transposed_multiplication=True,
                     reconstructed_table=candidate, verification=verification)
    if "moments_provenance" in payload:
        result["moments_provenance"] = payload["moments_provenance"]
    return result


def rational_character_moments(payload: Any) -> dict:
    """Validate a COMPLETE rational character table and return its moments.

    linear_characters[a][i] is the value of character a on source label i.
    This frontend rejects nonintegral rational eigenvalues and returns OPEN
    for algebraic-field encodings it does not implement.
    """
    basis, error = validate_basis(payload)
    if error:
        return error
    assert basis is not None
    n, unit = basis["rank"], basis["unit"]
    rows = payload.get("linear_characters")
    if n < 5 or not isinstance(rows, list) or len(rows) != n - 4:
        return _result("INVALID_INPUT", "COMPLETE_LINEAR_TABLE_SHAPE",
                       {"required_characters": n - 4, "rank": n})
    try:
        if any(not isinstance(row, list) or len(row) != n for row in rows):
            raise ValueError("Every character row must have one entry per source label")
        rows = [[rational(x) for x in row] for row in rows]
        supplied = payload.get("linear_codegrees")
        if supplied is not None:
            if not isinstance(supplied, list) or len(supplied) != len(rows):
                raise ValueError("linear_codegrees length must equal n-4")
            supplied = [rational(x) for x in supplied]
    except (ValueError, ZeroDivisionError) as exc:
        return _parse_error(exc)
    for a, row in enumerate(rows):
        if row[unit] != 1:
            return _result("EXCLUDED", "LINEAR_CHARACTER_UNIT_VALUE", {"character": a})
        for i, value in enumerate(row):
            if value.denominator != 1:
                return _result("EXCLUDED", "NONINTEGRAL_RATIONAL_CHARACTER_VALUE",
                               {"character": a, "source": i, "value": exact_json(value)})
            if value != row[basis["duality"][i]]:
                return _result("EXCLUDED", "RATIONAL_CHARACTER_DUALITY", {"character": a, "source": i})
            if abs(value) > basis["dimensions"][i]:
                return _result("EXCLUDED", "CHARACTER_EXCEEDS_PERRON_BOUND", {"character": a, "source": i})
    if [Fraction(d) for d in basis["dimensions"]] not in rows:
        return _result("EXCLUDED", "PERRON_CHARACTER_MISSING", {})
    codegrees = [sum(x * x for x in row) for row in rows]
    if supplied is not None and supplied != codegrees:
        return _result("EXCLUDED", "LINEAR_CODEGREES_MISMATCH",
                       {"supplied": [exact_json(x) for x in supplied],
                        "recovered": [exact_json(x) for x in codegrees]})
    for a in range(len(rows)):
        for b in range(a):
            inner = sum(x * y for x, y in zip(rows[a], rows[b]))
            if inner:
                return _result("EXCLUDED", "LINEAR_CHARACTERS_NOT_ORTHOGONAL",
                               {"characters": [a, b], "inner_product": exact_json(inner)})
    P = [[sum(rows[a][i] * rows[a][j] / codegrees[a] for a in range(len(rows)))
          for j in range(n)] for i in range(n)]
    T = [[[sum(rows[a][i] * rows[a][j] * rows[a][k] / codegrees[a]
               for a in range(len(rows))) for k in range(n)] for j in range(n)] for i in range(n)]
    out = {"unit": unit, "duality": basis["duality"], "dimensions": basis["dimensions"],
           "labels": basis["labels"],
           "linear_pair_moments": [[exact_json(x) for x in row] for row in P],
           "linear_triple_moments": [[[exact_json(x) for x in row] for row in mat] for mat in T],
           "moments_provenance": {"backend": "complete rational character rows",
                                  "character_count": len(rows),
                                  "linear_codegrees": [exact_json(x) for x in codegrees],
                                  "aligned_character_table_sha256": canonical_sha256(payload)}}
    if "matrix_codegree" in payload:
        out["matrix_codegree"] = payload["matrix_codegree"]
    return {"status": "MOMENTS_READY", "moments": out}


def reconstruct_one_m2(payload: Any, **target) -> dict:
    prepared = rational_character_moments(payload)
    if prepared["status"] != "MOMENTS_READY":
        return prepared
    return reconstruct_from_moments(prepared["moments"], **target)


def search_alignments(payload: Any, *, max_nodes: int | None = 1000, max_results: int = 1,
                      start_index: int = 0, time_limit: float | None = None,
                      target_dimension: int | None = 5400,
                      require_fusion_simple: bool = True,
                      min_nonunit_dimension: int | None = 3,
                      witness_limit: int = 32, event_sink=None) -> dict:
    """Bounded deterministic alignment of finite SUPPLIED rational row pools.

    row_pools[i] contains candidate vectors of all n-4 globally ordered
    linear-character values on source label i. linear_codegrees is required.
    The Perron character column is perron_column (default 0). Dual pairs use
    the intersection of their pools, since these frontend values are real.

    next_index is an index in the documented sorted, deduplicated, locally
    filtered dual-orbit product grid. A node is one decoded grid index;
    rigorous prefix interval bounds may advance over an entire subtree.
    Budgets are checked between nodes, never inside an atomic reconstruction.
    A complete finite-pool failure is not an exclusion of unsupplied rows.
    """
    began = time.monotonic()
    if ((max_nodes is not None and (type(max_nodes) is not int or max_nodes < 0)) or type(max_results) is not int
            or max_results < 1 or type(start_index) is not int or start_index < 0
            or type(witness_limit) is not int or witness_limit < 0
            or (time_limit is not None and (isinstance(time_limit, bool)
                or not isinstance(time_limit, (int, float)) or not isfinite(time_limit) or time_limit < 0))
            or (event_sink is not None and not callable(event_sink))):
        return _result("INVALID_INPUT", "INVALID_SEARCH_BOUND", {})
    basis, error = validate_basis(payload)
    if error:
        return error
    assert basis is not None
    n, unit, star, dims = basis["rank"], basis["unit"], basis["duality"], basis["dimensions"]
    ell = n - 4
    perron = payload.get("perron_column", 0)
    try:
        if ell < 1 or type(perron) is not int or not 0 <= perron < ell:
            raise ValueError("The one-M2 pool needs n-4 positive character columns")
        raw = payload.get("row_pools")
        codegrees = payload.get("linear_codegrees")
        if not isinstance(raw, list) or len(raw) != n:
            raise ValueError("row_pools must have one finite candidate list per source label")
        if not isinstance(codegrees, list) or len(codegrees) != ell:
            raise ValueError("linear_codegrees must contain n-4 exact values")
        codegrees = [rational(x) for x in codegrees]
        if any(f <= 0 for f in codegrees):
            raise ValueError("All supplied linear codegrees must be positive")
        parsed = []
        for pool in raw:
            if not isinstance(pool, list):
                raise ValueError("Each row pool must be a finite list")
            if any(not isinstance(row, list) or len(row) != ell for row in pool):
                raise ValueError("Each pooled row must contain n-4 globally aligned values")
            parsed.append(sorted(set(tuple(rational(x) for x in row) for row in pool)))
    except (ValueError, ZeroDivisionError) as exc:
        return _parse_error(exc)
    denominator = 1 - sum(1 / f for f in codegrees)
    if denominator <= 0:
        return _result("EXCLUDED", "POOL_CODEGREES_IMPOSSIBLE", {},
                       exclusion_scope="the supplied finite row pools only",
                       complete=True, next_index=0, total_assignments=0)
    f = 2 / denominator
    if f.denominator != 1:
        return _result("EXCLUDED", "POOL_MATRIX_CODEGREE_NONINTEGRAL",
                       {"matrix_codegree": exact_json(f)},
                       exclusion_scope="the supplied finite row pools only",
                       complete=True, next_index=0, total_assignments=0)
    if "matrix_codegree" in payload:
        try:
            supplied_f = rational(payload["matrix_codegree"])
        except (ValueError, ZeroDivisionError) as exc:
            return _parse_error(exc)
        if supplied_f != f:
            return _result("EXCLUDED", "POOL_MATRIX_CODEGREE_MISMATCH", {},
                           exclusion_scope="the supplied finite row pools only",
                           complete=True, next_index=0, total_assignments=0)
    orbits = []
    seen = set()
    removed = {}
    local_rejections = []
    input_hash = canonical_sha256(payload)
    for i in range(n):
        if i in seen:
            continue
        orbit = sorted({i, star[i]})
        seen.update(orbit)
        pool = set(parsed[orbit[0]])
        for j in orbit[1:]:
            pool &= set(parsed[j])
        allowed = []
        for row in sorted(pool):
            reason = None
            if i == unit and row != (Fraction(1),) * ell:
                reason = "unit_row"
            elif row[perron] != dims[i]:
                reason = "perron_value"
            elif any(x.denominator != 1 or abs(x) > dims[i] for x in row):
                reason = "rational_integrality_or_perron_bound"
            else:
                trace = f * (int(i == unit) - sum(row[a] / codegrees[a] for a in range(ell)))
                gram = f * (1 - sum(row[a] ** 2 / codegrees[a] for a in range(ell)))
                if trace.denominator != 1 or gram.denominator != 1 or gram < 0 or 2 * gram < trace * trace:
                    reason = "matrix_column_budget"
            if reason:
                removed[reason] = removed.get(reason, 0) + 1
                entry = {"event_type": "alignment_row_filter", "source_orbit": orbit,
                         "input_sha256": input_hash,
                         "row": [exact_json(x) for x in row], "reason": reason,
                         "status": "EXCLUDED_ROW"}
                entry["event_id"] = canonical_sha256(entry)
                local_rejections.append(entry)
                if event_sink is not None:
                    event_sink(entry)
            else:
                allowed.append(row)
        orbits.append((orbit, allowed))
    sizes = [len(pool) for orbit, pool in orbits]
    total = prod(sizes)
    if start_index > total:
        return _result("INVALID_INPUT", "RESUME_INDEX_OUTSIDE_POOL_GRID",
                       {"start_index": start_index, "total_assignments": total})
    grid = [{"source_orbit": orbit,
             "rows": [[exact_json(x) for x in row] for row in pool]}
            for orbit, pool in orbits]
    grid_hash = canonical_sha256({"orbits": grid, "codegrees": [exact_json(x) for x in codegrees],
                                  "basis": basis, "perron_column": perron})
    suffix_size = [1] * (len(orbits) + 1)
    for a in range(len(orbits) - 1, -1, -1):
        suffix_size[a] = sizes[a] * suffix_size[a + 1]
    pairs = [(a, b) for a in range(ell) for b in range(a, ell)]
    targets = [codegrees[a] if a == b else Fraction(0) for a, b in pairs]
    low = [[Fraction(0)] * len(pairs) for _ in range(len(orbits) + 1)]
    high = [[Fraction(0)] * len(pairs) for _ in range(len(orbits) + 1)]
    if total:
        for depth in range(len(orbits) - 1, -1, -1):
            orbit, pool = orbits[depth]
            for c, (a, b) in enumerate(pairs):
                choices = [len(orbit) * row[a] * row[b] for row in pool]
                low[depth][c] = low[depth + 1][c] + min(choices)
                high[depth][c] = high[depth + 1][c] + max(choices)
    cursor, nodes, leaves, reconstruction_count = start_index, 0, 0, 0
    solutions, witnesses, histogram = [], [], {}
    ledger = hashlib.sha256()
    stop = "pool_end"
    unresolved_reconstruction = None
    while cursor < total:
        if max_nodes is not None and nodes >= max_nodes:
            stop = "node_budget"
            break
        if time_limit is not None and time.monotonic() - began >= time_limit:
            stop = "time_budget"
            break
        indices = [(cursor // suffix_size[a + 1]) % sizes[a] for a in range(len(orbits))]
        accum = [Fraction(0)] * len(pairs)
        selected = [None] * n
        failure = None
        next_cursor = cursor + 1
        nodes += 1
        for depth, ((orbit, pool), choice) in enumerate(zip(orbits, indices)):
            row = pool[choice]
            for source in orbit:
                selected[source] = row
            for c, (a, b) in enumerate(pairs):
                accum[c] += len(orbit) * row[a] * row[b]
            for c, target in enumerate(targets):
                lower = accum[c] + low[depth + 1][c]
                upper = accum[c] + high[depth + 1][c]
                if not lower <= target <= upper:
                    block = suffix_size[depth + 1]
                    next_cursor = min(total, (cursor // block + 1) * block)
                    failure = {"reason": "COMMON_CHARACTER_ORTHOGONALITY_INTERVAL",
                               "prefix_depth": depth + 1, "character_pair": list(pairs[c]),
                               "target": exact_json(target), "reachable_interval": [exact_json(lower), exact_json(upper)]}
                    break
            if failure:
                break
        if failure is None:
            leaves += 1
            table_payload = {"unit": unit, "duality": star, "dimensions": dims,
                             "labels": basis["labels"],
                             "linear_codegrees": [exact_json(x) for x in codegrees],
                             "matrix_codegree": exact_json(f),
                             "linear_characters": [[exact_json(selected[i][a]) for i in range(n)]
                                                   for a in range(ell)]}
            reconstructed = reconstruct_one_m2(table_payload,
                target_dimension=target_dimension, require_fusion_simple=require_fusion_simple,
                min_nonunit_dimension=min_nonunit_dimension)
            reconstruction_count += 1
            if reconstructed.get("status") not in ("VERIFIED", "EXCLUDED"):
                # Keep the exact grid cursor pending. An unsupported or
                # malformed backend result does not eliminate this assignment.
                nodes -= 1
                leaves -= 1
                reconstruction_count -= 1
                unresolved_reconstruction = {"grid_index": cursor, "backend_result": reconstructed}
                stop = "unresolved_reconstruction"
                break
            if reconstructed["status"] == "VERIFIED":
                solution_id = "table_" + reconstructed["verification"]["table_sha256"]
                solutions.append({"solution_id": solution_id, "grid_index": cursor, "aligned_characters": table_payload,
                                  "reconstruction": reconstructed})
            failure = {"reason": reconstructed["reason"], "status": reconstructed["status"],
                       "witness": reconstructed.get("witness", {})}
            if reconstructed["status"] == "VERIFIED":
                failure["solution_id"] = solution_id
        entry = {"event_type": "alignment_interval", "grid_sha256": grid_hash,
                 "range_start": cursor, "range_stop": next_cursor,
                 "status": "EXCLUDED_INTERVAL", **failure}
        entry["event_id"] = canonical_sha256(entry)
        encoded = json.dumps(entry, sort_keys=True, separators=(",", ":")).encode()
        ledger.update(encoded + b"\n")
        if event_sink is not None:
            event_sink(entry)
        histogram[entry["reason"]] = histogram.get(entry["reason"], 0) + next_cursor - cursor
        if len(witnesses) < witness_limit:
            witnesses.append(entry)
        cursor = next_cursor
        if len(solutions) >= max_results:
            stop = "result_budget"
            break
    complete = cursor == total
    status = "VERIFIED" if solutions else "EXCLUDED" if complete and start_index == 0 else "OPEN"
    return {"schema": "bounded-rational-alignment-pool-v1", "status": status,
            "reason": "VERIFIED_TABLE_FOUND" if solutions else
                      "FINITE_SUPPLIED_POOL_EXHAUSTED" if status == "EXCLUDED" else "RECONSTRUCTION_REMAINS_OPEN" if unresolved_reconstruction else "BOUNDED_SEARCH_REMAINS_OPEN",
            "scope": "only the finite supplied rational row pools; unsupplied or algebraic rows remain unsearched",
            "global_dimension_or_type_exclusion": False,
            "categorification_established": False, "complete": complete,
            "start_index": start_index, "next_index": cursor, "total_assignments": total,
            "all_pool_assignments_covered_in_this_call": complete and start_index == 0,
            "grid_sha256": grid_hash, "indexing": "lexicographic product of sorted deduplicated locally filtered source-duality-orbit row pools",
            "source_orbits": [orbit for orbit, pool in orbits], "pool_sizes": sizes,
            "local_row_removals": removed, "stop_reason": stop,
            "unresolved_reconstruction": unresolved_reconstruction,
            "local_row_rejections": local_rejections,
            "events_emitted": nodes + len(local_rejections),
            "nodes": nodes, "orthogonal_alignment_leaves": leaves,
            "reconstruction_attempts": reconstruction_count,
            "raw_grid_assignments_covered": cursor - start_index,
            "reason_histogram": histogram, "solutions": solutions,
            "witness_excerpt": witnesses, "witness_excerpt_truncated": nodes > len(witnesses),
            "complete_visited_ledger_sha256": ledger.hexdigest(),
            "seconds": time.monotonic() - began}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("characters", "moments", "pool"))
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--any-dimension", action="store_true")
    parser.add_argument("--allow-proper-subrings", action="store_true")
    parser.add_argument("--min-nonunit-dimension", type=int, default=3)
    parser.add_argument("--max-nodes", type=int, default=1000)
    parser.add_argument("--max-results", type=int, default=1)
    parser.add_argument("--start-index", type=int, default=0)
    parser.add_argument("--time-limit", type=float)
    args = parser.parse_args()
    payload = json.loads(args.input.read_text())
    target = dict(target_dimension=None if args.any_dimension else 5400,
                  require_fusion_simple=not args.allow_proper_subrings,
                  min_nonunit_dimension=args.min_nonunit_dimension)
    if args.mode == "characters":
        result = reconstruct_one_m2(payload, **target)
    elif args.mode == "moments":
        result = reconstruct_from_moments(payload, **target)
    else:
        result = search_alignments(payload, max_nodes=args.max_nodes, max_results=args.max_results,
            start_index=args.start_index, time_limit=args.time_limit, **target)
    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
