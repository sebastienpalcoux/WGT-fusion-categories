"""Exact nonincreasing sum enumeration with a serializable DFS frontier.

Every popped DFS node is one budgeted node.  An integer bitset represents
all exactly reachable sums for a fixed number of remaining entries and
an upper palette index.  A missing bit is an exact combinatorial pruning,
not a heuristic.  Resume states contain the complete pending frontier.
"""
from __future__ import annotations

from bisect import bisect_right
from functools import lru_cache


@lru_cache(maxsize=8)
def reachable_table(values, max_slots, max_total):
    values = tuple(values)
    mask = (1 << (max_total + 1)) - 1
    previous = [1] + [0] * max_slots
    rows = []
    for value in values:
        current = [1] + [0] * max_slots
        for slots in range(1, max_slots + 1):
            current[slots] = (previous[slots] |
                              (current[slots - 1] << value)) & mask
        rows.append(tuple(current))
        previous = current
    return tuple(rows)


def exact_count(values, slots, total):
    """Independent coin-count DP, used for finite arithmetic scope sizes."""
    counts = [[0] * (total + 1) for _ in range(slots + 1)]
    counts[0][0] = 1
    for value in values:
        for n in range(1, slots + 1):
            current, previous = counts[n], counts[n - 1]
            for t in range(value, total + 1):
                current[t] += previous[t - value]
    return counts[slots][total]


class CompositionSearch:
    """JSON-restorable DFS for nonincreasing palette entries.

    `labels[i]` is the emitted label associated to `values[i]`.  Source
    types use square values and dimension labels; canonical inputs use
    the same values and labels.  Equal values must not occur in a palette.
    """

    def __init__(self, values, slots, total, *, labels=None, prefix=(),
                 cap=None, state=None):
        self.values = tuple(values)
        if not self.values or any(x <= 0 for x in self.values):
            raise ValueError("A positive, nonempty palette is required")
        if tuple(sorted(set(self.values))) != self.values:
            raise ValueError("Palette values must be strictly increasing")
        self.labels = tuple(labels if labels is not None else self.values)
        if len(self.labels) != len(self.values):
            raise ValueError("Value/label palette lengths differ")
        self.max_slots = slots
        self.max_total = max(0, total)
        self.reachable = reachable_table(self.values, slots, self.max_total)
        self.stats = {"dfs_nodes": 0, "children_considered": 0,
                      "bitset_prunes": 0, "yielded": 0}
        if state is None:
            cap = len(self.values) - 1 if cap is None else cap
            self.stack = [[total, slots, cap, list(prefix)]]
        else:
            self.stack = [list(frame) for frame in state["frontier"]]
            self.stats.update(state["counters"])

    @property
    def done(self):
        return not self.stack

    def state(self):
        return {"frontier": self.stack, "counters": dict(self.stats)}

    def possible(self, total, slots, cap):
        if slots == 0:
            return total == 0
        if total < 0 or cap < 0 or total > self.max_total:
            return False
        if total < slots * self.values[0] or total > slots * self.values[cap]:
            return False
        return bool((self.reachable[cap][slots] >> total) & 1)

    def step(self):
        """Process one DFS node; return a complete tuple or None."""
        if not self.stack:
            raise StopIteration
        total, slots, cap, prefix = self.stack.pop()
        self.stats["dfs_nodes"] += 1
        if not self.possible(total, slots, cap):
            self.stats["bitset_prunes"] += 1
            return None
        if slots == 0:
            self.stats["yielded"] += 1
            return tuple(prefix)
        high = min(cap, bisect_right(self.values,
                    total - (slots - 1) * self.values[0]) - 1)
        # Push in increasing order; the stack visits larger labels first.
        for i in range(high + 1):
            self.stats["children_considered"] += 1
            rest = total - self.values[i]
            if self.possible(rest, slots - 1, i):
                self.stack.append([rest, slots - 1, i,
                                   prefix + [self.labels[i]]])
            else:
                self.stats["bitset_prunes"] += 1
        return None


def fast_compositions(values, slots, total):
    """Same exact bitset pruning with low-overhead recursive iteration.

    Used only for a complete benchmark, not for resumable production.
    """
    values = tuple(values)
    reach = reachable_table(values, slots, max(0, total))
    prefix = [0] * slots

    def visit(t, n, cap, depth):
        if n == 0:
            if t == 0:
                yield tuple(prefix)
            return
        if t < n * values[0] or t > n * values[cap]:
            return
        if not ((reach[cap][n] >> t) & 1):
            return
        high = min(cap, bisect_right(values, t - (n - 1) * values[0]) - 1)
        for i in range(high, -1, -1):
            value = values[i]
            if value * n < t:
                break
            rest = t - value
            if n == 1:
                if rest == 0:
                    prefix[depth] = value
                    yield tuple(prefix)
            elif rest >= (n - 1) * values[0] and ((reach[i][n - 1] >> rest) & 1):
                prefix[depth] = value
                yield from visit(rest, n - 1, i, depth + 1)

    yield from visit(total, slots, len(values) - 1, 0)

