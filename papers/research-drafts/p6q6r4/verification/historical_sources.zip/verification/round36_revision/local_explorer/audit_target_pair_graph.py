"""Independent complete pair-class graph audit for an exact target row pool.

This does not use target_search or fixed_pair_scaled. Field traces are
computed by explicitly summing distinct Galois embeddings, independently
of the fast Ramanujan trace-vector helper. All pair-class subsets of the
required size are checked directly. Pool-generation completeness is a
separate obligation.
"""
from pathlib import Path
from functools import lru_cache
from itertools import combinations
from math import gcd
import argparse
import hashlib
import json

from orbit_exact import field_from_metadata
from verifier import canonical_sha256


def audit_pair_graph(pool):
    target = pool["target"]
    if target["kind"] != "symplectic":
        raise ValueError("This graph audit uses the symplectic fixed-space identity")
    D, F, required = target["dimension"], target["matrix_codegree"], target["pairs"]
    fields = [field_from_metadata(o) for o in pool["orbits"]]
    reps = []
    for field in fields:
        left = {u for u in range(field.conductor) if gcd(u, field.conductor) == 1}
        choices = []
        while left:
            u = min(left)
            choices.append(u)
            left -= {(u * h) % field.conductor for h in field.subgroup}
        if len(choices) != field.degree:
            raise AssertionError("Wrong number of field embeddings")
        reps.append(choices)

    @lru_cache(None)
    def trace(j, value):
        field = fields[j]
        total = [0] * field.ambient_degree
        for u in reps[j]:
            image = field.auto(value, u)
            total = [a + b for a, b in zip(total, image)]
        if any(total[1:]):
            raise AssertionError("Galois sum failed to be rational")
        return total[0]

    groups = {}
    nonselfdual_rows = []
    for row in pool["rows"]:
        if row["selfdual"]:
            continue
        vals = [field.value(value) for field, value in zip(fields, row["values"])]
        key = (row["dimension"], row["matrix_trace"],
               tuple(field.add(value, field.conjugate(value)) for field, value in zip(fields, vals)))
        groups.setdefault(key, []).append(row)
        nonselfdual_rows.append(row)
    classes = [(key, sorted(rows, key=lambda row: row["id"])) for key, rows in sorted(groups.items())]

    def gram(x, y):
        value = 2 * x["dimension"] * y["dimension"] + (D // F) * x["matrix_trace"] * y["matrix_trace"]
        for j, (field, orbit) in enumerate(zip(fields, pool["orbits"])):
            a, b = field.value(x["values"][j]), field.value(y["values"][j])
            twice_fixed_b = field.add(b, field.conjugate(b))
            value += (D // orbit["formal_codegree"]) * trace(j, field.mul(a, twice_fixed_b))
        return value

    matrix = [[gram(a[1][0], b[1][0]) for b in classes] for a in classes]
    if any(matrix[i][i] != D for i in range(len(classes))):
        raise AssertionError("A pair-class diagonal is not D")
    if any(matrix[i][j] != matrix[j][i] for i in range(len(classes)) for j in range(i)):
        raise AssertionError("Fixed Gram matrix is not symmetric")
    for key, rows in classes:
        for row in rows:
            for other_key, other_rows in classes:
                if gram(row, other_rows[0]) != gram(rows[0], other_rows[0]):
                    raise AssertionError("Fixed-class grouping changed a pairing")
    edges = [[i, j] for i in range(len(classes)) for j in range(i + 1, len(classes)) if matrix[i][j] == 0]
    candidates = 0
    cliques = []
    for indices in combinations(range(len(classes)), required):
        candidates += 1
        if all(matrix[i][j] == 0 for i, j in combinations(indices, 2)):
            cliques.append(list(indices))
    clique_counts = {}
    for size in range(1, min(required, len(classes)) + 1):
        count = sum(all(matrix[i][j] == 0 for i, j in combinations(indices, 2))
                    for indices in combinations(range(len(classes)), size))
        clique_counts[str(size)] = count
    return dict(status="PASS_INDEPENDENT_EXACT_PAIR_CLASS_GRAPH_AUDIT",
                scope="the supplied pair row pool; its completeness needs its separate audit",
                target=target, input_pool_claims_complete=pool.get("completeness", {}).get("complete") is True,
                canonical_pool_sha256=canonical_sha256(pool),
                trace_method="explicit sum over every distinct fixed-field Galois embedding",
                nonselfdual_rows=len(nonselfdual_rows), fixed_pair_classes=len(classes),
                pair_class_members=[[row["id"] for row in rows] for key, rows in classes],
                scaled_fixed_gram=matrix, orthogonality_edges=edges,
                required_pair_count=required, subsets_checked=candidates,
                required_cliques=cliques, clique_counts_by_size=clique_counts,
                no_required_pair_clique=not cliques,
                source_sha256={name: hashlib.sha256((Path(__file__).parent / name).read_bytes()).hexdigest()
                    for name in ("audit_target_pair_graph.py", "orbit_exact.py", "verifier.py")})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pool", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = audit_pair_graph(json.loads(args.pool.read_text()))
    report["input_file_sha256"] = hashlib.sha256(args.pool.read_bytes()).hexdigest()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: report[k] for k in ("status", "fixed_pair_classes", "subsets_checked", "clique_counts_by_size", "no_required_pair_clique")}, indent=2))


if __name__ == "__main__":
    main()
