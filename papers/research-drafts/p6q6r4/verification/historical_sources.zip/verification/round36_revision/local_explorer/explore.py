#!/usr/bin/env python3
"""Portable local exploration toward simple integral fusion rings at 5400.

Every successful run/resume emits one self-contained feedback ZIP. Numerical
survivors are explicitly separated from actual table verification.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import tempfile
import time

from common import atomic_json, read_json
from runner import create_run, execute, failure_feedback, import_or_directory, restart_from_feedback


def budget_options(parser):
    parser.add_argument("--workers", type=int, default=1, help="Conservative default: one local worker")
    parser.add_argument("--time-limit", type=float, default=30.0,
                        help="Seconds per worker for this invocation; 0 means no time limit")
    parser.add_argument("--node-limit", type=int, default=50000,
                        help="Total budgeted input/DFS nodes in this invocation; 0 means no node limit")
    parser.add_argument("--checkpoint-every", type=int, default=256,
                        help="Commit results and complete frontier together after this many nodes")
    parser.add_argument("--profile", action="store_true", help="Include cProfile counters and top cumulative timings")


def target_predicate_options(parser):
    parser.add_argument("--dimension", type=int, default=5400)
    parser.add_argument("--min-dimension", type=int, default=3)
    parser.add_argument("--allow-proper-subrings", action="store_true",
                        help="For explicit control examples: do not require fusion simplicity")


def known_target_options(parser):
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--skip-known", dest="skip_known", action="store_true",
                       help="Skip the bundled audited complete exclusions (default)")
    group.add_argument("--include-known", dest="skip_known", action="store_false",
                       help="Include the audited reference states for reproduction")
    parser.set_defaults(skip_known=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run", help="Screen a declared finite necessary-data scope")
    run.add_argument("--scope", choices=("r36-open", "rational-canonical", "source-types"), default="r36-open")
    run.add_argument("--rank", type=int, default=16)
    run.add_argument("--dimension", type=int, default=5400)
    run.add_argument("--hypotheses", choices=("center5400", "dimension-equation"), default="center5400")
    run.add_argument("--algebra", choices=("any", "commutative", "noncommutative"), default="any")
    run.add_argument("--min-dimension", type=int)
    run.add_argument("--seed", type=Path, help="Authenticated normalized OPEN chunk directory")
    run.add_argument("--corner-source", type=Path, help="Exact standalone corner provider bound by the seed manifest")
    extension = run.add_mutually_exclusive_group()
    extension.add_argument("--corner-extension", type=Path, help="Replace the bundled audited Frobenius extension with this explicitly selected standalone module")
    extension.add_argument("--base-only", action="store_true", help="Reproduce the historical base gate without the later Frobenius extension")
    run.add_argument("--shard-count", type=int, default=1)
    run.add_argument("--shard-index", type=int, default=0)
    run.add_argument("--output", type=Path, required=True, help="Fresh run directory; a sibling .feedback.zip is produced")
    budget_options(run)
    resume = commands.add_parser("resume", help="Resume a feedback ZIP or transactional run directory")
    resume.add_argument("feedback", type=Path)
    resume.add_argument("--output", type=Path, help="Fresh import directory when resuming a ZIP")
    resume.add_argument("--per-target-seconds", type=float, help="Optional explore-targets budget override for this invocation; 0 is unlimited")
    resume.add_argument("--per-target-nodes", type=int, help="Optional explore-targets budget override for this invocation; 0 is unlimited")
    budget_options(resume)
    restart = commands.add_parser("restart-from-feedback", help="Import an old scope/input but start fresh with the current code version")
    restart.add_argument("feedback", type=Path)
    restart.add_argument("--output", type=Path, required=True)
    restart.add_argument("--per-target-seconds", type=float)
    restart.add_argument("--per-target-nodes", type=int)
    budget_options(restart)
    inspect = commands.add_parser("inspect", help="Read a run report without executing mathematical code")
    inspect.add_argument("feedback", type=Path)
    benchmark = commands.add_parser("benchmark", help="Compare optimized dot arithmetic with the original supplied program")
    benchmark.add_argument("--attachment", type=Path, required=True)
    benchmark.add_argument("--output", type=Path, required=True)
    benchmark.add_argument("--reference-time-limit", type=float, default=300)
    for kind, description in (("verify", "Verify every axiom of a supplied integral fusion-ring table"),
                              ("reconstruct", "Reconstruct from a complete aligned rational character table"),
                              ("moments", "Reconstruct from exact full-orbit pair and triple moments"),
                              ("align", "Search explicitly supplied finite rational row pools"),
                              ("prepare-target", "Generate complete mixed-field necessary row pools for an actual target"),
                              ("search-target", "Search an exactly prepared mixed-field target pool")):
        backend = commands.add_parser(kind, help=description)
        if kind == "prepare-target":
            source = backend.add_mutually_exclusive_group()
            source.add_argument("--state", type=int, help="Original state ID in the bundled target catalogue; default 836343")
            source.add_argument("--input", type=Path, help="Explicit complete original target record")
            backend.add_argument("--catalogue", type=Path, help="Authenticated target catalogue directory")
        elif kind == "search-target":
            backend.add_argument("--pool", dest="input", type=Path, required=True)
        else:
            backend.add_argument("--input", type=Path, required=True)
        backend.add_argument("--output", type=Path, required=True)
        backend.add_argument("--max-results", type=int, default=1)
        target_predicate_options(backend)
        budget_options(backend)
        backend.set_defaults(node_limit=1000)
    listing = commands.add_parser("list-targets", help="Inspect the authenticated finite target catalogue")
    listing.add_argument("--catalogue", type=Path)
    listing.add_argument("--limit", type=int, default=20, help="Maximum displayed targets; 0 displays all")
    known_target_options(listing)
    batch = commands.add_parser("explore-targets", help="Prepare and search actual full-field S targets with per-target checkpoints")
    batch.add_argument("--catalogue", type=Path)
    batch.add_argument("--states", help="Comma-separated original state IDs; otherwise use the first --limit targets")
    batch.add_argument("--limit", type=int, default=3, help="Targets selected in catalogue order; 0 selects all")
    batch.add_argument("--per-target-seconds", type=float, default=5.0)
    batch.add_argument("--per-target-nodes", type=int, default=1000)
    batch.add_argument("--max-results", type=int, default=1)
    known_target_options(batch)
    batch.add_argument("--shard-count", type=int, default=1)
    batch.add_argument("--shard-index", type=int, default=0)
    batch.add_argument("--output", type=Path, required=True)
    budget_options(batch)
    args = parser.parse_args(argv)
    if args.command == "list-targets":
        from catalogue import describe_targets
        print(json.dumps(describe_targets(args.catalogue, args.limit, args.skip_known), indent=2, sort_keys=True))
        return 0
    if args.command == "inspect":
        if args.feedback.is_dir():
            report = read_json(args.feedback / "run_report.json")
        else:
            import zipfile
            with zipfile.ZipFile(args.feedback) as archive:
                report = json.loads(archive.read("run_report.json"))
        print(json.dumps(report, indent=2, sort_keys=True))
        return 0
    if args.command == "benchmark":
        from benchmark_arithmetic import run_benchmark
        existed = args.output.exists()
        try:
            if not math.isfinite(args.reference_time_limit) or args.reference_time_limit <= 0:
                raise ValueError("Benchmark process time limit must be finite and positive")
            report, feedback = run_benchmark(args.attachment, args.output, args.reference_time_limit)
        except Exception as exc:
            output = args.output.with_name(args.output.name + ".failed_" + str(time.time_ns())) if existed else args.output
            feedback = failure_feedback(output, exc, command="benchmark")
            print(json.dumps({"status": "FAILED", "error": str(exc), "feedback_zip": str(feedback)}, indent=2))
            return 2
        print(json.dumps({"report": report, "feedback_zip": str(feedback)}, indent=2))
        return 0 if report["status"] == "PASS_COMPLETE_EXACT_ARITHMETIC_COMPARISON" else 2
    began = time.monotonic()
    root = None
    requested_output = getattr(args, "output", None)
    output_preexisted = requested_output is not None and requested_output.exists()
    try:
        for name in ("time_limit", "per_target_seconds"):
            value = getattr(args, name, None)
            if value is not None and (not math.isfinite(value) or value < 0):
                raise ValueError(name.replace("_", "-") + " must be finite and nonnegative; use 0 for unlimited")
        if args.command == "run":
            extension_path = args.corner_extension
            if args.scope == "r36-open" and not args.base_only and extension_path is None:
                extension_path = Path(__file__).resolve().parent / "corner_extension.py"
            root = create_run(args.output, kind=args.scope, rank=args.rank, dimension=args.dimension,
                              hypotheses=args.hypotheses, algebra=args.algebra,
                              min_dimension=args.min_dimension, seed=args.seed,
                              corner_source=args.corner_source, shard_count=args.shard_count,
                              shard_index=args.shard_index, corner_extension=extension_path)
        elif args.command == "explore-targets":
            from target_batch import create_target_batch
            states = [int(s.strip()) for s in args.states.split(",")] if args.states is not None else None
            root = create_target_batch(args.output, catalogue=args.catalogue, states=states, limit=args.limit,
                        per_target_seconds=args.per_target_seconds, per_target_nodes=args.per_target_nodes,
                        max_results=args.max_results, shard_count=args.shard_count, shard_index=args.shard_index,
                        skip_known=args.skip_known)
        elif args.command in ("verify", "reconstruct", "moments", "align", "prepare-target", "search-target"):
            from backend_runs import create_backend_run
            provenance = None
            with tempfile.TemporaryDirectory(prefix="fusion5400_selected_input_") as temp:
                input_path = args.input
                if args.command == "prepare-target" and input_path is None:
                    from catalogue import select_target
                    payload, provenance = select_target(args.state if args.state is not None else 836343, args.catalogue)
                    input_path = Path(temp) / "selected_target.json"
                    atomic_json(input_path, payload)
                root = create_backend_run(args.output, args.command, input_path,
                            dimension=args.dimension, require_simple=not args.allow_proper_subrings,
                            min_dimension=args.min_dimension, max_results=args.max_results,
                            source_provenance=provenance)
        elif args.command == "restart-from-feedback":
            root = restart_from_feedback(args.feedback, args.output)
        else:
            root = import_or_directory(args.feedback, args.output)
        setup = time.monotonic() - began
        report, feedback, packing = execute(root, workers=args.workers, time_limit=args.time_limit,
                        node_limit=args.node_limit, checkpoint_every=args.checkpoint_every,
                        profile=args.profile, setup_seconds=setup,
                        per_target_seconds=getattr(args, "per_target_seconds", None),
                        per_target_nodes=getattr(args, "per_target_nodes", None))
    except Exception as exc:
        destination = root or requested_output
        if destination is None:
            destination = Path("failed_feedback_" + str(time.time_ns()))
        elif root is None and output_preexisted:
            destination = destination.with_name(destination.name + ".failed_" + str(time.time_ns()))
        feedback = failure_feedback(destination, exc, command=args.command)
        print(json.dumps({"status": "FAILED", "error": str(exc), "feedback_zip": str(feedback)}, indent=2))
        return 2
    print(json.dumps({"status": report["status"], "complete_declared_scope": report["complete_declared_scope"],
                      "committed_nodes": report["committed_nodes"], "result_counts": report["result_counts"],
                      "unvisited_or_pending_tasks": report["unvisited_or_pending_tasks"],
                      "feedback_zip": str(feedback), "packaging_seconds": packing,
                      "note": "OPEN numerical inputs are not fusion rings."}, indent=2))
    return 2 if report["status"] == "FAILED" else 0


if __name__ == "__main__":
    raise SystemExit(main())
