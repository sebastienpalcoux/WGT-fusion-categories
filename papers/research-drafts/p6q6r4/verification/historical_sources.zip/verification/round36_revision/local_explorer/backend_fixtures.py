"""Small exact controls, including a genuinely nonassociative pointed loop.

Fixtures are mathematical controls, not candidates of global dimension5400.
The A5 representation-ring fixture is integral and fusion-simple, but has
global dimension60. S3 and Q8 group rings exercise the split and nonsplit
rational degree-two reconstruction without categorification inference.
"""
from itertools import permutations


def _pointed(labels, multiply, inverse):
    n = len(labels)
    table = [[[0] * n for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            table[i][j][multiply(i, j)] = 1
    return dict(unit=0, labels=labels, dimensions=[1] * n,
                duality=[inverse(i) for i in range(n)], multiplication=table)


def cyclic_group(order=3):
    return _pointed([f"g^{i}" for i in range(order)],
                    lambda i, j: (i + j) % order, lambda i: (-i) % order)


def s3():
    elements = list(permutations(range(3)))
    index = {p: i for i, p in enumerate(elements)}
    def multiply(i, j):
        return index[tuple(elements[i][elements[j][k]] for k in range(3))]
    def inverse(i):
        p = elements[i]
        return index[tuple(p.index(k) for k in range(3))]
    table = _pointed(["".join(map(str, p)) for p in elements], multiply, inverse)
    sign = [(-1) ** sum(p[i] > p[j] for i in range(3) for j in range(i + 1, 3))
            for p in elements]
    characters = {key: table[key] for key in ("unit", "labels", "dimensions", "duality")}
    characters.update(linear_characters=[[1] * 6, sign], linear_codegrees=[6, 6],
                      matrix_codegree=3)
    return table, characters


def q8():
    cycle = {(1, 2): 3, (2, 3): 1, (3, 1): 2}
    def multiply(i, j):
        a, b = i % 4, j % 4
        minus = (i // 4) ^ (j // 4)
        if not a:
            c = b
        elif not b:
            c = a
        elif a == b:
            c, minus = 0, minus ^ 1
        elif (a, b) in cycle:
            c = cycle[a, b]
        else:
            c, minus = cycle[b, a], minus ^ 1
        return c + 4 * minus
    def inverse(i):
        return i if i % 4 == 0 else i ^ 4
    table = _pointed(["1", "i", "j", "k", "-1", "-i", "-j", "-k"], multiply, inverse)
    chars = []
    for a, b in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        chars.append([1, a, b, a * b] * 2)
    character_data = {key: table[key] for key in ("unit", "labels", "dimensions", "duality")}
    character_data.update(linear_characters=chars, linear_codegrees=[8] * 4,
                          matrix_codegree=4)
    return table, character_data


def a5_representation_ring():
    """The familiar irreducibles 1,3,3',4,5; all are selfdual."""
    n = 5
    table = [[[0] * n for _ in range(n)] for _ in range(n)]
    for i in range(n):
        table[0][i][i] = table[i][0][i] = 1
    products = {
        (1, 1): [1, 1, 0, 0, 1], (2, 2): [1, 0, 1, 0, 1],
        (1, 2): [0, 0, 0, 1, 1], (1, 3): [0, 0, 1, 1, 1],
        (2, 3): [0, 1, 0, 1, 1], (1, 4): [0, 1, 1, 1, 1],
        (2, 4): [0, 1, 1, 1, 1], (3, 3): [1, 1, 1, 1, 1],
        (3, 4): [0, 1, 1, 1, 2], (4, 4): [1, 1, 1, 2, 2],
    }
    for (i, j), value in products.items():
        table[i][j] = list(value)
        table[j][i] = list(value)
    return dict(unit=0, labels=["1", "3", "3prime", "4", "5"],
                dimensions=[1, 3, 3, 4, 5], duality=list(range(n)), multiplication=table)


def octonion_unit_loop():
    """The sixteen signed octonion units: inverse-property, not associative."""
    lines = ((1, 2, 3), (1, 4, 5), (1, 7, 6), (2, 4, 6),
             (2, 5, 7), (3, 4, 7), (3, 6, 5))
    oriented = {}
    for a, b, c in lines:
        oriented[a, b] = c
        oriented[b, c] = a
        oriented[c, a] = b
    def multiply(i, j):
        a, b = i % 8, j % 8
        minus = (i // 8) ^ (j // 8)
        if not a:
            c = b
        elif not b:
            c = a
        elif a == b:
            c, minus = 0, minus ^ 1
        elif (a, b) in oriented:
            c = oriented[a, b]
        else:
            c, minus = oriented[b, a], minus ^ 1
        return c + 8 * minus
    return _pointed([("-" if i >= 8 else "") + ("1" if i % 8 == 0 else f"e{i % 8}")
                     for i in range(16)], multiply,
                    lambda i: i if i % 8 == 0 else i ^ 8)


def s3_alignment_pool():
    table, characters = s3()
    out = {key: table[key] for key in ("unit", "labels", "dimensions", "duality")}
    out.update(linear_codegrees=[6, 6], matrix_codegree=3, perron_column=0,
               row_pools=[[[1, 1]]] + [[[1, -1], [1, 1]] for _ in range(5)])
    return out


def tensor_product(left, right):
    """Exact tensor product used for a denser verification benchmark."""
    n, m = len(left["dimensions"]), len(right["dimensions"])
    rank = n * m
    out = [[[0] * rank for _ in range(rank)] for _ in range(rank)]
    for a in range(rank):
        i, u = divmod(a, m)
        for b in range(rank):
            j, v = divmod(b, m)
            for k, x in enumerate(left["multiplication"][i][j]):
                if x:
                    for w, y in enumerate(right["multiplication"][u][v]):
                        if y:
                            out[a][b][k * m + w] = x * y
    return dict(unit=left["unit"] * m + right["unit"],
        labels=[f"({a},{b})" for a in left["labels"] for b in right["labels"]],
        dimensions=[a * b for a in left["dimensions"] for b in right["dimensions"]],
        duality=[left["duality"][i] * m + right["duality"][u]
                 for i in range(n) for u in range(m)], multiplication=out)
