"""Isolated exact table, row-pool and alignment backend invocation."""
from __future__ import annotations

import argparse
import cProfile
import hashlib
import inspect
import json
import os
from pathlib import Path
import pstats
import time
import traceback

from common import atomic_json, canonical_bytes, digest_object, read_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("plan", type=Path)
    args = parser.parse_args()
    root, plan = args.root.resolve(), read_json(args.plan)
    config = read_json(root / "config.json")
    payload = read_json(root / "resources/input.json")
    kind = config["scope"]["kind"]
    # The coordinator accepts a checkpoint only with its fully written result
    # and event ledger. A convenience checkpoint file is never authoritative.
    checkpoint = plan.get("checkpoint")
    next_checkpoint = checkpoint
    target = config["scope"].get("target_predicates", {})
    began, cpu = time.perf_counter(), time.process_time()
    profile = cProfile.Profile() if plan.get("profile") else None
    if profile:
        profile.enable()
    events_path = root / plan["events"]
    event_hash, event_count = hashlib.sha256(), 0
    result = None
    with events_path.open("wb") as events:
        def event_sink(event):
            nonlocal event_count
            encoded = canonical_bytes(event) + b"\n"
            events.write(encoded)
            event_hash.update(encoded)
            event_count += 1

        try:
            if kind == "verify":
                from verifier import verify_table
                result = verify_table(payload, **target)
                event_sink({"id": "supplied-table:" + digest_object(payload), "decision": result})
            elif kind in ("reconstruct", "moments"):
                from alignment import reconstruct_one_m2, reconstruct_from_moments
                fn = reconstruct_one_m2 if kind == "reconstruct" else reconstruct_from_moments
                result = fn(payload, **target)
                event_sink({"id": "supplied-aligned-data:" + digest_object(payload), "decision": result})
            elif kind == "align":
                from alignment import search_alignments
                start = checkpoint["next_index"] if checkpoint else 0
                kw = {"max_nodes": None if plan["node_limit"] == 0 else plan["node_limit"],
                      "max_results": plan["max_results"], "start_index": start,
                      "time_limit": None if plan["time_limit"] == 0 else plan["time_limit"], **target}
                if "event_sink" in inspect.signature(search_alignments).parameters:
                    kw["event_sink"] = event_sink
                result = search_alignments(payload, **kw)
                if "next_index" in result and "grid_sha256" in result:
                    if checkpoint and checkpoint["grid_sha256"] != result["grid_sha256"]:
                        raise ValueError("Alignment grid changed across resume")
                    if result["next_index"] < start:
                        raise ValueError("Alignment resume moved backwards")
                    next_checkpoint = {"next_index": result["next_index"],
                                "grid_sha256": result.get("grid_sha256"),
                                "total_assignments": result["total_assignments"],
                                "complete": result["complete"]}
            elif kind == "prepare-target":
                from target_pool import prepare_target
                result = prepare_target(payload, kernel_dir=Path(__file__).parent / "vendor/rank16",
                            time_limit=None if plan["time_limit"] == 0 else plan["time_limit"],
                            max_nodes=None if plan["node_limit"] == 0 else plan["node_limit"],
                            checkpoint=checkpoint,
                            progress=lambda item: event_sink({"stage": "pool_preparation", "progress": item}))
                next_checkpoint = result["checkpoint"]
            elif kind == "search-target":
                from target_search import search_target_pool
                kw = {"max_nodes": None if plan["node_limit"] == 0 else plan["node_limit"],
                      "max_results": plan["max_results"],
                      "time_limit": None if plan["time_limit"] == 0 else plan["time_limit"],
                      "checkpoint": checkpoint}
                if "event_sink" in inspect.signature(search_target_pool).parameters:
                    kw["event_sink"] = event_sink
                result = search_target_pool(payload, **kw)
                if result.get("checkpoint") is not None:
                    next_checkpoint = result["checkpoint"]
            else:
                raise ValueError("Unknown exact backend")
            outcome = {"status": "RETURNED", "result": result,
                       "committed_checkpoint": next_checkpoint,
                       "previous_checkpoint_sha256": digest_object(checkpoint)}
        except BaseException as exc:
            outcome = {"status": "FAILED", "error": {"type": type(exc).__name__,
                         "message": str(exc), "traceback": traceback.format_exc()},
                       "old_committed_checkpoint_remains_authoritative": True}
        events.flush()
        os.fsync(events.fileno())
    outcome.update(wall_seconds=time.perf_counter() - began,
                   cpu_seconds=time.process_time() - cpu,
                   events=plan["events"], event_count=event_count,
                   event_ledger_sha256=event_hash.hexdigest(),
                   input_sha256=digest_object(payload), kind=kind)
    if profile:
        profile.disable()
        pp = root / plan["report"]
        profile.dump_stats(str(pp.with_suffix(".pstats")))
        with pp.with_suffix(".profile.txt").open("w") as out:
            pstats.Stats(profile, stream=out).strip_dirs().sort_stats("cumulative").print_stats(30)
    atomic_json(root / plan["report"], outcome)
    print(json.dumps({k: v for k, v in outcome.items() if k not in ("result", "error")}, sort_keys=True))
    if outcome["status"] == "FAILED":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
