"""Independent fixture and adversarial controls for the local backend.

The nonassociative signed octonion loop deliberately passes the earlier
unit, nonnegativity, dimension, duality and Frobenius tests. Its exact
associativity rejection checks the substantive finite table verifier.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import time

from alignment import (rational_character_moments, reconstruct_from_moments,
                       reconstruct_one_m2, search_alignments)
from backend_fixtures import (a5_representation_ring, cyclic_group,
                              octonion_unit_loop, q8, s3, s3_alignment_pool,
                              tensor_product)
from verifier import verify_table


GENERIC = dict(target_dimension=None, require_fusion_simple=False,
               min_nonunit_dimension=1)


def run_controls():
    checks = []
    timings = {}

    def checked(name, result, status, reason=None):
        assert result["status"] == status, (name, result)
        if reason is not None:
            assert result["reason"] == reason, (name, result)
        assert result.get("categorification_established") is False, (name, result)
        assert result.get("global_dimension_or_type_exclusion") is False, (name, result)
        checks.append({"name": name, "status": result["status"],
                       "reason": result["reason"], "witness": result.get("witness")})

    control_tables = {"cyclic3": cyclic_group(), "RepA5": a5_representation_ring(),
                      "S3": s3()[0], "Q8": q8()[0]}
    for name, table in control_tables.items():
        began = time.perf_counter()
        r = verify_table(table, **GENERIC)
        timings["verify_" + name] = time.perf_counter() - began
        checked("valid_" + name, r, "VERIFIED")
        assert r["counters"]["ordered_associativity_triples"] == len(table["dimensions"]) ** 3
    r = verify_table(control_tables["RepA5"], target_dimension=60,
                     require_fusion_simple=True, min_nonunit_dimension=3)
    checked("simple_integral_RepA5", r, "VERIFIED")
    assert r["fusion_simple"] and r["frobenius_perron_dimension"] == 60
    assert all(len(c) == 5 for c in r["generated_subrings"].values())
    r = verify_table(control_tables["RepA5"])
    checked("wrong_5400_target_is_not_a_ring_failure", r, "EXCLUDED", "TARGET_CONSTRAINT_FAILURE")
    assert r["ring_axioms_verified"] and r["target_violations"] == [
        {"kind": "TARGET_DIMENSION", "actual": 60, "required": 5400}]
    r = verify_table(control_tables["S3"], target_dimension=6,
                     require_fusion_simple=True, min_nonunit_dimension=1)
    checked("proper_subring_detected", r, "EXCLUDED", "TARGET_CONSTRAINT_FAILURE")
    assert r["proper_subring_witness"]["closed_dimension"] in (2, 3)

    bad = copy.deepcopy(control_tables["S3"])
    bad["multiplication"][0][0][0] = True
    checked("bool_is_not_integer", verify_table(bad, **GENERIC),
            "INVALID_INPUT", "NONINTEGER_STRUCTURE_CONSTANT")
    bad = copy.deepcopy(control_tables["S3"])
    bad["multiplication"][1][1][0] = -1
    checked("negative_coefficient", verify_table(bad, **GENERIC),
            "EXCLUDED", "NEGATIVE_STRUCTURE_CONSTANT")
    bad = copy.deepcopy(control_tables["S3"])
    bad["multiplication"][0][1][1] = 0
    checked("unit_failure", verify_table(bad, **GENERIC), "EXCLUDED", "UNIT_FAILURE")
    bad = copy.deepcopy(control_tables["RepA5"])
    bad["dimensions"][1] = 4
    checked("wrong_positive_dimension_vector", verify_table(bad, **GENERIC),
            "EXCLUDED", "DIMENSION_HOMOMORPHISM_FAILURE")
    bad = copy.deepcopy(control_tables["S3"])
    bad["duality"][1] = 0
    checked("not_an_involution", verify_table(bad, **GENERIC),
            "EXCLUDED", "DUALITY_NOT_INVOLUTIVE")
    bad = copy.deepcopy(control_tables["Q8"])
    bad["duality"] = list(range(8))
    checked("wrong_inverse_not_missed", verify_table(bad, **GENERIC),
            "EXCLUDED", "FROBENIUS_RECIPROCITY")
    bad = copy.deepcopy(control_tables["S3"])
    bad["multiplication"].pop()
    checked("truncated_table", verify_table(bad, **GENERIC), "INVALID_INPUT", "TABLE_SHAPE")
    began = time.perf_counter()
    r = verify_table(octonion_unit_loop(), **GENERIC)
    timings["reject_nonassociative_rank16_loop"] = time.perf_counter() - began
    checked("nonassociative_inverse_property_loop", r, "EXCLUDED", "ASSOCIATIVITY_FAILURE")
    assert "both Frobenius reciprocity identities" in r["checked"]
    assert r["witness"]["ordered_triple"] == [1, 2, 4]

    for name, (table, chars) in (("S3", s3()), ("Q8", q8())):
        began = time.perf_counter()
        r = reconstruct_one_m2(chars, **GENERIC)
        timings["reconstruct_" + name] = time.perf_counter() - began
        checked("reconstruct_" + name, r, "VERIFIED")
        N = r["reconstructed_table"]["multiplication"]
        original = table["multiplication"]
        opposite = [[original[j][i] for j in range(len(N))] for i in range(len(N))]
        assert N == original or N == opposite
        moments = rational_character_moments(chars)
        assert moments["status"] == "MOMENTS_READY"
        raw = reconstruct_from_moments(moments["moments"], **GENERIC)
        assert raw["reconstructed_table"] == r["reconstructed_table"]
        assert raw["matrix_codegree"] == chars["matrix_codegree"]
    bad = copy.deepcopy(s3()[1])
    bad["linear_characters"][1][1] = {"field": "Q(sqrt(5))", "coordinates": [0, 1]}
    checked("unsupported_field_remains_open", reconstruct_one_m2(bad, **GENERIC),
            "OPEN_UNSUPPORTED_FIELD", "EXACT_FIELD_BACKEND_REQUIRED")
    bad = copy.deepcopy(s3()[1])
    bad["linear_characters"][1][1] = "1/2"
    checked("rational_noninteger_character", reconstruct_one_m2(bad, **GENERIC),
            "EXCLUDED", "NONINTEGRAL_RATIONAL_CHARACTER_VALUE")
    bad = copy.deepcopy(s3()[1])
    bad["linear_characters"][1] = [1] * 6
    checked("duplicate_character_not_orthogonal", reconstruct_one_m2(bad, **GENERIC),
            "EXCLUDED", "LINEAR_CHARACTERS_NOT_ORTHOGONAL")
    bad = rational_character_moments(s3()[1])["moments"]
    bad["linear_pair_moments"][1][1] = "1/2"
    checked("nonprojective_pair_moments", reconstruct_from_moments(bad, **GENERIC),
            "EXCLUDED", "LINEAR_PROJECTOR_NOT_IDEMPOTENT")
    bad = rational_character_moments(s3()[1])["moments"]
    bad["linear_triple_moments"][0][0][0] = 0
    checked("wrong_triple_unit_moment", reconstruct_from_moments(bad, **GENERIC),
            "EXCLUDED", "TRIPLE_MOMENT_UNIT_IDENTITY")

    pool = s3_alignment_pool()
    full_events = []
    full = search_alignments(pool, max_nodes=None, max_results=100,
                             event_sink=full_events.append, **GENERIC)
    checked("finite_pool_reconstructs_actual_S3", full, "VERIFIED")
    assert full["complete"] and full["total_assignments"] == 16
    assert len(full["solutions"]) == 1
    for key, value in (("max_nodes", 0), ("time_limit", 0)):
        result = search_alignments(pool, **{key: value}, **GENERIC)
        checked("bounded_" + key + "_remains_open", result, "OPEN")
        assert not result["complete"] and result["next_index"] == 0
    cursor, pieces, found, histogram, nodes = 0, [], [], {}, 0
    resumed_events = []
    while cursor < full["total_assignments"]:
        part = search_alignments(pool, max_nodes=1, max_results=100,
                                 start_index=cursor, event_sink=resumed_events.append, **GENERIC)
        assert part["grid_sha256"] == full["grid_sha256"]
        assert part["next_index"] > cursor
        pieces.append([cursor, part["next_index"]])
        cursor = part["next_index"]
        nodes += part["nodes"]
        found.extend(x["grid_index"] for x in part["solutions"])
        for reason, count in part["reason_histogram"].items():
            histogram[reason] = histogram.get(reason, 0) + count
    assert nodes == full["nodes"] and histogram == full["reason_histogram"]
    assert found == [x["grid_index"] for x in full["solutions"]]
    assert resumed_events == full_events
    events_bytes = b"".join(json.dumps(e, sort_keys=True, separators=(",", ":")).encode() + b"\n"
                            for e in full_events)
    assert hashlib.sha256(events_bytes).hexdigest() == full["complete_visited_ledger_sha256"]
    checks.append({"name": "safe_resume_partition", "status": "PASS",
                   "intervals": pieces, "nodes": nodes, "found_grid_indices": found})
    import alignment
    original_reconstruction = alignment.reconstruct_one_m2
    stopped_events = []
    try:
        alignment.reconstruct_one_m2 = lambda *a, **k: {
            "status": "OPEN_UNSUPPORTED_FIELD", "reason": "DELIBERATE_CONTROL"}
        stopped = search_alignments(pool, max_nodes=None, max_results=100,
                                    event_sink=stopped_events.append, **GENERIC)
    finally:
        alignment.reconstruct_one_m2 = original_reconstruction
    assert stopped["status"] == "OPEN" and not stopped["complete"]
    assert stopped["reason"] == "RECONSTRUCTION_REMAINS_OPEN"
    assert "DELIBERATE_CONTROL" not in stopped["reason_histogram"]
    restored = search_alignments(pool, max_nodes=None, max_results=100,
                                start_index=stopped["next_index"],
                                event_sink=stopped_events.append, **GENERIC)
    assert restored["complete"] and stopped_events == full_events
    checks.append({"name": "unsupported_reconstruction_retains_exact_grid_cursor",
                   "status": "PASS", "pending_grid_index": stopped["next_index"]})
    bad_row_pool = copy.deepcopy(pool)
    bad_row_pool["row_pools"][1].append([1, 2])
    row_events = []
    filtered = search_alignments(bad_row_pool, max_nodes=0, event_sink=row_events.append, **GENERIC)
    assert filtered["status"] == "OPEN" and filtered["nodes"] == 0
    assert len(row_events) == 1 and row_events[0]["event_type"] == "alignment_row_filter"
    assert row_events[0]["row"] == [1, 2]
    checks.append({"name": "complete_local_filter_event", "status": "PASS",
                   "event": row_events[0]})
    result = search_alignments(pool, max_nodes=1000, max_results=100,
                                target_dimension=6, require_fusion_simple=True,
                                min_nonunit_dimension=1)
    checked("exhaustion_is_only_the_supplied_pool", result, "EXCLUDED", "FINITE_SUPPLIED_POOL_EXHAUSTED")
    assert result["complete"] and "unsupplied" in result["scope"]

    # A denser rank25 positive fixture gives a more useful profile than a
    # multiplication table with one nonzero per product.
    dense = tensor_product(a5_representation_ring(), a5_representation_ring())
    began = time.perf_counter()
    result = verify_table(dense, **GENERIC)
    timings["verify_rank25_RepA5_tensor_RepA5"] = time.perf_counter() - began
    checked("dense_rank25_tensor_control", result, "VERIFIED")
    assert result["frobenius_perron_dimension"] == 3600 and not result["fusion_simple"]
    return {"status": "PASS_EXACT_LOCAL_BACKEND_CONTROLS", "controls": checks,
            "control_count": len(checks), "seconds_by_operation": timings,
            "dense_benchmark_counters": result["counters"],
            "actual_dimension5400_rings_found": 0,
            "categorification_claims": 0,
            "scope": "Explicit-table verification, exact rational/orbit-moment reconstruction and deterministic finite rational-pool resume controls"}


def main():
    if not __debug__:
        raise RuntimeError("Run controls with assertions enabled")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("backend_control_report.json"))
    parser.add_argument("--write-fixtures", type=Path)
    args = parser.parse_args()
    report = run_controls()
    here = Path(__file__).resolve().parent
    report["source_sha256"] = {name: hashlib.sha256((here / name).read_bytes()).hexdigest()
        for name in ("verifier.py", "alignment.py", "backend_fixtures.py", "backend_selftest.py")}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    if args.write_fixtures:
        args.write_fixtures.mkdir(parents=True, exist_ok=True)
        fixtures = {"RepA5_table.json": a5_representation_ring(),
                    "S3_table.json": s3()[0], "S3_characters.json": s3()[1],
                    "Q8_table.json": q8()[0], "Q8_characters.json": q8()[1],
                    "octonion_nonassociative.json": octonion_unit_loop(),
                    "S3_alignment_pool.json": s3_alignment_pool()}
        for name, value in fixtures.items():
            (args.write_fixtures / name).write_text(json.dumps(value, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("status", "control_count", "seconds_by_operation", "dense_benchmark_counters")}, indent=2))


if __name__ == "__main__":
    main()
