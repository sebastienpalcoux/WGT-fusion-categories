"""End-to-end Q8 and safe-frontier controls for the mixed-orbit search."""
from pathlib import Path
import argparse
import copy
import hashlib
import json

from backend_fixtures import q8
from target_search import search_target_pool


def q8_pool():
    table, chars = q8()
    orbits = [dict(label="Q", conductor=1, subgroup=[0], degree=1, formal_codegree=8)
              for _ in range(3)]
    rows = []
    for i in range(8):
        rows.append(dict(id="q" + str(i), dimension=1, matrix_trace=2 if i == 0 else -2 if i == 4 else 0,
            matrix_norm=2, selfdual=table["duality"][i] == i,
            values=[[row[i]] for row in chars["linear_characters"][1:]],
            dual_id="q" + str(table["duality"][i])))
    return dict(schema="fusion5400.target_pool.v1",
                target=dict(state_id="Q8-control", rank=8, dimension=8,
                            matrix_codegree=4, kind="symplectic", pairs=3, selfdual=2,
                            min_nonunit_dimension=1, require_fusion_simple=False),
                orbits=orbits, unit=rows[0], rows=rows[1:],
                completeness=dict(complete=True, scope="explicit Q8 control rows only"))


def run_controls():
    pool = q8_pool()
    events = []
    full = search_target_pool(pool, max_nodes=None, max_results=100, event_sink=events.append)
    assert full["status"] == "VERIFIED" and full["complete"]
    assert full["fixed_class_count"] == 4 and full["pair_fixed_classes"] == 3
    assert full["totals"]["fixed_cliques"] == full["totals"]["variant_assignments"] == 1
    assert full["totals"]["reconstruction_attempts"] == full["totals"]["verified_tables"] == 1
    assert len(full["solutions"]) == 1
    verification = full["solutions"][0]["reconstruction"]["verification"]
    assert verification["ring_axioms_verified"] and verification["frobenius_perron_dimension"] == 8
    assert not verification["commutative"] and not verification["fusion_simple"]
    assert not verification["categorification_established"]
    event_bytes = b"".join(json.dumps(e, sort_keys=True, separators=(",", ":")).encode() + b"\n" for e in events)
    assert hashlib.sha256(event_bytes).hexdigest() == full["visited_ledger_sha256"]
    assert len(events) == full["nodes"]

    checkpoint = None
    resumed_events, resumed_solutions, chunks = [], [], []
    while True:
        result = search_target_pool(pool, max_nodes=1, max_results=100,
                                    checkpoint=checkpoint, event_sink=resumed_events.append)
        assert result["status"] != "INVALID_INPUT", result
        chunks.append({"nodes": result["nodes"], "status": result["status"],
                       "remaining_frames": len(result["checkpoint"]["frontier"])})
        resumed_solutions.extend(x["solution_id"] for x in result["solutions"])
        checkpoint = result["checkpoint"]
        if result["complete"]:
            break
        assert len(chunks) <= full["nodes"] + 2
    assert result["totals"] == full["totals"]
    assert resumed_events == events
    assert resumed_solutions == [x["solution_id"] for x in full["solutions"]]
    for kwargs in ({"max_nodes": 0}, {"time_limit": 0}):
        stopped = search_target_pool(pool, **kwargs)
        assert stopped["status"] == "OPEN" and not stopped["complete"] and stopped["nodes"] == 0
    stop_events = []
    stopped = search_target_pool(pool, max_nodes=None, max_results=100,
                                 event_sink=stop_events.append,
                                 should_stop=lambda: len(stop_events) >= 2)
    assert stopped["stop_reason"] == "requested_stop" and not stopped["complete"]
    assert stop_events == events[:2]
    after = search_target_pool(pool, max_nodes=None, max_results=100,
                              checkpoint=stopped["checkpoint"], event_sink=stop_events.append)
    assert after["complete"] and stop_events == events and after["totals"] == full["totals"]
    import target_search
    original_reconstruction = target_search.reconstruct_from_moments
    unsupported_events = []
    try:
        target_search.reconstruct_from_moments = lambda *a, **k: {
            "status": "OPEN_UNSUPPORTED_FIELD", "reason": "DELIBERATE_CONTROL"}
        blocked = search_target_pool(pool, max_nodes=None, max_results=100,
                                     event_sink=unsupported_events.append)
    finally:
        target_search.reconstruct_from_moments = original_reconstruction
    assert blocked["status"] == "OPEN" and not blocked["complete"]
    assert blocked["reason"] == "RECONSTRUCTION_REMAINS_OPEN"
    assert "DELIBERATE_CONTROL" not in blocked["totals"]["reason_histogram"]
    unblocked = search_target_pool(pool, max_nodes=None, max_results=100,
                                  checkpoint=blocked["checkpoint"], event_sink=unsupported_events.append)
    assert unblocked["complete"] and unsupported_events == events
    assert unblocked["totals"] == full["totals"]
    bounded = search_target_pool(pool, max_nodes=1)
    bad_cp = copy.deepcopy(bounded["checkpoint"])
    bad_cp["pool_sha256"] = "0" * 64
    assert search_target_pool(pool, checkpoint=bad_cp)["reason"] == "CHECKPOINT_POOL_OR_CODE_BINDING_MISMATCH"
    bad_cp = copy.deepcopy(bounded["checkpoint"])
    bad_cp["frontier"][-1]["mass"] += 1
    assert search_target_pool(pool, checkpoint=bad_cp)["reason"] == "MALFORMED_CHECKPOINT"
    partial = copy.deepcopy(pool)
    partial["completeness"]["complete"] = False
    partial["target"]["require_fusion_simple"] = True
    r = search_target_pool(partial, max_nodes=None, max_results=100)
    assert r["status"] == "OPEN" and not r["complete"] and r["supplied_pool_traversal_complete"]
    assert r["reason"] == "PARTIAL_POOL_REQUIRES_MORE_ROWS"
    orthogonal = copy.deepcopy(pool)
    orthogonal["target"]["kind"] = "orthogonal"
    r = search_target_pool(orthogonal)
    assert r["status"] == "OPEN_UNSUPPORTED_CONTEXT"
    return dict(status="PASS_EXACT_TARGET_SEARCH_CONTROLS",
                controls=["Q8 fixed-space clique", "complete orbit-moment reconstruction",
                          "full integer-ring verification", "complete event stream hash",
                          "one-node checkpoint resume equality", "zero-node OPEN",
                          "zero-time OPEN", "changed-pool checkpoint rejection",
                          "graceful stop resumes exact event suffix",
                          "unsupported reconstruction retains exact variant OPEN",
                          "derived-state checkpoint rejection", "partial-pool non-exclusion",
                          "unsupported orthogonal context remains OPEN"],
                full_counters=full["totals"], resume_chunks=chunks,
                event_count=len(events), complete_event_stream_sha256=full["visited_ledger_sha256"],
                verified_Q8_table_sha256=verification["table_sha256"],
                source_sha256={name: hashlib.sha256((Path(__file__).parent / name).read_bytes()).hexdigest()
                    for name in ("target_search.py", "target_search_selftest.py", "orbit_exact.py",
                                 "alignment.py", "verifier.py", "backend_fixtures.py")})


def main():
    if not __debug__:
        raise RuntimeError("Run exact controls with assertions enabled")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("target_search_control_report.json"))
    parser.add_argument("--write-fixture", type=Path)
    args = parser.parse_args()
    result = run_controls()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    if args.write_fixture:
        args.write_fixture.parent.mkdir(parents=True, exist_ok=True)
        args.write_fixture.write_text(json.dumps(q8_pool(), indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: result[k] for k in ("status", "event_count", "full_counters")}, indent=2))


if __name__ == "__main__":
    main()
