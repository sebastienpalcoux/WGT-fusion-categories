#!/usr/bin/env python3
"""Vendor the frozen selected rank16 Python closure and its small profile data.

Only authenticated files from the immutable release manifest are copied.
No large input, certificate batch or replay ledger is included here.
"""
from pathlib import Path
import argparse
import json

from common import atomic_json, file_hash
from runner import copy_bound


def install(source, destination):
    source, destination = Path(source).resolve(), Path(destination).resolve()
    manifest_path = source / "RELEASE_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text())
    files = {x["file"]: x for x in manifest["files"]}
    selected = [name for name in files if "/" not in name and name.endswith(".py")]
    selected.append("symplectic_profiles.json")
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("Vendor directory is not empty; do not silently replace a frozen dependency closure")
    destination.mkdir(parents=True, exist_ok=True)
    checked = {}
    for name in sorted(selected):
        checked[name] = copy_bound(source / name, destination / name, files[name]["sha256"])
    provenance = {"status": "PASS_AUTHENTICATED_FROZEN_RANK16_VENDOR",
                  "original_manifest_sha256": file_hash(manifest_path),
                  "files": checked,
                  "selection": "Every selected top-level Python file, plus symplectic_profiles.json. No large search payloads.",
                  "source_files_modified": False}
    atomic_json(destination / "VENDOR_MANIFEST.json", provenance)
    return provenance


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("--destination", type=Path, default=Path(__file__).parent / "vendor/rank16")
    args = parser.parse_args()
    result = install(args.source, args.destination)
    print(json.dumps({"status": result["status"], "files": len(result["files"]),
                      "bytes": sum(x["bytes"] for x in result["files"].values())}, indent=2))
