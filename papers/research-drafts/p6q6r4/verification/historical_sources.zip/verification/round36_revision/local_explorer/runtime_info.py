"""Minimal public machine metadata for interpreting a local performance report."""
from __future__ import annotations

import os
import platform
import sys


def runtime_info():
    # No hostname, username, home directory, environment variables or network
    # information is collected. These fields explain timing differences only.
    result = {
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "operating_system": platform.system(),
        "operating_system_release": platform.release(),
        "machine_architecture": platform.machine(),
        "logical_cpu_count": os.cpu_count(),
        "byte_order": sys.byteorder,
        "exact_arithmetic": "Python arbitrary-precision integers and Fraction",
    }
    if hasattr(os, "sched_getaffinity"):
        try:
            result["available_cpu_count"] = len(os.sched_getaffinity(0))
        except OSError:
            pass
    return result
