"""Reproduce the supplied program, then compare exact sets and CPU timings."""
from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

from common import atomic_json, digest_object, file_hash, read_json, utc_now
from runner import HERE, copy_bound, current_code
from storage import write_feedback
from version import SCHEMA, TOOL_VERSION


def run_benchmark(attachment, output, reference_time_limit=300):
    attachment, output = Path(attachment).resolve(), Path(output).resolve()
    if output.exists():
        raise ValueError("Benchmark output must be a fresh directory")
    output.mkdir(parents=True)
    code = current_code()
    for name, expected in code.items():
        copy_bound(HERE / name, output / "tool_snapshot" / name, expected)
    reference = output / "reference"
    reference.mkdir()
    sources = {}
    for name in ("base.py", "cheap_gates.py", "benchmark.py"):
        sources[name] = copy_bound(attachment / name, reference / name)
    atomic_json(output / "config.json", {"schema": SCHEMA, "tool_version": TOOL_VERSION,
                "created_utc": utc_now(), "scope": "Complete attachment all-rational arithmetic benchmark",
                "attachment_source_files": sources, "code_files": code,
                "code_sha256": digest_object(code), "reference_time_limit": reference_time_limit})
    report = {"status": "FAILED", "complete_declared_scope": False}
    try:
        wrapper = ("import json,runpy,time; from pathlib import Path; "
                   "w=time.perf_counter(); c=time.process_time(); "
                   "runpy.run_path('benchmark.py',run_name='__main__'); "
                   "Path('process_metrics.json').write_text(json.dumps(dict("
                   "wall_seconds=time.perf_counter()-w,cpu_seconds=time.process_time()-c)))")
        with (reference / "stdout.json").open("w") as out, (reference / "stderr.log").open("w") as err:
            result = subprocess.run([sys.executable, "-B", "-S", "-c", wrapper], cwd=reference,
                                    stdout=out, stderr=err, timeout=reference_time_limit)
        if result.returncode:
            raise RuntimeError("Original supplied benchmark failed; see reference/stderr.log")
        with (output / "optimized.log").open("w") as out:
            result = subprocess.run([sys.executable, "-B", "-S", str(output / "tool_snapshot/benchmark_worker.py"),
                                     str(output / "optimized.json")], stdout=out, stderr=subprocess.STDOUT,
                                    timeout=reference_time_limit)
        if result.returncode:
            raise RuntimeError("Optimized benchmark failed; see optimized.log")
        old, new = read_json(reference / "stdout.json"), read_json(output / "optimized.json")
        metrics = read_json(reference / "process_metrics.json")
        old_survivors = read_json(reference / "combined_survivors.json")
        old_excluded = read_json(reference / "new_corner_exclusions.json")
        if old["counts"] != new["counts"] or old["per_prime_survival"] != new["per_prime_survival"]:
            raise AssertionError("Original and optimized exact counts disagree")
        if digest_object(sorted(old_survivors)) != new["combined_survivors_sorted_sha256"]:
            raise AssertionError("Exact combined-survivor input sets differ")
        if digest_object(sorted(old_excluded)) != new["new_corner_exclusions_sorted_sha256"]:
            raise AssertionError("Exact new-corner exclusion input sets differ")
        report = {"schema": SCHEMA, "status": "PASS_COMPLETE_EXACT_ARITHMETIC_COMPARISON",
                  "complete_declared_scope": True, "counts": new["counts"],
                  "per_prime_survival": new["per_prime_survival"],
                  "combined_survivors_sorted_sha256": new["combined_survivors_sorted_sha256"],
                  "new_corner_exclusions_sorted_sha256": new["new_corner_exclusions_sorted_sha256"],
                  "original_process_seconds": metrics,
                  "optimized_enumeration_cpu_seconds": new["enumeration_cpu_seconds"],
                  "optimized_enumeration_wall_seconds": new["enumeration_wall_seconds"],
                  "optimized_process_cpu_seconds": new["process_cpu_seconds"],
                  "optimized_process_wall_seconds": new["process_wall_seconds"],
                  "observed_cpu_ratio": metrics["cpu_seconds"] / new["process_cpu_seconds"],
                  "scope": "All-rational canonical placements. No incremental credit against the full-field R36 row pipeline is inferred.",
                  "comparison": "Every count, per-prime count and the two complete normalized input sets agree.",
                  "performance_limit": "Observed timings on this machine only; no fastest-possible claim."}
    except subprocess.TimeoutExpired as exc:
        report = {"schema": SCHEMA, "status": "BUDGET_STOP", "complete_declared_scope": False,
                  "reason": "benchmark_process_time_limit", "details": str(exc),
                  "comparison_passed": False}
    except Exception as exc:
        report = {"schema": SCHEMA, "status": "FAILED", "complete_declared_scope": False,
                  "reason": type(exc).__name__, "details": str(exc), "comparison_passed": False}
    atomic_json(output / "run_report.json", report)
    atomic_json(output / "restart.json", {"supported": False,
                "reason": "A timing comparison is restarted as a complete bounded benchmark; it is not a partial mathematical exclusion."})
    return report, write_feedback(output)
