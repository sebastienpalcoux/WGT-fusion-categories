"""Exact cyclotomic orbit arithmetic for complete character-table inputs.

No floating-point embedding is used. Values use the integral power basis of
Z[zeta_c]; a labelled fixed field is checked by its automorphism subgroup.
All linear embeddings in a Galois orbit are included by the field trace.
This module never treats a field label or row moment as an aligned table.
"""
from functools import lru_cache
from fractions import Fraction
from math import gcd

VERSION = "orbit-exact-1"


def _trim(poly):
    p = list(poly)
    while len(p) > 1 and not p[-1]:
        p.pop()
    return tuple(p)


def _divide_monic(a, b):
    a = list(_trim(a)); b = _trim(b)
    if b[-1] != 1:
        raise ValueError("Divisor is not monic")
    out = [0] * max(1, len(a) - len(b) + 1)
    for k in range(len(a)-len(b), -1, -1):
        q = a[k+len(b)-1]; out[k] = q
        for j, v in enumerate(b):
            a[k+j] -= q*v
    if any(a):
        raise ValueError("Polynomial division is not exact")
    return _trim(out)


@lru_cache(None)
def cyclotomic(n):
    if not isinstance(n, int) or n < 1:
        raise ValueError("A positive conductor is required")
    p = [-1] + [0] * (n-1) + [1]
    for d in range(1, n):
        if n % d == 0:
            p = _divide_monic(p, cyclotomic(d))
    return tuple(p)


def kronecker_unit(delta, a):
    """Kronecker(delta/a), for nonnegative a (zero is also handled)."""
    if a == 0:
        return int(abs(delta) == 1)
    if a < 0:
        raise ValueError("Nonnegative denominator required")
    ans = 1
    while a % 2 == 0:
        a //= 2
        if delta % 2 == 0:
            return 0
        if delta % 8 in (3, 5):
            ans = -ans
    delta %= a
    while delta:
        while delta % 2 == 0:
            delta //= 2
            if a % 8 in (3, 5):
                ans = -ans
        delta, a = a, delta
        if delta % 4 == a % 4 == 3:
            ans = -ans
        delta %= a
    return ans if a == 1 else 0


def _mobius(n):
    s = 1; p = 2
    while p*p <= n:
        if n % p == 0:
            n //= p; s = -s
            if n % p == 0:
                return 0
            while n % p == 0:
                n //= p
        p += 1
    return -s if n > 1 else s


def fundamental_discriminant(delta):
    if delta in (0, 1):
        return False
    if delta % 4 == 1:
        radicand = delta
    elif delta % 4 == 0 and (delta//4) % 4 in (2, 3):
        radicand = delta//4
    else:
        return False
    return _mobius(abs(radicand)) != 0


@lru_cache(None)
def ramanujan(n, k):
    g = gcd(n, k)
    return sum(d*_mobius(n//d) for d in range(1, g+1) if g % d == 0)


class CyclotomicField:
    def __init__(self, conductor, subgroup):
        self.conductor = int(conductor)
        self.poly = cyclotomic(self.conductor)
        self.ambient_degree = len(self.poly)-1
        units = {u for u in range(self.conductor) if gcd(u, self.conductor) == 1}
        h = frozenset(int(x) % self.conductor for x in subgroup)
        if not h or self.conductor and (1 % self.conductor) not in h:
            raise ValueError("The field subgroup must contain the identity")
        if not h <= units or any((a*b) % self.conductor not in h for a in h for b in h):
            raise ValueError("Invalid cyclotomic subgroup")
        self.subgroup = tuple(sorted(h))
        self.degree = self.ambient_degree // len(h)
        if self.degree*len(h) != self.ambient_degree:
            raise ValueError("Invalid fixed-field degree")
        self.zero = (0,) * self.ambient_degree
        self.one = (1,) + (0,) * (self.ambient_degree-1)
        self.trace_vector = tuple(ramanujan(self.conductor, j) for j in range(self.ambient_degree))
        self.powers = tuple(self.reduce([0]*j+[1]) for j in range(self.conductor))

    def reduce(self, coeffs):
        p = list(coeffs)
        if any(not isinstance(x, int) or isinstance(x, bool) for x in p):
            raise ValueError("Character values require integer cyclotomic coefficients")
        n = self.ambient_degree
        p += [0] * max(0, n-len(p))
        for k in range(len(p)-1, n-1, -1):
            q = p[k]
            if q:
                for j in range(n):
                    p[k-n+j] -= q*self.poly[j]
        return tuple(p[:n])

    def add(self, a, b):
        return tuple(x+y for x, y in zip(a, b))

    def scale(self, a, k):
        return tuple(k*x for x in a)

    @lru_cache(maxsize=131072)
    def mul(self, a, b):
        n = self.ambient_degree
        p = [0] * (2*n-1)
        for i, x in enumerate(a):
            if x:
                for j, y in enumerate(b):
                    if y:
                        p[i+j] += x*y
        return self.reduce(p)

    @lru_cache(maxsize=65536)
    def auto(self, a, u):
        out = [0] * self.ambient_degree
        for j, x in enumerate(a):
            if x:
                for i, y in enumerate(self.powers[(u*j) % self.conductor]):
                    out[i] += x*y
        return tuple(out)

    def conjugate(self, a):
        return self.auto(a, self.conductor-1)

    def is_fixed(self, a):
        return all(self.auto(a, u) == a for u in self.subgroup)

    def value(self, coefficients):
        a = self.reduce(coefficients)
        if not self.is_fixed(a):
            raise ValueError("Value is not in the specified fixed field")
        return a

    @lru_cache(maxsize=131072)
    def trace(self, a):
        numerator = sum(x*t for x, t in zip(a, self.trace_vector))
        denominator = len(self.subgroup)
        if numerator % denominator:
            raise ValueError("Nonintegral field trace; check fixed-field membership")
        return numerator // denominator

    @lru_cache(maxsize=262144)
    def inner(self, a, b):
        return self.trace(self.mul(a, self.conjugate(b)))

    def metadata(self, label=None, formal_codegree=None):
        out = dict(conductor=self.conductor, subgroup=list(self.subgroup), degree=self.degree)
        if label is not None:
            out['label'] = label
        if formal_codegree is not None:
            out['formal_codegree'] = int(formal_codegree)
        return out


@lru_cache(None)
def field_for_label(label):
    if label == 'Q':
        return CyclotomicField(1, (0,))
    if label == 'Q(sqrt(-3))':
        return CyclotomicField(3, (1,))
    if label == 'real_cubic_conductor9':
        return CyclotomicField(9, (1, 8))
    if label.startswith('quadratic_disc='):
        delta = int(label.split('=', 1)[1]); c = abs(delta)
        if c < 3 or not fundamental_discriminant(delta):
            raise ValueError("Invalid quadratic discriminant")
        h = tuple(a for a in range(c) if gcd(a, c) == 1 and kronecker_unit(delta, a) == 1)
        field = CyclotomicField(c, h)
        if field.degree != 2:
            raise ValueError("Discriminant does not specify a quadratic field")
        return field
    if label.startswith('zeta') and ':H=' in label:
        c, h = label[4:].split(':H=', 1)
        return CyclotomicField(int(c), tuple(map(int, h.split(','))))
    raise ValueError("Unsupported field label: " + str(label))


def field_from_metadata(orbit):
    field = field_for_label(orbit['label'])
    for key, actual in [('conductor', field.conductor), ('degree', field.degree)]:
        if key in orbit and orbit[key] != actual:
            raise ValueError("Inconsistent field metadata: " + key)
    if 'subgroup' in orbit and tuple(orbit['subgroup']) != field.subgroup:
        raise ValueError("Inconsistent field subgroup")
    return field


def integral_basis_small(label):
    """A proved full integral basis for Q, a quadratic field, or real K9."""
    field = field_for_label(label)
    if label == 'Q':
        return (field.one,)
    if label == 'real_cubic_conductor9':
        theta = field.add(field.powers[1], field.powers[8])
        return (field.one, theta, field.mul(theta, theta))
    delta = -3 if label == 'Q(sqrt(-3))' else (
        int(label.split('=', 1)[1]) if label.startswith('quadratic_disc=') else None)
    if delta is None:
        raise ValueError("No full small integral-basis enumerator for " + label)
    gauss = field.zero
    for a in range(field.conductor):
        chi = kronecker_unit(delta, a)
        if chi:
            gauss = field.add(gauss, field.scale(field.powers[a], chi))
    if field.mul(gauss, gauss) != field.scale(field.one, delta):
        raise ValueError("Quadratic Gauss-sum identity failed")
    t = 1 if delta % 4 == 1 else 0
    numerator = field.add(gauss, field.scale(field.one, t))
    if any(x % 2 for x in numerator):
        raise ValueError("Quadratic integral-basis embedding failed")
    omega = tuple(x//2 for x in numerator)
    if not field.is_fixed(omega):
        raise ValueError("Quadratic basis not fixed by subgroup")
    return (field.one, omega)


def _row_values(row, fields):
    values = row['values']
    if len(values) != len(fields):
        raise ValueError("Wrong number of character orbits in a row")
    return tuple(field.value(v) for field, v in zip(fields, values))


def conjugate_values(row, orbits):
    fields = tuple(field_from_metadata(o) for o in orbits)
    values = _row_values(row, fields)
    return tuple(f.conjugate(v) for f, v in zip(fields, values))


def fixed_key(row, orbits):
    fields = tuple(field_from_metadata(o) for o in orbits)
    values = _row_values(row, fields)
    return (row['dimension'], row['matrix_trace'],
            tuple(f.add(v, f.conjugate(v)) for f, v in zip(fields, values)))


def pair_scaled(x, y, orbits, dimension=5400):
    """D times the complete linear trace pairing, including Perron."""
    total = int(x['dimension'])*int(y['dimension'])
    for o, a, b in zip(orbits, x['values'], y['values']):
        f = int(o['formal_codegree'])
        if dimension % f:
            raise ValueError("Codegree must divide the chosen dimension")
        field = field_from_metadata(o)
        total += (dimension//f)*field.inner(tuple(a), tuple(b))
    return total


def fixed_pair_scaled(x, y, orbits, dimension=5400, matrix_codegree=60):
    """2D times fixed-part pairing for a symplectic one-M2 table.

    Distinct representative rows must have value zero. A selfdual diagonal
    is 2D; a representative of a nonselfdual pair has diagonal D.
    """
    if dimension % matrix_codegree:
        raise ValueError("Matrix codegree must divide dimension")
    total = 2*int(x['dimension'])*int(y['dimension'])
    total += (dimension//matrix_codegree)*int(x['matrix_trace'])*int(y['matrix_trace'])
    for o, a, b in zip(orbits, x['values'], y['values']):
        field = field_from_metadata(o)
        twice_real_b = field.add(tuple(b), field.conjugate(tuple(b)))
        total += (dimension//int(o['formal_codegree']))*field.trace(field.mul(tuple(a), twice_real_b))
    return total


def exact_json(x):
    x = Fraction(x)
    return x.numerator if x.denominator == 1 else str(x)


def moments_payload(rows, duality, orbits, dimension=5400, matrix_codegree=None):
    """Build exact complete linear moments for reconstruction_from_moments.

    The caller supplies the complete common simple basis, including its unit.
    All characteristic-zero embeddings of each orbit are included by trace.
    """
    n = len(rows)
    if len(duality) != n or any(not isinstance(j, int) or not 0 <= j < n for j in duality):
        raise ValueError("Invalid complete duality permutation")
    if any(duality[duality[i]] != i for i in range(n)):
        raise ValueError("Duality must be an involution")
    fields = tuple(field_from_metadata(o) for o in orbits)
    vals = tuple(_row_values(row, fields) for row in rows)
    if 1 + sum(f.degree for f in fields) != n-4:
        raise ValueError("Linear orbits do not have dimension rank minus four")
    if rows[0]['dimension'] != 1 or duality[0] != 0:
        raise ValueError("The first row must be the tensor unit")
    for f, value in zip(fields, vals[0]):
        if value != f.one:
            raise ValueError("Every unit character value must be one")
    for i in range(n):
        if rows[i]['dimension'] != rows[duality[i]]['dimension']:
            raise ValueError("Dual dimensions disagree")
        for k, f in enumerate(fields):
            if vals[duality[i]][k] != f.conjugate(vals[i][k]):
                raise ValueError("Character values do not respect source duality")
    weights = []
    for o in orbits:
        codegree = int(o['formal_codegree'])
        if codegree <= 0 or dimension % codegree:
            raise ValueError("Invalid integral formal codegree")
        weights.append(dimension//codegree)
    dims = [int(row['dimension']) for row in rows]
    pair = [[dims[i]*dims[j] for j in range(n)] for i in range(n)]
    triple = [[[dims[i]*dims[j]*dims[k] for k in range(n)] for j in range(n)] for i in range(n)]
    for b, (field, weight) in enumerate(zip(fields, weights)):
        values = tuple(vals[i][b] for i in range(n))
        for i in range(n):
            for j in range(n):
                pair[i][j] += weight*field.inner(values[i], values[j])
                product = field.mul(values[i], values[j])
                for k in range(n):
                    triple[i][j][k] += weight*field.inner(product, values[k])
    return dict(unit=0, duality=list(duality), dimensions=dims,
                linear_pair_moments=[[exact_json(Fraction(x, dimension)) for x in row] for row in pair],
                linear_triple_moments=[[[exact_json(Fraction(x, dimension)) for x in row] for row in layer] for layer in triple],
                matrix_codegree=matrix_codegree,
                labels=[str(row.get('id', i)) for i, row in enumerate(rows)],
                moments_provenance=dict(module_version=VERSION, exact=True,
                    representation='integral cyclotomic fixed-field orbit traces',
                    all_embeddings_in_each_orbit=True,
                    orbits=orbits))
