"""Small exact controls for enumeration, feedback integrity and safe resume.

This is not another large mathematical sweep. It checks independent tiny
enumerations, transactional failure semantics, archive validation, and real
backend paths including stopped/resumed target preparation and alignment.
"""
from __future__ import annotations

import argparse
import gzip
from itertools import combinations_with_replacement
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

from common import atomic_json, canonical_bytes, digest_object, file_hash, read_json
from compositions import CompositionSearch, exact_count, fast_compositions
from storage import TaskStore, import_feedback, write_feedback

HERE = Path(__file__).resolve().parent


def run_controls(output):
    output = Path(output).resolve()
    if output.exists():
        raise ValueError("Control output must be fresh")
    output.mkdir(parents=True)
    checks = []
    timings = {}

    def passed(name, **details):
        checks.append({"name": name, "status": "PASS", **details})

    def invoke(name, args, *, script=None):
        began = time.monotonic()
        cp = subprocess.run([sys.executable, "-B", "-S", str(script or HERE / "explore.py"), *map(str, args)],
                            capture_output=True, text=True)
        (output / (name + ".stdout.txt")).write_text(cp.stdout)
        (output / (name + ".stderr.txt")).write_text(cp.stderr)
        assert cp.returncode == 0, (name, cp.returncode, cp.stdout, cp.stderr)
        timings[name] = time.monotonic() - began
        return json.loads(cp.stdout)

    def results(directory):
        with gzip.open(directory / "results.jsonl.gz", "rt") as handle:
            return [json.loads(line) for line in handle]

    # Three independent descriptions: direct product, integer count DP and
    # resumable bitset DFS. The state is JSON-round-tripped after every node.
    cases = 0
    for values in ((1, 2, 4), (1, 4, 9), (3, 6, 10)):
        for slots in range(5):
            for total in range(25):
                direct = sorted(tuple(reversed(x)) for x in combinations_with_replacement(values, slots) if sum(x) == total)
                actual = []
                engine = CompositionSearch(values, slots, total)
                while not engine.done:
                    item = engine.step()
                    if item is not None:
                        actual.append(item)
                    engine = CompositionSearch(values, slots, total, state=json.loads(json.dumps(engine.state())))
                assert sorted(actual) == direct
                assert exact_count(values, slots, total) == len(direct)
                assert sorted(fast_compositions(values, slots, total)) == direct
                cases += 1
    passed("bruteforce_count_bitset_and_nodewise_resume", exact_cases=cases)

    db = output / "transaction.sqlite"
    store = TaskStore(db, "tiny-exact-task")
    store.commit({"offset": 1}, [(0, {"id": "committed", "status": "OPEN"})])
    store.db.execute("INSERT INTO results VALUES(1,'uncommitted','EXCLUDED','{}')")
    store.db.execute("UPDATE meta SET value='{}' WHERE key='checkpoint'")
    store.close()
    store = TaskStore(db, "tiny-exact-task", readonly=True)
    assert store.state() == {"offset": 1} and store.histogram() == {"OPEN": 1}
    store.close()
    passed("sqlite_uncommitted_result_and_frontier_rollback")

    common = ["run", "--scope", "source-types", "--hypotheses", "dimension-equation",
              "--dimension", 60, "--rank", 4, "--time-limit", 0]
    first = output / "types_partial"
    run = invoke("types_partial", common + ["--node-limit", 2, "--workers", 2,
                 "--checkpoint-every", 1, "--output", first])
    assert run["status"] == "BUDGET_STOP" and run["committed_nodes"] == 2
    resumed = output / "types_resumed"
    run = invoke("types_resumed", ["resume", first.with_suffix(".feedback.zip"),
                 "--output", resumed, "--node-limit", 0, "--time-limit", 0, "--workers", 2],
                 script=first / "tool_snapshot/explore.py")
    assert run["complete_declared_scope"]
    single = output / "types_single"
    invoke("types_single", common + ["--node-limit", 0, "--workers", 1, "--output", single])
    assert results(resumed) == results(single)
    expected = sorted([1, *reversed(ds)] for ds in combinations_with_replacement(range(1, 8), 3)
                      if 1 + sum(d*d for d in ds) == 60)
    actual = sorted(row["input"]["dimensions"] for row in results(single))
    assert actual == expected and len(actual) == 2
    passed("workers_two_zip_resume_equals_workers_one_exact_source_types", types=actual)

    shards = []
    for i in range(2):
        path = output / ("types_shard_" + str(i))
        invoke(path.name, common + ["--node-limit", 0, "--shard-count", 2,
                                   "--shard-index", i, "--output", path])
        shards += results(path)
    assert sorted(shards, key=lambda r:r["id"]) == sorted(results(single), key=lambda r:r["id"])
    assert len({r["id"] for r in shards}) == len(shards)
    passed("external_shards_disjoint_exact_union")

    empty_root = output / "empty_payload"
    empty_root.mkdir()
    (empty_root / "empty.jsonl").write_bytes(b"")
    (empty_root / "data.txt").write_text("bound exact data\n")
    archive = write_feedback(empty_root)
    imported = import_feedback(archive, output / "empty_imported")
    assert (imported / "empty.jsonl").is_file() and (imported / "empty.jsonl").stat().st_size == 0
    for mutation in ("hash", "traversal", "alias"):
        broken = output / (mutation + ".zip")
        with zipfile.ZipFile(archive) as source, zipfile.ZipFile(broken, "w") as dest:
            for item in source.infolist():
                data = source.read(item.filename)
                if mutation == "hash" and item.filename == "data.txt":
                    data = data.replace(b"bound", b"wrong")
                dest.writestr(item, data)
            if mutation == "traversal":
                dest.writestr("../escape", "forbidden")
            if mutation == "alias":
                dest.writestr("./data.txt", "ambiguous alias")
        try:
            import_feedback(broken, output / (mutation + "_accepted"))
        except ValueError:
            pass
        else:
            raise AssertionError("Tampered feedback was accepted: " + mutation)
    passed("feedback_empty_members_preserved_and_hash_traversal_rejected")

    fixture = read_json(HERE / "backend_fixture_inputs/fullfield_first100_audit.json")
    combined = output / "fullfield_default100"
    invoke("fullfield_default100", ["run", "--shard-count", 98, "--shard-index", 0,
           "--node-limit", 100, "--time-limit", 0, "--output", combined])
    observed = results(combined)
    assert [r["open_index"] for r in observed] == list(range(100))
    expected = {r["state"]: (stage,r["witness"]) for stage, values in fixture["negative_stages"].items() for r in values}
    negatives = {r["state"]:r for r in observed if r["status"] == "EXCLUDED"}
    assert negatives.keys() == expected.keys()
    for state, row in negatives.items():
        stage, witness = expected[state]
        assert row["certificate"]["witness"] == witness
        assert (row["gate"] == "frobenius-corner-descent-v1") == (stage == "frobenius")
    base = output / "fullfield_base100"
    invoke("fullfield_base100", ["run", "--base-only", "--shard-count", 98, "--shard-index", 0,
           "--node-limit", 100, "--time-limit", 0, "--output", base])
    assert {r["state"] for r in results(base) if r["status"] == "EXCLUDED"} == {
        r["state"] for r in fixture["negative_stages"]["base"]}
    passed("default_frobenius_and_explicit_base_only_match_independently_audited_witnesses",
           records=100, base_exclusions=len(fixture["negative_stages"]["base"]),
           additional_frobenius_exclusions=len(fixture["negative_stages"]["frobenius"]))

    from backend_fixtures import a5_representation_ring, octonion_unit_loop, s3_alignment_pool
    a5_input, bad_input, align_input = output / "A5.json", output / "loop.json", output / "S3_pool.json"
    atomic_json(a5_input, a5_representation_ring())
    atomic_json(bad_input, octonion_unit_loop())
    atomic_json(align_input, s3_alignment_pool())
    verified = output / "verified_A5"
    invoke("verify_A5", ["verify", "--input", a5_input, "--dimension", 60,
                        "--output", verified])
    report = read_json(verified / "run_report.json")
    assert report["verified_labelled_fusion_ring_tables"] == 1 and report["complete_declared_scope"]
    rejected = output / "rejected_loop"
    invoke("reject_loop", ["verify", "--input", bad_input, "--dimension", 16,
                          "--min-dimension", 1, "--allow-proper-subrings", "--output", rejected])
    result = read_json(rejected / "backend_invocations/invocation_0000.json")["result"]
    assert result["reason"] == "ASSOCIATIVITY_FAILURE" and result["status"] == "EXCLUDED", result
    passed("cli_exact_simple_A5_verifies_and_nonassociative_loop_rejects")

    invalid_input, invalid = output / "invalid_table.json", output / "invalid_table_run"
    atomic_json(invalid_input, {})
    invoke("invalid_table", ["verify", "--input", invalid_input, "--output", invalid])
    invalid_report = read_json(invalid / "run_report.json")
    assert invalid_report["status"] == "INVALID_INPUT" and not invalid_report["complete_declared_scope"]
    assert invalid_report["verified_labelled_fusion_ring_tables"] == 0
    passed("invalid_table_never_becomes_a_completed_exclusion_scope")

    aligned = output / "alignment_partial"
    invoke("alignment_partial", ["align", "--input", align_input, "--dimension", 6,
           "--min-dimension", 1, "--allow-proper-subrings", "--max-results", 100,
           "--node-limit", 1, "--time-limit", 0, "--output", aligned])
    assert not read_json(aligned / "run_report.json")["complete_declared_scope"]
    (aligned / "backend_checkpoint.json").unlink()
    invoke("alignment_resume", ["resume", aligned, "--node-limit", 0, "--time-limit", 0],
           script=aligned / "tool_snapshot/explore.py")
    report = read_json(aligned / "run_report.json")
    assert report["complete_declared_scope"] and report["verified_labelled_fusion_ring_tables"] >= 1
    from backend_runs import validated_history
    history, outcomes, cp = validated_history(aligned)
    intervals = []
    for outcome in outcomes:
        for line in (aligned / outcome["events"]).read_text().splitlines():
            event = json.loads(line)
            if event.get("event_type") == "alignment_interval":
                intervals.append((event["range_start"], event["range_stop"]))
    assert intervals[0][0] == 0 and intervals[-1][1] == cp["total_assignments"]
    assert all(a[1] == b[0] for a,b in zip(intervals, intervals[1:]))
    passed("backend_history_recovers_without_convenience_checkpoint_and_covers_grid", intervals=len(intervals))

    pool_partial = output / "pool_partial"
    invoke("pool_partial", ["prepare-target", "--state", 836343, "--node-limit", 1,
                            "--time-limit", 0, "--output", pool_partial])
    assert not read_json(pool_partial / "pool.json")["completeness"]["complete"]
    invoke("pool_resume", ["resume", pool_partial, "--node-limit", 0, "--time-limit", 0],
           script=pool_partial / "tool_snapshot/explore.py")
    pool_complete = output / "pool_complete"
    invoke("pool_complete", ["prepare-target", "--state", 836343, "--node-limit", 0,
                             "--time-limit", 0, "--output", pool_complete])
    a,b = read_json(pool_partial / "pool.json"), read_json(pool_complete / "pool.json")
    for key in ("target", "rows", "unit", "orbits"):
        assert a[key] == b[key]
    assert a["completeness"]["complete"] and b["completeness"]["complete"]
    passed("full_field_pool_one_node_stop_resume_equals_complete", exact_rows=len(a["rows"]))

    target = output / "target_partial"
    invoke("target_partial", ["search-target", "--pool", pool_complete / "pool.json",
           "--node-limit", 1, "--time-limit", 0, "--output", target])
    assert not read_json(target / "run_report.json")["complete_declared_scope"]
    invoke("target_resume", ["resume", target, "--node-limit", 0, "--time-limit", 0],
           script=target / "tool_snapshot/explore.py")
    report = read_json(target / "run_report.json")
    assert report["complete_declared_scope"] and report["committed_nodes"] == 11
    assert report["verified_labelled_fusion_ring_tables"] == 0
    validated_history(target)
    passed("full_field_target_one_node_stop_resume_exact_exhaustion", nodes=11)

    batch = output / "batch_partial"
    invoke("batch_partial", ["explore-targets", "--include-known", "--states", 836343, "--per-target-seconds", 0,
           "--per-target-nodes", 0, "--node-limit", 10, "--time-limit", 0, "--output", batch])
    assert not read_json(batch / "run_report.json")["complete_declared_scope"]
    invoke("batch_resume", ["resume", batch, "--node-limit", 0, "--time-limit", 0],
           script=batch / "tool_snapshot/explore.py")
    report = read_json(batch / "run_report.json")
    assert report["complete_declared_scope"] and report["committed_nodes"] == 77
    assert report["result_counts"] == {"EXCLUDED_WITHIN_COMPLETE_ROW_POOL": 1}
    passed("combined_target_batch_transactional_stop_resume", moment_nodes=66, graph_nodes=11)

    from target_batch import fair_pending_tasks
    tasks = [{"id": str(i), "state": i} for i in range(1, 5)]
    history = [{"workers": [{"visited_target_ids": [1, 3]}]}]
    assert fair_pending_tasks(tasks, ["1", "2", "3", "4"], history) == ["2", "4", "1", "3"]
    history.append({"workers": [{"visited_target_ids": [2, 4]}]})
    assert fair_pending_tasks(tasks, ["1", "2", "3", "4"], history) == ["1", "2", "3", "4"]
    passed("fair_resume_scheduling_prevents_early_target_starvation")

    listing = invoke("default_target_selection", ["list-targets", "--limit", 0])
    assert listing["known_complete_state_exclusions"] == [47412, 461210, 836343, 1284815]
    assert listing["unresolved_record_count"] == listing["selected_record_count"] == 1488
    assert len(listing["targets"]) == 1488
    assert all(x["known_result"] == "OPEN_IN_DECLARED_TARGET_CATALOGUE" for x in listing["targets"])
    passed("default_catalogue_skips_four_bound_exclusions", unresolved=1488)

    from runtime_info import runtime_info
    environment = read_json(batch / "environment.json")
    assert environment["python_version"] == runtime_info()["python_version"]
    assert not {"hostname", "username", "environment", "home"} & environment.keys()
    passed("feedback_records_minimal_performance_environment")

    from runner import current_code
    report = {"status": "PASS_LOCAL_EXPLORER_INFRASTRUCTURE_CONTROLS", "checks": checks,
              "control_count": len(checks), "timings_seconds": timings,
              "source_sha256": current_code(),
              "actual_dimension5400_rings_found": 0,
              "scope": "Small infrastructure controls; complete arithmetic benchmark and mathematical gate audits are separate."}
    atomic_json(output / "control_report.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = run_controls(args.output)
    print(json.dumps({"status": report["status"], "control_count": report["control_count"]}, indent=2))


if __name__ == "__main__":
    main()
