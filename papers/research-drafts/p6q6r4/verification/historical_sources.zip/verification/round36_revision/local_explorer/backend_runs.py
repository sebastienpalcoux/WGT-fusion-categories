"""Feedback/restart envelope for exact supplied-table and alignment work."""
from __future__ import annotations

import json
from pathlib import Path
import signal
import subprocess
import sys
import time

from common import atomic_json, digest_object, file_hash, read_json, utc_now
from runner import HERE, copy_bound, current_code, task_record, validate_run
from storage import write_feedback
from version import SCHEMA, TOOL_VERSION, ALGORITHM_VERSION
from runtime_info import runtime_info

BACKENDS = ("verify", "reconstruct", "moments", "align", "prepare-target", "search-target")


def validated_history(root):
    """Return only complete, chained invocations with exact retained ledgers.

    A killed invocation without a committed history entry is replayed. A kill
    after that entry is safe even before convenience exports have been written.
    """
    history = read_json(root / "history.json")
    checkpoint = None
    outcomes = []
    for index, item in enumerate(history):
        if item["invocation"] != index:
            raise ValueError("Backend invocation history is not contiguous")
        path = root / item["outcome_path"]
        if file_hash(path) != item["outcome_sha256"]:
            raise ValueError("Backend committed outcome changed")
        old = read_json(path)
        if old.get("events") and file_hash(root / old["events"]) != old["event_ledger_sha256"]:
            raise ValueError("Backend committed event ledger changed")
        if old["status"] == "RETURNED":
            if old["previous_checkpoint_sha256"] != digest_object(checkpoint):
                raise ValueError("Backend checkpoint chain is broken")
            checkpoint = old.get("committed_checkpoint")
        outcomes.append(old)
    return history, outcomes, checkpoint


def create_backend_run(output, kind, input_path, *, dimension=5400,
                       require_simple=True, min_dimension=3, max_results=1,
                       source_provenance=None):
    output, input_path = Path(output).resolve(), Path(input_path).resolve()
    if output.exists():
        raise ValueError("Backend run directory must be fresh")
    if kind not in BACKENDS or max_results < 1:
        raise ValueError("Invalid backend kind or result limit")
    payload = read_json(input_path)
    output.mkdir(parents=True)
    code = current_code()
    for name, expected in code.items():
        copy_bound(HERE / name, output / "tool_snapshot" / name, expected)
    resource = copy_bound(input_path, output / "resources/input.json")
    scope = {"kind": kind, "input_sha256": digest_object(payload),
             "target_predicates": {"target_dimension": dimension,
                                   "require_fusion_simple": require_simple,
                                   "min_nonunit_dimension": min_dimension},
             "max_results": max_results,
             "scope_limit": "The supplied exact table, aligned data or explicitly supplied/prepared finite row pool only.",
             "categorification_established": False,
             "necessary_data_only": kind in ("prepare-target", "search-target", "align")}
    if source_provenance is not None:
        scope["source_provenance"] = source_provenance
    tasks = [task_record(kind, input_sha256=digest_object(payload))]
    config = {"schema": SCHEMA, "tool_version": TOOL_VERSION, "algorithm_version": ALGORITHM_VERSION,
              "created_utc": utc_now(), "scope": scope, "scope_sha256": digest_object(scope),
              "task_inventory_sha256": digest_object(tasks), "code_files": code,
              "code_sha256": digest_object(code), "resources": {"resources/input.json": resource},
              "portability": "Exact input, full portable code/vendor snapshot, output and restart cursor are bundled."}
    atomic_json(output / "config.json", config)
    atomic_json(output / "tasks.json", tasks)
    atomic_json(output / "history.json", [])
    return output


def execute_backend(root, *, workers=1, time_limit=30.0, node_limit=1000,
                    checkpoint_every=256, profile=False, setup_seconds=0.0):
    root = Path(root).resolve()
    config = validate_run(root)
    if workers != 1:
        raise ValueError("This exact alignment frontier is sequential; use --workers 1. Enumeration/screening commands support parallel workers.")
    if node_limit < 0 or time_limit < 0:
        raise ValueError("Negative backend budget")
    history, outcomes, checkpoint = validated_history(root)
    invocation = len(history)
    (root / "backend_invocations").mkdir(exist_ok=True)
    name = f"backend_invocations/invocation_{invocation:04d}"
    plan = {"time_limit": time_limit, "node_limit": node_limit, "profile": profile,
            "max_results": config["scope"]["max_results"],
            "checkpoint": checkpoint,
            "report": name + ".json", "events": name + ".events.jsonl"}
    plan_path = root / (name + ".plan.json")
    atomic_json(plan_path, plan)
    began = time.monotonic()
    with (root / (name + ".log")).open("wb") as log:
        proc = subprocess.Popen([sys.executable, "-B", "-S", str(root / "tool_snapshot/backend_worker.py"),
                                 str(root), str(plan_path)], stdout=log, stderr=subprocess.STDOUT)
        try:
            proc.wait()
        except KeyboardInterrupt:
            proc.send_signal(signal.SIGINT)
            proc.wait()
    outcome = read_json(root / plan["report"]) if (root / plan["report"]).exists() else {
        "status": "FAILED", "error": {"message": "Backend process did not return; previous committed checkpoint remains resumable."}}
    if outcome["status"] == "RETURNED":
        if (outcome.get("input_sha256") != config["scope"]["input_sha256"]
                or outcome.get("kind") != config["scope"]["kind"]
                or outcome.get("previous_checkpoint_sha256") != digest_object(checkpoint)
                or file_hash(root / outcome["events"]) != outcome["event_ledger_sha256"]):
            raise ValueError("Returned backend outcome failed its input/checkpoint/ledger binding")
    if not (root / plan["report"]).exists():
        atomic_json(root / plan["report"], outcome)
    history.append({"invocation": invocation, "ended_utc": utc_now(), "plan": plan,
                    "outcome_path": plan["report"], "status": outcome["status"],
                    "runtime": runtime_info(),
                    "outcome_sha256": file_hash(root / plan["report"])})
    atomic_json(root / "history.json", history)
    outcomes.append(outcome)
    if outcome["status"] == "RETURNED":
        checkpoint = outcome.get("committed_checkpoint")
    if checkpoint is not None:
        atomic_json(root / "backend_checkpoint.json", checkpoint)
    result = outcome.get("result", {})
    kind = config["scope"]["kind"]
    if kind == "prepare-target":
        complete = result.get("pool", {}).get("completeness", {}).get("complete", False)
        if "pool" in result:
            atomic_json(root / "pool.json", result["pool"])
    elif kind in ("align", "search-target"):
        complete = result.get("complete", False)
    else:
        complete = outcome["status"] == "RETURNED" and result.get("status") in ("VERIFIED", "EXCLUDED")
    unique_verified = {}
    for old in outcomes:
        value = old.get("result", {})
        for solution in value.get("solutions", []):
            reconstruction = solution.get("reconstruction", {})
            if reconstruction.get("status") != "VERIFIED":
                raise ValueError("Backend offered an unverified solution")
            key = reconstruction.get("verification", {}).get("table_sha256")
            if not key:
                raise ValueError("Verified solution has no exact normalized table hash")
            unique_verified[key] = solution
        if kind in ("verify", "reconstruct", "moments") and value.get("status") == "VERIFIED":
            key = value.get("table_sha256") or value.get("verification", {}).get("table_sha256")
            if not key:
                raise ValueError("Verified supplied table has no exact normalized table hash")
            unique_verified[key] = value
    atomic_json(root / "verified_labelled_tables.json", list(unique_verified.values()))
    status = ("FAILED" if outcome["status"] == "FAILED" else "INVALID_INPUT" if result.get("status") == "INVALID_INPUT"
              else "COMPLETE" if complete else result["status"] if result.get("status", "").startswith("OPEN_UNSUPPORTED")
              else "BUDGET_STOP")
    report = {"schema": SCHEMA, "status": status, "backend_status": result.get("status"),
              "complete_declared_scope": bool(complete), "scope": config["scope"],
              "verified_labelled_fusion_ring_tables": len(unique_verified),
              "categorification_established": False,
              "committed_nodes": (checkpoint.get("counts", {}).get("moment_rows", 0)
                                   if kind == "prepare-target" and checkpoint else
                                   sum(h.get("result", {}).get("nodes", 0) for h in outcomes)),
              "result_counts": {result.get("status", "FAILED"): 1},
              "unvisited_or_pending_tasks": 0 if complete else 1,
              "latest_result": plan["report"], "restart_checkpoint": "backend_checkpoint.json"
                   if (root / "backend_checkpoint.json").exists() else None,
              "stage_seconds": {"prepare_inputs": setup_seconds, "backend_wall": time.monotonic() - began,
                                "backend_cpu": outcome.get("cpu_seconds", 0),
                                "all_backend_invocations_cpu": sum(x.get("cpu_seconds", 0) for x in outcomes)},
              "event_ledger_sha256": outcome.get("event_ledger_sha256"),
              "event_count": outcome.get("event_count", 0),
              "event_count_all_committed_invocations": sum(h.get("event_count", 0) for h in outcomes if h["status"] == "RETURNED"),
              "counters": result.get("totals", result.get("statistics", result.get("counters", {
                  key: result[key] for key in ("nodes", "raw_grid_assignments_covered", "reconstruction_attempts") if key in result}))),
              "scope_sha256": config["scope_sha256"], "code_sha256": config["code_sha256"],
              "limitations": ["A completed supplied-pool search does not exclude rows outside that pool.",
                              "A verified labelled fusion-ring table is not a categorification or a count of isomorphism classes.",
                              "Time/node/result stops and unsupported fields never certify a global exclusion."]}
    if outcome.get("error"):
        report["error"] = outcome["error"]
    atomic_json(root / "run_report.json", report)
    atomic_json(root / "restart.json", {"schema": SCHEMA, "complete": bool(complete),
                "backend_checkpoint": report["restart_checkpoint"],
                "scope_sha256": config["scope_sha256"], "code_sha256": config["code_sha256"]})
    packed = time.monotonic()
    feedback = write_feedback(root)
    return report, feedback, time.monotonic() - packed
