"""Complete algebraic lifts of frozen one-M2 necessary character rows.

Preparing a pool does not construct a fusion ring. A complete pool covers all
rows surviving the documented necessary moment conditions for ONE input state.
Budgeted/interruptible preparations retain an exact restart cursor and are
explicitly incomplete. Every scalar embedding is retained through integral
cyclotomic coordinates; no independent rowwise Galois quotient is taken.
"""
from pathlib import Path
from functools import lru_cache
from fractions import Fraction
from itertools import product
import hashlib
import importlib
import json
import sys
import time

from orbit_exact import (cyclotomic, field_for_label, fixed_key, fixed_pair_scaled,
                         conjugate_values)

VERSION = 'target-pool-1'
SCHEMA = 'fusion5400.target_pool.v1'


def canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


def digest_json(value):
    return hashlib.sha256(canonical_json(value).encode()).hexdigest()


def load_kernels(kernel_dir=None):
    if kernel_dir is None:
        kernel_dir = Path(__file__).resolve().parent/'vendor'/'rank16'
    kernel_dir = Path(kernel_dir).resolve()
    if not (kernel_dir/'fixed_field_rows.py').is_file():
        raise ValueError('The preserved rank16 row kernel is missing: ' + str(kernel_dir))
    sys.path.insert(0, str(kernel_dir))
    fixed = importlib.import_module('fixed_field_rows')
    context = importlib.import_module('context16')
    lattice = importlib.import_module('fixed_lattice')
    orbit = importlib.import_module('orbit_pairs')
    for mod in (fixed, context, lattice, orbit):
        if Path(mod.__file__).resolve().parent != kernel_dir:
            raise ValueError('A different row-kernel module was already imported')
    return kernel_dir, fixed, context, lattice, orbit


def _layout(assignment, matrix_degree, fixed):
    orbits = []; specs = [(matrix_degree, 2, 'matrix', ())]
    for block in assignment['fields']:
        f = int(block['formal_codegree']); a = 5400//f
        labelled = []
        for label in block['fields']:
            field = field_for_label(label)
            i = len(orbits); orbits.append(field.metadata(label, f))
            labelled.append((i, label, field.degree))
        rational = [i for i, label, e in labelled if label == 'Q']
        if rational:
            tag = 'rational6' if f == 6 else 'Q'
            specs.append((a, 1, tag, (rational[0],)))
            if len(rational) > 1:
                tag = 'rational6' if f == 6 else 'rational_group'
                specs.append((a, len(rational)-1, tag, tuple(rational[1:])))
        special = [i for i, label, e in labelled if f == 6 and label == 'Q(sqrt(-3))']
        if special:
            specs.append((a, 2*len(special), 'complex6', tuple(special)))
        for i, label, e in labelled:
            if label == 'Q' or (f == 6 and label == 'Q(sqrt(-3))'):
                continue
            specs.append((a, e, label, (i,)))
    specs.sort(key=lambda x: (x[1] > 1, -x[0], x[2]))
    pieces, double = fixed.fixed_blocks(assignment, matrix_degree)
    if [x[:3] for x in specs] != pieces:
        raise ValueError('The scalar-orbit layout disagrees with the preserved kernel')
    return orbits, specs, pieces, double


def row_key(row):
    return (row['dimension'], bool(row['selfdual']), row['matrix_trace'],
            row['matrix_norm'], tuple(tuple(x) for x in row['values']))


def prepare_target(record, *, kernel_dir=None, time_limit=None, max_nodes=None,
                   checkpoint=None, progress=None, should_stop=None):
    """Return {pool, checkpoint, statistics}; stop only between complete rows.

    The optional checkpoint is the full object returned by an earlier call.
    A node is a complete necessary moment row (including all algebraic lifts).
    Kernel initialization and a single exact lattice/row step may overrun a
    wall-clock budget; no interrupted substep is credited as a completed node.
    """
    started = time.monotonic()
    if record.get('kind') not in ('orthogonal', 'symplectic'):
        raise ValueError('A complete one-M2 input state is required')
    kd, fixed, context, lattice, orbit = load_kernels(kernel_dir)
    kernel_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted(kd.glob('*.py'))}
    input_hash = digest_json(record); kernel_hash = digest_json(kernel_hashes)
    assignment = record['assignment']; a = int(record['double_degree']); F = 5400//a
    orbits, specs, pieces, double = _layout(assignment, a, fixed)
    # The old moment engine treated quadratic fields directly and did not
    # need every quadratic conductor in its cyclotomic table. Supply the
    # exact independently generated polynomial for algebraic lifting only.
    for o in orbits:
        conductor = o['conductor']
        polynomial = cyclotomic(conductor)
        if conductor in orbit.POLY and tuple(orbit.POLY[conductor]) != polynomial:
            raise AssertionError('Cyclotomic polynomial implementations disagree')
        orbit.POLY[conductor] = polynomial
    q = int(assignment['q']); pairs = q + (3 if record['kind'] == 'symplectic' else 1)
    rank = 1 + 4 + sum(o['degree'] for o in orbits)
    if rank != 16:
        raise ValueError('This preserved row kernel is specifically rank sixteen')
    ctx = context.context(assignment, a, record['kind'], audit=True)
    unit = dict(id='unit', dimension=1, matrix_trace=2, matrix_norm=2,
                selfdual=True, values=[list(field_for_label(o['label']).one) for o in orbits])
    phases = [(True, d) for d in range(3, 73)] + [(False, d) for d in range(3, 52)]
    rows = {}; next_phase = next_moment = 0
    counts = dict(moment_rows=0, lifted_rows_before_deduplication=0,
                  lifted_rows_rejected_by_fixed_diagonal=0,
                  field_lattice_vectors=0, completed_phases=0)
    previous_seconds = 0.0
    if checkpoint is not None:
        if checkpoint.get('schema') != SCHEMA+'.checkpoint':
            raise ValueError('Wrong target-pool checkpoint schema')
        if checkpoint['input_sha256'] != input_hash or checkpoint['kernel_sha256'] != kernel_hash:
            raise ValueError('Target input or preserved kernel changed; restart explicitly')
        if checkpoint['pool_version'] != VERSION:
            raise ValueError('Pool implementation version changed; restart explicitly')
        next_phase, next_moment = checkpoint['cursor']
        counts.update(checkpoint['counts'])
        previous_seconds = checkpoint.get('elapsed_seconds', 0.0)
        for row in checkpoint['rows']:
            rows[row['id']] = row
    starting_nodes = counts['moment_rows']
    deadline = None if time_limit is None else started + max(0.0, float(time_limit))
    stopped = None

    @lru_cache(None)
    def values_for(index, sd):
        o = orbits[index]; label = o['label']; f = o['formal_codegree']
        field = field_for_label(label); out = {}
        if label == 'Q':
            from math import isqrt
            for v in range(-isqrt(f-1), isqrt(f-1)+1):
                out.setdefault((v, v*v), []).append((v,))
            counts['field_lattice_vectors'] += 2*isqrt(f-1)+1
        else:
            basis, gram, traces = lattice.fixed_lattice(field.conductor, field.subgroup, sd)
            for z, norm in orbit.lattice_vectors(gram, len(field.subgroup)*(f-1)):
                coeffs = [sum(z[j]*basis[j][i] for j in range(len(basis)))
                          for i in range(field.ambient_degree)]
                if any(v.denominator != 1 for v in coeffs):
                    continue
                value = tuple(int(v) for v in coeffs)
                if not field.is_fixed(value) or (sd and field.conjugate(value) != value):
                    raise AssertionError('The independent fixed-field check failed')
                trace = field.trace(value); t = field.inner(value, value)
                if Fraction(norm, len(field.subgroup)) != t:
                    raise AssertionError('Independent field norm disagrees with lattice kernel')
                out.setdefault((trace, t), []).append(value)
                counts['field_lattice_vectors'] += 1
        return {key: tuple(sorted(set(values))) for key, values in out.items()}

    @lru_cache(maxsize=65536)
    def group_values(indices, s, t, sd, dimension):
        if not indices:
            return ((),) if s == t == 0 else ()
        i, rest = indices[0], indices[1:]
        options = values_for(i, sd)
        if not rest:
            return tuple((v,) for v in options.get((s, t), ())
                         if orbits[i]['label'] != 'Q' or abs(v[0]) < dimension)
        answer = []
        for (u, vnorm), actuals in sorted(options.items()):
            if vnorm > t:
                continue
            tails = group_values(rest, s-u, t-vnorm, sd, dimension)
            if not tails:
                continue
            for value in actuals:
                if orbits[i]['label'] == 'Q' and abs(value[0]) >= dimension:
                    continue
                answer.extend((value,)+tail for tail in tails)
        return tuple(answer)

    try:
        for phase in range(next_phase, len(phases)):
            sd, dimension = phases[phase]
            skip = next_moment if phase == next_phase else 0
            if should_stop is not None and should_stop():
                next_phase, next_moment = phase, skip
                stopped = 'requested_stop'; break
            if deadline is not None and time.monotonic() >= deadline:
                next_phase, next_moment = phase, skip
                stopped = 'time_limit'; break
            iterator = fixed.fixed_rows(pieces, double, assignment['q6'], q,
                      record['kind'], context=ctx, dimensions=(dimension,),
                      source_dualities=(sd,), square_budget=True)
            for ordinal, moment in enumerate(iterator):
                if ordinal < skip:
                    continue
                next_phase, next_moment = phase, ordinal
                if should_stop is not None and should_stop():
                    stopped = 'requested_stop'; break
                if deadline is not None and time.monotonic() >= deadline:
                    stopped = 'time_limit'; break
                if max_nodes is not None and counts['moment_rows']-starting_nodes >= max_nodes:
                    stopped = 'node_limit'; break
                actual_sd, actual_d, row_moments = moment
                if (actual_sd, actual_d) != (sd, dimension):
                    raise AssertionError('Moment-row domain changed')
                choices = []; mapped = []
                for j, spec in enumerate(specs):
                    if j == double:
                        continue
                    lifts = group_values(spec[3], *row_moments[j], sd, dimension)
                    choices.append(lifts); mapped.append(spec[3])
                additions = []; local_lifted = local_rejected = 0
                for selected in product(*choices):
                    values = [None]*len(orbits)
                    for indices, group in zip(mapped, selected):
                        for i, value in zip(indices, group):
                            values[i] = list(value)
                    candidate = dict(dimension=dimension, selfdual=sd,
                                     matrix_trace=row_moments[double][0],
                                     matrix_norm=row_moments[double][1], values=values)
                    local_lifted += 1
                    if record['kind'] == 'symplectic':
                        expected = 10800 if sd else 5400
                        if fixed_pair_scaled(candidate, candidate, orbits, 5400, F) != expected:
                            local_rejected += 1
                            continue
                        if fixed_pair_scaled(candidate, unit, orbits, 5400, F) != 0:
                            raise AssertionError('Unit orthogonality failed after exact lifting')
                    candidate['id'] = 'row_'+digest_json(row_key(candidate))
                    candidate['fixed_key'] = canonical_json(fixed_key(candidate, orbits))
                    additions.append(candidate)
                for candidate in additions:
                    old = rows.get(candidate['id'])
                    if old is not None and row_key(old) != row_key(candidate):
                        raise AssertionError('Stable identifier collision')
                    rows[candidate['id']] = candidate
                counts['lifted_rows_before_deduplication'] += local_lifted
                counts['lifted_rows_rejected_by_fixed_diagonal'] += local_rejected
                counts['moment_rows'] += 1
                next_phase, next_moment = phase, ordinal+1
                if progress is not None and counts['moment_rows'] % 1000 == 0:
                    progress(dict(phase=phase, dimension=dimension, selfdual=sd,
                                  moment_rows=counts['moment_rows'], rows=len(rows)))
            if stopped:
                break
            next_phase, next_moment = phase+1, 0
            counts['completed_phases'] = phase+1
            if progress is not None:
                progress(dict(completed_phase=phase, dimension=dimension, selfdual=sd,
                              moment_rows=counts['moment_rows'], rows=len(rows)))
    except KeyboardInterrupt:
        stopped = 'keyboard_interrupt'
    complete = next_phase == len(phases) and stopped is None
    row_list = [rows[k] for k in sorted(rows)]
    for row in row_list:
        dual = dict(row); dual['values'] = [list(x) for x in conjugate_values(row, orbits)]
        row['dual_id'] = 'row_'+digest_json(row_key(dual))
        if complete and row['dual_id'] not in rows:
            raise AssertionError('A complete pool is not closed under duality')
    elapsed = time.monotonic()-started
    provenance = dict(input_sha256=input_hash, kernel_sha256=kernel_hash,
                      kernel_files=kernel_hashes, pool_version=VERSION,
                      orbit_arithmetic_sha256=hashlib.sha256((Path(__file__).parent/'orbit_exact.py').read_bytes()).hexdigest(),
                      pool_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    pool = dict(schema=SCHEMA,
        target=dict(state_id=record['state'], rank=rank, dimension=5400,
                    matrix_codegree=F, kind=record['kind'], pairs=pairs,
                    selfdual=rank-2*pairs, min_nonunit_dimension=3,
                    require_fusion_simple=True),
        orbits=orbits, unit=unit, rows=row_list,
        completeness=dict(complete=complete,
            scope='All algebraic lifts of all preserved necessary moment rows for this one state',
            selfdual_dimensions=[3,72], nonselfdual_dimensions=[3,51],
            fixed_field_lattice='All integral ambient cyclotomic free coordinates; pivot integrality checked',
            no_rowwise_galois_quotient=True,
            extra_necessary_test='Symplectic fixed-part diagonal and unit orthogonality' if record['kind']=='symplectic' else None,
            stop_reason=stopped, cursor=[next_phase,next_moment], provenance=provenance),
        statistics=dict(**counts, unique_rows=len(row_list),
            selfdual_rows=sum(r['selfdual'] for r in row_list),
            nonselfdual_rows=sum(not r['selfdual'] for r in row_list),
            fixed_classes=len({r['fixed_key'] for r in row_list}),
            seconds=elapsed, cumulative_seconds=previous_seconds+elapsed))
    cp = dict(schema=SCHEMA+'.checkpoint', input_sha256=input_hash,
              kernel_sha256=kernel_hash, pool_version=VERSION,
              cursor=[next_phase,next_moment], counts=counts, rows=row_list,
              elapsed_seconds=previous_seconds+elapsed)
    return dict(status='COMPLETE_ROW_POOL' if complete else 'PARTIAL_ROW_POOL',
                pool=pool, checkpoint=cp, statistics=pool['statistics'])
