"""Authenticated, deterministic target selection; these records are not rings."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

from common import canonical_bytes, digest_object, file_hash, read_json

HERE = Path(__file__).resolve().parent


def load_catalogue(directory=None):
    directory = Path(directory or HERE / "data")
    manifest_path = directory / "symplectic_target_manifest.json"
    manifest = read_json(manifest_path)
    if manifest.get("status") not in ("PASS_COMPLETE_CORNER_SURVIVING_SYMPLECTIC_TARGETS",
                                      "PASS_COMPLETE_FROBENIUS_SURVIVING_SYMPLECTIC_TARGETS"):
        raise ValueError("Target catalogue is not an authenticated complete declared S scope")
    name = manifest["file"]
    if Path(name).name != name:
        raise ValueError("Target catalogue filename must be local")
    path = directory / name
    if path.stat().st_size != manifest["bytes"] or file_hash(path) != manifest["sha256"]:
        raise ValueError("Target catalogue hash/size mismatch")
    stream = hashlib.sha256()
    records = {}
    with gzip.open(path, "rb") as handle:
        for line in handle:
            stream.update(line)
            record = json.loads(line)
            state = record["state"]
            if type(state) is not int or state in records or record["kind"] != "symplectic":
                raise ValueError("Target catalogue has a duplicate or invalid state")
            if 5400 % record["double_degree"]:
                raise ValueError("Target matrix formal codegree is not integral")
            records[state] = record
    counts = Counter(5400 // r["double_degree"] for r in records.values())
    if (len(records) != manifest["records"] or stream.hexdigest() != manifest["uncompressed_sha256"]
            or sorted(counts.items()) != [(x["f"], x["states"]) for x in manifest["counts_by_matrix_formal_codegree"]]):
        raise ValueError("Target catalogue inventory mismatch")
    order = sorted(records, key=lambda s: (counts[5400 // records[s]["double_degree"]],
                                           5400 // records[s]["double_degree"], s))
    provenance = {"catalogue_sha256": manifest["sha256"],
                  "catalogue_manifest_sha256": file_hash(manifest_path),
                  "catalogue_records": len(records), "scope": manifest["scope"],
                  "order": "ascending number of retained states sharing the matrix formal codegree, then codegree, then original state ID"}
    return records, order, provenance


def select_target(state, directory=None):
    records, _, provenance = load_catalogue(directory)
    if state not in records:
        raise ValueError("State is not in the bundled post-corner S target catalogue")
    record = records[state]
    return record, {**provenance, "state": state, "selected_record_sha256": digest_object(record)}


def load_known_results(records, directory=None):
    """Known exclusions affect explicit selection only, never a new gate count."""
    directory = Path(directory or HERE / "data")
    path = directory / "known_target_results.json"
    data = read_json(path)
    if data.get("schema") != "fusion5400.known_target_results.v1":
        raise ValueError("Unsupported known-target result catalogue")
    known, bound = {}, {"known_target_results.json": file_hash(path)}
    for item in data["verified_complete_exclusions"]:
        state = item["state"]
        if state not in records or state in known or digest_object(records[state]) != item["record_sha256"]:
            raise ValueError("Known result does not bind a distinct exact catalogue state")
        for entry in [item["audit_report"], *item["source_files"]]:
            name = entry["file"]
            relative = Path(name)
            if relative.is_absolute() or ".." in relative.parts or file_hash(directory / name) != entry["sha256"]:
                raise ValueError("Known-result source/report binding failed")
            bound[name] = entry["sha256"]
        audit = read_json(directory / item["audit_report"]["file"])
        if audit.get("status") != item["audit_status"] or not item["audit_status"].startswith("PASS"):
            raise ValueError("Known-result audit did not pass")
        if audit.get("state") != state:
            raise ValueError("Known-result audit identifies a different state")
        known[state] = item
    return known, bound


def describe_targets(directory=None, limit=20, skip_known=True):
    records, order, provenance = load_catalogue(directory)
    known, bound = load_known_results(records, directory)
    if skip_known:
        order = [s for s in order if s not in known]
    if limit < 0:
        raise ValueError("A target listing limit cannot be negative")
    chosen = order if limit == 0 else order[:limit]
    counts = Counter(5400 // r["double_degree"] for r in records.values())
    return {"status": "AUTHENTICATED_TARGET_CATALOGUE", "provenance": provenance,
            "record_count": len(records), "unresolved_record_count": len(records)-len(known),
            "selected_record_count": len(order), "shown": len(chosen), "skip_known": skip_known,
            "known_complete_state_exclusions": sorted(known), "known_result_files": bound,
            "note": "These are necessary numerical states, not fusion rings. The default selection omits the audited complete exclusions without crediting a new exclusion. Use --include-known to reproduce their calculations.",
            "targets": [{"state": s, "matrix_formal_codegree": 5400 // records[s]["double_degree"],
                         "known_result": "AUDITED_COMPLETE_EXCLUSION" if s in known else "OPEN_IN_DECLARED_TARGET_CATALOGUE",
                         "states_with_this_matrix_formal_codegree": counts[5400 // records[s]["double_degree"]],
                         "canonical_profile_id": records[s]["index"],
                         "field_blocks": records[s]["assignment"]["fields"]} for s in chosen]}
