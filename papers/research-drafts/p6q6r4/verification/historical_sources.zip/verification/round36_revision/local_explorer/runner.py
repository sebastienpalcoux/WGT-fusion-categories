"""Run construction, deterministic subprocess scheduling, and feedback export."""
from __future__ import annotations

from collections import Counter
import gzip
import hashlib
import json
from math import isqrt
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

from common import atomic_json, canonical_bytes, digest_object, file_hash, read_json, utc_now
from storage import TaskStore, import_feedback, write_feedback
from version import ALGORITHM_VERSION, SCHEMA, TOOL_VERSION
from runtime_info import runtime_info

HERE = Path(__file__).resolve().parent


def current_code():
    files = list(HERE.glob("*.py"))
    vendor = HERE / "vendor"
    if vendor.exists():
        files.extend(p for p in vendor.rglob("*") if p.is_file()
                     and "__pycache__" not in p.parts and p.suffix not in (".pyc", ".tmp"))
    return {p.relative_to(HERE).as_posix(): file_hash(p) for p in sorted(files)}


def copy_bound(source, destination, expected=None):
    source, destination = Path(source), Path(destination)
    actual = file_hash(source)
    if expected is not None and actual != expected:
        raise ValueError("Input hash mismatch: " + str(source))
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    if file_hash(destination) != actual:
        raise ValueError("Copied input hash mismatch")
    return {"sha256": actual, "bytes": destination.stat().st_size}


def task_record(kind, **data):
    payload = {"kind": kind, **data}
    return {"id": "task_" + digest_object(payload)[:24], **payload}


def create_run(output, *, kind, rank=16, dimension=5400, hypotheses="center5400",
               algebra="any", min_dimension=None, seed=None, corner_source=None,
               shard_count=1, shard_index=0, parent_feedback=None, corner_extension=None):
    output = Path(output).resolve()
    if output.exists():
        raise ValueError("Run directory already exists; use resume or a fresh --output")
    if shard_count < 1 or not 0 <= shard_index < shard_count:
        raise ValueError("Require 0 <= shard-index < shard-count")
    if dimension < 1:
        raise ValueError("The dimension must be a positive integer")
    output.mkdir(parents=True)
    resources = {}
    code = current_code()
    for name, expected in code.items():
        copy_bound(HERE / name, output / "tool_snapshot" / name, expected)
    scope = {"kind": kind, "dimension": dimension, "rank": rank,
             "hypotheses": hypotheses, "algebra": algebra,
             "shard_count": shard_count, "shard_index": shard_index,
             "necessary_data_only": True, "categorification_established": False}
    tasks = []
    if kind == "r36-open":
        if rank != 16 or dimension != 5400 or hypotheses != "center5400":
            raise ValueError("The frozen R36 OPEN input has rank16, dimension5400 and the stated center hypotheses")
        if algebra == "commutative":
            raise ValueError("The frozen full-field rank16 input is the noncommutative one-M2 scope")
        seed = Path(seed or HERE / "data" / "r36_open").resolve()
        source = Path(corner_source or HERE / "corner_gate.py").resolve()
        manifest = read_json(seed / "manifest.json")
        if manifest.get("status") != "PASS_COMPLETE_AUTHENTICATED_R36_OPEN_NORMALIZATION":
            raise ValueError("The seed manifest does not certify the complete R36 normalization")
        if manifest["records"] != 976867:
            raise ValueError("The seed does not have the authenticated complete OPEN universe")
        resources["resources/corner_gate.py"] = copy_bound(source, output / "resources/corner_gate.py", manifest["gate_sha256"])
        if corner_extension is not None:
            resources["resources/corner_extension.py"] = copy_bound(corner_extension, output / "resources/corner_extension.py")
            scope["corner_extension"] = {"resource": "resources/corner_extension.py",
                    "sha256": resources["resources/corner_extension.py"]["sha256"],
                    "semantics": "Runs only on base-gate survivors. Its complete exact exclusions are recorded separately from the frozen base stage."}
        resources["resources/seed/manifest.json"] = copy_bound(seed / "manifest.json", output / "resources/seed/manifest.json")
        for name, key in (("field_local_inventory.json", "field_local_inventory_sha256"),
                          ("matrix_context_inventory.json.gz", "matrix_context_inventory_sha256")):
            dest = "resources/seed/" + name
            resources[dest] = copy_bound(seed / name, output / dest, manifest[key])
        expected_start = 0
        for chunk_index, item in enumerate(manifest["chunks"]):
            if item["start"] != expected_start or item["stop"] - item["start"] != item["records"]:
                raise ValueError("Input chunk ranges are not disjoint and contiguous")
            expected_start = item["stop"]
            name = item["file"]
            if Path(name).name != name:
                raise ValueError("Chunk paths must be simple filenames")
            destination = "resources/seed/" + name
            if chunk_index % shard_count == shard_index:
                resources[destination] = copy_bound(seed / name, output / destination, item["sha256"])
            tasks.append(task_record(kind, resource=destination, records=item["records"],
                                     open_start=item["start"], open_stop=item["stop"],
                                     input_sha256=item["sha256"]))
        if expected_start != manifest["records"]:
            raise ValueError("Input chunk scope is incomplete")
        scope.update(whole_input_records=manifest["records"], algebra="one-m2",
                     input_description="All completed R36 OPEN full-field/duality states; no field-degree cutoff. The exact gate combines pair/resource constraints, corner parity and valid division restrictions.",
                     original_normalized_stream_sha256=manifest["normalized_uncompressed_sha256"],
                     node_definition="One complete input state checked by the exact corner gate.")
    elif kind == "rational-canonical":
        from arithmetic import PALETTE
        if hypotheses != "center5400" or dimension != 5400 or not 16 <= rank <= 64:
            raise ValueError("The rational one-M2 palette is supported at dimension5400, center hypotheses, ranks16..64")
        if algebra == "commutative":
            raise ValueError("A one-M2 algebra is noncommutative")
        slots = rank - 5
        for a in PALETTE:
            total = dimension - 1 - 2 * a
            if total >= slots * PALETTE[0] and total <= slots * PALETTE[-1]:
                tasks.append(task_record(kind, values=list(PALETTE), slots=slots,
                                         total=total, matrix_degree=a))
        scope.update(algebra="one-m2", field_scope="ALL_RATIONAL_ONLY",
                     canonical_palette=list(PALETTE), canonical_length=rank - 2,
                     input_description="Explicit all-rational one-M2 canonical sub-scope; higher fields are outside this command, not excluded.",
                     node_definition="One popped node of the exact nonincreasing canonical-sum DFS.")
    elif kind == "source-types":
        if not 2 <= rank <= 64:
            raise ValueError("This local small-rank enumerator supports ranks2..64")
        if hypotheses == "center5400":
            if dimension != 5400 or rank < (16 if algebra == "noncommutative" else 14):
                raise ValueError("The requested rank violates the stated inherited center-hypothesis bound")
            minimum = 3
            if min_dimension is not None and min_dimension != 3:
                raise ValueError("Use hypotheses=dimension-equation for a different minimum dimension")
        elif hypotheses == "dimension-equation":
            minimum = 1 if min_dimension is None else min_dimension
            if minimum < 1:
                raise ValueError("Minimum source dimension must be positive")
        else:
            raise ValueError("Unknown hypothesis profile")
        room = dimension - 1 - minimum * minimum * (rank - 2)
        maximum = isqrt(max(0, room))
        labels = list(range(minimum, maximum + 1))
        values = [d * d for d in labels]
        for cap, first in enumerate(labels):
            total = dimension - 1 - first * first
            slots = rank - 2
            if total < slots * minimum * minimum or total > slots * first * first:
                continue
            tasks.append(task_record(kind, values=values, labels=labels, slots=slots,
                                     total=total, cap=cap, prefix=[first]))
        scope.update(min_nonunit_dimension=minimum, max_nonunit_dimension=maximum,
                     source_divides_5400_assumed=False,
                     input_description="Unordered integer source dimension types only, under exactly the recorded hypothesis profile.",
                     node_definition="One popped node of the exact nonincreasing square-sum DFS.")
    else:
        raise ValueError("Unknown enumeration scope")
    if kind != "r36-open" and corner_extension is not None:
        raise ValueError("A corner extension applies only to the full-field R36 input scope")
    whole_task_count = len(tasks)
    tasks = [task for index, task in enumerate(tasks) if index % shard_count == shard_index]
    scope.update(whole_scope_tasks=whole_task_count, selected_tasks=len(tasks),
                 selected_input_records=sum(t["records"] for t in tasks) if kind == "r36-open" else None)
    config = {"schema": SCHEMA, "tool_version": TOOL_VERSION,
              "algorithm_version": ALGORITHM_VERSION, "created_utc": utc_now(),
              "scope": scope, "scope_sha256": digest_object(scope),
              "task_inventory_sha256": digest_object(tasks), "code_files": code,
              "code_sha256": digest_object(code), "resources": resources,
              "parent_feedback_sha256": parent_feedback,
              "portability": "The feedback ZIP contains source snapshots, all selected input resources, exact results and restart databases."}
    atomic_json(output / "config.json", config)
    atomic_json(output / "tasks.json", tasks)
    atomic_json(output / "history.json", [])
    return output


def validate_run(root, *, require_current_code=True):
    root = Path(root)
    config = read_json(root / "config.json")
    if config.get("schema") != SCHEMA:
        raise ValueError("Unsupported run schema")
    if digest_object(config["scope"]) != config["scope_sha256"]:
        raise ValueError("Scope hash mismatch")
    if digest_object(read_json(root / "tasks.json")) != config["task_inventory_sha256"]:
        raise ValueError("Task inventory hash mismatch")
    if require_current_code and current_code() != config["code_files"]:
        raise ValueError("Code version differs. Use restart-from-feedback for a fresh run with this version; an old checkpoint is never silently upgraded.")
    for name, expected in config["code_files"].items():
        if file_hash(root / "tool_snapshot" / name) != expected:
            raise ValueError("Tool snapshot hash mismatch: " + name)
    for name, expected in config["resources"].items():
        path = root / name
        if path.stat().st_size != expected["bytes"] or file_hash(path) != expected["sha256"]:
            raise ValueError("Run input resource changed: " + name)
    return config


def summarize(root, history, *, wall_seconds, setup_seconds=0.0):
    root = Path(root)
    config, tasks = read_json(root / "config.json"), read_json(root / "tasks.json")
    hist, nodes, done, recorded = Counter(), 0, 0, 0
    exclusions_by_gate = Counter()
    frontier = []
    with (root / "results.jsonl.gz").open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as out:
            for task in tasks:
                path = root / "checkpoints" / (task["id"] + ".sqlite")
                if not path.exists():
                    frontier.append({"task": task["id"], "status": "UNVISITED"})
                    continue
                store = TaskStore(path, digest_object(task), readonly=True)
                try:
                    checkpoint = store.state()
                    if checkpoint is None:
                        frontier.append({"task": task["id"], "status": "UNVISITED"})
                        continue
                    current = store.histogram()
                    if current != checkpoint["histogram"]:
                        raise ValueError("Result/checkpoint histogram differs for " + task["id"])
                    hist.update(current)
                    nodes += checkpoint["nodes"]
                    recorded += sum(current.values())
                    done += checkpoint["complete"]
                    for row, in store.iter_results():
                        out.write(row.encode() + b"\n")
                        item = json.loads(row)
                        if item["status"] == "EXCLUDED":
                            exclusions_by_gate[item["gate"]] += 1
                    if not checkpoint["complete"]:
                        frontier.append({"task": task["id"], "status": "BUDGET_STOP",
                                         "committed_nodes": checkpoint["nodes"],
                                         "checkpoint": path.relative_to(root).as_posix()})
                finally:
                    store.close()
    atomic_json(root / "restart.json", {"schema": SCHEMA,
                "scope_sha256": config["scope_sha256"], "code_sha256": config["code_sha256"],
                "pending_tasks": frontier, "complete": done == len(tasks),
                "instruction": "Resume this feedback with the same code version; all pending DFS/input state is transactional."})
    errors = [w for event in history for w in event.get("workers", []) if w["status"] == "FAILED"]
    complete = done == len(tasks)
    latest_errors = [w for w in history[-1].get("workers", []) if w["status"] == "FAILED"] if history else []
    report = {"schema": SCHEMA, "status": "COMPLETE" if complete else "FAILED" if latest_errors else "BUDGET_STOP",
              "complete_declared_scope": complete, "scope": config["scope"],
              "completed_tasks": done, "selected_tasks": len(tasks),
              "committed_nodes": nodes, "checked_candidate_records": recorded,
              "result_counts": dict(hist), "surviving_necessary_records": hist["OPEN"] + hist["NOT_APPLICABLE"],
              "exclusions_by_gate": dict(exclusions_by_gate),
              "exact_exclusions": hist["EXCLUDED"], "verified_fusion_rings": 0,
              "unvisited_or_pending_tasks": len(frontier),
              "unvisited_input_records": (config["scope"]["selected_input_records"] - recorded
                                          if config["scope"]["kind"] == "r36-open" else None),
              "stage_seconds": {"prepare_inputs": setup_seconds, "latest_invocation": wall_seconds},
              "cpu_seconds_all_worker_attempts": sum(w.get("cpu_seconds", 0) for h in history for w in h.get("workers", [])),
              "run_history_entries": len(history), "historical_worker_errors": len(errors),
              "results_sha256": file_hash(root / "results.jsonl.gz"),
              "scope_sha256": config["scope_sha256"], "code_sha256": config["code_sha256"],
              "limitations": ["OPEN and NOT_APPLICABLE are numerical necessary-data statuses, not fusion rings.",
                              "No branch after a budget stop or unsupported operation is counted as excluded.",
                              "A complete flag refers only to the explicitly recorded finite scope.",
                              "Categorification and the simple-center hypothesis are not established by these local computations."]}
    atomic_json(root / "run_report.json", report)
    return report


def execute(root, *, workers=1, time_limit=30.0, node_limit=50000,
            checkpoint_every=256, profile=False, setup_seconds=0.0,
            per_target_seconds=None, per_target_nodes=None):
    root = Path(root).resolve()
    config = validate_run(root)
    if config["scope"]["kind"] == "explore-targets":
        from target_batch import execute_target_batch
        return execute_target_batch(root, workers=workers, time_limit=time_limit, node_limit=node_limit,
                    checkpoint_every=checkpoint_every, profile=profile, setup_seconds=setup_seconds,
                    per_target_seconds=per_target_seconds, per_target_nodes=per_target_nodes)
    if per_target_seconds is not None or per_target_nodes is not None:
        raise ValueError("Per-target resume budgets apply only to an explore-targets run")
    if config["scope"]["kind"] in ("verify", "reconstruct", "moments", "align", "prepare-target", "search-target"):
        from backend_runs import execute_backend
        return execute_backend(root, workers=workers, time_limit=time_limit, node_limit=node_limit,
                               checkpoint_every=checkpoint_every, profile=profile, setup_seconds=setup_seconds)
    if workers < 1 or workers > 64 or time_limit < 0 or node_limit < 0 or checkpoint_every < 1:
        raise ValueError("Invalid worker count or budget")
    tasks = read_json(root / "tasks.json")
    pending = []
    for task in tasks:
        path = root / "checkpoints" / (task["id"] + ".sqlite")
        if not path.exists():
            pending.append(task["id"])
            continue
        store = TaskStore(path, digest_object(task), readonly=True)
        state = store.state()
        store.close()
        if state is None or not state["complete"]:
            pending.append(task["id"])
    history = read_json(root / "history.json")
    invocation = len(history)
    workers = min(workers, max(1, len(pending)), max(1, node_limit) if node_limit else workers)
    began = time.monotonic()
    processes, logs, reports = [], [], []
    (root / "workers").mkdir(exist_ok=True)
    try:
        for worker in range(workers):
            assigned = pending[worker::workers]
            if not assigned:
                continue
            quota = (node_limit // workers + (worker < node_limit % workers)) if node_limit else 0
            name = f"invocation_{invocation:04d}_worker_{worker:03d}"
            plan = {"worker": worker, "tasks": assigned, "time_limit": time_limit,
                    "node_limit": quota, "checkpoint_every": checkpoint_every, "profile": profile,
                    "report": "workers/" + name + ".json"}
            plan_path = root / "workers" / (name + ".plan.json")
            atomic_json(plan_path, plan)
            log = (root / "workers" / (name + ".log")).open("wb")
            logs.append(log)
            proc = subprocess.Popen([sys.executable, "-B", "-S", str(root / "tool_snapshot/worker.py"),
                                     str(root), str(plan_path)], stdout=log, stderr=subprocess.STDOUT)
            processes.append((proc, root / plan["report"]))
        try:
            for proc, _ in processes:
                proc.wait()
        except KeyboardInterrupt:
            for proc, _ in processes:
                if proc.poll() is None:
                    proc.send_signal(signal.SIGTERM)
            for proc, _ in processes:
                proc.wait()
        for proc, path in processes:
            reports.append(read_json(path) if path.exists() else {
                "status": "FAILED", "returncode": proc.returncode,
                "error": {"message": "Worker stopped before writing its report; committed checkpoint remains resumable."}})
    finally:
        for log in logs:
            log.close()
    event = {"invocation": invocation, "ended_utc": utc_now(), "workers_requested_or_used": workers,
             "time_limit_seconds_per_worker": time_limit, "total_node_limit": node_limit,
             "checkpoint_every_nodes": checkpoint_every, "profile": profile,
             "wall_seconds": time.monotonic() - began, "workers": reports,
             "runtime": runtime_info(),
             "sharding": "Pending deterministic task list is assigned round-robin; node quota is split deterministically."}
    history.append(event)
    atomic_json(root / "history.json", history)
    report = summarize(root, history, wall_seconds=event["wall_seconds"], setup_seconds=setup_seconds)
    packed = time.monotonic()
    feedback = write_feedback(root)
    return report, feedback, time.monotonic() - packed


def import_or_directory(source, output=None):
    source = Path(source).resolve()
    if source.is_dir():
        if output is not None:
            raise ValueError("A live run directory is resumed in place; omit --output")
        return source
    if output is None:
        output = source.with_name(source.stem + "_resume_" + str(time.time_ns()))
    return import_feedback(source, output)


def restart_from_feedback(source, output):
    """Keep the exact input/scope, discard all old progress, use current code."""
    import tempfile
    source, output = Path(source).resolve(), Path(output).resolve()
    if output.exists():
        raise ValueError("Restart output must be fresh")
    temporary = None
    if source.is_dir():
        old = source
        parent_hash = file_hash(source / "config.json")
    else:
        temporary = Path(tempfile.mkdtemp(prefix="fusion5400_feedback_read_"))
        old = import_feedback(source, temporary / "imported")
        parent_hash = file_hash(source)
    try:
        previous = validate_run(old, require_current_code=False)
        output.mkdir(parents=True)
        code = current_code()
        for name, expected in code.items():
            copy_bound(HERE / name, output / "tool_snapshot" / name, expected)
        for name, item in previous["resources"].items():
            copy_bound(old / name, output / name, item["sha256"])
        config = dict(previous)
        config.update(tool_version=TOOL_VERSION, algorithm_version=ALGORITHM_VERSION,
                      created_utc=utc_now(), code_files=code, code_sha256=digest_object(code),
                      parent_feedback_sha256=parent_hash,
                      restart_semantics="Fresh run under current code; no old exclusion or checkpoint is silently reused.")
        atomic_json(output / "config.json", config)
        atomic_json(output / "tasks.json", read_json(old / "tasks.json"))
        atomic_json(output / "history.json", [])
        return output
    finally:
        if temporary is not None:
            shutil.rmtree(temporary, ignore_errors=True)


def failure_feedback(output, error, *, command):
    """A failed setup still produces one diagnostic feedback artifact."""
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    report = {"schema": SCHEMA, "status": "FAILED", "complete_declared_scope": False,
              "error_type": type(error).__name__, "error": str(error), "command": command,
              "exact_exclusions_credited_by_this_failure": 0,
              "restart_supported": (output / "config.json").exists() and (output / "tasks.json").exists(),
              "note": "A setup/integrity failure is not a mathematical exclusion."}
    atomic_json(output / "failure.json", report)
    previous = output / "run_report.json"
    if previous.exists():
        copy_bound(previous, output / ("previous_run_report_" + str(time.time_ns()) + ".json"))
    atomic_json(previous, report)
    return write_feedback(output)

