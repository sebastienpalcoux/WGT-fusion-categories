#!/usr/bin/env python3
"""Independent complete lift audit for the four published small-field targets.

Uses the preserved ORIGINAL moment-row kernel. Algebraic integers are
enumerated in explicit full integral bases by inverse-Gram coordinate bounds;
neither target_pool, orbit_exact nor the fixed-lattice enumerator is imported.
"""
from pathlib import Path
from fractions import Fraction
from itertools import product
from functools import lru_cache
from math import isqrt
import argparse
import hashlib
import importlib
import json
import sys
import time


def inverse(matrix):
    n=len(matrix)
    a=[[Fraction(x)for x in row]+[Fraction(i==j)for j in range(n)]for i,row in enumerate(matrix)]
    for j in range(n):
        k=next(i for i in range(j,n)if a[i][j]);a[j],a[k]=a[k],a[j]
        q=a[j][j];a[j]=[x/q for x in a[j]]
        for i in range(n):
            if i!=j:
                q=a[i][j];a[i]=[x-q*y for x,y in zip(a[i],a[j])]
    return [row[n:]for row in a]


def field_data(label):
    if label=='Q':return ((1,),),((1,),),(1,),False
    if label in('Q(sqrt(-3))','quadratic_disc=-3'):
        return ((1,0),(1,1)),((2,1),(1,2)),(2,1),True
    if label=='quadratic_disc=-4':
        return ((1,0),(0,1)),((2,0),(0,2)),(2,0),True
    if label=='quadratic_disc=-15':
        return ((1,0,0,0,0,0,0,0),(-1,2,1,-1,2,-1,0,1)),((2,1),(1,8)),(2,1),True
    if label=='real_cubic_conductor9':
        return ((1,0,0,0,0,0),(0,1,-1,0,0,-1),(2,-1,1,0,-1,0)),((3,0,6),(0,6,-3),(6,-3,18)),(3,0,6),False
    raise ValueError('This independent integral-basis audit does not support '+label)


@lru_cache(None)
def integer_values(f,label,sd):
    basis,gram,traces,imaginary=field_data(label);n=len(basis);cap=f-1
    inv=inverse(gram)
    bounds=[isqrt((cap*inv[i][i]).numerator//(cap*inv[i][i]).denominator)for i in range(n)]
    result={}
    for coordinates in product(*(range(-v,v+1)for v in bounds)):
        if sd and imaginary and coordinates[1]:continue
        norm=sum(coordinates[i]*gram[i][j]*coordinates[j]for i in range(n)for j in range(n))
        if norm>cap:continue
        trace=sum(x*t for x,t in zip(coordinates,traces))
        value=tuple(sum(coordinates[j]*basis[j][i]for j in range(n))for i in range(len(basis[0])))
        result.setdefault((trace,norm),[]).append(value)
    return {k:tuple(sorted(set(v)))for k,v in result.items()}


def poly_multiply(a,b,poly):
    n=len(poly)-1;p=[0]*(2*n-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):p[i+j]+=x*y
    for k in range(len(p)-1,n-1,-1):
        q=p[k]
        for j in range(n):p[k-n+j]-=q*poly[j]
    return tuple(p[:n])


def audit_basis_embeddings():
    data=[('quadratic_disc=-3',(1,1,1),1,1),
          ('quadratic_disc=-4',(1,0,1),0,1),
          ('quadratic_disc=-15',(1,-1,0,1,-1,1,0,-1,1),1,4)]
    for label,poly,t,norm in data:
        basis,gram,traces,imag=field_data(label);one,w=basis
        square=poly_multiply(w,w,poly)
        assert all(z-t*x+norm*y==0 for z,x,y in zip(square,w,one))
        discriminant=t*t-4*norm
        assert discriminant==int(label.split('=')[1])
        assert gram==((2,t),(t,2*norm))
    basis,gram,trace,imag=field_data('real_cubic_conductor9')
    one,theta,theta2=basis;poly=(1,0,0,1,0,0,1)
    assert poly_multiply(theta,theta,poly)==theta2
    assert all(a-3*b+c == 0 for a,b,c in zip(poly_multiply(theta2,theta,poly),theta,one))


def audit_one(root,state,original,optimized,contexts):
    base=root/('state_'+str(state))
    record=json.loads((base/'record.json').read_text())
    pool=json.loads((base/'pool.json').read_text())
    assert pool['completeness']['complete']and pool['target']['state_id']==state
    orbits=pool['orbits'];assignment=record['assignment'];a=record['double_degree']
    pieces,double=original.fixed_blocks(assignment,a)
    assert (pieces,double)==optimized.fixed_blocks(assignment,a)
    ctx=contexts.context(assignment,a,record['kind'],audit=True)
    args=(pieces,double,assignment['q6'],assignment['q'],record['kind'])
    original_rows=list(original.fixed_rows(*args,context=ctx))
    optimized_rows=list(optimized.fixed_rows(*args,context=ctx))
    assert len(original_rows)==len(set(original_rows))
    assert set(original_rows)==set(optimized_rows)
    available={}
    for i,o in enumerate(orbits):available.setdefault((o['formal_codegree'],o['label']),[]).append(i)
    mapping=[]
    for j,(degree,count,label)in enumerate(pieces):
        if j==double:mapping.append(());continue
        f=5400//degree
        if label in('Q','rational6','rational_group'):
            key=(f,'Q');take=count
        elif label=='complex6':
            key=(f,'Q(sqrt(-3))');take=count//2;assert 2*take == count
        else:key=(f,label);take=1
        picked=tuple(available[key][:take]);del available[key][:take]
        assert len(picked)==take
        mapping.append(picked)
    assert all(not v for v in available.values())
    expected=set();unliftable=0
    for sd,d,moments in original_rows:
        choices=[];indices=[]
        for j,ids in enumerate(mapping):
            if j==double:continue
            s,t=moments[j];group=[]
            tables=[integer_values(orbits[i]['formal_codegree'],orbits[i]['label'],sd)for i in ids]
            for moment_choices in product(*(tuple(tab)for tab in tables)):
                if sum(x[0]for x in moment_choices)!=s or sum(x[1]for x in moment_choices)!=t:continue
                for values in product(*(table[key]for table,key in zip(tables,moment_choices))):
                    if any(orbits[i]['label']=='Q'and abs(value[0])>=d for i,value in zip(ids,values)):continue
                    group.append(values)
            choices.append(group);indices.append(ids)
        before=len(expected)
        for group_choice in product(*choices):
            values=[None]*len(orbits)
            for ids,vs in zip(indices,group_choice):
                for i,v in zip(ids,vs):values[i]=v
            expected.add((d,sd,*moments[double],tuple(values)))
        unliftable+=len(expected)==before
    actual={(r['dimension'],r['selfdual'],r['matrix_trace'],r['matrix_norm'],
             tuple(tuple(v)for v in r['values']))for r in pool['rows']}
    assert len(actual)==len(pool['rows'])and actual==expected,(state,len(actual),len(expected),len(actual-expected),len(expected-actual))
    assert len(original_rows)==pool['statistics']['moment_rows']
    return dict(state=state,status='PASS_ORIGINAL_KERNEL_AND_INDEPENDENT_INTEGRAL_BASIS_LIFTS',
        moment_rows=len(original_rows),exact_rows=len(actual),selfdual_rows=sum(x[1]for x in actual),
        nonselfdual_rows=sum(not x[1]for x in actual),unliftable_moment_rows=unliftable,
        source_dimensions_selfdual=[3,72],source_dimensions_nonselfdual=[3,51],
        pool_sha256=hashlib.sha256((base/'pool.json').read_bytes()).hexdigest(),
        record_sha256=hashlib.sha256((base/'record.json').read_bytes()).hexdigest())


