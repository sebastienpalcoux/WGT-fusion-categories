"""Portable multi-target orchestration over exact preparation/search backends."""
from __future__ import annotations

from collections import Counter
import gzip
import json
from pathlib import Path
import signal
import subprocess
import sys
import time

from catalogue import load_catalogue, load_known_results
from common import atomic_json, canonical_bytes, digest_object, read_json, utc_now
from runner import HERE, copy_bound, current_code, task_record, validate_run
from storage import TaskStore, write_feedback
from version import SCHEMA, TOOL_VERSION, ALGORITHM_VERSION
from runtime_info import runtime_info


def create_target_batch(output, *, catalogue=None, states=None, limit=3,
                        per_target_seconds=5.0, per_target_nodes=1000, max_results=1,
                        shard_count=1, shard_index=0, skip_known=True):
    output = Path(output).resolve()
    if output.exists():
        raise ValueError("Target batch directory must be fresh")
    if (limit < 0 or per_target_seconds < 0 or per_target_nodes < 0 or max_results < 1
            or shard_count < 1 or not 0 <= shard_index < shard_count):
        raise ValueError("Invalid target-batch selection or budget")
    records, order, provenance = load_catalogue(catalogue)
    if states is not None:
        if len(states) != len(set(states)) or any(s not in records for s in states):
            raise ValueError("Requested target IDs must be distinct catalogue members")
        selected_set = set(states)
        order = [s for s in order if s in selected_set]
    skipped, known_files = [], {}
    if skip_known:
        known, known_files = load_known_results(records, catalogue)
        skipped = [s for s in order if s in known]
        order = [s for s in order if s not in known]
    if states is None and limit:
        order = order[:limit]
    full_order = order
    order = order[shard_index::shard_count]
    output.mkdir(parents=True)
    code = current_code()
    for name, expected in code.items():
        copy_bound(HERE / name, output / "tool_snapshot" / name, expected)
    resources, tasks = {}, []
    if skip_known:
        directory = Path(catalogue or HERE / "data")
        for name, expected in known_files.items():
            destination = "resources/known_results/" + name
            resources[destination] = copy_bound(directory / name, output / destination, expected)
    for state in order:
        name = f"resources/targets/state_{state}.json"
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        atomic_json(path, records[state])
        from common import file_hash
        resources[name] = {"sha256": file_hash(path), "bytes": path.stat().st_size}
        tasks.append(task_record("explore-targets", state=state, resource=name,
                                 input_sha256=digest_object(records[state])))
    scope = {"kind": "explore-targets", "dimension": 5400, "rank": 16,
             "target_ids": order, "selection_before_sharding": full_order,
             "shard_count": shard_count, "shard_index": shard_index,
             "skip_known": skip_known, "skipped_known_target_ids": skipped,
             "known_result_files": known_files,
             "catalogue_provenance": provenance, "per_target_seconds": per_target_seconds,
             "per_target_nodes": per_target_nodes, "max_results": max_results,
             "necessary_data_only": True, "categorification_established": False,
             "scope_limit": "Only selected exact S states from the recorded authenticated catalogue; preparation covers full supplied field labels. A target is excluded only after complete preparation and complete alignment traversal.",
             "budget_semantics": "Per-target values in this scope are defaults; explicit per-invocation overrides are recorded in history.json.",
             "scheduling": "One bounded visit per target per invocation. Pending states with the fewest previous visits are scheduled first; catalogue order breaks ties. This prevents early difficult states from starving later targets across resumes."}
    config = {"schema": SCHEMA, "tool_version": TOOL_VERSION, "algorithm_version": ALGORITHM_VERSION,
              "created_utc": utc_now(), "scope": scope, "scope_sha256": digest_object(scope),
              "code_files": code, "code_sha256": digest_object(code), "resources": resources,
              "task_inventory_sha256": digest_object(tasks),
              "portability": "All selected input states, exact code/vendor snapshot, transactional frontiers and event witnesses are bundled."}
    atomic_json(output / "config.json", config)
    atomic_json(output / "tasks.json", tasks)
    atomic_json(output / "history.json", [])
    return output


def summarize_targets(root, history, *, setup_seconds=0.0, wall_seconds=0.0):
    config, tasks = read_json(root / "config.json"), read_json(root / "tasks.json")
    counts, node_counts, tables = Counter(), Counter(), {}
    records, pending, total_nodes = [], [], 0
    with (root / "stage_results.jsonl.gz").open("wb") as compressed:
        with gzip.GzipFile(fileobj=compressed, mode="wb", mtime=0) as out:
            for task in tasks:
                path = root / "checkpoints" / (task["id"] + ".sqlite")
                saved = None
                latest_search = None
                if path.exists():
                    store = TaskStore(path, digest_object(task), readonly=True)
                    try:
                        saved = store.state()
                        local_nodes, local_steps, last_hash, last_status = 0, 0, None, None
                        for (encoded,) in store.iter_results():
                            result = json.loads(encoded)
                            if result["state"] != task["state"] or (last_hash is not None and
                                    result["previous_checkpoint_sha256"] != last_hash):
                                raise ValueError("Target event history is not a single bound checkpoint chain")
                            local_nodes += result["nodes"]
                            local_steps += 1
                            last_hash, last_status = result["checkpoint_sha256"], result["status"]
                            node_counts[result["stage"]] += result["nodes"]
                            if result["stage"] == "search":
                                latest_search = result["result"]
                            out.write(encoded.encode() + b"\n")
                            for solution in result["result"].get("solutions", []):
                                check = solution["reconstruction"]
                                if check["status"] != "VERIFIED":
                                    raise ValueError("Unverified result in committed target checkpoint")
                                tables[check["verification"]["table_sha256"]] = solution
                        if saved and (saved["nodes"] != local_nodes or saved["steps"] != local_steps or
                                      digest_object(saved) != last_hash or saved["latest_status"] != last_status):
                            raise ValueError("Target frontier differs from its complete committed event history")
                    finally:
                        store.close()
                exports = {}
                if saved:
                    destination = root / "targets" / ("state_" + str(task["state"]))
                    if saved.get("pool") is not None:
                        atomic_json(destination / "pool.json", saved["pool"])
                        exports["pool"] = (destination / "pool.json").relative_to(root).as_posix()
                    if latest_search is not None:
                        atomic_json(destination / "latest_search.json", latest_search)
                        exports["latest_search"] = (destination / "latest_search.json").relative_to(root).as_posix()
                status = saved.get("latest_status", "UNVISITED") if saved else "UNVISITED"
                complete = bool(saved and saved["complete"])
                if not complete:
                    pending.append(task["id"])
                counts[status] += 1
                nodes = saved["nodes"] if saved else 0
                total_nodes += nodes
                records.append({"state": task["state"], "task_id": task["id"],
                                "input_sha256": task["input_sha256"], "status": status,
                                "exports": exports,
                                "complete": complete, "committed_nodes": nodes,
                                "checkpoint": str(path.relative_to(root)) if path.exists() else None,
                                "pool_complete": bool(saved and saved.get("pool") and saved["pool"]["completeness"]["complete"]),
                                "verified_labelled_tables": len(saved["verified_table_ids"]) if saved else 0})
    if total_nodes != sum(node_counts.values()):
        raise ValueError("Target checkpoint and retained ledger node counts differ")
    atomic_json(root / "target_statuses.json", records)
    atomic_json(root / "verified_labelled_tables.json", list(tables.values()))
    complete = not pending
    failures = any(w.get("status") == "FAILED" for w in (history[-1]["workers"] if history else []))
    report = {"schema": SCHEMA, "status": "FAILED" if failures else "COMPLETE" if complete else "BUDGET_STOP",
              "complete_declared_scope": complete, "scope": config["scope"],
              "committed_nodes": total_nodes, "nodes_by_stage": dict(node_counts),
              "result_counts": dict(counts), "unvisited_or_pending_tasks": len(pending),
              "selected_targets": len(tasks), "verified_labelled_fusion_ring_tables": len(tables),
              "categorification_established": False,
              "scope_sha256": config["scope_sha256"], "code_sha256": config["code_sha256"],
              "stage_seconds": {"prepare_inputs": setup_seconds, "worker_wall": wall_seconds},
              "cpu_seconds_all_worker_attempts": sum(w.get("cpu_seconds", 0) for h in history for w in h["workers"]),
              "latest_invocation_budgets": {k: history[-1][k] for k in
                  ("node_limit", "time_limit_seconds_per_worker", "per_target_seconds", "per_target_nodes") if k in history[-1]} if history else {},
              "limitations": ["Each exclusion concerns one selected full-field state, not every state of its profile or an entire source type.",
                              "Partial pool preparation, partial alignment and interrupted invocations remain OPEN.",
                              "A verified labelled fusion-ring table does not establish categorification or count isomorphism classes."]}
    atomic_json(root / "run_report.json", report)
    atomic_json(root / "restart.json", {"schema": SCHEMA, "complete": complete, "pending_task_ids": pending,
                "scope_sha256": config["scope_sha256"], "code_sha256": config["code_sha256"],
                "checkpoint_semantics": "Each SQLite task commits the complete preparation/search frontier and all exact witnesses together."})
    return report


def fair_pending_tasks(tasks, pending, history):
    """Rotate unfinished work using recorded visits, without changing its scope."""
    visits = Counter(state for invocation in history for worker in invocation.get("workers", [])
                     for state in worker.get("visited_target_ids", []))
    positions = {task["id"]: index for index, task in enumerate(tasks)}
    states = {task["id"]: task["state"] for task in tasks}
    return sorted(pending, key=lambda task_id: (visits[states[task_id]], positions[task_id]))


def execute_target_batch(root, *, workers=1, time_limit=30.0, node_limit=50000,
                         checkpoint_every=256, profile=False, setup_seconds=0.0,
                         per_target_seconds=None, per_target_nodes=None):
    root = Path(root).resolve()
    config = validate_run(root)
    target_seconds = config["scope"]["per_target_seconds"] if per_target_seconds is None else per_target_seconds
    target_nodes = config["scope"]["per_target_nodes"] if per_target_nodes is None else per_target_nodes
    if workers < 1 or workers > 64 or time_limit < 0 or node_limit < 0 or target_seconds < 0 or target_nodes < 0:
        raise ValueError("Invalid worker count or budget")
    pending = []
    tasks = read_json(root / "tasks.json")
    for task in tasks:
        path = root / "checkpoints" / (task["id"] + ".sqlite")
        if path.exists():
            store = TaskStore(path, digest_object(task), readonly=True)
            saved = store.state()
            store.close()
            if saved and saved["complete"]:
                continue
        pending.append(task["id"])
    history = read_json(root / "history.json")
    pending = fair_pending_tasks(tasks, pending, history)
    invocation = len(history)
    workers = min(workers, max(1, len(pending)), max(1, node_limit) if node_limit else workers)
    (root / "workers").mkdir(exist_ok=True)
    processes, reports = [], []
    began = time.monotonic()
    for worker in range(workers):
        assigned = pending[worker::workers]
        if not assigned:
            continue
        name = f"workers/invocation_{invocation:04d}_worker_{worker:03d}"
        plan = {"tasks": assigned, "time_limit": time_limit, "profile": profile,
                "node_limit": (node_limit // workers + (worker < node_limit % workers)) if node_limit else 0,
                "per_target_seconds": target_seconds,
                "per_target_nodes": target_nodes,
                "max_results": config["scope"]["max_results"], "report": name + ".json"}
        atomic_json(root / (name + ".plan.json"), plan)
        log = (root / (name + ".log")).open("wb")
        process = subprocess.Popen([sys.executable, "-B", "-S", str(root / "tool_snapshot/target_batch_worker.py"),
                                    str(root), str(root / (name + ".plan.json"))],
                                   stdout=log, stderr=subprocess.STDOUT)
        processes.append((process, log, root / plan["report"]))
    try:
        for process, _, _ in processes:
            process.wait()
    except KeyboardInterrupt:
        for process, _, _ in processes:
            if process.poll() is None:
                process.send_signal(signal.SIGTERM)
        for process, _, _ in processes:
            process.wait()
    finally:
        for process, log, path in processes:
            log.close()
            reports.append(read_json(path) if path.exists() else {"status": "FAILED", "returncode": process.returncode,
                           "note": "Only previously committed SQLite frontiers and results are credited."})
    history.append({"invocation": invocation, "ended_utc": utc_now(), "workers": reports,
                    "node_limit": node_limit, "time_limit_seconds_per_worker": time_limit,
                    "per_target_seconds": target_seconds, "per_target_nodes": target_nodes,
                    "workers_requested_or_used": workers, "wall_seconds": time.monotonic() - began,
                    "runtime": runtime_info(), "scheduled_task_ids": pending})
    atomic_json(root / "history.json", history)
    report = summarize_targets(root, history, setup_seconds=setup_seconds, wall_seconds=time.monotonic() - began)
    packed = time.monotonic()
    feedback = write_feedback(root)
    return report, feedback, time.monotonic() - packed
