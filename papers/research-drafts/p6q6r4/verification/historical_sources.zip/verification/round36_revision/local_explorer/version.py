"""Version identifiers are part of every local feedback bundle."""
TOOL_VERSION = "1.1.0"
SCHEMA = "fusion5400-local-feedback-v1"
ALGORITHM_VERSION = "exact-scope-and-resume-2"

