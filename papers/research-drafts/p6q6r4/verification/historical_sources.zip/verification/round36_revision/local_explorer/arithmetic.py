"""Exact all-rational one-M2 arithmetic, explicitly a restricted sub-scope.

These necessary tests reproduce the supplied corner-parity audit.  They
do not test all full fields, quaternion trace isometries or multiplication.
The default full-field command uses a separate certified corner provider.
"""
from __future__ import annotations

from collections import Counter
from functools import lru_cache
from itertools import combinations
from math import gcd

N = 5400
PRIMES = (2, 3, 5)
PALETTE = tuple(a for a in range(10, 901) if N % a == 0
                and sum(a % p == 0 for p in PRIMES) >= 2)


@lru_cache(maxsize=4096)
def valuation(n, p):
    if n <= 0:
        raise ValueError("Valuation requires a positive integer")
    e = 0
    while n % p == 0:
        n //= p
        e += 1
    return e


@lru_cache(maxsize=512)
def degree_signature(a):
    f = N // a
    out = [0, 0, 0, 0]
    parity = 0
    for bit, p in enumerate(PRIMES):
        v = valuation(f, p)
        parity ^= (v & 1) << bit
        if v != 1:
            continue
        u = (f // p) % p
        if p == 2:
            out[0] = 1
        elif p == 3:
            out[1] = 1 if u == 1 else -1
        elif u in (1, 4):
            out[2] = 1 if u == 1 else -1
        else:
            out[3] = 1 if u == 2 else -1
    return tuple(out), parity


def signature(linear):
    a = b = c = d = parity = 0
    for value in linear:
        v, p = degree_signature(value)
        a += v[0]
        b += v[1]
        c += v[2]
        d += v[3]
        parity ^= p
    return (a & 1, b, c, d), parity


def _single_bin(sig, p, residue, amount):
    if p == 2:
        return (sig[0] - amount) % 2 == 0
    if p == 3:
        return sig[1] == (amount if residue == 1 else -amount)
    if residue in (1, 4):
        return sig[3] == 0 and sig[2] == (amount if residue == 1 else -amount)
    return sig[2] == 0 and sig[3] == (amount if residue == 2 else -amount)


def prime_screens(sig, F, p):
    """Return original, resource-sharp, and combined-corner booleans."""
    t = valuation(F, p)
    imbalance = (sig[0] if p == 2 else abs(sig[1]) if p == 3
                 else abs(sig[2]) + abs(sig[3]))
    if imbalance == 0:
        return True, True, True
    original = imbalance <= (0 if t == 0 else 4 if t == 1 else 2)
    corner = False
    if t == 1:
        u = (-(F // p)) % p
        corner = _single_bin(sig, p, u, 1) or _single_bin(sig, p, u, 2)
    sharp = corner
    if p == 2:
        sharp = sharp or (t == 2 and sig[0] == 1)
    elif t == 1:
        u = (-(F // p) * pow(2, -1, p)) % p
        sharp = sharp or _single_bin(sig, p, u, 1)
    return original, sharp, corner


def rational_residue_failure(linear, matrix_degree):
    pairs = [(x, 1) for x in linear[1:]] + [(matrix_degree, 2)]
    weighted = [d * m for d, m in pairs]
    prefix = [0]
    for value in weighted:
        prefix.append(gcd(prefix[-1], value))
    suffix = [0] * (len(weighted) + 1)
    for i in range(len(weighted) - 1, -1, -1):
        suffix[i] = gcd(suffix[i + 1], weighted[i])
    seen = set()
    for i, (a, m) in enumerate(pairs):
        g = gcd(prefix[i], suffix[i + 1])
        key = (a, m, g)
        if key in seen:
            continue
        seen.add(key)
        remainder, common = a - m, gcd(a * m, g)
        if remainder % common:
            return {"a": a, "m": m, "other_weight_gcd": g,
                    "common_divisor": common, "remainder": remainder,
                    "failure": "nondivisible_remainder"}
        modulus = g // common
        root = ((-remainder // common) *
                pow((a * m) // common, -1, modulus)) % modulus if modulus > 1 else 0
        if min(root, modulus - root) >= remainder:
            return {"a": a, "m": m, "other_weight_gcd": g,
                    "modulus": modulus, "root": root, "remainder": remainder,
                    "failure": "strict_scalar_interval_empty"}
    return None


def two_character_failure(linear, matrix_degree):
    degrees = linear[1:]
    seen = set()
    for i, j in combinations(range(len(degrees)), 2):
        pair = (degrees[i], degrees[j])
        if pair in seen:
            continue
        seen.add(pair)
        modulus = gcd(N, matrix_degree,
                      *(x for k, x in enumerate(degrees) if k not in (i, j)))
        if modulus == 1:
            continue
        for ai, aj in (pair, pair[::-1]):
            Q = 1
            for p in PRIMES:
                k = valuation(modulus, p)
                alpha, beta = valuation(ai, p), valuation(aj, p)
                Q *= p ** min(k, beta + (max(0, k - alpha - beta) + 1) // 2)
            if Q >= 2 * (ai - 1):
                return {"first_degree": ai, "second_degree": aj,
                        "modulus": modulus, "forced_multiple": Q,
                        "strict_upper_bound": 2 * (ai - 1)}
    return None


def cheap_failure(linear, matrix_degree, determinant_parity=None):
    if matrix_degree == 10 or 10 in linear:
        return "rational_canonical_degree_ten", {"canonical_degree": 10}
    if determinant_parity is None:
        determinant_parity = signature(linear)[1]
    if determinant_parity:
        return "linear_trace_determinant", {"valuation_parity_bits": determinant_parity}
    witness = rational_residue_failure(linear, matrix_degree)
    if witness is not None:
        return "rational_canonical_residue", witness
    witness = two_character_failure(linear, matrix_degree)
    if witness is not None:
        return "two_character_modulus", witness
    return None, None


def screen_placement(matrix_degree, nonunit_linear):
    linear = (1,) + tuple(nonunit_linear)
    F = N // matrix_degree
    sig, parity = signature(linear)
    for p in PRIMES:
        if not prime_screens(sig, F, p)[2]:
            return {"status": "EXCLUDED", "gate": "rational_corner_resource",
                    "witness": {"prime": p, "matrix_codegree": F,
                                "linear_codegrees": [N // a for a in linear],
                                "valuation_one_signature": list(sig)}}
    gate, witness = cheap_failure(linear, matrix_degree, parity)
    if gate:
        return {"status": "EXCLUDED", "gate": gate, "witness": witness}
    return {"status": "OPEN", "gate": "rational_necessary_gates",
            "scope": "All-rational one-M2 canonical placement only; not a fusion ring."}


def benchmark_counts(*, collect=False):
    from compositions import fast_compositions
    counts = Counter()
    per_prime = {name: Counter() for name in ("old", "sharp", "corner")}
    survivors, new_exclusions = [], []
    for matrix_degree in PALETTE:
        F = N // matrix_degree
        for tail in fast_compositions(PALETTE, 11, N - 1 - 2 * matrix_degree):
            linear = (1,) + tail
            counts["raw"] += 1
            sig, parity = signature(linear)
            flags = [True, True, True]
            for p in PRIMES:
                triple = prime_screens(sig, F, p)
                for j, name in enumerate(("old", "sharp", "corner")):
                    per_prime[name][p] += triple[j]
                    flags[j] = flags[j] and triple[j]
            old, sharp, corner = flags
            if corner and not sharp or sharp and not old:
                raise AssertionError("The exact nested arithmetic screens disagree")
            counts["old"] += old
            counts["sharp"] += sharp
            counts["corner"] += corner
            if sharp:
                no10 = matrix_degree != 10 and 10 not in linear
                cheap = cheap_failure(linear, matrix_degree, parity)[0] is None
                counts["sharp_no10"] += no10
                counts["corner_no10"] += corner and no10
                counts["sharp_plus_cheap"] += cheap
                counts["corner_plus_cheap"] += corner and cheap
                if collect and not corner:
                    new_exclusions.append([matrix_degree, *linear])
            if collect and corner:
                survivors.append([matrix_degree, *linear])
    return (dict(counts), {name: dict(v) for name, v in per_prime.items()},
            survivors, new_exclusions)
