"""Bounded target preparation/alignment worker with transactional checkpoints."""
from __future__ import annotations

import argparse
from collections import Counter
import cProfile
from pathlib import Path
import pstats
import signal
import time
import traceback

from common import atomic_json, digest_object, read_json, stable_id
from storage import TaskStore

STOP = False


def request_stop(_signum, _frame):
    global STOP
    STOP = True


def bounded_time(deadline, target_deadline):
    remaining = min(deadline, target_deadline) - time.monotonic()
    return None if remaining == float("inf") else max(0.0, remaining)


def run(root, plan):
    from target_pool import prepare_target
    from target_search import search_target_pool
    tasks = {x["id"]: x for x in read_json(root / "tasks.json")}
    began, cpu = time.monotonic(), time.process_time()
    deadline = began + plan["time_limit"] if plan["time_limit"] else float("inf")
    quota = plan["node_limit"] or None
    counters, timings = Counter(), Counter()
    errors = []
    visited = []
    for task_id in plan["tasks"]:
        if STOP or quota == 0 or time.monotonic() >= deadline:
            break
        task = tasks[task_id]
        target_deadline = (time.monotonic() + plan["per_target_seconds"]
                           if plan["per_target_seconds"] else float("inf"))
        target_quota = plan["per_target_nodes"] or None
        store = TaskStore(root / "checkpoints" / (task_id + ".sqlite"), digest_object(task))
        state = store.state() or dict(complete=False, stage="prepare", nodes=0,
                steps=0, prepare_checkpoint=None, search_checkpoint=None,
                pool=None, verified_table_ids=[], target_state=task["state"])
        if state["complete"]:
            store.close()
            continue
        record = read_json(root / task["resource"])
        visited.append(task["state"])
        try:
            # At most one preparation invocation and one alignment invocation
            # per target per sweep. This prevents one hard target starving all
            # later targets; its complete frontier is resumed on the next run.
            for _ in range(2):
                if STOP or quota == 0 or target_quota == 0 or time.monotonic() >= min(deadline, target_deadline):
                    break
                stage = state["stage"]
                bound = min(x for x in (quota, target_quota) if x is not None) if any(
                    x is not None for x in (quota, target_quota)) else None
                events = []
                clock, stage_cpu = time.monotonic(), time.process_time()
                previous = digest_object(state)
                if stage == "prepare":
                    old = state["prepare_checkpoint"]
                    result = prepare_target(record, kernel_dir=Path(__file__).parent / "vendor/rank16",
                        time_limit=bounded_time(deadline, target_deadline), max_nodes=bound,
                        checkpoint=old, progress=events.append, should_stop=lambda: STOP)
                    nodes = result["statistics"]["moment_rows"] - (old["counts"]["moment_rows"] if old else 0)
                    new = dict(state, prepare_checkpoint=result["checkpoint"], pool=result["pool"])
                    if result["pool"]["completeness"]["complete"]:
                        new["stage"] = "search"
                    status = "POOL_COMPLETE" if new["stage"] == "search" else "OPEN_POOL_PREPARATION"
                else:
                    if not state["pool"]["completeness"]["complete"]:
                        raise ValueError("Target alignment cannot consume an incomplete prepared pool")
                    result = search_target_pool(state["pool"],
                        max_nodes=bound, max_results=plan["max_results"],
                        time_limit=bounded_time(deadline, target_deadline),
                        checkpoint=state["search_checkpoint"], event_sink=events.append,
                        should_stop=lambda: STOP)
                    if result.get("status", "").startswith("OPEN_UNSUPPORTED"):
                        raise ValueError("Target backend cannot cover the supplied full field context: " + result["reason"])
                    if result.get("status") == "INVALID_INPUT" or "checkpoint" not in result:
                        raise ValueError("Target backend did not return a complete safe frontier: " + str(result))
                    nodes = result["nodes"]
                    verified = set(state["verified_table_ids"])
                    for solution in result.get("solutions", []):
                        reconstruction = solution["reconstruction"]
                        if reconstruction["status"] != "VERIFIED":
                            raise ValueError("Unverified table was offered as a target solution")
                        verified.add(reconstruction["verification"]["table_sha256"])
                    new = dict(state, search_checkpoint=result["checkpoint"],
                               verified_table_ids=sorted(verified), complete=bool(result["complete"]))
                    status = ("COMPLETE_WITH_VERIFIED_TABLES" if new["complete"] and verified else
                              "EXCLUDED_WITHIN_COMPLETE_ROW_POOL" if new["complete"] else
                              "VERIFIED_TABLE_FOUND_SEARCH_OPEN" if verified else "OPEN_TARGET_ALIGNMENT")
                if nodes < 0 or (bound is not None and nodes > bound):
                    raise ValueError("Backend reported invalid atomic node accounting")
                elapsed, used_cpu = time.monotonic() - clock, time.process_time() - stage_cpu
                new.update(nodes=state["nodes"] + nodes, steps=state["steps"] + 1, latest_status=status)
                ledger = {"id": stable_id("target-stage", {"state": task["state"], "stage": stage,
                          "step": state["steps"], "input": task["input_sha256"]}),
                          "status": status, "state": task["state"], "stage": stage,
                          "previous_checkpoint_sha256": previous, "checkpoint_sha256": digest_object(new),
                          "nodes": nodes, "wall_seconds": elapsed, "cpu_seconds": used_cpu,
                          "events": events, "result": result,
                          "exclusion_scope": "This exact state and its complete necessary row pool only",
                          "categorification_established": False}
                # Frontier, exact events, table witnesses and status advance
                # in the same SQLite transaction. Nothing earlier than this
                # commit is credited by the coordinator.
                store.commit(new, [(state["steps"], ledger)])
                state = new
                counters[stage + "_nodes"] += nodes
                counters[stage + "_invocations"] += 1
                counters["event_records"] += len(events)
                timings[stage + "_wall_seconds"] += elapsed
                timings[stage + "_cpu_seconds"] += used_cpu
                if quota is not None:
                    quota -= nodes
                if target_quota is not None:
                    target_quota -= nodes
                if state["complete"] or state["stage"] == stage:
                    break
        except BaseException as exc:
            errors.append({"state": task["state"], "type": type(exc).__name__, "message": str(exc),
                           "traceback": traceback.format_exc(),
                           "previous_committed_frontier_is_authoritative": True})
        finally:
            store.close()
    report = {"status": "FAILED" if errors else "RETURNED", "visited_target_ids": visited,
              "counters": dict(counters), "stage_seconds": dict(timings), "errors": errors,
              "wall_seconds": time.monotonic() - began, "cpu_seconds": time.process_time() - cpu,
              "stop_reason": "signal" if STOP else "time_limit" if time.monotonic() >= deadline else
                             "node_limit" if quota == 0 else "one_bounded_visit_per_assigned_target"}
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("plan", type=Path)
    args = parser.parse_args()
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    root, plan = args.root.resolve(), read_json(args.plan)
    profile = cProfile.Profile() if plan.get("profile") else None
    if profile:
        profile.enable()
    report = run(root, plan)
    if profile:
        profile.disable()
        path = root / plan["report"]
        profile.dump_stats(str(path.with_suffix(".pstats")))
        with path.with_suffix(".profile.txt").open("w") as out:
            pstats.Stats(profile, stream=out).strip_dirs().sort_stats("cumulative").print_stats(30)
    atomic_json(root / plan["report"], report)


if __name__ == "__main__":
    main()
