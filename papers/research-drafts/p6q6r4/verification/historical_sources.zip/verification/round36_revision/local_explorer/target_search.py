"""Exact fixed-space clique search for a symplectic one-M2 row pool.

The supplied rows contain actual, globally aligned cyclotomic values. First
we choose orthogonal fixed parts, with the exact source-dimension and trace
budgets. Only then do we expand imaginary variants, check the common linear
projector, reconstruct multiplication, and run the complete based-ring
verifier. Exhaustion concerns this supplied pool; its mathematical
completeness is a separate, source-bound row-generation claim.
"""
from __future__ import annotations

from fractions import Fraction
import hashlib
from math import isfinite, prod
from pathlib import Path
import json
import time

from alignment import reconstruct_from_moments
from orbit_exact import (field_from_metadata, fixed_key, fixed_pair_scaled,
                         pair_scaled, moments_payload)
from verifier import canonical_sha256

VERSION = "symplectic-fixed-clique-1"
SCHEMA = "fusion5400.target_search.v1"


def _bits(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def _failure(status, reason, witness=None):
    return dict(schema=SCHEMA, status=status, reason=reason, witness=witness or {},
                global_dimension_or_type_exclusion=False,
                categorification_established=False,
                scope="the supplied aligned row pool only")


def _code_hashes():
    here = Path(__file__).resolve().parent
    return {name: hashlib.sha256((here / name).read_bytes()).hexdigest()
            for name in ("target_search.py", "orbit_exact.py", "alignment.py", "verifier.py")}


def _model(payload):
    if not isinstance(payload, dict) or payload.get("schema") != "fusion5400.target_pool.v1":
        raise ValueError("Expected fusion5400.target_pool.v1")
    target = payload.get("target", {})
    if target.get("kind") != "symplectic":
        return None, _failure("OPEN_UNSUPPORTED_CONTEXT", "SYMPLECTIC_FIXED_SPACE_REQUIRED")
    for key in ("rank", "dimension", "matrix_codegree", "pairs", "selfdual"):
        if type(target.get(key)) is not int or target[key] < (0 if key == "pairs" else 1):
            raise ValueError("Invalid target integer: " + key)
    n, D, F = target["rank"], target["dimension"], target["matrix_codegree"]
    if n != target["selfdual"] + 2 * target["pairs"] or n < 5 or D % F:
        raise ValueError("Inconsistent one-M2 rank, duality counts or integral codegree")
    minimum = target.get("min_nonunit_dimension", 3)
    simple = target.get("require_fusion_simple", True)
    if type(minimum) is not int or minimum < 1 or type(simple) is not bool:
        raise ValueError("Invalid target minimum or simplicity flag")
    orbits = payload.get("orbits")
    if not isinstance(orbits, list):
        raise ValueError("Explicit complete non-Perron orbit metadata is required")
    try:
        fields = [field_from_metadata(o) for o in orbits]
    except ValueError as exc:
        return None, _failure("OPEN_UNSUPPORTED_FIELD", "EXACT_ORBIT_METADATA_REQUIRED",
                              {"detail": str(exc)})
    if 1 + sum(field.degree for field in fields) != n - 4:
        raise ValueError("The supplied complete linear orbits must have dimension rank minus four")
    for orbit in orbits:
        f = orbit.get("formal_codegree")
        if type(f) is not int or f <= 0 or D % f:
            raise ValueError("The exact orbit helper requires positive integral codegrees dividing D")
    trace_unit = Fraction(1, D) + sum(Fraction(field.degree, orbit["formal_codegree"])
                                    for field, orbit in zip(fields, orbits)) + Fraction(2, F)
    if trace_unit != 1:
        return None, _failure("EXCLUDED_POOL", "FORMAL_CODEGREE_UNIT_TRACE",
                              {"sum": str(trace_unit), "required": 1})

    def normalize(row, is_unit=False):
        if not isinstance(row, dict):
            raise ValueError("A row must be an object")
        for name in ("dimension", "matrix_trace", "matrix_norm"):
            if type(row.get(name)) is not int:
                raise ValueError("Row " + name + " must be an integer")
        if type(row.get("selfdual")) is not bool:
            raise ValueError("Row selfdual must be a boolean")
        identifier = row.get("id", "unit" if is_unit else None)
        if not isinstance(identifier, str) or not identifier:
            raise ValueError("Row identifiers must be nonempty strings")
        values = row.get("values")
        if not isinstance(values, list) or len(values) != len(fields):
            raise ValueError("Wrong number of exact orbit values")
        values = [list(field.value(value)) for field, value in zip(fields, values)]
        out = dict(id=identifier, dimension=row["dimension"], matrix_trace=row["matrix_trace"],
                   matrix_norm=row["matrix_norm"], selfdual=row["selfdual"], values=values)
        key = json.dumps(fixed_key(out, orbits), separators=(",", ":"))
        if "fixed_key" in row and json.loads(row["fixed_key"]) != json.loads(key):
            raise ValueError("A row's supplied fixed_key differs from its exact values")
        out["fixed_key"] = key
        out["dual_id"] = row.get("dual_id", identifier if is_unit else None)
        return out

    unit = normalize(payload.get("unit"), True)
    if (unit["dimension"], unit["matrix_trace"], unit["matrix_norm"], unit["selfdual"]) != (1, 2, 2, True):
        raise ValueError("Incorrect unit row")
    if any(tuple(v) != field.one for field, v in zip(fields, unit["values"])):
        raise ValueError("Every unit orbit value must be one")
    raw_rows = payload.get("rows")
    if not isinstance(raw_rows, list):
        raise ValueError("rows must be an explicit finite list")
    rows = [normalize(row) for row in raw_rows]
    by_id = {row["id"]: row for row in rows}
    if len(by_id) != len(rows) or unit["id"] in by_id:
        raise ValueError("Duplicate source row identifier")
    complete = payload.get("completeness", {}).get("complete") is True
    removed = []
    allowed = []
    for row in rows:
        conjugates = [list(field.conjugate(tuple(v))) for field, v in zip(fields, row["values"])]
        dual_id = row["dual_id"]
        if not isinstance(dual_id, str):
            raise ValueError("Each pooled row needs its exact dual_id")
        dual = by_id.get(dual_id)
        if dual is None and complete:
            raise ValueError("A purportedly complete pool is not closed under duality")
        if dual is not None:
            if (dual["dual_id"] != row["id"]
                    or any(dual[k] != row[k] for k in ("dimension", "matrix_trace", "matrix_norm", "selfdual"))
                    or dual["values"] != conjugates):
                raise ValueError("Inconsistent exact dual rows")
        if row["selfdual"] and (dual_id != row["id"] or conjugates != row["values"]):
            raise ValueError("A selfdual row must have real orbit values and be fixed by duality")
        d, s, t = row["dimension"], row["matrix_trace"], row["matrix_norm"]
        weight = 1 if row["selfdual"] else 2
        reason = None
        if d < minimum or t < 0:
            reason = "minimum_dimension_or_negative_matrix_norm"
        elif weight * d * d + (n - 1 - weight) * minimum * minimum > D - 1:
            reason = "individual_source_dimension_budget"
        elif F * pair_scaled(row, unit, orbits, D) + D * s != 0:
            reason = "unit_character_orthogonality"
        elif F * pair_scaled(row, row, orbits, D) != D * (F - t):
            reason = "matrix_norm_column_identity"
        elif fixed_pair_scaled(row, row, orbits, D, F) != (2 * D if row["selfdual"] else D):
            reason = "symplectic_fixed_diagonal"
        elif row["selfdual"] and s * s != 2 * t:
            reason = "selfdual_scalar_matrix_image"
        if reason:
            removed.append({"row_id": row["id"], "reason": reason})
            continue
        # One orientation per nonselfdual pair suffices up to relabelling the
        # source basis. Missing conjugates in a partial pool are forced values,
        # not a claim that generation of the pool has finished.
        chosen = row
        if not row["selfdual"] and dual_id < row["id"]:
            chosen = dict(row, id=dual_id, dual_id=row["id"], values=conjugates)
        allowed.append(chosen)
    grouped = {}
    for row in allowed:
        key = (row["selfdual"], row["fixed_key"])
        signatures = grouped.setdefault(key, {})
        signature = (row["matrix_norm"], tuple(tuple(v) for v in row["values"]))
        old = signatures.get(signature)
        if old is None or row["id"] < old["id"]:
            signatures[signature] = row
    classes = []
    for (sd, key), variants in sorted(grouped.items(), key=lambda item: (not item[0][0], item[0][1])):
        options = sorted(variants.values(), key=lambda row: (row["id"], row["matrix_norm"]))
        row = options[0]
        classes.append(dict(index=len(classes), selfdual=sd, fixed_key=key,
            dimension=row["dimension"], matrix_trace=row["matrix_trace"],
            representative=row, variants=options, weight=1 if sd else 2))
    model_key = dict(target=target, orbits=orbits, unit=unit,
                     classes=[{k: c[k] for k in ("index", "selfdual", "fixed_key", "variants")}
                              for c in classes],
                     input_pool_complete_claim=complete)
    return dict(target=target, n=n, D=D, F=F, minimum=minimum, simple=simple,
                orbits=orbits, fields=fields, unit=unit, classes=classes,
                pool_claims_complete=complete, pool_sha256=canonical_sha256(model_key),
                source_pool_provenance=payload.get("completeness", {}),
                row_filter_witnesses=removed,
                raw_rows=len(rows)), None


def search_target_pool(payload, *, max_nodes=1000, max_results=1,
                       time_limit=None, checkpoint=None, witness_limit=128,
                       event_sink=None, should_stop=None):
    """Search a supplied symplectic fixed-space pool with a resumable DFS.

    The JSON checkpoint contains the complete unvisited DFS frontier and the
    active imaginary-variant cursor, bound to exact pool and source hashes.
    Budgets are checked between atomic branch/variant steps. Initial exact
    pool validation and one graph-neighbour or reconstruction step may exceed
    a very short wall-clock limit. Resumed completion explicitly requires the
    prior chunk history; an arbitrary checkpoint is not a proof of that history.
    """
    began = time.monotonic()
    if ((max_nodes is not None and (type(max_nodes) is not int or max_nodes < 0)) or type(max_results) is not int
            or max_results < 1 or type(witness_limit) is not int or witness_limit < 0
            or (time_limit is not None and (isinstance(time_limit, bool)
                or not isinstance(time_limit, (int, float)) or not isfinite(time_limit) or time_limit < 0))
            or (event_sink is not None and not callable(event_sink))
            or (should_stop is not None and not callable(should_stop))):
        return _failure("INVALID_INPUT", "INVALID_SEARCH_BUDGET")
    try:
        model, error = _model(payload)
    except (ValueError, TypeError, KeyError, ZeroDivisionError) as exc:
        return _failure("INVALID_INPUT", "MALFORMED_TARGET_POOL", {"detail": str(exc)})
    if error:
        return error
    classes, target = model["classes"], model["target"]
    D, F, orbits = model["D"], model["F"], model["orbits"]
    code_hashes = _code_hashes()
    m = len(classes)
    sd_mask = sum(1 << i for i, c in enumerate(classes) if c["selfdual"])
    pair_mask = ((1 << m) - 1) ^ sd_mask
    adjacency = {}
    edges_evaluated = 0

    def neighbours(i):
        nonlocal edges_evaluated
        if i not in adjacency:
            row = classes[i]["representative"]
            mask = 0
            for j, c in enumerate(classes):
                if i != j:
                    edges_evaluated += 1
                    if fixed_pair_scaled(row, c["representative"], orbits, D, F) == 0:
                        mask |= 1 << j
            adjacency[i] = mask
        return adjacency[i]

    def frame(selected, s_mask, p_mask, need_sd, need_pair, mass, trace_square, correlation):
        kind = "sd" if not need_pair else "pair" if not need_sd else (
            "sd" if s_mask.bit_count() * need_pair <= p_mask.bit_count() * need_sd else "pair")
        terminal = need_sd == need_pair == 0
        return dict(selected=selected, sd_mask=s_mask, pair_mask=p_mask,
                    need_sd=need_sd, need_pair=need_pair, mass=mass,
                    trace_square=trace_square, correlation=correlation,
                    kind=kind, choices=0 if terminal else s_mask if kind == "sd" else p_mask,
                    variant_cursor=0 if terminal else None)

    def necessary_bounds(state):
        bounds = {"mass": [state["mass"], state["mass"]],
                  "trace_square": [state["trace_square"], state["trace_square"]],
                  "correlation": [state["correlation"], state["correlation"]]}
        for kind, mask, need in (("selfdual", state["sd_mask"], state["need_sd"]),
                                 ("pair", state["pair_mask"], state["need_pair"])):
            indices = list(_bits(mask))
            if len(indices) < need:
                return {"reason": "FIXED_CLIQUE_CARDINALITY", "basis_kind": kind,
                        "candidate_classes": indices, "available": len(indices), "required": need}
            if not need:
                continue
            for name, value in (
                ("mass", lambda c: c["weight"] * c["dimension"] ** 2),
                ("trace_square", lambda c: c["weight"] * c["matrix_trace"] ** 2),
                ("correlation", lambda c: c["weight"] * c["dimension"] * c["matrix_trace"])):
                values = sorted(value(classes[i]) for i in indices)
                bounds[name][0] += sum(values[:need])
                bounds[name][1] += sum(values[-need:])
        for name, required in (("mass", D), ("trace_square", 2 * F), ("correlation", 0)):
            low, high = bounds[name]
            if not low <= required <= high:
                return {"reason": "FIXED_CLIQUE_" + name.upper() + "_BOUND",
                        "reachable_interval": [low, high], "required": required}
        return None

    if checkpoint is None:
        stack = [frame([], sd_mask, pair_mask, target["selfdual"] - 1,
                       target["pairs"], 1, 4, 2)]
        totals = dict(nodes=0, fixed_cliques=0, variant_assignments=0,
                      common_projector_passes=0, reconstruction_attempts=0,
                      verified_tables=0, reason_histogram={})
        prior_chunks = 0
    else:
        if (not isinstance(checkpoint, dict) or checkpoint.get("schema") != SCHEMA + ".checkpoint"
                or checkpoint.get("version") != VERSION
                or checkpoint.get("pool_sha256") != model["pool_sha256"]
                or checkpoint.get("source_sha256") != code_hashes):
            return _failure("INVALID_INPUT", "CHECKPOINT_POOL_OR_CODE_BINDING_MISMATCH")
        try:
            stack = []
            for raw in checkpoint["frontier"]:
                state = dict(raw)
                for key in ("sd_mask", "pair_mask", "choices"):
                    state[key] = int(state[key], 16)
                    if state[key] < 0 or state[key] >> m:
                        raise ValueError("Checkpoint bitmask outside fixed classes")
                if (not isinstance(state["selected"], list)
                        or len(set(state["selected"])) != len(state["selected"])
                        or any(type(i) is not int or not 0 <= i < m for i in state["selected"])):
                    raise ValueError("Invalid selected class sequence")
                for key in ("need_sd", "need_pair", "mass", "trace_square"):
                    if type(state[key]) is not int or state[key] < 0:
                        raise ValueError("Invalid checkpoint count")
                rebuilt = frame([], sd_mask, pair_mask, target["selfdual"] - 1,
                                target["pairs"], 1, 4, 2)
                for i in state["selected"]:
                    c = classes[i]
                    required_kind = "sd" if c["selfdual"] else "pair"
                    candidate_mask = rebuilt[required_kind + "_mask"]
                    if rebuilt["kind"] != required_kind or not (candidate_mask >> i) & 1:
                        raise ValueError("Checkpoint prefix is not a canonical eligible DFS path")
                    adjacent = neighbours(i)
                    sm = rebuilt["sd_mask"] & adjacent
                    pm = rebuilt["pair_mask"] & adjacent
                    if c["selfdual"]:
                        sm &= ~((1 << (i + 1)) - 1)
                    else:
                        pm &= ~((1 << (i + 1)) - 1)
                    rebuilt = frame(rebuilt["selected"] + [i], sm, pm,
                        rebuilt["need_sd"] - int(c["selfdual"]),
                        rebuilt["need_pair"] - int(not c["selfdual"]),
                        rebuilt["mass"] + c["weight"] * c["dimension"] ** 2,
                        rebuilt["trace_square"] + c["weight"] * c["matrix_trace"] ** 2,
                        rebuilt["correlation"] + c["weight"] * c["dimension"] * c["matrix_trace"])
                for key in ("sd_mask", "pair_mask", "need_sd", "need_pair", "mass",
                            "trace_square", "correlation", "kind"):
                    if state[key] != rebuilt[key]:
                        raise ValueError("Checkpoint derived state mismatch: " + key)
                choices = state["choices"]
                if choices:
                    first = (choices & -choices).bit_length() - 1
                    if choices != rebuilt["choices"] & ~((1 << first) - 1):
                        raise ValueError("Checkpoint remaining choices are not a canonical suffix")
                if rebuilt["variant_cursor"] is None:
                    if state["variant_cursor"] is not None:
                        raise ValueError("Unexpected imaginary-variant cursor")
                elif (type(state["variant_cursor"]) is not int or not
                      0 <= state["variant_cursor"] <= prod(len(classes[i]["variants"]) for i in state["selected"])):
                    raise ValueError("Invalid imaginary-variant cursor")
                stack.append(state)
            totals = json.loads(json.dumps(checkpoint["totals"]))
            prior_chunks = checkpoint["completed_chunks"]
            if type(prior_chunks) is not int or prior_chunks < 1:
                raise ValueError("Invalid checkpoint chunk count")
            for key in ("nodes", "fixed_cliques", "variant_assignments", "common_projector_passes",
                        "reconstruction_attempts", "verified_tables"):
                if type(totals[key]) is not int or totals[key] < 0:
                    raise ValueError("Invalid checkpoint cumulative counter")
            if not isinstance(totals["reason_histogram"], dict) or any(
                    not isinstance(key, str) or type(value) is not int or value < 0
                    for key, value in totals["reason_histogram"].items()):
                raise ValueError("Invalid checkpoint reason histogram")
        except (ValueError, TypeError, KeyError) as exc:
            return _failure("INVALID_INPUT", "MALFORMED_CHECKPOINT", {"detail": str(exc)})
    initial_totals = {k: v for k, v in totals.items() if k != "reason_histogram"}
    solutions, witnesses = [], []
    ledger = hashlib.sha256()
    stop_reason = "frontier_exhausted"
    unresolved_reconstruction = None
    events_emitted = 0

    def emit(entry):
        nonlocal events_emitted
        events_emitted += 1
        entry = dict(event_type="target_search_node", pool_sha256=model["pool_sha256"],
                     node_ordinal=totals["nodes"], **entry)
        entry["event_id"] = canonical_sha256(entry)
        ledger.update(json.dumps(entry, sort_keys=True, separators=(",", ":")).encode() + b"\n")
        if len(witnesses) < witness_limit:
            witnesses.append(entry)
        if event_sink is not None:
            event_sink(entry)

    def record(entry):
        reason = entry["reason"]
        totals["reason_histogram"][reason] = totals["reason_histogram"].get(reason, 0) + 1
        emit(dict(status="EXCLUDED_NODE", **entry))

    while stack:
        if should_stop is not None and should_stop():
            stop_reason = "requested_stop"
            break
        if max_nodes is not None and totals["nodes"] - initial_totals["nodes"] >= max_nodes:
            stop_reason = "node_budget"
            break
        if time_limit is not None and time.monotonic() - began >= time_limit:
            stop_reason = "time_budget"
            break
        state = stack[-1]
        impossible = necessary_bounds(state)
        if impossible:
            totals["nodes"] += 1
            record(dict(selected_classes=state["selected"], **impossible))
            stack.pop()
            continue
        if state["need_sd"] or state["need_pair"]:
            if not state["choices"]:
                stack.pop()
                continue
            bit = state["choices"] & -state["choices"]
            i = bit.bit_length() - 1
            state["choices"] ^= bit
            c = classes[i]
            adjacent = neighbours(i)
            s_mask = state["sd_mask"] & adjacent
            p_mask = state["pair_mask"] & adjacent
            if c["selfdual"]:
                s_mask &= ~((1 << (i + 1)) - 1)
            else:
                p_mask &= ~((1 << (i + 1)) - 1)
            child = frame(state["selected"] + [i], s_mask, p_mask,
                state["need_sd"] - int(c["selfdual"]),
                state["need_pair"] - int(not c["selfdual"]),
                state["mass"] + c["weight"] * c["dimension"] ** 2,
                state["trace_square"] + c["weight"] * c["matrix_trace"] ** 2,
                state["correlation"] + c["weight"] * c["dimension"] * c["matrix_trace"])
            totals["nodes"] += 1
            impossible = necessary_bounds(child)
            if impossible:
                record(dict(selected_classes=child["selected"], **impossible))
            else:
                if child["need_sd"] == child["need_pair"] == 0:
                    totals["fixed_cliques"] += 1
                emit(dict(status="OPEN_BRANCH", reason="FIXED_CLIQUE_BRANCH_CONTINUES",
                          selected_classes=child["selected"],
                          candidate_selfdual_classes=list(_bits(child["sd_mask"])),
                          candidate_pair_classes=list(_bits(child["pair_mask"])),
                          remaining_selfdual=child["need_sd"], remaining_pairs=child["need_pair"]))
                stack.append(child)
            continue

        selected = sorted(state["selected"], key=lambda i: (not classes[i]["selfdual"], i))
        sizes = [len(classes[i]["variants"]) for i in selected]
        variant_total = prod(sizes)
        cursor = state["variant_cursor"]
        if cursor >= variant_total:
            stack.pop()
            continue
        index, chosen = cursor, []
        choices = [0] * len(selected)
        for depth in range(len(selected) - 1, -1, -1):
            index, choices[depth] = divmod(index, sizes[depth])
        for i, choice in zip(selected, choices):
            chosen.append(classes[i]["variants"][choice])
        state["variant_cursor"] += 1
        totals["nodes"] += 1
        totals["variant_assignments"] += 1
        norm = 2 + sum((1 if row["selfdual"] else 2) * row["matrix_norm"] for row in chosen)
        base = dict(selected_classes=selected, variant_index=cursor)
        if norm != 4 * F:
            record(dict(**base, reason="TOTAL_MATRIX_GRAM_TRACE", actual=norm, required=4 * F))
            continue
        rows, duality = [dict(model["unit"], id="b0")], [0]
        for row in chosen:
            i = len(rows)
            rows.append(dict(row, id=f"b{i}"))
            if row["selfdual"]:
                duality.append(i)
            else:
                duality.append(i + 1)
                conjugates = [list(field.conjugate(tuple(v))) for field, v in zip(model["fields"], row["values"])]
                rows.append(dict(row, id=f"b{i + 1}", values=conjugates))
                duality.append(i)
        n = len(rows)
        P = [[pair_scaled(x, y, orbits, D) for y in rows] for x in rows]
        failed = None
        for i in range(n):
            for j in range(n):
                value = sum(P[i][a] * P[a][j] for a in range(n))
                if value != D * P[i][j]:
                    failed = dict(**base, reason="COMMON_LINEAR_PROJECTOR",
                                  indices=[i, j], square_scaled=value,
                                  required_scaled=D * P[i][j])
                    break
            if failed:
                break
        if failed:
            record(failed)
            continue
        totals["common_projector_passes"] += 1
        moments = moments_payload(rows, duality, orbits, D, F)
        moments["moments_provenance"]["target_pool_sha256"] = model["pool_sha256"]
        result = reconstruct_from_moments(moments, target_dimension=D,
            require_fusion_simple=model["simple"], min_nonunit_dimension=model["minimum"])
        totals["reconstruction_attempts"] += 1
        if result.get("status") not in ("VERIFIED", "EXCLUDED"):
            # An unsupported or malformed reconstruction is not a mathematical
            # failure. Retain this exact variant at the frontier, so neither
            # this run nor a later resume can silently skip it. Diagnostics
            # record the attempted operation; committed node totals and their
            # event ledger continue to describe only completed decisions.
            state["variant_cursor"] -= 1
            for name in ("nodes", "variant_assignments", "common_projector_passes", "reconstruction_attempts"):
                totals[name] -= 1
            unresolved_reconstruction = dict(**base, backend_result=result)
            stop_reason = "unresolved_reconstruction"
            break
        if result["status"] == "VERIFIED":
            totals["verified_tables"] += 1
            solution_id = "table_" + result["verification"]["table_sha256"]
            solutions.append(dict(**base, solution_id=solution_id,
                                  row_ids=[row["id"] for row in chosen], reconstruction=result))
            emit(dict(**base, status="VERIFIED_TABLE", reason=result["reason"],
                      solution_id=solution_id))
            if len(solutions) >= max_results:
                stop_reason = "result_budget"
                break
        else:
            record(dict(**base, reason=result["reason"], reconstruction_status=result["status"],
                        witness=result.get("witness", {})))

    # Removing already exhausted frames is bookkeeping, not a search step.
    while stack:
        state = stack[-1]
        if state["need_sd"] or state["need_pair"]:
            exhausted = not state["choices"]
        else:
            exhausted = state["variant_cursor"] >= prod(len(classes[i]["variants"]) for i in state["selected"])
        if not exhausted:
            break
        stack.pop()
    traversal_complete = not stack
    complete = traversal_complete and model["pool_claims_complete"]
    frontier = []
    for state in stack:
        saved = dict(state)
        for key in ("sd_mask", "pair_mask", "choices"):
            saved[key] = hex(saved[key])
        frontier.append(saved)
    cp = dict(schema=SCHEMA + ".checkpoint", version=VERSION,
              pool_sha256=model["pool_sha256"], source_sha256=code_hashes,
              frontier=frontier, totals=totals, completed_chunks=prior_chunks + 1)
    status = ("VERIFIED" if solutions else "COMPLETE_WITH_VERIFIED_TABLES" if complete and totals["verified_tables"]
              else "EXCLUDED_POOL" if complete and checkpoint is None
              else "POOL_FRONTIER_EXHAUSTED" if complete
              else "OPEN")
    return dict(schema=SCHEMA, status=status, version=VERSION,
        reason="VERIFIED_RING_FOUND" if solutions else "SUPPLIED_POOL_TRAVERSAL_FINISHED" if complete else "RECONSTRUCTION_REMAINS_OPEN" if unresolved_reconstruction else "PARTIAL_POOL_REQUIRES_MORE_ROWS" if traversal_complete else "BOUNDED_SEARCH_REMAINS_OPEN",
        scope="only the supplied aligned row pool; row-pool completeness and resumed chunk history require their separate audits",
        global_dimension_or_type_exclusion=False, categorification_established=False,
        target=target, pool_sha256=model["pool_sha256"], source_sha256=code_hashes,
        input_pool_claims_complete=model["pool_claims_complete"], complete=complete,
        supplied_pool_traversal_complete=traversal_complete,
        complete_traversal_performed_in_this_call=complete and checkpoint is None,
        prior_chunk_history_required=checkpoint is not None,
        stop_reason=stop_reason, checkpoint=cp, totals=totals,
        unresolved_reconstruction=unresolved_reconstruction,
        counters_this_call={k: totals[k] - initial_totals[k] for k in initial_totals},
        nodes=totals["nodes"] - initial_totals["nodes"],
        fixed_class_count=m, selfdual_fixed_classes=sd_mask.bit_count(),
        pair_fixed_classes=pair_mask.bit_count(),
        class_catalogue=[dict(index=c["index"], selfdual=c["selfdual"], fixed_key=c["fixed_key"],
            dimension=c["dimension"], matrix_trace=c["matrix_trace"],
            variant_row_ids=[row["id"] for row in c["variants"]]) for c in classes],
        row_filter_witnesses=model["row_filter_witnesses"],
        graph_pairs_evaluated=edges_evaluated,
        graph_neighbour_masks={str(i): hex(mask) for i, mask in sorted(adjacency.items())},
        visited_ledger_sha256=ledger.hexdigest(), witness_excerpt=witnesses,
        events_emitted=events_emitted,
        witness_excerpt_may_be_truncated=events_emitted > len(witnesses),
        solutions=solutions, seconds=time.monotonic() - began)


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pool", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--max-nodes", type=int, default=1000)
    parser.add_argument("--max-results", type=int, default=1)
    parser.add_argument("--time-limit", type=float)
    args = parser.parse_args()
    checkpoint = json.loads(args.checkpoint.read_text()) if args.checkpoint else None
    if checkpoint and "checkpoint" in checkpoint:
        checkpoint = checkpoint["checkpoint"]
    result = search_target_pool(json.loads(args.pool.read_text()), max_nodes=args.max_nodes,
        max_results=args.max_results, time_limit=args.time_limit, checkpoint=checkpoint)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: result[k] for k in ("status", "reason", "complete", "nodes", "totals", "seconds") if k in result}, indent=2))


if __name__ == "__main__":
    main()
