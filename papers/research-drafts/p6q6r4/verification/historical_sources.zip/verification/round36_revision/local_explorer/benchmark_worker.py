"""Complete optimized arithmetic benchmark in an isolated process."""
import argparse
import json
from pathlib import Path
import time

from arithmetic import PALETTE, benchmark_counts
from common import atomic_json, digest_object
from compositions import exact_count, reachable_table


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    started, cpu = time.perf_counter(), time.process_time()
    counts, per_prime, survivors, excluded = benchmark_counts(collect=True)
    enumeration_wall = time.perf_counter() - started
    enumeration_cpu = time.process_time() - cpu
    count_start = time.perf_counter()
    counts["profiles"] = exact_count(PALETTE, 13, 5399)
    report = {"counts": counts,
              "per_prime_survival": {s: {str(p): n for p, n in d.items()} for s, d in per_prime.items()},
              "combined_survivors_sorted_sha256": digest_object(sorted(survivors)),
              "new_corner_exclusions_sorted_sha256": digest_object(sorted(excluded)),
              "enumeration_wall_seconds": enumeration_wall,
              "enumeration_cpu_seconds": enumeration_cpu,
              "independent_profile_count_seconds": time.perf_counter() - count_start,
              "reachable_bitset_cache": reachable_table.cache_info()._asdict(),
              "process_cpu_seconds": time.process_time() - cpu,
              "process_wall_seconds": time.perf_counter() - started,
              "scope": "Complete all-rational rank16 one-M2 arithmetic audit; not the full-field R36 input."}
    atomic_json(args.output, report)
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
