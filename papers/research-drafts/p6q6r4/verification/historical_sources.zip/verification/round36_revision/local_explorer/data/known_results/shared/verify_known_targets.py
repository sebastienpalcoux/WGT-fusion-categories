#!/usr/bin/env python3
"""Replay the four audited exclusions independently of the target search DFS.

The row audit enumerates full integral-basis coordinates with the preserved
original moment kernel. The graph audit uses explicit Galois embeddings,
then all pair cliques and their selfdual completions. Neither uses the
target search's dimension/trace/correlation pruning.
"""
from __future__ import annotations

import argparse
import importlib
from pathlib import Path
import sys
import time

from common import atomic_json, digest_object, file_hash, read_json
from catalogue import load_catalogue
from audit_known_row_pools import audit_basis_embeddings, audit_one
from audit_fixed_clique_completion import audit


STATES = (47412, 461210, 836343, 1284815)
HERE = Path(__file__).resolve().parent


def verify_known_targets(output):
    if not __debug__:
        raise RuntimeError("Run independent checks with assertions enabled")
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    vendor = HERE / "vendor/rank16"
    sys.path.insert(0, str(vendor))
    original = importlib.import_module("fixed_field_rows_original")
    optimized = importlib.import_module("fixed_field_rows")
    contexts = importlib.import_module("context16")
    records, _, _ = load_catalogue()
    root = HERE / "data/known_results"
    started = time.monotonic()
    audit_basis_embeddings()
    summaries = []
    for state in STATES:
        base = root / ("state_" + str(state))
        record, pool = read_json(base / "record.json"), read_json(base / "pool.json")
        if record != records[state]:
            raise ValueError("Proof input is not the exact catalogue record")
        row_report = audit_one(root, state, original, optimized, contexts)
        graph_report = audit(pool)
        if not graph_report["input_pool_claims_complete"] or not graph_report["no_full_fixed_clique"]:
            raise ValueError("Complete independently verified exclusion was not reproduced")
        destination = output / ("state_" + str(state))
        atomic_json(destination / "row_pool_audit.json", row_report)
        atomic_json(destination / "fixed_clique_audit.json", graph_report)
        summary = {
            "state": state,
            "status": "PASS_INDEPENDENT_COMPLETE_ROW_POOL_AND_FIXED_CLIQUE_EXCLUSION",
            "record_sha256": digest_object(record),
            "record_file_sha256": file_hash(base / "record.json"),
            "pool_file_sha256": file_hash(base / "pool.json"),
            "moment_rows": row_report["moment_rows"],
            "exact_algebraic_rows": row_report["exact_rows"],
            "pair_fixed_classes": graph_report["pair_graph_audit"]["fixed_pair_classes"],
            "pair_graph_edges": len(graph_report["pair_graph_audit"]["orthogonality_edges"]),
            "pair_cliques_of_required_size": len(graph_report["pair_graph_audit"]["required_cliques"]),
            "full_fixed_cliques": len(graph_report["full_fixed_cliques"]),
            "row_pool_audit_sha256": file_hash(destination / "row_pool_audit.json"),
            "fixed_clique_audit_sha256": file_hash(destination / "fixed_clique_audit.json"),
        }
        atomic_json(destination / "audit_report.json", summary)
        summaries.append(summary)
    sources = ("verify_known_targets.py", "audit_known_row_pools.py",
               "audit_fixed_clique_completion.py", "audit_target_pair_graph.py",
               "orbit_exact.py", "verifier.py")
    report = {
        "status": "PASS_FOUR_INDEPENDENT_KNOWN_TARGET_EXCLUSIONS",
        "targets": summaries,
        "source_sha256": {name: file_hash(HERE / name) for name in sources},
        "original_moment_kernel_sha256": file_hash(vendor / "fixed_field_rows_original.py"),
        "seconds": time.monotonic() - started,
        "categorification_established": False,
    }
    atomic_json(output / "known_targets_replay.json", report)
    return report


def main():
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = verify_known_targets(args.output)
    print(json.dumps({"status": report["status"], "seconds": report["seconds"],
                      "states": [item["state"] for item in report["targets"]]}, indent=2))


if __name__ == "__main__":
    main()
