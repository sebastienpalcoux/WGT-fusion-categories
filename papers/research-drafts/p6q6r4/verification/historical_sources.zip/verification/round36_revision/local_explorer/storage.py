"""Transactional checkpoints and authenticated, self-contained feedback ZIPs."""
from __future__ import annotations

import gzip
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sqlite3
import stat
import tempfile
import zipfile

from common import atomic_json, canonical_bytes, file_hash, read_json
from version import SCHEMA
from runtime_info import runtime_info


class TaskStore:
    """One SQLite database per deterministic task; one writer at a time.

    Results and the complete search frontier advance in ONE transaction.
    A killed process can lose only an uncommitted batch, which is recomputed.
    No absent row or unvisited branch is inferred from an interruption.
    """

    def __init__(self, path, task_hash, *, readonly=False):
        self.path = Path(path)
        self.readonly = readonly
        if readonly:
            self.db = sqlite3.connect(self.path.resolve().as_uri() + "?mode=ro", uri=True)
        else:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.db = sqlite3.connect(self.path)
            self.db.execute("PRAGMA journal_mode=DELETE")
            self.db.execute("PRAGMA synchronous=FULL")
            self.db.executescript("""
                CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS results(
                    step INTEGER PRIMARY KEY, id TEXT UNIQUE NOT NULL,
                    status TEXT NOT NULL, record TEXT NOT NULL);
            """)
            found = self.db.execute("SELECT value FROM meta WHERE key='task_hash'").fetchone()
            if found is None:
                self.db.execute("INSERT INTO meta VALUES('task_hash',?)", (task_hash,))
                self.db.commit()
            elif found[0] != task_hash:
                raise ValueError("Checkpoint belongs to a different exact task")
        found = self.db.execute("SELECT value FROM meta WHERE key='task_hash'").fetchone()
        if found is None or found[0] != task_hash:
            raise ValueError("Checkpoint task binding is absent or incorrect")

    def state(self):
        row = self.db.execute("SELECT value FROM meta WHERE key='checkpoint'").fetchone()
        return json.loads(row[0]) if row else None

    def commit(self, state, records):
        if self.readonly:
            raise RuntimeError("Read-only checkpoint")
        with self.db:
            for step, record in records:
                self.db.execute("INSERT INTO results VALUES(?,?,?,?)",
                                (step, record["id"], record["status"],
                                 canonical_bytes(record).decode()))
            self.db.execute("INSERT OR REPLACE INTO meta VALUES('checkpoint',?)",
                            (canonical_bytes(state).decode(),))

    def iter_results(self):
        yield from self.db.execute("SELECT record FROM results ORDER BY step")

    def histogram(self):
        return dict(self.db.execute("SELECT status, COUNT(*) FROM results GROUP BY status"))

    def close(self):
        self.db.close()


def payload_manifest(root):
    root = Path(root)
    result = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        name = path.relative_to(root).as_posix()
        if name == "MANIFEST.json" or name.endswith((".tmp", "-journal", "-wal", "-shm")):
            continue
        if path.is_symlink():
            raise ValueError("Feedback payload cannot contain symbolic links")
        result[name] = {"sha256": file_hash(path), "bytes": path.stat().st_size}
    return {"schema": SCHEMA, "files": result}


def write_feedback(root, destination=None):
    root = Path(root).resolve()
    destination = Path(destination).resolve() if destination else root.with_name(root.name + ".feedback.zip")
    if destination.is_relative_to(root):
        raise ValueError("Feedback ZIP must be outside the directory it archives")
    atomic_json(root / "environment.json", runtime_info())
    manifest = payload_manifest(root)
    atomic_json(root / "MANIFEST.json", manifest)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6, allowZip64=True) as archive:
        for name in sorted(manifest["files"]):
            archive.write(root / name, name)
        archive.write(root / "MANIFEST.json", "MANIFEST.json")
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:
            raise ValueError("Feedback ZIP CRC check failed")
        expected = set(manifest["files"]) | {"MANIFEST.json"}
        names = archive.namelist()
        if set(names) != expected or len(names) != len(expected):
            raise ValueError("Feedback ZIP member inventory is not exact")
        # Compare every archived byte stream, including empty checkpoints.
        import hashlib
        for name, item in manifest["files"].items():
            h = hashlib.sha256()
            size = 0
            with archive.open(name) as stream:
                for block in iter(lambda: stream.read(1 << 20), b""):
                    size += len(block)
                    h.update(block)
            if size != item["bytes"] or h.hexdigest() != item["sha256"]:
                raise ValueError("Archived payload differs: " + name)
    os.replace(temporary, destination)
    return destination


def import_feedback(source, destination):
    """Validate names, sizes and hashes before accepting any restart state."""
    source, destination = Path(source).resolve(), Path(destination).resolve()
    if destination.exists():
        raise ValueError("Import destination already exists; choose a fresh directory")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".feedback_import_", dir=destination.parent))
    try:
        with zipfile.ZipFile(source) as archive:
            infos = archive.infolist()
            names = [item.filename for item in infos]
            if len(names) != len(set(names)) or "MANIFEST.json" not in names:
                raise ValueError("Duplicate ZIP member or absent manifest")
            for item in infos:
                path = PurePosixPath(item.filename)
                mode = item.external_attr >> 16
                if (path.is_absolute() or ".." in path.parts or "\\" in item.filename
                        or path.as_posix() != item.filename or not path.parts
                        or any(":" in part or "\x00" in part for part in path.parts)
                        or item.is_dir() or stat.S_ISLNK(mode)):
                    raise ValueError("Unsafe feedback member name or type")
            manifest = json.loads(archive.read("MANIFEST.json"))
            if manifest.get("schema") != SCHEMA:
                raise ValueError("Unsupported feedback schema")
            if set(names) != set(manifest["files"]) | {"MANIFEST.json"}:
                raise ValueError("Feedback inventory differs from its manifest")
            info_by_name = {x.filename: x for x in infos}
            for name, item in manifest["files"].items():
                if info_by_name[name].file_size != item["bytes"]:
                    raise ValueError("Feedback member size differs: " + name)
                path = temporary / name
                path.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(name) as inp, path.open("wb") as out:
                    shutil.copyfileobj(inp, out, 1 << 20)
                if file_hash(path) != item["sha256"]:
                    raise ValueError("Feedback hash differs: " + name)
            atomic_json(temporary / "MANIFEST.json", manifest)
        os.replace(temporary, destination)
    except BaseException:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    return destination


def verify_directory(root):
    root = Path(root)
    manifest = read_json(root / "MANIFEST.json")
    if manifest.get("schema") != SCHEMA:
        raise ValueError("Unsupported feedback schema")
    for name, item in manifest["files"].items():
        path = root / name
        if not path.is_file() or path.stat().st_size != item["bytes"] or file_hash(path) != item["sha256"]:
            raise ValueError("Feedback payload changed: " + name)
    return manifest

