"""Exact verification of an explicitly supplied finite based-ring table.

The input convention is multiplication[i][j][k] = [b_i b_j : b_k].
Only Python integers are accepted for structure constants and dimensions;
booleans, floats and truncated tables are not silently coerced.  A VERIFIED
result proves the stated ring axioms and requested arithmetic properties.
It does not assert that any fusion category categorifies the ring.

No failure of one table excludes other tables of the same dimension/type.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

SCHEMA = "exact-based-ring-v1"


def canonical_sha256(value: Any) -> str:
    data = json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")
    return hashlib.sha256(data).hexdigest()


def _integer(x: Any) -> bool:
    return type(x) is int


def _failure(status: str, reason: str, witness: dict, *, checked=(),
             ring_axioms_verified=False) -> dict:
    return {
        "schema": SCHEMA, "status": status, "reason": reason,
        "scope": "the explicitly supplied multiplication table only",
        "global_dimension_or_type_exclusion": False,
        "ring_axioms_verified": ring_axioms_verified,
        "categorification_established": False,
        "checked": list(checked), "witness": witness,
    }


def validate_basis(payload: Any) -> tuple[dict | None, dict | None]:
    """Validate shared source-basis data without asserting any ring axiom."""
    if not isinstance(payload, dict):
        return None, _failure("INVALID_INPUT", "OBJECT_REQUIRED", {})
    dimensions = payload.get("dimensions")
    duality = payload.get("duality")
    if not isinstance(dimensions, list) or not dimensions:
        return None, _failure("INVALID_INPUT", "POSITIVE_DIMENSION_LIST_REQUIRED", {})
    n = len(dimensions)
    for i, d in enumerate(dimensions):
        if not _integer(d) or d <= 0:
            return None, _failure("INVALID_INPUT", "NONPOSITIVE_OR_NONINTEGER_DIMENSION",
                                  {"index": i, "value": d})
    unit = payload.get("unit", 0)
    if not _integer(unit) or not 0 <= unit < n:
        return None, _failure("INVALID_INPUT", "INVALID_UNIT_INDEX", {"unit": unit})
    if not isinstance(duality, list) or len(duality) != n:
        return None, _failure("INVALID_INPUT", "DUALITY_LENGTH", {"rank": n})
    for i, j in enumerate(duality):
        if not _integer(j) or not 0 <= j < n:
            return None, _failure("INVALID_INPUT", "INVALID_DUAL_INDEX",
                                  {"index": i, "value": j})
    labels = payload.get("labels", [str(i) for i in range(n)])
    if (not isinstance(labels, list) or len(labels) != n
            or any(not isinstance(x, str) for x in labels)
            or len(set(labels)) != n):
        return None, _failure("INVALID_INPUT", "LABELS_MUST_BE_DISTINCT_STRINGS", {})
    for i in range(n):
        if duality[duality[i]] != i:
            return None, _failure("EXCLUDED", "DUALITY_NOT_INVOLUTIVE",
                                  {"index": i, "double_dual": duality[duality[i]]})
        if dimensions[duality[i]] != dimensions[i]:
            return None, _failure("EXCLUDED", "DUAL_DIMENSIONS_DIFFER",
                                  {"index": i, "dual": duality[i]})
    if duality[unit] != unit or dimensions[unit] != 1:
        return None, _failure("EXCLUDED", "UNIT_BASIS_DATA",
                              {"unit": unit, "dual": duality[unit],
                               "dimension": dimensions[unit]})
    return {"rank": n, "unit": unit, "duality": list(duality),
            "dimensions": list(dimensions), "labels": list(labels)}, None


def _closure(generator: int, unit: int, star: list[int], supports: list) -> list[int]:
    """Smallest support- and duality-closed basis subset containing a label."""
    closed = {unit, generator, star[generator]}
    frontier = set(closed)
    while frontier:
        old = sorted(closed)
        new = set()
        # Old-old pairs were processed in earlier rounds. Each pair involving
        # a new label is processed in both orders; commutativity is not assumed.
        for a in sorted(frontier):
            new.add(star[a])
            for b in old:
                new.update(k for k, _ in supports[a][b])
                new.update(k for k, _ in supports[b][a])
        frontier = new - closed
        closed.update(frontier)
    return sorted(closed)


def verify_table(payload: Any, *, target_dimension: int | None = 5400,
                 require_fusion_simple: bool = True,
                 min_nonunit_dimension: int | None = 3) -> dict:
    """Completely check one finite dense table, without a search budget.

    ``target_dimension=None`` disables the dimension-total target for controls;
    ``require_fusion_simple=False`` still computes and reports simplicity.
    Target failures are distinguished from failures of the ring axioms.
    """
    if target_dimension is not None and (not _integer(target_dimension)
                                         or target_dimension < 1):
        return _failure("INVALID_INPUT", "INVALID_TARGET_DIMENSION", {})
    if type(require_fusion_simple) is not bool:
        return _failure("INVALID_INPUT", "INVALID_SIMPLICITY_FLAG", {})
    if min_nonunit_dimension is not None and (
            not _integer(min_nonunit_dimension) or min_nonunit_dimension < 1):
        return _failure("INVALID_INPUT", "INVALID_MINIMUM_DIMENSION", {})
    basis, error = validate_basis(payload)
    if error is not None:
        return error
    assert basis is not None
    n, unit = basis["rank"], basis["unit"]
    star, dims = basis["duality"], basis["dimensions"]
    table = payload.get("multiplication")
    if not isinstance(table, list) or len(table) != n:
        return _failure("INVALID_INPUT", "TABLE_SHAPE", {"required": [n, n, n]})
    for i, row in enumerate(table):
        if not isinstance(row, list) or len(row) != n:
            return _failure("INVALID_INPUT", "TABLE_SHAPE", {"row": i})
        for j, product in enumerate(row):
            if not isinstance(product, list) or len(product) != n:
                return _failure("INVALID_INPUT", "TABLE_SHAPE", {"product": [i, j]})
            for k, value in enumerate(product):
                if not _integer(value):
                    return _failure("INVALID_INPUT", "NONINTEGER_STRUCTURE_CONSTANT",
                                    {"indices": [i, j, k], "value": value})
                if value < 0:
                    return _failure("EXCLUDED", "NEGATIVE_STRUCTURE_CONSTANT",
                                    {"indices": [i, j, k], "value": value})
    checked = ["finite integer nonnegative structure constants", "basis duality"]
    for i in range(n):
        for k in range(n):
            expected = int(i == k)
            if table[unit][i][k] != expected or table[i][unit][k] != expected:
                return _failure("EXCLUDED", "UNIT_FAILURE",
                                {"indices": [i, k], "left": table[unit][i][k],
                                 "right": table[i][unit][k], "expected": expected},
                                checked=checked)
    checked.append("two-sided basis unit")
    supports = [[[(k, value) for k, value in enumerate(table[i][j]) if value]
                 for j in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            expected_unit = int(j == star[i])
            if table[i][j][unit] != expected_unit:
                return _failure("EXCLUDED", "RIGID_UNIT_COEFFICIENT",
                                {"indices": [i, j, unit], "actual": table[i][j][unit],
                                 "expected": expected_unit}, checked=checked)
            actual_dim = sum(value * dims[k] for k, value in supports[i][j])
            if actual_dim != dims[i] * dims[j]:
                return _failure("EXCLUDED", "DIMENSION_HOMOMORPHISM_FAILURE",
                                {"product": [i, j], "product_dimension": actual_dim,
                                 "required_dimension": dims[i] * dims[j]}, checked=checked)
            for k in range(n):
                a = table[i][j][k]
                b = table[star[j]][star[i]][star[k]]
                if a != b:
                    return _failure("EXCLUDED", "DUALITY_ANTI_MULTIPLICATIVITY",
                                    {"indices": [i, j, k], "value": a,
                                     "dual_product_value": b}, checked=checked)
                left = table[star[i]][k][j]
                right = table[k][star[j]][i]
                if a != left or a != right:
                    return _failure("EXCLUDED", "FROBENIUS_RECIPROCITY",
                                    {"indices": [i, j, k], "value": a,
                                     "left_reciprocal": left,
                                     "right_reciprocal": right}, checked=checked)
    checked += ["rigid unit coefficient", "duality anti-multiplicativity",
                "both Frobenius reciprocity identities",
                "positive integral dimension homomorphism"]
    products_checked = 0
    term_operations = 0
    # All ordered triples are checked. Sparsity accelerates each exact identity;
    # it does not restrict the finite associativity domain.
    for i in range(n):
        for j in range(n):
            for k in range(n):
                lhs, rhs = [0] * n, [0] * n
                for a, x in supports[i][j]:
                    for b, y in supports[a][k]:
                        lhs[b] += x * y
                        term_operations += 1
                for a, x in supports[j][k]:
                    for b, y in supports[i][a]:
                        rhs[b] += x * y
                        term_operations += 1
                products_checked += 1
                if lhs != rhs:
                    b = next(b for b in range(n) if lhs[b] != rhs[b])
                    return _failure("EXCLUDED", "ASSOCIATIVITY_FAILURE",
                                    {"ordered_triple": [i, j, k], "output": b,
                                     "left_coefficient": lhs[b],
                                     "right_coefficient": rhs[b],
                                     "ordered_triples_checked": products_checked},
                                    checked=checked)
    checked.append("all ordered associativity identities")
    closures = {}
    proper = None
    # A nontrivial proper fusion subring contains a nonunit basis element. Its
    # generated duality-closed support ring is still proper. Checking every
    # singleton is therefore complete, not a sampling of possible subrings.
    for i in range(n):
        if i == unit:
            continue
        closure = _closure(i, unit, star, supports)
        closures[str(i)] = closure
        if len(closure) < n and proper is None:
            proper = {"generator": i, "closed_basis_indices": closure,
                      "closed_dimension": sum(dims[j] ** 2 for j in closure)}
    simple = proper is None
    checked.append("all single-label generated fusion subrings")
    dimension = sum(d * d for d in dims)
    commutative = all(table[i][j] == table[j][i]
                      for i in range(n) for j in range(i))
    violations = []
    if target_dimension is not None and dimension != target_dimension:
        violations.append({"kind": "TARGET_DIMENSION", "actual": dimension,
                           "required": target_dimension})
    if min_nonunit_dimension is not None:
        bad = [i for i in range(n) if i != unit and dims[i] < min_nonunit_dimension]
        if bad:
            violations.append({"kind": "MINIMUM_NONUNIT_DIMENSION",
                               "required": min_nonunit_dimension, "indices": bad})
    if require_fusion_simple and not simple:
        violations.append({"kind": "PROPER_FUSION_SUBRING", **proper})
    normalized = {"unit": unit, "duality": star, "dimensions": dims,
                  "multiplication": table}
    result = {
        "schema": SCHEMA, "status": "EXCLUDED" if violations else "VERIFIED",
        "reason": "TARGET_CONSTRAINT_FAILURE" if violations else "EXACT_BASED_RING_VERIFIED",
        "scope": "the explicitly supplied multiplication table only",
        "global_dimension_or_type_exclusion": False,
        "ring_axioms_verified": True, "categorification_established": False,
        "rank": n, "frobenius_perron_dimension": dimension,
        "positive_dimension_vector_is_fp": True,
        "fusion_simple": simple, "commutative": commutative,
        "table_sha256": canonical_sha256(normalized), "checked": checked,
        "generated_subrings": closures, "proper_subring_witness": proper,
        "target": {"dimension": target_dimension,
                   "require_fusion_simple": require_fusion_simple,
                   "min_nonunit_dimension": min_nonunit_dimension},
        "target_violations": violations,
        "counters": {"structure_constants": n ** 3,
                     "ordered_associativity_triples": products_checked,
                     "associativity_integer_term_operations": term_operations,
                     "singleton_closures": max(n - 1, 0)},
        "fp_justification": "Each nonnegative multiplication matrix has the supplied strictly positive dimension vector as an eigenvector after transposition; diagonal conjugation gives constant row sum d_i, proving spectral radius d_i exactly.",
    }
    if violations:
        result["witness"] = {"target_violations": violations}
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--target-dimension", type=int, default=5400)
    parser.add_argument("--any-dimension", action="store_true")
    parser.add_argument("--allow-proper-subrings", action="store_true")
    parser.add_argument("--min-nonunit-dimension", type=int, default=3)
    args = parser.parse_args()
    payload = json.loads(args.input.read_text())
    result = verify_table(payload,
        target_dimension=None if args.any_dimension else args.target_dimension,
        require_fusion_simple=not args.allow_proper_subrings,
        min_nonunit_dimension=args.min_nonunit_dimension)
    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
