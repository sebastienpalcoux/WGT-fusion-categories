#!/usr/bin/env python3
"""Independent short certificate for the symplectic F=60 endpoint.

This proof audit imports neither the row kernels, orbit_exact, target_pool,
nor target_search. It compares a quadratic-discriminant enumeration with
an independent bounded integer box and checks all orthogonality edges.
"""
from fractions import Fraction
from itertools import product, combinations
from math import isqrt
from pathlib import Path
import hashlib
import json


def determinant(a):
    if not a:
        return 1
    return sum((-1)**j*a[0][j]*determinant([row[:j]+row[j+1:] for row in a[1:]])
               for j in range(len(a)))


def rank(a):
    a = [[Fraction(x) for x in row] for row in a]; h = 0
    for j in range(len(a[0])):
        pivot = next((i for i in range(h, len(a)) if a[i][j]), None)
        if pivot is None:
            continue
        a[h], a[pivot] = a[pivot], a[h]
        q = a[h][j]; a[h] = [x/q for x in a[h]]
        for i in range(len(a)):
            if i != h:
                q = a[i][j]; a[i] = [x-q*y for x,y in zip(a[i],a[h])]
        h += 1
        if h == len(a):
            break
    return h


def reduce9(a):
    a = list(a)+[0]*max(0,6-len(a))
    for k in range(len(a)-1,5,-1):
        a[k-3] -= a[k]; a[k-6] -= a[k]
    return tuple(a[:6])


def mul9(a,b):
    out=[0]*11
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return reduce9(out)


def audit_cubic_lattice():
    powers=[reduce9([0]*j+[1]) for j in range(9)]
    conjugation=[[powers[-j%9][i] for j in range(6)] for i in range(6)]
    identity=[[int(i==j)for j in range(6)]for i in range(6)]
    assert rank([[conjugation[i][j]-identity[i][j]for j in range(6)]for i in range(6)])==3
    one=(1,0,0,0,0,0);theta=(0,1,-1,0,0,-1)
    theta2=mul9(theta,theta);basis=[one,theta,theta2]
    assert tuple(x-3*y+z for x,y,z in zip(mul9(theta2,theta),theta,one))==(0,)*6
    for b in basis:
        assert tuple(sum(conjugation[i][j]*b[j]for j in range(6))for i in range(6))==b
    # These integral free coordinates have a unimodular basis matrix.
    assert abs(determinant([[b[i]for b in basis]for i in(0,4,5)]))==1
    def trace(v):
        numerator=6*v[0]-3*v[3]
        assert numerator%2==0
        return numerator//2
    gram=[[trace(mul9(a,b))for b in basis]for a in basis]
    assert gram==[[3,0,6],[0,6,-3],[6,-3,18]]
    assert determinant(gram)==81
    inverse_diagonal=[Fraction(11,9),Fraction(2,9),Fraction(2,9)]
    bounds=[isqrt((4*x).numerator//(4*x).denominator)for x in inverse_diagonal]
    small=[]
    for a,b,c in product(*(range(-v,v+1)for v in bounds)):
        q=3*a*a+6*b*b+18*c*c+12*a*c-6*b*c
        completed=3*Fraction(a+2*c)**2+6*(Fraction(b)-Fraction(c,2))**2+Fraction(9,2)*c*c
        assert q==completed
        if q<=4:small.append([a,b,c])
    assert small==[[-1,0,0],[0,0,0],[1,0,0]]
    return dict(fixed_lattice_rank=3,unimodular_free_coordinates=[0,4,5],
                gram=gram,norm_at_most_four=small)


def discriminant_rows():
    out=set();trials=0
    for x in(-1,0,1):
        R=5400-3600*x*x
        for u,v,s in product(range(-isqrt(R//400),isqrt(R//400)+1),
                             range(-isqrt(R//90),isqrt(R//90)+1),
                             range(-2*(isqrt(R//90)//2),2*(isqrt(R//90)//2)+1,2)):
            trials+=1
            A=200*u+45*v+90*s;B=400*u*u+90*v*v+90*s*s
            delta=1200*R-96*A*A-1200*B
            if delta<0:continue
            z=isqrt(delta)
            if z*z!=delta:continue
            for z in {z,-z}:
                numerator=-48*A+z
                if numerator%600:continue
                w=numerator//600;d=-A-12*w
                if 3<=d<=51:out.add((d,s,x,-x,u,v,w))
    assert trials==1185
    return sorted(out),trials


def box_rows():
    out=set();trials=0
    for x in(-1,0,1):
        R=5400-3600*x*x
        for d,u,v,s in product(range(3,52),
                range(-isqrt(R//400),isqrt(R//400)+1),
                range(-isqrt(R//90),isqrt(R//90)+1),
                range(-2*(isqrt(R//90)//2),2*(isqrt(R//90)//2)+1,2)):
            trials+=1
            numerator=-(d+200*u+45*v+90*s)
            if numerator%12:continue
            w=numerator//12
            if 2*d*d+400*u*u+90*v*v+12*w*w+90*s*s==R:
                out.add((d,s,x,-x,u,v,w))
    return sorted(out),trials


def main():
    cubic=audit_cubic_lattice()
    dual_norm=Fraction(1,2)+100+Fraction(45,2)+12+90
    assert dual_norm==225
    assert 1800**2>225*1800
    assert 1350**2>225*2700
    assert 450**2==225*900 and Fraction(450,225*2)==1
    assert 900**2==225*3600 and Fraction(900,225*2)==2
    rows,trials=discriminant_rows();independent,box_trials=box_rows()
    assert rows==independent and len(rows)==13
    weights=(2,90,1800,1800,400,90,12)
    gram=[[sum(w*x*y for w,x,y in zip(weights,a,b))for b in rows]for a in rows]
    assert all(gram[i][i]==5400 for i in range(13))
    for d,s,x,y,u,v,w in rows:
        assert d+900*(x+y)+200*u+45*v+12*w+90*s==0
    edges=[(i+1,j+1)for i,j in combinations(range(13),2)if gram[i][j]==0]
    assert edges==[(4,9),(7,8),(9,12),(10,11)]
    triangles=[(i+1,j+1,k+1)for i,j,k in combinations(range(13),3)
               if gram[i][j]==gram[i][k]==gram[j][k]==0]
    assert triangles==[]
    result=dict(status='PASS_INDEPENDENT_FIXED_PROJECTION_EXCLUSION',
        dimension=5400,rank=16,state=836343,matrix_codegree=60,kind='symplectic',
        assumptions=['nonunit dimensions at least three','specified complete linear field/codegree assignment',
                     'unique symplectic degree-two component','even matrix traces from the proved commutator theorem'],
        required_source_dual_pairs=5,cubic_lattice=cubic,residual_dual_norm=225,
        discriminant_trials=trials,independent_box_trials=box_trials,
        fixed_rows=[dict(index=i+1,d=r[0],s=r[1],x=r[2],y=r[3],u=r[4],v=r[5],w=r[6])for i,r in enumerate(rows)],
        gram_matrix=gram,orthogonality_edges=edges,triangles=triangles,maximum_clique=2,
        imports_row_pool_or_row_kernel=False,
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    out=Path(__file__).parent/'fixed_projection_audit.json'
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k]for k in('status','discriminant_trials','independent_box_trials','orthogonality_edges','maximum_clique')},indent=2))


if __name__=='__main__':main()
