"""Bounded deterministic worker.  Only committed exact results are exported."""
from __future__ import annotations

import argparse
from collections import Counter
import cProfile
import gzip
import importlib.util
import json
from pathlib import Path
import pstats
import signal
import sys
import time
import traceback

from common import atomic_json, digest_object, read_json, stable_id
from compositions import CompositionSearch, reachable_table
from storage import TaskStore

STOP = False


def request_stop(_signum, _frame):
    global STOP
    STOP = True


class ChunkEngine:
    def __init__(self, root, task, state):
        self.task = task
        self.offset = 0 if state is None else state["offset"]
        self.reader = gzip.open(root / task["resource"], "rt", encoding="utf-8")
        for _ in range(self.offset):
            if not self.reader.readline():
                raise ValueError("Checkpoint offset is beyond its authenticated input")

    @property
    def done(self):
        return self.offset == self.task["records"]

    def state(self):
        return {"offset": self.offset}

    def step(self):
        if self.done:
            raise StopIteration
        line = self.reader.readline()
        if not line:
            raise ValueError("Input chunk is shorter than its authenticated scope")
        record = json.loads(line)
        offset = self.offset
        self.offset += 1
        if self.done and self.reader.readline():
            raise ValueError("Input chunk is longer than its authenticated scope")
        return offset, record

    def close(self):
        self.reader.close()


def load_corner(root):
    source = root / "resources" / "corner_gate.py"
    spec = importlib.util.spec_from_file_location("bound_corner_provider", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # The optional extension imports exactly this authenticated base provider.
    sys.modules["corner_gate"] = module
    return module


def load_extension(root, config):
    specification = config["scope"].get("corner_extension")
    if specification is None:
        return None
    path = root / specification["resource"]
    spec = importlib.util.spec_from_file_location("bound_corner_extension", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not callable(getattr(module, "corner_extension", None)):
        raise ValueError("The supplied corner extension must expose corner_extension(record, base_decision=None)")
    return module


def enumerate_task(task, saved):
    return CompositionSearch(task["values"], task["slots"], task["total"],
                             labels=task.get("labels"), prefix=task.get("prefix", []),
                             cap=task.get("cap"), state=saved)


def run_worker(root, plan):
    config = read_json(root / "config.json")
    task_index = {x["id"]: x for x in read_json(root / "tasks.json")}
    deadline = (time.monotonic() + plan["time_limit"]
                if plan["time_limit"] > 0 else float("inf"))
    remaining = plan["node_limit"] if plan["node_limit"] > 0 else None
    began = time.monotonic()
    cpu_began = time.process_time()
    counters, timings = Counter(), Counter()
    corner = None
    extension = None
    error = None
    completed = 0
    stop_reason = None
    for task_id in plan["tasks"]:
        if STOP or time.monotonic() >= deadline or remaining == 0:
            stop_reason = "signal" if STOP else "time_limit" if time.monotonic() >= deadline else "node_limit"
            break
        task = task_index[task_id]
        store = TaskStore(root / "checkpoints" / (task_id + ".sqlite"), digest_object(task))
        checkpoint = store.state()
        if checkpoint and checkpoint["complete"]:
            completed += 1
            store.close()
            continue
        nodes = checkpoint["nodes"] if checkpoint else 0
        state = checkpoint["search_state"] if checkpoint else None
        setup = time.perf_counter()
        engine = ChunkEngine(root, task, state) if task["kind"] == "r36-open" else enumerate_task(task, state)
        timings["engine_setup_seconds"] += time.perf_counter() - setup
        if task["kind"] == "r36-open" and corner is None:
            corner = load_corner(root)
            extension = load_extension(root, config)
        pending = []
        pending_nodes = 0
        old_hist = Counter(checkpoint.get("histogram", {})) if checkpoint else Counter()
        task_hist = old_hist.copy()
        try:
            while not engine.done:
                if STOP or time.monotonic() >= deadline or remaining == 0:
                    stop_reason = "signal" if STOP else "time_limit" if time.monotonic() >= deadline else "node_limit"
                    break
                started = time.perf_counter()
                value = engine.step()
                timings["enumeration_seconds"] += time.perf_counter() - started
                step = nodes
                nodes += 1
                pending_nodes += 1
                counters["nodes"] += 1
                if remaining is not None:
                    remaining -= 1
                if value is not None:
                    started = time.perf_counter()
                    if task["kind"] == "r36-open":
                        offset, source = value
                        decision = corner.corner_gate(source)
                        base_decision = decision
                        extension_decision = None
                        if decision["status"] != "EXCLUDED" and extension is not None:
                            extension_started = time.perf_counter()
                            extension_decision = extension.corner_extension(source, base_decision=base_decision)
                            timings["corner_extension_seconds"] += time.perf_counter() - extension_started
                            counters["extension_inputs"] += 1
                            if extension_decision.get("status") not in ("EXCLUDED", "OPEN", "NOT_APPLICABLE"):
                                raise ValueError("Corner extension returned an unrecognized status")
                            counters["extension_status:" + extension_decision["status"]] += 1
                            if (extension_decision["status"] == "EXCLUDED" or
                                    base_decision["status"] == "NOT_APPLICABLE" and extension_decision["status"] == "OPEN"):
                                decision = extension_decision
                        status = decision["status"]
                        if status not in ("EXCLUDED", "OPEN", "NOT_APPLICABLE"):
                            raise ValueError("Corner provider returned an unrecognized status")
                        record = {"id": "r36:state:" + str(source["state"]),
                                  "state": source["state"], "open_index": source["open_index"],
                                  "status": status, "gate": "unramified_pair_resource_corner_and_division",
                                  "input_ref": {"resource": task["resource"], "line": offset},
                                  "source_record_sha256": source["source_record_sha256"]}
                        if extension_decision is not None:
                            record["base_gate_status"] = base_decision["status"]
                            record["extension_status"] = extension_decision["status"]
                            if extension_decision["status"] == "EXCLUDED":
                                record["gate"] = extension_decision.get("gate", "exact_corner_extension")
                        if status == "EXCLUDED":
                            record["certificate"] = decision
                        else:
                            record["eligible_primes"] = decision.get("eligible_primes", [])
                        counters["eligible_prime_checks"] += len(base_decision.get("eligible_primes", []))
                        for name, count in base_decision.get("counters", {}).items():
                            if type(count) is int:
                                counters["corner:" + name] += count
                        for name, count in (extension_decision or {}).get("counters", {}).items():
                            if type(count) is int:
                                counters["extension:" + name] += count
                    elif task["kind"] == "rational-canonical":
                        from arithmetic import screen_placement
                        data = {"rank": config["scope"]["rank"], "matrix_canonical_degree": task["matrix_degree"],
                                "nonunit_linear_canonical_degrees": list(value)}
                        record = {"id": stable_id("rational-one-m2", data), "input": data,
                                  **screen_placement(task["matrix_degree"], value)}
                    else:
                        data = {"dimension": config["scope"]["dimension"], "rank": config["scope"]["rank"],
                                "dimensions": [1, *value]}
                        record = {"id": stable_id("source-dimension-type", data), "input": data,
                                  "status": "OPEN", "gate": "exact_dimension_equation",
                                  "scope": "Dimension-equation type only; no character table or multiplication is supplied."}
                    timings["exact_gate_seconds"] += time.perf_counter() - started
                    pending.append((step, record))
                    task_hist[record["status"]] += 1
                    counters["candidate_records"] += 1
                    counters["status:" + record["status"]] += 1
                if pending_nodes >= plan["checkpoint_every"]:
                    started = time.perf_counter()
                    store.commit({"nodes": nodes, "search_state": engine.state(),
                                  "complete": engine.done, "histogram": dict(task_hist)}, pending)
                    timings["checkpoint_seconds"] += time.perf_counter() - started
                    pending, pending_nodes = [], 0
            started = time.perf_counter()
            store.commit({"nodes": nodes, "search_state": engine.state(),
                          "complete": engine.done, "histogram": dict(task_hist)}, pending)
            timings["checkpoint_seconds"] += time.perf_counter() - started
            if engine.done:
                completed += 1
        except BaseException as exc:
            # The current uncommitted batch is intentionally discarded.
            error = {"task": task_id, "type": type(exc).__name__, "message": str(exc),
                     "traceback": traceback.format_exc(), "uncommitted_nodes": pending_nodes}
            break
        finally:
            if hasattr(engine, "close"):
                engine.close()
            store.close()
        if stop_reason:
            break
    cache = reachable_table.cache_info()._asdict()
    return {"status": "FAILED" if error else "BUDGET_STOP" if stop_reason else "COMPLETE",
            "stop_reason": stop_reason, "error": error, "worker": plan["worker"],
            "assigned_tasks": len(plan["tasks"]), "completed_tasks": completed,
            "counters": dict(counters), "stage_seconds": dict(timings),
            "wall_seconds": time.monotonic() - began,
            "cpu_seconds": time.process_time() - cpu_began,
            "reachable_bitset_cache": cache,
            "budget_semantics": "One node is one input record or one popped sum-enumeration DFS node."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_directory", type=Path)
    parser.add_argument("plan", type=Path)
    args = parser.parse_args()
    root = args.run_directory.resolve()
    plan = read_json(args.plan)
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, request_stop)
    profiler = cProfile.Profile() if plan.get("profile") else None
    if profiler:
        profiler.enable()
    try:
        report = run_worker(root, plan)
    except BaseException as exc:
        report = {"status": "FAILED", "worker": plan["worker"],
                  "error": {"type": type(exc).__name__, "message": str(exc),
                            "traceback": traceback.format_exc()}}
    if profiler:
        profiler.disable()
        profile_path = root / plan["report"]
        profiler.dump_stats(str(profile_path.with_suffix(".pstats")))
        with profile_path.with_suffix(".profile.txt").open("w") as out:
            pstats.Stats(profiler, stream=out).strip_dirs().sort_stats("cumulative").print_stats(30)
    atomic_json(root / plan["report"], report)
    print(json.dumps({k: v for k, v in report.items() if k != "error"}, sort_keys=True), flush=True)
    if report["status"] == "FAILED":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
