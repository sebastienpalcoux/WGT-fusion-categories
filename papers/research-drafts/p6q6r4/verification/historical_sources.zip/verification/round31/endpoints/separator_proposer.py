"""Numerical proposer; every returned exclusion is checked in exact integers.

This optional producer requires NumPy/SciPy. The certificate verifier does not.
"""
from fractions import Fraction
from functools import reduce
from math import gcd,lcm
import numpy as np
from scipy.optimize import linprog

def certificate(vectors, target, slots):
    # Include the slot-count equality as the first coordinate.
    rows = [(1,) + v for v,g in vectors]
    goal = (slots,) + target
    if not rows:
        return {'kind':'empty'}
    mat = np.array(rows,dtype=float)
    scales = np.maximum(np.max(np.abs(mat),axis=0),np.abs(goal))
    scales = np.maximum(scales,1)
    # A bounded separation problem; a negative objective gives a Farkas ray.
    result = linprog(np.array(goal,dtype=float)/scales,
                     A_ub=-mat/scales,b_ub=np.zeros(len(rows)),
                     bounds=[(-1,1)]*len(goal),method='highs')
    if not result.success or result.fun >= -1e-8:
        return None
    for denominator in [100,10000,1000000,1000000000]:
        y = [Fraction(float(v/s)).limit_denominator(denominator)
             for v,s in zip(result.x,scales)]
        # Repair rounding by adding a constant to all row evaluations.
        low = min(sum(a*b for a,b in zip(y,row)) for row in rows)
        if low<0:y[0]-=low
        value = sum(a*b for a,b in zip(y,goal))
        if value < 0:
            common = lcm(*(q.denominator for q in y))
            z = [int(q*common) for q in y]
            divisor = reduce(gcd,(abs(v) for v in z))
            z = [v//divisor for v in z]
            evaluations = [sum(a*b for a,b in zip(z,row)) for row in rows]
            target_value = sum(a*b for a,b in zip(z,goal))
            assert min(evaluations)>=0 and target_value<0
            return {'kind':'integer_separator','coefficients':z,
                    'minimum_row_value':min(evaluations),
                    'target_value':target_value}
    return None

