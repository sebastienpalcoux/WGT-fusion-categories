"""Portable exact numerical input for the two dimension5400 endpoints."""
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DIM=5400
DEGREES=tuple(a for a in range(10,901) if DIM%a==0
              and sum(a%p==0 for p in (2,3,5))>=2)

def degree_profiles(left=10,total=DIM-1,last=None):
    if last is None:last=len(DEGREES)-1
    if left==0:
        if total==0:yield ()
        return
    for j in range(last,-1,-1):
        a=DEGREES[j]
        if left*a<total:break
        if a+(left-1)*DEGREES[0]<=total:
            for rest in degree_profiles(left-1,total-a,j):
                yield (a,)+rest
