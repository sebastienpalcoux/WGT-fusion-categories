"""Exact endpoint filter from order discriminants and linear f6 fields.

States record projected invariants, not full field assignments or fusion rings.
For rank13 the unique degree-two simple algebra is rational central; its
absolute regular-trace discriminant is a square, whether split or quaternion.
"""
from collections import Counter
from functools import lru_cache
from itertools import combinations
from math import gcd
from pathlib import Path
import json
from orbit_pairs import quadratic_discriminants,phi

def squareclass(n):
    out=1;p=2
    while p*p<=n:
        odd=0
        while n%p==0:n//=p;odd^=1
        if odd:out*=p
        p+=1
    return out*n

def multiply(a,b):
    return a*b//gcd(a,b)**2

def kronecker(delta,a):
    ans=1
    while a%2==0:
        a//=2
        if delta%8 in (3,5):ans=-ans
    delta%=a
    while delta:
        while delta%2==0:
            delta//=2
            if a%8 in (3,5):ans=-ans
        delta,a=a,delta
        if delta%4==a%4==3:ans=-ans
        delta%=a
    assert a==1
    return ans

@lru_cache(None)
def field_types(f,k):
    """Triples (degree, absolute-discriminant squareclass, complex-pair count)."""
    if f==6:return ((1,1,0),(2,3,1))
    c=gcd(2*f,f*f);n=phi(c)
    if k>=4:
        assert c in (9,12,16,20,24),(f,k,c)
        units=[a for a in range(c) if gcd(a,c)==1]
        types=set()
        for size in range(1,len(units)+1):
            if n%size or n//size>k:continue
            for tail in combinations([a for a in units if a!=1],size-1):
                h={1,*tail}
                if any(a*b%c not in h for a in h for b in h):continue
                e=n//size
                quads=[d for d in quadratic_discriminants(c)
                       if all(kronecker(d,a)==1 for a in h)]
                # The regular permutation discriminant is nonsquare exactly
                # when the quotient's2-Sylow is nontrivial cyclic; equivalently
                # it has exactly one quadratic subfield.
                disc=squareclass(abs(quads[0])) if len(quads)==1 else 1
                complex_pairs=0 if c-1 in h else e//2
                types.add((e,disc,complex_pairs))
        return tuple(sorted(types))
    # A degree10 central simple cannot be Galois fixed: D does not divide19!.
    types=set() if f==540 else {(1,1,0)}
    if k>=2:
        types.update((2,squareclass(abs(d)),0 if d>0 else 1)
                     for d in quadratic_discriminants(c))
    if k>=3 and c%9==0:
        assert c%27!=0,(f,k,c)
        types.add((3,1,0))
    return tuple(sorted(types))

@lru_cache(None)
def block_states(f,k):
    states=[set() for _ in range(k+1)];states[0].add((1,0,0))
    for used in range(k):
        for disc,q6,r2 in states[used]:
            for e,s,t in field_types(f,k):
                if used+e<=k:
                    states[used+e].add((multiply(disc,s),q6+(f==6 and e==2),r2+t))
    return frozenset(states[k])

def profile_states(profile):
    states={(1,0,0)};target=squareclass(5400)
    for a,k in Counter(profile).items():
        f=5400//a
        if k%2:target=multiply(target,squareclass(f))
        states={(multiply(disc,s),q6+u,r2+v)
                for disc,q6,r2 in states for s,u,v in block_states(f,k)}
    compatible=sorted((disc,q6,r2) for disc,q6,r2 in states
                      if disc==target and r2>=2*q6 and q6<=1 and r2<=4)
    return target,compatible

def placement_states(profile,double_degree):
    counts=Counter(profile)
    assert counts[double_degree]>=2
    target=squareclass(5400)
    for a,k in counts.items():
        if k%2:target=multiply(target,squareclass(5400//a))
    # The unique dimension-two character is rational. Its canonical central
    # simple therefore cannot have degree10, by the global factorial lemma.
    if double_degree==10:return target,[]
    counts[double_degree]-=2
    states={(1,0,0)}
    for a,k in counts.items():
        if not k:continue
        f=5400//a
        states={(multiply(disc,s),q6+u,q+v)
                for disc,q6,q in states for s,u,v in block_states(f,k)}
    compatible=[]
    f_double=5400//double_degree
    for disc,q6,q in sorted(states):
        if disc!=target:continue
        kinds=[]
        if q+1>=2*q6 and not (q==q6==1 and f_double%2):
            kinds.append('orthogonal')
        # Even total dimension and odd rank require at least three selfdual
        # labels, so the symplectic dual-pair count q+3 is at most five.
        symplectic=q+3>=2*q6 and q<=2
        if q==q6:
            permitted=(8,72) if q==1 else (36,100)
            symplectic=symplectic and f_double in permitted
        if symplectic:
            kinds.append('symplectic')
        if kinds:compatible.append((disc,q6,q,kinds))
    return target,compatible

def main():
    from endpoint_core import degree_profiles,ROOT
    profiles=list(degree_profiles())
    records=[];noncomm=[]
    for i,p in enumerate(profiles):
        target,states=profile_states(p)
        records.append({'index':i,'profile':p,'discriminant_squareclass':target,
                        'compatible_field_states':states,'excluded':not states})
        for a,k in Counter(p).items():
            if k<2:continue
            target,states=placement_states(p,a)
            noncomm.append({'index':i,'profile':p,'double_degree':a,
                            'discriminant_squareclass':target,
                            'compatible_field_states':states,'excluded':not states})
    (ROOT/'commutative_discriminant_filter.json').write_text(json.dumps(records,indent=2)+'\n')
    (ROOT/'noncommutative_discriminant_filter.json').write_text(json.dumps(noncomm,indent=2)+'\n')
    print('profiles',len(records),'excluded',sum(r['excluded'] for r in records),
          'not_excluded',sum(not r['excluded'] for r in records))
    print('first survivors',[r['index'] for r in records if not r['excluded']][:30])
    for i in range(10):print(i,records[i]['discriminant_squareclass'],records[i]['compatible_field_states'])
    print('noncommutative placements',len(noncomm),'excluded',sum(r['excluded'] for r in noncomm),
          'not_excluded',sum(not r['excluded'] for r in noncomm))
    print('first noncommutative survivors',[(r['index'],r['double_degree']) for r in noncomm
                                          if not r['excluded']][:30])

if __name__=='__main__':main()
