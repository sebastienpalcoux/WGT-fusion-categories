"""Exact endpoint rows with primitive norm bounds and forced rational columns."""
from collections import Counter
from math import gcd,isqrt
from itertools import combinations
from orbit_pairs import allowed_pairs,phi

DIM=5400

def odd_orbit_possible(f,count):
    n=phi(gcd(2*f,f*f))
    return any(n%e==0 for e in range(3,count+1,2))

def refine(profile,double_degree=None):
    pieces=[]
    for a,count in Counter(profile).items():
        if a==double_degree:
            assert count>=2
            pieces.append((a,2,True));count-=2
        if count and count%2 and not odd_orbit_possible(DIM//a,count):
            # Every nontrivial orbit has even size, so an odd set has a
            # rational character. Remove one; the remainder remains stable.
            pieces.append((a,1,False));count-=1
        if count:pieces.append((a,count,False))
    pieces.sort(key=lambda x:(x[1]>1,-x[0],x[2]))
    blocks=[(a,k) for a,k,d in pieces]
    double=next((i for i,x in enumerate(pieces) if x[2]),None)
    assert sum(k for a,k in blocks)==10
    return blocks,double

def rows_for(blocks,double):
    def options(d,index):
        a,k=blocks[index];f=DIM//a
        cap=min((DIM-d*d)//a,k*d*d-1,f-1)
        if index==double:
            assert k==2
            return [(s,t) for t in range(cap+1)
                    for s in range(-min(2*d-1,isqrt(2*t)),min(2*d-1,isqrt(2*t))+1)]
        return [(s,t) for s,t in allowed_pairs(f,k,d)
                if t<=cap and abs(s)<k*d]

    for d in range(3,73):
        choices=[sorted(options(d,i),key=lambda x:(x[1],x[0])) for i in range(len(blocks))]
        if any(not opt for opt in choices):continue
        order=sorted(range(len(blocks)),key=lambda i:len(choices[i]))
        lookup=[set(opt) for opt in choices]
        selected=[None]*len(blocks)
        suffix_s=[0]*(len(blocks)+1);suffix_t=[0]*(len(blocks)+1)
        suffix_mass=[0]*(len(blocks)+1);suffix_factor=[1]*(len(blocks)+1)
        suffix_gcd=[[0]*4 for _ in range(len(blocks)+1)]
        for h in reversed(range(len(blocks))):
            i=order[h];a,k=blocks[i]
            suffix_s[h]=suffix_s[h+1]+a*max(abs(s) for s,t in choices[i])
            suffix_t[h]=suffix_t[h+1]+a*max(t for s,t in choices[i])
            suffix_mass[h]=suffix_mass[h+1]+a*k
            suffix_factor[h]=max(suffix_factor[h+1],2 if i==double else 1)
            gg=suffix_gcd[h+1].copy()
            for s,t in choices[i]:
                for j,v in enumerate((a*s,a*t,a*(t-s),a*(t+s))):gg[j]=gcd(gg[j],v)
            suffix_gcd[h]=gg
        def rec(h,linear,square):
            if square<0 or square>suffix_t[h] or abs(linear)>suffix_s[h]:return
            if abs(linear)>suffix_factor[h]*square:return
            if linear*linear>suffix_mass[h]*square:return
            for value,g in zip((linear,square,square-linear,square+linear),suffix_gcd[h]):
                if (g and value%g) or (not g and value):return
            i=order[h];a,k=blocks[i]
            if h==len(blocks)-1:
                if linear%a or square%a:return
                pair=(linear//a,square//a)
                if pair in lookup[i]:
                    selected[i]=pair
                    yield d,tuple(selected)
                return
            for s,t in choices[i]:
                if a*t>square:break
                selected[i]=(s,t)
                yield from rec(h+1,linear-a*s,square-a*t)
        yield from rec(0,-d,DIM-d*d)

def selfdual_possible(blocks,values,double,d):
    for i,((a,k),(s,t)) in enumerate(zip(blocks,values)):
        if i==double:
            # A self-adjoint2x2 matrix has real algebraic-integer eigenvalues.
            if (s*s-t)%2:return False
            if t>=2*d*d-2*d*abs(s)+s*s:return False
        elif (s,t) not in allowed_pairs(DIM//a,k,d,True):return False
    return True

def moment_target(blocks,double):
    target=[DIM-1]
    for i,(a,k) in enumerate(blocks):
        f=DIM//a
        target.extend(((k+2*(i==double))*f-k,-k,k*f-k*k))
    pairs=list(combinations(range(len(blocks)),2))
    target.extend(-blocks[i][1]*blocks[j][1] for i,j in pairs)
    return tuple(target)

def row_moment_vector(d,values):
    v=[d*d]
    for s,t in values:v.extend((t,d*s,s*s))
    v.extend(values[i][0]*values[j][0] for i,j in combinations(range(len(values)),2))
    return tuple(v)

def moment_data(blocks,rows,double):
    target=moment_target(blocks,double)
    vectors=set()
    for d,values in rows:
        v=row_moment_vector(d,values)
        group=1 if selfdual_possible(blocks,values,double,d) else 2
        vectors.add((v,group))
    return target,sorted(vectors)

if __name__=='__main__':
    from endpoint_core import degree_profiles
    import time
    for j,p in enumerate(degree_profiles()):
        if j>=4:break
        for doubled in [None]+[a for a,k in Counter(p).items() if k>=2]:
            b,i=refine(p,doubled);start=time.monotonic();r=list(rows_for(b,i))
            print(j,'double',doubled,'blocks',b,'rows',len(r),
                  'seconds',round(time.monotonic()-start,3),flush=True)
