"""Exact necessary (trace, squared-norm trace) pairs for small character blocks.

A block consists of k linear characters with common formal codegree f.
Character fields lie in Q(zeta_gcd(2*f,f*f)).  Galois orbits of the characters
are allowed independently at each basis element; this is a relaxation.
All lattice enumeration and orbit computations below use integers/Fractions.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import gcd, isqrt

POLY = {
 9:[1,0,0,1,0,0,1],
 12:[1,0,-1,0,1],
 16:[1,0,0,0,0,0,0,0,1],
 20:[1,0,-1,0,1,0,-1,0,1],
 24:[1,0,0,0,-1,0,0,0,1],
}

def phi(n):
    return sum(gcd(i,n)==1 for i in range(1,n+1))

def mu(n):
    answer=1;p=2
    while p*p<=n:
        if n%p==0:
            n//=p;answer=-answer
            if n%p==0:return 0
            while n%p==0:n//=p
        p+=1
    return -answer if n>1 else answer

def ramanujan(n,k):
    q=n//gcd(n,k)
    return mu(q)*(phi(n)//phi(q))

def exact_ldl(g):
    n=len(g);u=[[F(i==j) for j in range(n)] for i in range(n)];d=[]
    for i in range(n):
        d.append(F(g[i][i])-sum(d[k]*u[k][i]**2 for k in range(i)))
        assert d[i]>0
        for j in range(i+1,n):
            u[i][j]=(F(g[i][j])-sum(d[k]*u[k][i]*u[k][j] for k in range(i)))/d[i]
    return u,d

def lattice_vectors(g,bound):
    u,d=exact_ldl(g);n=len(g);x=[0]*n
    def rec(i,remaining):
        if i<0:
            q=sum(x[a]*g[a][b]*x[b] for a in range(n) for b in range(n))
            assert 0<=q<=bound
            yield tuple(x),q
            return
        center=-sum(u[i][j]*x[j] for j in range(i+1,n))
        floor=center.numerator//center.denominator
        r=remaining/d[i]
        radius=isqrt(r.numerator//r.denominator)+1
        for a in range(floor-radius-1,floor+radius+2):
            cost=d[i]*(F(a)-center)**2
            if cost<=remaining:
                x[i]=a
                yield from rec(i-1,remaining-cost)
    yield from rec(n-1,F(bound))

def powers(modulus):
    poly=POLY[modulus];n=len(poly)-1
    out=[];v=[1]+[0]*(n-1)
    for _ in range(modulus):
        out.append(tuple(v))
        carry=v[-1];v=[0]+v[:-1]
        for j in range(n):v[j]-=carry*poly[j]
    assert v==[1]+[0]*(n-1)
    return out

@lru_cache(None)
def full_orbits(modulus,cap,max_size,real_only=False):
    """Return necessary orbit triples (e,s,t), retaining every allowed alpha.

    We enumerate a superset: Tr_full(|alpha|^2)<=phi(modulus)*cap.
    If alpha is the value of any orbit of size e and t<=cap, this holds.
    An entry field of degree m can lie in an orbit field of degree e only
    when m|e|phi(modulus). Allowing all such e only enlarges the set.
    """
    n=len(POLY[modulus])-1
    gram=[[ramanujan(modulus,i-j) for j in range(n)] for i in range(n)]
    pp=powers(modulus)
    autos=[tuple(pp[(a*j)%modulus] for j in range(n))
           for a in range(1,modulus) if gcd(a,modulus)==1]
    traces=[ramanujan(modulus,j) for j in range(n)]
    answer=set()
    for x,q in lattice_vectors(gram,n*cap):
        if real_only:
            conjugate=tuple(sum(x[j]*autos[-1][j][i] for j in range(n)) for i in range(n))
            if conjugate!=x:continue
        images={tuple(sum(x[j]*auto[j][i] for j in range(n)) for i in range(n))
                for auto in autos}
        m=len(images)
        if m>max_size:continue
        trace=sum(a*b for a,b in zip(x,traces))
        for e in range(m,max_size+1,m):
            if n%e==0 and e*q<=n*cap:
                assert (e*q)%n==0 and (e*trace)%n==0
                answer.add((e,e*trace//n,e*q//n))
    return frozenset(answer)

def quadratic_discriminants(conductor):
    answer=[]
    for m in [-30,-15,-10,-6,-5,-3,-2,-1,2,3,5,6,10,15,30]:
        delta=m if m%4==1 else 4*m
        if conductor%abs(delta)==0:answer.append(delta)
    return answer

@lru_cache(None)
def orbit_triples(f,max_size,d=0,real_only=False):
    cap=f-1;conductor=gcd(2*f,f*f)
    limit=min(isqrt(cap),d-1) if d else isqrt(cap)
    answer={(1,a,a*a) for a in range(-limit,limit+1)}
    if max_size>=2:
        for delta in quadratic_discriminants(conductor):
            if real_only and delta<0:continue
            for b in range(isqrt(2*cap//abs(delta))+1):
                for s in range(-isqrt(2*cap),isqrt(2*cap)+1):
                    if delta%4==1:
                        if (s-b)%2:continue
                    elif s%2:continue
                    numerator=s*s+abs(delta)*b*b
                    if numerator%2==0 and numerator//2<=cap:
                        if d:
                            if delta>0:
                                if 2*d<=abs(s) or delta*b*b>=(2*d-abs(s))**2:continue
                            elif numerator>=4*d*d:continue
                        answer.add((2,s,numerator//2))
    if max_size>=3 and conductor%9==0:
        # In every repeated block of size>=3 used at these endpoints,
        # the only possible cubic field is the real cubic of conductor9.
        for e,s,t in full_orbits(9,cap,3,real_only):
            if e==3 and (not d or t<e*d*d):answer.add((e,s,t))
    if max_size>=4:
        assert conductor in POLY,(f,max_size,conductor)
        answer.update((e,s,t) for e,s,t in full_orbits(conductor,cap,max_size,real_only)
                      if e>=4 and (not d or t<e*d*d))
    return frozenset(answer)

@lru_cache(None)
def allowed_pairs(f,k,d=0,real_only=False):
    triples=orbit_triples(f,k,d,real_only)
    dp=[set() for _ in range(k+1)];dp[0].add((0,0))
    for used in range(k):
        for s,t in dp[used]:
            for e,u,v in triples:
                if used+e<=k and t+v<f:dp[used+e].add((s+u,t+v))
    return frozenset(dp[k])

def row_allowed(blocks,values,double=None):
    for i,((a,k),(s,t)) in enumerate(zip(blocks,values)):
        if i==double:
            # Contains one two-dimensional representation, so the linear
            # character orbit test does not apply to the whole block.
            if abs(s)>2*t:return False
        elif (s,t) not in allowed_pairs(5400//a,k):return False
    return True

if __name__=='__main__':
    import time
    for f,k in [(6,5),(8,7),(9,6),(10,5),(12,4),(15,3),(18,3),(24,3),(50,3)]:
        start=time.monotonic();p=allowed_pairs(f,k)
        print('f',f,'k',k,'pairs',len(p),'seconds',round(time.monotonic()-start,3),flush=True)
