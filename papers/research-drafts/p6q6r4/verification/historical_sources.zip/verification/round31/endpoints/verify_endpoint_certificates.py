"""Verify every claimed endpoint exclusion using Python's standard library.

Run: python3 verify_endpoint_certificates.py
No numerical solver is imported. A certificate is checked against the entire
exactly enumerated necessary row set, with integer dot products. Missing
certificates are expressly unresolved, not assertions of integer feasibility.
Optional --start/--stop split the independent verification by profile index.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import argparse,json,time
from endpoint_core import ROOT,degree_profiles
from refined_rows import refine,rows_for,moment_target,row_moment_vector
from field_discriminant_profiles import profile_states,placement_states

def input_hashes():
    names=['endpoint_core.py','orbit_pairs.py','refined_rows.py',
           'field_discriminant_profiles.py','endpoint_certificates.json',
           'verify_endpoint_certificates.py']
    return {name:sha256((ROOT/name).read_bytes()).hexdigest() for name in names}

def load_cases():
    profiles=list(degree_profiles())
    assert len(profiles)==497
    expected={(i,d) for i,p in enumerate(profiles)
              for d in [None]+[a for a,k in Counter(p).items() if k>=2]}
    assert len(expected)==1327
    records=json.loads((ROOT/'endpoint_certificates.json').read_text())
    cases={(r['index'],r['double_degree']):r for r in records}
    assert len(cases)==len(records)==len(expected)
    assert set(cases)==expected
    for (i,d),r in cases.items():
        assert r['profile']==list(profiles[i])
        blocks,double=refine(profiles[i],d)
        assert r['blocks']==[list(b) for b in blocks]
        assert r['double']==double and r['rank']==(11 if d is None else 13)
    return profiles,cases

def exact_field_records(profiles):
    result={}
    for i,p in enumerate(profiles):
        target,states=profile_states(p)
        result[i,None]={'target':target,'states':states,'excluded':not states}
        for a,k in Counter(p).items():
            if k<2:continue
            target,states=placement_states(p,a)
            result[i,a]={'target':target,'states':states,'excluded':not states}
    return result

def combined_summary(cases,fields):
    answer={}
    for rank in (11,13):
        keys=[key for key,r in cases.items() if r['rank']==rank]
        sep={key for key in keys if cases[key]['certificate'] is not None}
        fld={key for key in keys if fields[key]['excluded']}
        unresolved=sorted(set(keys)-sep-fld,key=lambda x:(x[0],-(x[1] or 0)))
        answer[str(rank)]={
            'case_count':len(keys),'separator_exclusions':len(sep),
            'field_exclusions':len(fld),'intersection':len(sep&fld),
            'combined_exclusions':len(sep|fld),
            'unresolved_count':len(unresolved),'unresolved_cases':unresolved,
        }
    return answer

def verify_record(record):
    cert=record['certificate']
    assert cert is not None
    blocks,double=refine(tuple(record['profile']),record['double_degree'])
    goal=(record['rank']-1,)+moment_target(blocks,double)
    if cert['kind']=='integer_separator':
        y=cert['coefficients']
        assert len(y)==len(goal) and all(type(z) is int for z in y)
        target_value=sum(a*b for a,b in zip(y,goal))
        assert target_value==cert['target_value'] and target_value<0
    else:
        assert cert['kind']=='empty'
        y=None
    minimum=None;count=0
    for d,values in rows_for(blocks,double):
        count+=1
        assert y is not None,('nonempty row set',record['index'],record['double_degree'])
        row=(1,)+row_moment_vector(d,values)
        value=sum(a*b for a,b in zip(y,row))
        assert value>=0,(record['index'],record['double_degree'],d,values,value)
        minimum=value if minimum is None else min(minimum,value)
    assert count==record['rows']
    if y is not None:
        assert count>0 and minimum==cert['minimum_row_value']
    return count

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--stop',type=int,default=497)
    ap.add_argument('--output',default='endpoint_verification.json')
    args=ap.parse_args()
    profiles,cases=load_cases()
    fields=exact_field_records(profiles)
    summary=combined_summary(cases,fields)
    start=time.monotonic();verified=[];row_total=0
    selected=sorted((key for key,r in cases.items()
                     if args.start<=key[0]<args.stop and r['certificate'] is not None),
                    key=lambda x:(x[0],-(x[1] or 0)))
    for key in selected:
        count=verify_record(cases[key]);row_total+=count;verified.append(key)
        print('VERIFIED',key,'rows',count,flush=True)
    result={'status':'PASS','profile_range':[args.start,args.stop],
            'profiles':497,'placements':830,'input_sha256':input_hashes(),
            'verified_certificate_count':len(verified),
            'verified_cases':verified,'rows_checked':row_total,
            'field_and_certificate_summary':summary,
            'elapsed_seconds':time.monotonic()-start,
            'scope':'Exclusions only. Unresolved cases are not integer witnesses or fusion rings.'}
    (ROOT/args.output).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in
                     ('verified_cases','input_sha256','field_and_certificate_summary')},indent=2))
    print(json.dumps({rank:{k:v for k,v in data.items() if k!='unresolved_cases'}
                      for rank,data in summary.items()},indent=2))

if __name__=='__main__':main()
