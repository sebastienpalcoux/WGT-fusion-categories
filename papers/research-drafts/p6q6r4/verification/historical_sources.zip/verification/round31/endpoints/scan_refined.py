"""Endpoint scan with exact character rows and certified rational separators."""
from endpoint_core import degree_profiles,ROOT
from separator_proposer import certificate
from refined_rows import refine,rows_for,moment_data
from collections import Counter
import argparse,json,time

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--stop',type=int,default=497)
    ap.add_argument('--output',default='refined_separators.jsonl')
    args=ap.parse_args()
    profiles=list(degree_profiles())
    out=(ROOT/args.output).open('a')
    for index,p in enumerate(profiles):
        if not args.start<=index<args.stop:continue
        for doubled in [None]+[a for a,k in Counter(p).items() if k>=2]:
            start=time.monotonic();blocks,double=refine(p,doubled)
            rows=list(rows_for(blocks,double))
            target,vectors=moment_data(blocks,rows,double)
            slots=10 if doubled is None else 12
            cert=certificate(vectors,target,slots)
            record={'index':index,'profile':p,'blocks':blocks,'rank':slots+1,
                    'double_degree':doubled,'double':double,'rows':len(rows),
                    'vectors':len(vectors),'certificate':cert,
                    'seconds':time.monotonic()-start}
            out.write(json.dumps(record,separators=(',',':'))+'\n');out.flush()
            print(index,'rank',slots+1,'double',doubled,'rows',len(rows),
                  'CERTIFIED' if cert else 'UNRESOLVED',
                  round(record['seconds'],3),flush=True)
    out.close()
if __name__=='__main__':main()
