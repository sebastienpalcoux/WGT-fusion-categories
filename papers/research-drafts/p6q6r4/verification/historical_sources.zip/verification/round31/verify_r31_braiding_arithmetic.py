#!/usr/bin/env python3
"""Exact auxiliary checks for the Round 31 canonical-braiding fragments.

This verifies finite arithmetic only. It does not prove the conductor
reduction, the canonical algebra assertions, or categorifiability.
Uses the integral basis 1,w of Q(w), w^2+w+1=0; no floating point.
"""
from itertools import combinations_with_replacement, product
from math import gcd, ceil, factorial
from functools import reduce
import json
from pathlib import Path


def add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def mul(a, b):
    return (a[0]*b[0] - a[1]*b[1],
            a[0]*b[1] + a[1]*b[0] - a[1]*b[1])


def scale(n, a):
    return (n*a[0], n*a[1])


def conj(a):
    return (a[0]-a[1], -a[1])


roots = ((1, 0), (-1, 0), (0, 1), (-1, -1), (1, 1), (0, -1))
names = ("1", "-1", "w", "wbar", "z6", "z6bar")
palette = (10, 12, 15, 18, 20, 24, 30, 36, 40, 45, 50, 54)


def canon(ds, qs):
    return tuple(sorted(zip(ds, qs)))


solutions = {(t, v): set() for t in (1, -1) for v in range(6)}
for ds in combinations_with_replacement(palette, 4):
    if sum(ds) != 100:
        continue
    for qs in product(range(6), repeat=4):
        first = (0, 0)
        second = (0, 0)
        prodq = (1, 0)
        for d, q in zip(ds, qs):
            first = add(first, scale(d, roots[q]))
            second = add(second, scale(d, mul(roots[q], roots[q])))
            prodq = mul(prodq, roots[q])
        if first != (10, 0):
            continue
        for t in (1, -1):
            a = 7 if t == 1 else -2
            for v in range(6):
                if t == 1 and v == 0:
                    continue  # strictness equality
                vb = conj(roots[v])
                if second != add((10*a, 0), scale(30, vb)):
                    continue
                if mul(prodq, prodq) != mul(vb, vb):
                    continue
                solutions[t, v].add(canon(ds, qs))

expected = {(t, v): set() for t in (1, -1) for v in range(6)}
expected[1, 1].add(canon((45, 15, 20, 20), (0, 1, 2, 3)))
for v in (2, 3):
    for u in range(6):
        if mul(roots[u], roots[u]) == conj(roots[v]):
            negu = roots.index(scale(-1, roots[u]))
            expected[1, v].add(canon((40, 30, 15, 15), (0, 1, u, negu)))
expected[-1, 0].add(canon((10, 30, 30, 30), (0, 0, 2, 3)))
expected[-1, 0].add(canon((10, 30, 30, 30), (0, 1, 4, 5)))
expected[-1, 0].add(canon((20, 20, 30, 30), (0, 0, 2, 3)))
expected[-1, 1].add(canon((20, 20, 30, 30), (2, 3, 4, 5)))
assert solutions == expected, (solutions, expected)


def partitions(n, lo=1):
    if n == 0:
        yield ()
    for j in range(lo, n+1):
        for rest in partitions(n-j, j):
            yield (j,) + rest


def duality_values(weights):
    """Partial involutions: fixed=selfdual, paired=duals, absent=outside."""
    if not weights:
        return {0}
    first, *tail = weights
    out = set(duality_values(tuple(tail)))  # dual lies outside P
    out |= {first*first + t for t in duality_values(tuple(tail))}
    for j, w in enumerate(tail):
        rest = tuple(tail[:j] + tail[j+1:])
        out |= {2*first*w + t for t in duality_values(rest)}
    return out


gram = {}
raw_gram = {}
for m in (1, 2, 3, 4):
    rem = 10-m
    raw = set()
    kept = set()
    # A partition lists the simple dimensions with repeated occurrences.
    for dim_parts in partitions(rem, 3):
        by_dim = {d: dim_parts.count(d) for d in set(dim_parts)}
        degree_keys = sorted(by_dim)
        # Partition occurrences of a fixed degree among distinct labels.
        choices = [list(partitions(by_dim[d])) for d in degree_keys]
        for blocks in product(*choices):
            weights = tuple(w for block in blocks for w in block)
            q = sum(w*w for w in weights)
            t_values = {0}
            for block in blocks:
                t_values = {a+b for a in t_values for b in duality_values(block)}
            raw |= {(q, t) for t in t_values}
            content = reduce(gcd, weights)
            if (7-m) % content == 0:
                kept |= {(q, t) for t in t_values}
    raw_gram[m] = sorted(raw)
    gram[m] = sorted(kept)

base = {(1, 0), (1, 1), (2, 0), (2, 1), (2, 2)}
expected_gram = {
    1: base | {(3, t) for t in range(4)}
            | {(5, t) for t in (0, 1, 4, 5)} | {(9, 0), (9, 9)},
    2: base,
    3: base,
    4: base,
}
assert {m: set(v) for m, v in gram.items()} == expected_gram

costs = {}
for m in (2, 3, 4):
    a = m*(m+1)//2
    b = m*(m-1)//2
    constant = 1+a*a+b*b+ceil(m**4/2)
    es = [e for e in range(2, 289, 2) if 288 % e == 0
          and m*m*e+constant <= 490]
    costs[m] = {"constant": constant, "minimum_rank": 2*m*m+constant,
                "largest_possible_even_degree": max(es)}
assert costs == {
    2: {"constant": 19, "minimum_rank": 27, "largest_possible_even_degree": 96},
    3: {"constant": 87, "minimum_rank": 105, "largest_possible_even_degree": 36},
    4: {"constant": 265, "minimum_rank": 297, "largest_possible_even_degree": 12},
}

def valuation(n, p):
    v = 0
    while n % p == 0:
        n //= p
        v += 1
    return v


factorial_checks = {
    "source_n": 5400,
    "modular_D": 5400**2,
    "v5_9_factorial": valuation(factorial(9), 5),
    "v5_19_factorial": valuation(factorial(19), 5),
    "source_first_factorial_remainder": next(
        d for d in range(1, 20) if factorial(2*d-1) % 5400 == 0),
}
assert factorial_checks["v5_9_factorial"] == 1
assert factorial_checks["v5_19_factorial"] == 3
assert factorial_checks["source_first_factorial_remainder"] == 6
assert not any(13*a+28*b == 35 for a in range(4) for b in range(2))
assert 1+145*36+2*49+81 == 5400
assert 1+145+2+1 == 149
assert 1+2*25+15**2+2*10**2 == 476
assert 476+100 > 490
assert 1+2*36+21**2+2*15**2 == 964

# At c >= 16, 2*c*c is increasing, so these finite ranges contain
# the global minima subject to c+h >= 16 and nonnegative c,h.
seventy_two_rank_costs = {
    "adjoint_cost_c_at_most_six": min(
        c*c+(16-c)**2 for c in range(7)),
    "adjoint_cost_c_at_least_seven": min(
        2*c*c+max(0, 16-c)**2 for c in range(7, 17)),
    "other_disjoint_cost": 1+2*4**2+10**2+6**2,
}
assert seventy_two_rank_costs == {
    "adjoint_cost_c_at_most_six": 136,
    "adjoint_cost_c_at_least_seven": 179,
    "other_disjoint_cost": 169,
}
assert 136+169 == 305
assert 179+169 == 348

report = {
    "status": "all exact arithmetic checks passed",
    "scope": "finite mu6, dimension, duality, rank and factorial arithmetic only; no categorifiability claim",
    "mu6_solutions": {
        f"t={t},v={names[v]}": [
            [[d, names[q]] for d, q in sol] for sol in sorted(sols)]
        for (t, v), sols in solutions.items()
    },
    "raw_gram_pairs": raw_gram,
    "gram_pairs_after_content_test": gram,
    "rank_field_costs": costs,
    "factorial_checks": factorial_checks,
    "rational_commutative_source_rank_bound": 149,
    "exceptional_m5_rank_before_orbit_cost": 476,
    "positive_seventy_two_m4_rank_costs": seventy_two_rank_costs,
}
destination = Path(__file__).with_name("r31_braiding_arithmetic_results.json")
destination.write_text(json.dumps(report, indent=2) + "\n")
print(report["status"])
print(f"Finite mu6 alternatives: {sum(len(s) for s in solutions.values())}")
print("Gram pairs and rank/field bounds verified exactly.")
