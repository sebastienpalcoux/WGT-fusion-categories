"""Exact integer checks for the new codegree-six type bounds.

These are necessary dimension-equation filters, not fusion-ring existence
checks. No assumption that source simple dimensions divide 5400 is made.
"""
from math import isqrt

N = 5399

def ceil_sqrt(n):
    r = isqrt(n)
    return r if r*r == n else r+1

def max_count_table(min_degree):
    dp = [-10**6]*(N+1)
    last = [0]*(N+1)
    dp[0] = 0
    for d in range(min_degree, 73):
        q = d*d
        for n in range(q, N+1):
            if dp[n-q]+1 > dp[n]:
                dp[n] = dp[n-q]+1
                last[n] = d
    return dp, last

cache = {}
records = []
for eps in (1,-1):
    for u in range(6 if eps == 1 else 7, 73):
        v = 2*u+eps
        if v > 72:
            continue
        min_degree = ceil_sqrt(v+1)
        if min_degree not in cache:
            cache[min_degree] = max_count_table(min_degree)
        dp,last = cache[min_degree]
        rem = N-u*u-v*v
        if rem < 0 or dp[rem] < 0:
            continue
        rank = 3+dp[rem]
        records.append((rank,eps,u,v,min_degree))

best = max(x[0] for x in records)
assert best == 325, best
print('Rational {2,1} branch: exact dimension-equation rank upper bound',best)
for rank,eps,u,v,s in records:
    if rank != best:
        continue
    dp,last=cache[s]
    rem=N-u*u-v*v
    counts={1:1,u:1,v:1}
    while rem:
        d=last[rem]
        assert d
        counts[d]=counts.get(d,0)+1
        rem-=d*d
    assert sum(d*d*n for d,n in counts.items()) == 5400
    assert sum(counts.values()) == rank
    print('  necessary moment witness:',eps,u,v,dict(sorted(counts.items())))

# One-negative five-value branch: ranks330/329 force the four positive
# supported dimensions to remain3, then require impossible excess10/26.
possible_excess = {0}
for n in range(1,43):
    if any(n-(d*d-16) in possible_excess for d in range(5,8) if d*d-16 <= n):
        possible_excess.add(n)
assert 10 not in possible_excess and 26 not in possible_excess
assert 13 not in possible_excess and 42 in possible_excess
one_negative_witness = {1:1,3:4,4:320,5:1,7:1,13:1}
assert sum(d*d*n for d,n in one_negative_witness.items()) == 5400
assert sum(one_negative_witness.values()) == 328
print('One-negative five-value branch: necessary moment witness at rank328:',one_negative_witness)
print('No fusion-ring or categorical existence is asserted.')

# Exact coincident-support projector obstruction in Q(sqrt(-3)).
from fractions import Fraction as F

def qmul(x,y):
    return (x[0]*y[0]-3*x[1]*y[1], x[0]*y[1]+x[1]*y[0])
def qconj(x):
    return (x[0],-x[1])
def qadd(x,y):
    return (x[0]+y[0],x[1]+y[1])

for a in (-1,1):
    for b in (-1,1):
        h1t=(F(a,2),F(1,2));h1u=(F(b,2),F(1,2))
        h2t=(F(-a,2),F(1,2));h2u=(F(-b,2),F(-1,2))
        total=(F(0),F(0))
        for t,u in ((h1t,h1u),(qconj(h1t),qconj(h1u)),
                    (h2t,h2u),(qconj(h2t),qconj(h2u))):
            total=qadd(total,qmul(u,qconj(t)))
        assert total==(F(a*b),F(0)),(a,b,total)
        projected_entry=total[0]/6
        assert (3*projected_entry).denominator==2
print('Coincident-support projector: all4 sign patterns give 3L_e entry±1/2.')

# Quartic-field support: the vanishing Fourier coefficients at frequencies
# 1,2,3 modulo6 force all six residue counts to equal1.
# In Z[zeta6], zeta6^2=zeta6-1; use pairs (a,b) for a+b*zeta6.
zeta6_powers=[(1,0),(0,1),(-1,1),(-1,0),(0,-1),(1,-1)]
def compositions(total,length):
    if length==1:
        yield (total,)
    else:
        for x in range(total+1):
            for tail in compositions(total-x,length-1):
                yield (x,)+tail
solutions=[]
for c in compositions(6,6):
    good=True
    for frequency in (1,2,3):
        value=tuple(sum(c[j]*zeta6_powers[(frequency*j)%6][k]
                        for j in range(6)) for k in (0,1))
        if value!=(0,0):
            good=False
            break
    if good:solutions.append(c)
assert solutions==[(1,1,1,1,1,1)],solutions
print('Quartic support Fourier equations: unique residue count (1,1,1,1,1,1).')

# Fully rational commutative source: all scalar spectra are integral,
# so the spectral factorial obstruction gives minimum nonunit degree6.
excess6={0}
for n in range(1,72):
    if any(n-(d*d-36) in excess6 for d in range(7,11) if d*d-36 <= n):
        excess6.add(n)
assert 35 not in excess6 and 71 in excess6
rational_witness={1:1,6:145,7:2,9:1}
assert sum(d*d*n for d,n in rational_witness.items())==5400
assert sum(rational_witness.values())==149
print('Fully rational commutative source: rank150 excess35 impossible; rank149 moment witness:',rational_witness)

# Two nonreal f6 pairs: signed dimension equations imply the paired
# square contribution is0mod4. The remaining1+one/two squares cannot be0.
assert all((1+r*r)%4 for r in range(4))
assert all((1+r*r+s*s)%4 for r in range(4) for s in range(4))
print('Two nonreal f6 pairs: ranks10 and11 excluded by exact mod4 residue check.')
