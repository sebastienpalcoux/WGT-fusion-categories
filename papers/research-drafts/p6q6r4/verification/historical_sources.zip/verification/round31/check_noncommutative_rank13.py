"""Exact arithmetic checks for rank13 duality/discriminant refinements.

The categorical/rational-algebra arguments are in
r31_noncommutative_rank13.tex; these checks validate their normalizations.
"""
from fractions import Fraction as F
from math import isqrt, prod

DEGREES=(10,12,15,18,20,24,30,36,40,45,50,54,60,72,75,90,
100,108,120,135,150,180,200,216,225,270,300,360,450,540,600,675,900)
CODEGREES=sorted(5400//d for d in DEGREES)

def mul(x,y,a,b):
    # Quaternion basis1,i,j,k withi²=a,j²=b,ij=k=-ji.
    table={
      (0,0):(0,1),(0,1):(1,1),(0,2):(2,1),(0,3):(3,1),
      (1,0):(1,1),(2,0):(2,1),(3,0):(3,1),
      (1,1):(0,a),(2,2):(0,b),(3,3):(0,-a*b),
      (1,2):(3,1),(2,1):(3,-1),
      (1,3):(2,a),(3,1):(2,-a),
      (2,3):(1,-b),(3,2):(1,b),
    }
    z=[F(0)]*4
    for i,u in enumerate(x):
        for j,v in enumerate(y):
            k,c=table[i,j];z[k]+=u*v*c
    return tuple(z)

def conj(x):return (x[0],-x[1],-x[2],-x[3])
def scalar_norm(x,a,b):
    v=mul(x,conj(x),a,b)
    assert v[1:]==(0,0,0)
    return v[0]

e=[tuple(F(i==j) for j in range(4)) for i in range(4)]
for a in (-6,-1,1,3):
    for b in (-5,-1,1,2):
        gram=[[4*mul(x,y,F(a),F(b))[0] for y in e] for x in e]
        expected=[4,4*a,4*b,-4*a*b]
        assert all(gram[i][j]==(expected[i] if i==j else 0)
                   for i in range(4) for j in range(4))
        assert prod(expected)==-256*a*a*b*b
print('Degree2 regular-trace discriminant: -256a²b²; absolute squareclass1.')

square4=[f for f in CODEGREES if isqrt(f)**2==f and f%4==0]
eight_squares=[f for f in CODEGREES if f%8==0 and isqrt(f//8)**2==f//8]
assert square4==[36,100]
assert eight_squares==[8,72]
print('Symplectic q=q6=0 or2 codegrees:',square4)
print('Symplectic q=q6=1 codegrees:',eight_squares)

for f in square4:
    a=b=F(-f)
    x=e[1];y=e[2];z=tuple(c/isqrt(f) for c in e[3])
    assert [scalar_norm(v,a,b) for v in (x,y,z)]==[f,f,f]
    p=mul(mul(x,y,a,b),z,a,b)
    tau=F(2,f)*p[0]
    assert tau==-2*isqrt(f)
    print('  q0 normalization f',f,'unit coefficient',tau)
for f in eight_squares:
    a=b=F(-f)
    x=e[1];y=e[2];z=tuple(c/(2*isqrt(f//2)) for c in e[3])
    assert [scalar_norm(v,a,b) for v in (x,y,z)]==[f,f,F(f,2)]
    p=mul(mul(x,y,a,b),z,a,b)
    tau=F(2,f)*p[0]
    assert tau==-2*isqrt(f//2)
    print('  q1 normalization f',f,'unit coefficient',tau)
for f in square4:
    a=b=F(-f,2)
    x=e[1];y=e[2];z=tuple(c*2/isqrt(f) for c in e[3])
    assert [scalar_norm(v,a,b) for v in (x,y,z)]==[F(f,2),F(f,2),f]
    p=mul(mul(x,y,a,b),z,a,b)
    tau=F(2,f)*p[0]
    assert tau==-isqrt(f)
    print('  q2 normalization f',f,'unit coefficient',tau)

for q in range(5):
    assert (13-(9-2*q+2))//2==q+1
    assert (13-(9-2*q-2))//2==q+3
assert 7-2*3==1
assert all((1+2*s)%2==1 for s in range(20))
print('Duality counts: q+1 orthogonal, q+3 symplectic; symplecticq3 excluded by even dimension.')
print('All exact normalization checks passed.')
