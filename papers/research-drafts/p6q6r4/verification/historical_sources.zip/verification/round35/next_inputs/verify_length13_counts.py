#!/usr/bin/env python3
"""Exact raw canonical-length-thirteen inputs, before any field tests.

Profile/partition enumeration and a separate Euler-product coefficient
computation agree. These counts are not surviving types or fusion rings.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import hashlib, json, time

HERE=Path(__file__).resolve().parent
D=5400; L=13
A=tuple(a for a in range(10,901) if D%a==0 and sum(a%p==0 for p in (2,3,5))>=2)

def profiles(slots,total,cap=900):
    if slots==0:
        if total==0:
            yield ()
        return
    if total<10*slots:
        return
    for a in reversed(A):
        if a>cap:
            continue
        if a*slots<total:
            break
        if total-a<10*(slots-1):
            continue
        for tail in profiles(slots-1,total-a,a):
            yield (a,)+tail

@lru_cache(None)
def partitions(n,cap):
    if n==0:
        return ((),)
    return tuple((m,)+tail for m in range(min(n,cap),0,-1)
                 for tail in partitions(n-m,m))

@lru_cache(None)
def rank_polynomial(k):
    return Counter(sum(m*m for m in p) for p in partitions(k,k))

def multiply(a,b):
    c=Counter()
    for i,x in a.items():
        for j,y in b.items():
            c[i+j]+=x*y
    return c

def euler_coefficient(all_degrees):
    dp=[[0]*D for k in range(L)]
    dp[0][0]=1
    for a in A:
        for m in (range(1,L) if all_degrees else (1,)):
            weight=m*a
            if weight>=D:
                continue
            for k in range(m,L):
                current=dp[k]; previous=dp[k-m]
                for total in range(weight,D):
                    current[total]+=previous[total-weight]
    return dp[L-1][D-1]

def main():
    assert __debug__
    started=time.monotonic(); n=0; distribution=Counter(); max_mult=0
    for p in profiles(L-1,D-1):
        n+=1; counts=Counter(p); max_mult=max(max_mult,max(counts.values()))
        poly=Counter({1:1})
        for k in counts.values():
            poly=multiply(poly,rank_polynomial(k))
        distribution.update(poly)
    assert all(r%2==L%2 for r in distribution)
    independent_profiles=euler_coefficient(False)
    independent_assignments=euler_coefficient(True)
    assert n==independent_profiles==62776
    assert sum(distribution.values())==independent_assignments
    assert distribution[L]==n
    report={'status':'PASS','canonical_length':L,'dimension':D,'canonical_palette':A,
            'weighted_profiles':n,'multiplicity_assignments':sum(distribution.values()),
            'assignment_rank_distribution':dict(sorted(distribution.items())),
            'maximum_repetition_in_weighted_profile':max_mult,
            'independent_euler_product_profiles':independent_profiles,
            'independent_euler_product_assignments':independent_assignments,
            'equation':'Coefficient of x^12 y^5399 in product_(a in A,m=1..12)(1-x^m y^(ma))^-1.',
            'scope':'Raw necessary canonical data only. No field, duality, source-type, multiplication, or categorification survival is asserted.',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'seconds':time.monotonic()-started}
    (HERE/'length13_counts.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    main()
