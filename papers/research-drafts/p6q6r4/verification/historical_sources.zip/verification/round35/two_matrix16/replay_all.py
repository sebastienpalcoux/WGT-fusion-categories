"""Run the complete dependency-free rank16 proof from a portable directory.

Usage: python -B -S replay_all.py --workers 2 --output replay_output
The mathematical verifier uses no optimizer or third-party Python module.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,subprocess,sys,time
from proof_snapshot import checked
HERE=Path(__file__).resolve().parent

def run(script,args,console):
    with console.open('w')as out:
        process=subprocess.run([sys.executable,'-B','-S',str(HERE/script),*map(str,args)],
                               cwd=HERE,stdout=out,stderr=subprocess.STDOUT)
    assert process.returncode==0,(script,process.returncode,str(console))

def main():
    assert __debug__
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=2)
    ap.add_argument('--shards',type=int,default=73);ap.add_argument('--output',type=Path,default=HERE/'replay_output')
    args=ap.parse_args();assert 1<=args.workers<=24 and 1<=args.shards<=9268
    checked();output=args.output.resolve();output.mkdir(parents=True,exist_ok=True)
    start=time.monotonic();trace_report=output/'trace_replay.json'
    run('verify_trace16.py',['--output',trace_report],output/'trace_console.txt')
    print('Complete input and trace replay PASS.',flush=True)
    tasks=[];ledgers=[]
    for part in range(args.shards):
        lo=9268*part//args.shards;hi=9268*(part+1)//args.shards
        ledger=output/f'ledger_{lo}_{hi}.jsonl';ledgers.append(ledger)
        report=output/f'report_{lo}_{hi}.json';console=output/f'console_{lo}_{hi}.txt'
        tasks.append((part,['--state-start',lo,'--state-stop',hi,'--ledger',ledger,'--output',report],console))
    with ThreadPoolExecutor(max_workers=args.workers)as pool:
        futures={pool.submit(run,'verify_rank16.py',params,console):part for part,params,console in tasks}
        for future in as_completed(futures):
            future.result();print('Exact row shard PASS:',futures[future],flush=True)
    final_report=output/'complete_replay.json'
    run('merge_rank16.py',['--ledgers',*ledgers,'--trace-report',trace_report,'--report',final_report],output/'merge_console.txt')
    report=json.loads(final_report.read_text());assert report['status']=='PASS_COMPLETE_EXCLUSION'
    print(json.dumps({'status':report['status'],'exact_replays_checked':report['exact_replays_checked'],
                      'report':str(final_report),'seconds':time.monotonic()-start},indent=2))

if __name__=='__main__':main()
