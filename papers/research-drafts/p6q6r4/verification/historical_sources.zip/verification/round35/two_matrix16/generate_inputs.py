"""Complete canonical input universe for rank sixteen and two M2 blocks."""
from collections import Counter
from itertools import combinations_with_replacement
from pathlib import Path
import hashlib,json,time
from canonical_input_counts import profiles,coefficients,PALETTE,N

HERE=Path(__file__).resolve().parent

def enumerate_inputs():
    result=[];inventory=Counter();placement_counts=Counter();admitted=0
    all_profiles=list(profiles(11,N-1))
    for pi,p in enumerate(all_profiles):
        c=Counter(p);eligible=sorted(a for a,k in c.items() if k>=2)
        selected=[ab for ab in combinations_with_replacement(eligible,2)
                  if ab[0]!=ab[1] or c[ab[0]]>=4]
        admitted+=bool(selected)
        for a,b in selected:
            rest=c.copy();rest[a]-=2;rest[b]-=2
            assert sum(rest.values())==7
            inventory.update((N//aa,k) for aa,k in rest.items() if k)
            placement_counts[a,b]+=1
            result.append({'placement_index':len(result),'profile_index':pi,
                           'profile':list(p),'nonlinear_degrees':[a,b]})
    return all_profiles,result,inventory,placement_counts,admitted

def main():
    start=time.monotonic()
    pp,rr,inv,pc,admitted=enumerate_inputs();dp=coefficients()
    assert len(pp)==dp[11][N-1]==6547
    assert admitted==6455 and len(rr)==12257
    for a,b in combinations_with_replacement(PALETTE,2):
        remaining=N-1-2*a-2*b
        assert pc[a,b]==(dp[7][remaining] if remaining>=0 else 0)
    output=HERE/'input12257.json';output.write_text(json.dumps(rr,separators=(',',':'))+'\n')
    report={'status':'PASS_COMPLETE_INPUT_ENUMERATION','rank':16,'dimension':N,
            'profiles':len(pp),'admitted_profiles':admitted,'placements':len(rr),
            'input_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
            'linear_block_inventory':[{'f':f,'k':k,'occurrences':count}for(f,k),count in sorted(inv.items())],
            'independent_check':'Every unordered placement count agrees with a separate generating-function coefficient table.',
            'seconds':time.monotonic()-start}
    (HERE/'input_enumeration.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
