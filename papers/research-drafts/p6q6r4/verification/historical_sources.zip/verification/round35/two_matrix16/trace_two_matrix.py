"""Necessary full-linear-field and finite two-matrix trace-form gates.

Exact standard-library arithmetic. Rational degree-two components are
allowed all quaternion classes unramified outside f. Orthogonal skew
squareclasses are squarefree divisors of f, from the integral rank-one
skew projection. Quadratic matrix orbits are retained with only proved
necessary transfer-form tests; no splitting or Schur-index assumption.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import product
from math import gcd,prod,isqrt
from functools import lru_cache
from linear_field_lattice import assignment_failure,verify_field_lattice
from pathlib import Path
import json,time,argparse
import generic_fields as fields
import r32_trace_forms as forms
HERE=Path(__file__).resolve().parent
N=5400
RANK=16

def squarefree_divisors(f):
    return tuple(d for d in range(1,f+1)if f%d==0 and forms.squareclass(d)==d)

@lru_cache(None)
def sum_squares(n,b):
    if n==0:return True
    if b==0:return False
    return any(sum_squares(n-x*x,b-1)for x in range(isqrt(n),-1,-1))

@lru_cache(None)
def matrix_forms(f,kind,b):
    out=[]
    if kind=='S':
        for ram,diag in [((2,),(1,1,1,1)),((3,),(1,1,3,3)),((5,),(1,2,5,10)),((2,3,5),(1,3,10,30))]:
            if all(f%p==0 for p in ram):
                w=tuple(Q(2*x,f)for x in diag)
                out.append((f'S:ram={ram}',w,w[:1],w[1:]))
        return tuple(out)
    for delta in squarefree_divisors(f):
        if not sum_squares(f//delta,b):continue
        targets=[ram for ram in ((),(2,3),(2,5),(3,5))
                 if all(f%p==0 and not forms.locally_square(-delta,p)for p in ram)]
        found={}
        for c in range(1,10001):
            primes={2}|forms.prime_factors(delta)|forms.prime_factors(c)
            ram=tuple(p for p in sorted(primes)if forms.hilbert(-delta,c,p)==-1)
            if ram in targets and ram not in found:found[ram]=c
            if len(found)==len(targets):break
        assert set(found)==set(targets),(f,delta,targets,found)
        for ram,c in found.items():
            w=tuple(Q(2*x,f)for x in (1,delta,c,delta*c))
            out.append((f'O:delta={delta}:c={c}:ram={ram}',w,(w[0],w[2],w[3]),(w[1],)))
    return tuple(out)

def residue_pass(degrees,linear,matrix_rational):
    entries=[(a,2,rat)for a,rat in zip(degrees,matrix_rational)]
    for a,labels in linear:
        for label in labels:
            if label=='Q':e=1
            elif label=='Q(sqrt(-3))'or label.startswith('quadratic'):e=2
            elif label=='real_cubic_conductor9':e=3
            else:
                c,h=label.split(':H=');e=forms.phi(int(c[4:]))//len(h.split(','))
            entries.extend([(a,1,label=='Q')]*e)
    for i,(a,m,rat)in enumerate(entries):
        if not rat:continue
        r=a-m;g=0
        for j,(aa,mm,_)in enumerate(entries):
            if j!=i:g=gcd(g,aa*mm)
        if not any((r+m*a*u)%g==0 for u in range(-r+1,r)):return False
    return True

@lru_cache(None)
def rational_gate(whole,plus,minus,q,q6,f1,f2,kinds):
    b=q+sum(1 if k=='O' else 3 for k in kinds)
    if b>7 or b<2*q6:return ()
    if kinds=='SS'and f1==f2==6:return ()
    target_plus=[1]*(RANK-2*b)+[2]*b
    allowed=[]
    for x,y in product(matrix_forms(f1,kinds[0],b),matrix_forms(f2,kinds[1],b)):
        if not forms.isometric(minus+x[3]+y[3],[2]*b):continue
        if not forms.isometric(whole+x[1]+y[1],[1]*RANK):continue
        assert forms.isometric(plus+x[2]+y[2],target_plus)
        allowed.append((x[0],y[0]))
    return tuple(allowed)

@lru_cache(None)
def quadratic_gate(whole,plus,minus,q,q6,f,D,kind):
    d=D if D%4==1 else D//4
    b=q+({'O':2,'S':6,'U':4}[kind])
    if b>7 or b<2*q6:return False
    if f==6:return False # R34 sole nonlinear quadratic-orbit theorem: rank>=17.
    target_plus=tuple([1]*(RANK-2*b)+[2]*b)
    if kind=='S':
        # The fixed space of a symplectic quaternion involution is K.
        return forms.isometric(plus+(Q(4,f),Q(4*d,f)),target_plus)
    if kind=='U':
        # B^- = sqrt(-abs(d)) B^+ and the positive forms scale by abs(d).
        dd=-d
        return forms.isometric(plus+tuple(Q(2,dd)for _ in range(b)),target_plus+tuple(a/dd for a in minus))
    # For a real quadratic orthogonal orbit the skew plane is the
    # transferred one-dimensional form (2/f) Tr_K(delta x^2). Its
    # determinant divided by disc(K) must be a K/Q norm.
    det=Q(2)**b/prod(minus)
    norm_class=forms.squareclass(det/d)
    ps={2}|forms.prime_factors(d)|forms.prime_factors(norm_class)
    return all(forms.hilbert(d,norm_class,p)==1 for p in ps)

def analyze(record):
    profile=record['profile'];degrees=tuple(record['nonlinear_degrees'])
    counts=Counter(profile)
    for a in degrees:counts[a]-=2
    blocks=[(a,k)for a,k in counts.items()if k]
    assert sum(k for a,k in blocks)==7
    alternatives=[fields.decompositions(N//a,k)for a,k in blocks]
    result=[];stats=Counter()
    for assignment in product(*alternatives):
        stats['linear_assignments']+=1
        q6=sum(x[4]for x in assignment);q=sum(len(x[3])for x in assignment)
        if q>3 or q6>2:continue
        whole=(Q(1,N),)+tuple(a for x in assignment for a in x[1])
        if forms.squareclass(prod(whole))!=1:continue
        stats['determinant_pass']+=1
        plus=(Q(1,N),)+tuple(a for x in assignment for a in x[2]);minus=tuple(a for x in assignment for a in x[3])
        linear=[(a,tuple(x[0]))for(a,k),x in zip(blocks,assignment)]
        descr=[{'formal_codegree':N//a,'fields':list(labels)}for a,labels in linear]
        cert=assignment_failure({'fields':descr})
        if cert is not None:
            assert verify_field_lattice({'fields':descr},cert)
            stats['linear_covariance_exclusions']+=1
            continue
        matrix=[]
        if 10 not in degrees and residue_pass(degrees,linear,(True,True)):
            for kind in ('OO','OS','SO','SS'):
                if degrees[0]==degrees[1]and kind=='SO':continue
                options=rational_gate(whole,plus,minus,q,q6,N//degrees[0],N//degrees[1],kind)
                if options:matrix.append({'field':'Q+Q','kind':kind,'forms':options})
        if degrees[0]==degrees[1] and residue_pass(degrees,linear,(False,False)):
            f=N//degrees[0];c=gcd(2*f,f*f)
            for D in forms.quadratic_discriminants(c):
                for kind in ('O','S')if D>0 else('U',):
                    if quadratic_gate(whole,plus,minus,q,q6,f,D,kind):matrix.append({'field':f'quadratic_disc={D}','kind':kind})
        if matrix:
            result.append({'fields':descr,'q':q,'q6':q6,'matrix_options':matrix})
            stats['retained_assignments']+=1;stats['matrix_states']+=len(matrix)
    return {'profile_index':record['profile_index'],'profile':profile,'nonlinear_degrees':degrees,'statistics':dict(stats),'assignments':result,'excluded':not result}

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'trace_two_matrix.jsonl');args=p.parse_args()
    inputs=json.loads((HERE/'input12257.json').read_text());start=time.monotonic();counts=Counter()
    with args.output.open('w')as out:
        for i,r in enumerate(inputs):
            x=analyze(r);x['placement_index']=i;out.write(json.dumps(x)+'\n');out.flush()
            counts['placements']+=1;counts['excluded']+=x['excluded'];counts.update(x['statistics'])
            if i%100==0:print(i,r['profile_index'],r['nonlinear_degrees'],x['statistics'],'excluded',x['excluded'],'seconds',round(time.monotonic()-start,2),flush=True)
    summary={'status':'PASS','counts':dict(counts),'seconds':time.monotonic()-start}
    (HERE/'trace_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
