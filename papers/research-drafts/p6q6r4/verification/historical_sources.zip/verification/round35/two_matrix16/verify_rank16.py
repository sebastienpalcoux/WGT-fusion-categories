"""Exact pure-Python replay of selected rank16 two-matrix certificates."""
from pathlib import Path
from collections import Counter
import argparse,json,time
from two_matrix_rows import build_pieces,pair_count,rows_for,moment_data,cheap_certificate
from two_matrix_words import word_possible
from strong_certificates import support_certificate,forced_atom_certificate
from exact_certificate_checks import verify_certificate
from proof_snapshot import checked,canonical_sha,sha
from cache_hygiene import clear_state_caches
HERE=Path(__file__).resolve().parent

def contexts():
    data=[json.loads(x)for x in(HERE/'trace_two_matrix.jsonl').read_text().splitlines()]
    result=[]
    for case in data:
        for ai,assignment in enumerate(case['assignments']):
            for mi,matrix in enumerate(assignment['matrix_options']):
                result.append((case,ai,mi,assignment,matrix))
    assert len(result)==9268
    return result

def replay(record,context):
    case,ai,mi,assignment,matrix=context
    assert [case['placement_index'],ai,mi]==record['key']
    cert=record['certificate'];kind=cert['kind'];b=pair_count(assignment,matrix)
    if record['method']=='analytic_support':
        assert record['base_rows']==record['rows']==record['vectors']==0
        if kind=='forbidden_24_200':
            c=Counter(case['profile'])
            assert c[24]==c[200]==1 and all(a in (24,200)or a%225==0 for a in c)
        elif kind=='symplectic_six_support':
            assert matrix['field']=='Q+Q' and b<5
            assert any(a==900 and k=='S'for a,k in zip(case['nonlinear_degrees'],matrix['kind']))
            assert cert['pairs']==b
        else:raise AssertionError(kind)
        return 0,0
    pieces=build_pieces(assignment,case['nonlinear_degrees'],matrix)
    base=list(rows_for(pieces,assignment['q6']));assert len(base)==record['base_rows']
    if record['method']=='word_refinement':
        rows=[r for r in base if word_possible(pieces,r)]
    else:
        assert record['method']in('fixed_fields','regular_canonical_support')
        rows=base
    assert len(rows)==record['rows']
    target,vectors=moment_data(pieces,rows,b);assert len(vectors)==record['vectors']
    if kind in('canonical_remainder','duality_dimension_squares'):
        assert cheap_certificate(case['profile'],case['nonlinear_degrees'],rows,b)==cert
    elif kind=='regular_duality_canonical_remainder':
        assert support_certificate(pieces,rows)==cert
    elif kind=='forced_central_atom':
        assert forced_atom_certificate(pieces,rows)==cert
    else:
        assert kind=='integer_separator'
        assert verify_certificate(vectors,target,cert)
    return len(base),len(rows)

def main():
    assert __debug__
    ap=argparse.ArgumentParser();ap.add_argument('--certificates',type=Path,default=HERE/'rank16_certificates.jsonl')
    ap.add_argument('--state-start',type=int,default=0);ap.add_argument('--state-stop',type=int,default=9268)
    ap.add_argument('--ledger',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();start=time.monotonic();frozen=checked()
    assert sha(args.certificates)==frozen['inputs']['rank16_certificates.jsonl']
    assert 0<=args.state_start<=args.state_stop<=9268
    assert not any((d**3-d)%5400==0 for d in range(3,73))
    records=[json.loads(x)for x in args.certificates.read_text().splitlines()]
    assert len(records)==9268 and [r['state']for r in records]==list(range(9268))
    assert all(r['certificate']is not None for r in records)
    ctx=contexts();hist=Counter();raw=retained=0
    with args.ledger.open('w')as out:
        for state in range(args.state_start,args.state_stop):
            record=records[state];n,m=replay(record,ctx[state]);raw+=n;retained+=m
            hist[record['certificate']['kind']]+=1
            entry={'state':state,'status':'PASS_EXACT_CERTIFICATE',
                   'proof_sha256':frozen['proof_sha256'],'certificate_sha256':canonical_sha(record),
                   'base_rows_regenerated':n,'retained_rows':m}
            out.write(json.dumps(entry,separators=(',',':'))+'\n');out.flush()
            clear_state_caches()
            if (state-args.state_start)%25==0:
                print('exact state',state,'rows',raw,'seconds',round(time.monotonic()-start,2),flush=True)
    report={'status':'PASS_EXACT_CERTIFICATES','state_range':[args.state_start,args.state_stop],
            'exact_replays_checked':args.state_stop-args.state_start,
            'base_rows_regenerated':raw,'retained_rows':retained,'certificate_histogram':dict(hist),
            'proof_sha256':frozen['proof_sha256'],'certificate_file_sha256':sha(args.certificates),
            'ledger_sha256':sha(args.ledger),'seconds':time.monotonic()-start}
    args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
