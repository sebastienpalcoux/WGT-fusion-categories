"""Hash the complete mathematical code used by the rank16 replayers."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
PROOF_FILES=(
 'canonical_input_counts.py','generate_inputs.py','trace_two_matrix.py',
 'generic_fields.py','r32_trace_forms.py','linear_field_lattice.py',
 'fixed_lattice.py','fixed_field_rows.py','orbit_pairs.py','coupled_rows.py',
 'refined_rows.py','endpoint_core.py','gap_filter.py','power_trace_filter.py',
 'field_power_polynomials.py','field_discriminant_profiles.py',
 'two_matrix_rows.py','two_matrix_words.py','strong_certificates.py',
 'exact_certificate_checks.py','verify_trace16.py','verify_rank16.py',
 'merge_rank16.py','proof_snapshot.py','cache_hygiene.py')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as source:
        for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def canonical_sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def current():
    files={name:sha(HERE/name)for name in PROOF_FILES}
    return {'files':files,'proof_sha256':canonical_sha(files)}

def checked():
    if not __debug__:
        raise RuntimeError('Exact proof replay requires assertions; do not use Python -O.')
    frozen=json.loads((HERE/'proof_freeze_manifest.json').read_text())
    assert frozen['status']=='FROZEN_BEFORE_COMPLETE_EXACT_REPLAY'
    now=current();assert frozen['files']==now['files']
    assert frozen['proof_sha256']==now['proof_sha256']
    for name,digest in frozen['inputs'].items():assert sha(HERE/name)==digest,name
    return frozen

if __name__=='__main__':
    if not __debug__:
        raise RuntimeError('Proof freezing requires assertions; do not use Python -O.')
    path=HERE/'proof_freeze_manifest.json';assert not path.exists()
    record=current();record['inputs']={name:sha(HERE/name)for name in
        ('input12257.json','trace_two_matrix.jsonl','rank16_certificates.jsonl')}
    record['status']='FROZEN_BEFORE_COMPLETE_EXACT_REPLAY'
    path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
