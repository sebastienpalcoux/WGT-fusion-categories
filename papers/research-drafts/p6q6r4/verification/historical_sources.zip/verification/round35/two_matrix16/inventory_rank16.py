"""Descriptive tables derived from the authenticated complete proof records."""
from pathlib import Path
from collections import Counter,defaultdict
import json
from proof_snapshot import checked,canonical_sha,sha
from verify_rank16 import contexts
from two_matrix_rows import pair_count
HERE=Path(__file__).resolve().parent

def summary_table(items):
    return [{'label':label,**value,'methods':dict(sorted(value['methods'].items())),
             'certificate_kinds':dict(sorted(value['certificate_kinds'].items()))}
            for label,value in sorted(items.items())]

def build_inventory():
    frozen=checked();report=json.loads((HERE/'complete_replay.json').read_text())
    assert report['status']=='PASS_COMPLETE_EXCLUSION' and report['exact_replays_checked']==9268
    assert report['proof_sha256']==frozen['proof_sha256']
    certs=[json.loads(x)for x in(HERE/'rank16_certificates.jsonl').read_text().splitlines()]
    ledger=[json.loads(x)for x in(HERE/'exact_ledger.jsonl').read_text().splitlines()]
    assert report['certificate_file_sha256']==sha(HERE/'rank16_certificates.jsonl')
    assert report['ledger_sha256']=={'exact_ledger.jsonl':sha(HERE/'exact_ledger.jsonl')}
    assert len(certs)==len(ledger)==9268
    def blank():return {'states':0,'base_rows_regenerated':0,'retained_rows':0,
                        'methods':Counter(),'certificate_kinds':Counter()}
    families=defaultdict(blank);methods=defaultdict(blank);kinds=defaultdict(blank)
    b_hist=Counter();q_hist=Counter();q6_hist=Counter();coexistence=Counter()
    degree_pairs=Counter();codegree_pairs=Counter()
    dimensions=[];dimension_subtypes=Counter();raw=retained=0;placements=set();assignments=set()
    for state,((case,ai,mi,assignment,matrix),cert,entry)in enumerate(zip(contexts(),certs,ledger)):
        assert cert['state']==entry['state']==state
        assert cert['key']==[case['placement_index'],ai,mi]
        assert entry['status']=='PASS_EXACT_CERTIFICATE'
        assert entry['proof_sha256']==frozen['proof_sha256']
        assert entry['certificate_sha256']==canonical_sha(cert)
        n,m=entry['base_rows_regenerated'],entry['retained_rows']
        assert n==cert['base_rows'] and m==cert['rows']
        raw+=n;retained+=m;kind=cert['certificate']['kind'];method=cert['method']
        family=matrix['field']+'/'+matrix['kind'];b=pair_count(assignment,matrix)
        b_hist[b]+=1;q_hist[assignment['q']]+=1;q6_hist[assignment['q6']]+=1
        if matrix['field']=='Q+Q'and assignment['q6'] and any(
            a==900 and k=='S'for a,k in zip(case['nonlinear_degrees'],matrix['kind'])):
            coexistence[b]+=1
        degree_pairs[tuple(case['nonlinear_degrees'])]+=1
        codegree_pairs[tuple(sorted(5400//a for a in case['nonlinear_degrees']))]+=1
        placements.add(case['placement_index']);assignments.add((case['placement_index'],ai))
        for item in(families[family],methods[method],kinds[kind]):
            item['states']+=1;item['base_rows_regenerated']+=n;item['retained_rows']+=m
            item['methods'][method]+=1;item['certificate_kinds'][kind]+=1
        if kind=='duality_dimension_squares':
            cc=cert['certificate'];sd=cc['eligible_selfdual'];pairs=cc['eligible_pair'];s=15-2*b
            minimum=maximum=None
            if not sd:subtype='no_selfdual_dimension'
            elif not pairs:subtype='no_pair_dimension'
            else:
                minimum=s*min(sd)**2+2*b*min(pairs)**2
                maximum=s*max(sd)**2+2*b*max(pairs)**2
                subtype=('minimum_above_5399'if minimum>5399 else
                         'maximum_below_5399'if maximum<5399 else'exact_composition_gap')
            dimension_subtypes[subtype]+=1
            dimensions.append({'state':state,'key':cert['key'],'selfdual_slots':s,'pair_slots':b,
                               'eligible_selfdual_dimensions':sd,'eligible_pair_dimensions':pairs,
                               'minimum_squared_mass':minimum,'maximum_squared_mass':maximum,
                               'target_squared_mass':5399,'subtype':subtype,
                               'base_rows_regenerated':n,'retained_rows':m})
    assert raw==report['base_rows_regenerated'] and retained==report['retained_rows']
    assert len(placements)==2648 and len(assignments)==4747 and len(families)==14
    inventory={'status':'AUTHENTICATED_DESCRIPTIVE_INVENTORY','dimension':5400,'rank':16,
               'complex_algebra':'C^8+M2+M2','canonical_length':12,
               'trace_retained_placements':len(placements),'trace_retained_assignments':len(assignments),
               'states':9268,'base_rows_regenerated':raw,'retained_rows':retained,
               'field_involution_histogram':summary_table(families),
               'method_histogram':summary_table(methods),'certificate_histogram':summary_table(kinds),
               'source_dual_pairs_histogram':dict(sorted(b_hist.items())),
               'linear_nonreal_pairs_histogram':dict(sorted(q_hist.items())),
               'linear_complex_codegree_six_orbits_histogram':dict(sorted(q6_hist.items())),
               'symplectic_six_complex_six_coexistence_by_source_pairs':dict(sorted(coexistence.items())),
               'canonical_matrix_degree_pairs':[{'degrees':list(pair),'states':n}for pair,n in sorted(degree_pairs.items())],
               'nonlinear_formal_codegree_pairs':[{'codegrees':list(pair),'states':n}for pair,n in sorted(codegree_pairs.items())],
               'source_dimension_square_certificates':len(dimensions),
               'source_dimension_square_subtypes':dict(sorted(dimension_subtypes.items())),
               'source_dimension_range':[3,72],'pair_representative_dimension_range':[3,51],
               'proof_sha256':frozen['proof_sha256'],'input_sha256':frozen['inputs'],
               'certificate_file_sha256':sha(HERE/'rank16_certificates.jsonl'),
               'ledger_sha256':sha(HERE/'exact_ledger.jsonl')}
    return inventory,dimensions

def main():
    inventory,dimensions=build_inventory()
    (HERE/'state_inventory.json').write_text(json.dumps(inventory,sort_keys=True,indent=2)+'\n')
    (HERE/'dimension_square_cases.json').write_text(json.dumps(dimensions,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:inventory[k]for k in('status','states','base_rows_regenerated','retained_rows','source_dimension_square_certificates')},indent=2))

if __name__=='__main__':main()
