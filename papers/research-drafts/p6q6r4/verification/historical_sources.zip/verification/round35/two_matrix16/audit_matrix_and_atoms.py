"""Independent direct-matrix audit of word and central-atom identities."""
from itertools import product
from pathlib import Path
import hashlib,json,time
from two_matrix_rows import add,scale,mul,conj,trace
from two_matrix_words import rational_words,quadratic_words
from audit_word_identities import matrices
HERE=Path(__file__).resolve().parent

def scalar(A):return A[0][1]==A[1][0]==(0,0) and A[0][0]==A[1][1]

def main():
    started=time.monotonic();count=0;atom_count=0;bound=16
    actual=sorted({int(m['field'].split('=')[1])for line in(HERE/'trace_two_matrix.jsonl').read_text().splitlines()
                   for a in json.loads(line)['assignments']for m in a['matrix_options']if m['field']!='Q+Q'})
    assert actual==[-24,-20,-8,-4,-3,5,8,12,24]
    for D in actual:
        mm,star,tr,det,I=matrices(D)
        for entries in product(((0,0),(1,0),(-1,1)),repeat=4):
            A=(entries[:2],entries[2:]);B=star(A);C=mm(A,B)
            ps=[I];qs=[I];ns=[I]
            for k in range(2*bound):ps.append(mm(ps[-1],A));qs.append(mm(qs[-1],B))
            for k in range(bound):ns.append(mm(ns[-1],C))
            alpha,beta,gamma=tr(A),det(A),tr(C)
            got=quadratic_words(D,alpha,beta,gamma,bound)
            assert got[0]==tuple(trace(tr(M),D)for M in ps)
            assert got[1]==tuple(trace(tr(M),D)for M in ns)
            mixed=tuple(trace(tr(mm(ps[k],qs[l])),D)for k in range(bound+1)for l in range(k+1))
            assert got[2]==mixed
            assert got[3]==trace(tr(ns[2]),D)-trace(tr(mm(ps[2],qs[2])),D)
            aa=conj(alpha,D)if D<0 else alpha;bb=conj(beta,D)if D<0 else beta
            pure=add(scale(gamma,2),scale(mul(alpha,aa,D),-1))
            assert (pure==(0,0))==scalar(A)
            total=tuple(tuple(add(A[i][j],B[i][j])for j in range(2))for i in range(2))
            ss=add(alpha,aa)
            tt=add(add(mul(alpha,alpha,D),mul(aa,aa,D)),add(scale(gamma,2),scale(add(beta,bb),-2)))
            assert tr(total)==ss and tr(mm(total,total))==tt
            pair_pure=add(scale(tt,2),scale(mul(ss,ss,D),-1))
            assert (pair_pure==(0,0))==scalar(total)
            count+=1;atom_count+=2
        for entries in product((-1,0,1),repeat=4):
            A=tuple(tuple((entries[2*i+j],0)for j in range(2))for i in range(2))
            B=star(A);C=mm(A,B);ps=[I];qs=[I];ns=[I]
            for k in range(2*bound):ps.append(mm(ps[-1],A));qs.append(mm(qs[-1],B))
            for k in range(bound):ns.append(mm(ns[-1],C))
            got=rational_words(tr(A)[0],tr(C)[0],det(A)[0],bound)
            assert got[0]==tuple(tr(M)[0]for M in ps)
            assert got[1]==tuple(tr(M)[0]for M in ns)
            assert got[2]==tuple(tr(mm(ps[k],qs[l]))[0]for k in range(bound+1)for l in range(k+1))
            assert got[3]==tr(ns[2])[0]-tr(mm(ps[2],qs[2]))[0]
            count+=1
    report={'status':'PASS','direct_matrix_cases':count,'central_atom_identity_cases':atom_count,
            'quadratic_discriminants':[-24,-20,-8,-4,-3,5,8,12,24],
            'power_degree':2*bound,'mixed_word_exponent_bound':bound,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'input_sha256':hashlib.sha256((HERE/'trace_two_matrix.jsonl').read_bytes()).hexdigest(),
            'module_sha256':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()for name in
                ('two_matrix_rows.py','two_matrix_words.py','strong_certificates.py','audit_word_identities.py')},
            'seconds':time.monotonic()-started}
    (HERE/'matrix_and_atom_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
