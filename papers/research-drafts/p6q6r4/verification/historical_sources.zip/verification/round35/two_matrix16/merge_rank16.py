"""Strict coverage merger for already completed exact certificate replays."""
from pathlib import Path
from collections import Counter
import argparse,json
from proof_snapshot import checked,canonical_sha,sha
HERE=Path(__file__).resolve().parent

def main():
    assert __debug__
    ap=argparse.ArgumentParser();ap.add_argument('--certificates',type=Path,default=HERE/'rank16_certificates.jsonl')
    ap.add_argument('--ledgers',type=Path,nargs='+',required=True)
    ap.add_argument('--trace-report',type=Path,required=True);ap.add_argument('--report',type=Path,required=True)
    args=ap.parse_args();frozen=checked()
    assert sha(args.certificates)==frozen['inputs']['rank16_certificates.jsonl']
    records=[json.loads(x)for x in args.certificates.read_text().splitlines()]
    assert len(records)==9268 and [r['state']for r in records]==list(range(9268))
    assert all(r['certificate']is not None for r in records)
    trace=json.loads(args.trace_report.read_text())
    assert trace['status']=='PASS_COMPLETE_TRACE_REPLAY'
    assert trace['proof_sha256']==frozen['proof_sha256'] and trace['input_sha256']==frozen['inputs']
    assert trace['counts']['placements']==12257 and trace['counts']['matrix_states']==9268
    seen=set();raw=retained=0;digests={}
    for path in args.ledgers:
        assert path.name not in digests;digests[path.name]=sha(path)
        for line in path.read_text().splitlines():
            row=json.loads(line);state=row['state'];assert state not in seen and 0<=state<9268
            assert row['status']=='PASS_EXACT_CERTIFICATE'
            assert row['proof_sha256']==frozen['proof_sha256']
            assert row['certificate_sha256']==canonical_sha(records[state])
            assert row['base_rows_regenerated']==records[state]['base_rows']
            assert row['retained_rows']==records[state]['rows']
            seen.add(state);raw+=row['base_rows_regenerated'];retained+=row['retained_rows']
    assert seen==set(range(9268)),sorted(set(range(9268))-seen)[:20]
    report={'status':'PASS_COMPLETE_EXCLUSION','dimension':5400,'rank':16,
            'complex_algebra':'C^8+M2+M2','expected_states':9268,'closed_records':9268,
            'exact_replays_checked':len(seen),'open_records':0,'base_rows_regenerated':raw,
            'retained_rows':retained,'proof_sha256':frozen['proof_sha256'],
            'certificate_file_sha256':sha(args.certificates),'ledger_sha256':digests,
            'certificate_histogram':dict(Counter(r['certificate']['kind']for r in records)),
            'trace_replay':trace}
    args.report.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
