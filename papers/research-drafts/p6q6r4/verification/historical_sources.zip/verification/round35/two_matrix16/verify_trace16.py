"""Regenerate the complete rank16 input and full-field/involution trace stage."""
from pathlib import Path
from collections import Counter
from itertools import combinations_with_replacement
import argparse,json,time
from generate_inputs import enumerate_inputs
from canonical_input_counts import coefficients,PALETTE,N
from trace_two_matrix import analyze
from proof_snapshot import checked,sha
HERE=Path(__file__).resolve().parent

def main():
    assert __debug__
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    start=time.monotonic();frozen=checked()
    pp,rr,inventory,counts,admitted=enumerate_inputs();dp=coefficients()
    assert len(pp)==dp[11][N-1]==6547 and admitted==6455 and len(rr)==12257
    for a,b in combinations_with_replacement(PALETTE,2):
        n=N-1-2*a-2*b
        assert counts[a,b]==(dp[7][n]if n>=0 else 0)
    assert rr==json.loads((HERE/'input12257.json').read_text())
    old=[json.loads(x)for x in(HERE/'trace_two_matrix.jsonl').read_text().splitlines()]
    assert len(old)==12257
    totals=Counter()
    for index,record in enumerate(rr):
        actual=analyze(record);actual['placement_index']=index
        assert json.loads(json.dumps(actual))==old[index],index
        totals['placements']+=1;totals['excluded']+=actual['excluded'];totals.update(actual['statistics'])
        if index%500==0:print('trace placement',index,'seconds',round(time.monotonic()-start,2),flush=True)
    assert dict(totals)=={'placements':12257,'excluded':9609,'linear_assignments':65580,
                         'determinant_pass':8729,'linear_covariance_exclusions':1773,
                         'retained_assignments':4747,'matrix_states':9268}
    report={'status':'PASS_COMPLETE_TRACE_REPLAY','profiles':6547,'admitted_profiles':6455,
            'counts':dict(totals),'proof_sha256':frozen['proof_sha256'],
            'input_sha256':frozen['inputs'],'seconds':time.monotonic()-start}
    args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
