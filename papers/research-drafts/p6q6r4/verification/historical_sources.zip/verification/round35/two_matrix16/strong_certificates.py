"""Exact canonical support semigroups using source duality and regular trace."""
from two_matrix_words import scalar_real
from two_matrix_rows import quadratic_matrix_choices,add,scale,mul,conj

def regular_value(pieces,row):
    sd,d,values=row
    return d+sum((2 if p[2].startswith('matrix') else 1)*v[0]
                 for p,v in zip(pieces,values))

def canonical_columns(pieces):
    columns=set()
    for a,k,label in pieces:
        if label.startswith('matrixquad:'):
            D=int(label.split(':')[1]);m=2;real=D>0
        elif label.startswith('matrix'):
            m=2;real=True
        else:
            m=1;real=scalar_real(label)
        columns.add((a,m,real))
    return tuple(sorted(columns))

def support_certificate(pieces,rows):
    regular=[regular_value(pieces,row) for row in rows]
    for a,m,real in canonical_columns(pieces):
        remainder=a-m
        coins=sorted({(d if sd or not real else 2*d)
                      for (sd,d,v),lam in zip(rows,regular) if lam>=m
                      and (d if sd or not real else 2*d)<=remainder})
        bits=1;mask=(1<<(remainder+1))-1
        for coin in coins:
            for n in range(coin,remainder+1):
                if (bits>>(n-coin))&1:bits|=1<<n
        if not (bits>>remainder)&1:
            return {'kind':'regular_duality_canonical_remainder',
                    'degree':a,'multiplicity':m,'selfdual_column':real,
                    'remainder':remainder,'eligible_coins':coins}
    return None

def matrix_atom_central(pieces,row,pair_atom):
    sd,d,values=row
    for (a,k,label),(s,t,b) in zip(pieces,values):
        if label in ('matrixO','matrixS'):
            if pair_atom:
                if t%2:return False
            elif s%2 or 2*t!=s*s:return False
        elif label.startswith('matrixquad:'):
            _,DD,kind=label.split(':');D=int(DD)
            possibilities=quadratic_matrix_choices(5400//a,D,kind,sd).get((s,t,b),())
            good=False
            for alpha,beta,gamma in possibilities:
                star_alpha=conj(alpha,D) if D<0 else alpha
                star_beta=conj(beta,D) if D<0 else beta
                if pair_atom:
                    ss=add(alpha,star_alpha)
                    if any(v%2 for v in ss):continue
                    tt=add(add(mul(alpha,alpha,D),mul(star_alpha,star_alpha,D)),
                           add(scale(gamma,2),scale(add(beta,star_beta),-2)))
                    pure=add(scale(tt,2),scale(mul(ss,ss,D),-1))
                else:
                    if any(v%2 for v in alpha):continue
                    pure=add(scale(gamma,2),scale(mul(alpha,star_alpha,D),-1))
                if pure==(0,0):good=True;break
            if not good:return False
    return True

def forced_atom_certificate(pieces,rows):
    regular=[regular_value(pieces,row) for row in rows]
    for a,m,real in canonical_columns(pieces):
        remainder=a-m
        eligible=[row for row,lam in zip(rows,regular) if lam>=m
                  and (row[1] if row[0] or not real else 2*row[1])<=remainder]
        coins=sorted({row[1] if row[0] or not real else 2*row[1] for row in eligible})
        if not coins or remainder>=2*min(coins):continue
        candidates=[row for row in eligible
                    if (row[1] if row[0] or not real else 2*row[1])==remainder]
        if not any(matrix_atom_central(pieces,row,real and not row[0]) for row in candidates):
            return {'kind':'forced_central_atom','degree':a,'multiplicity':m,
                    'selfdual_column':real,'remainder':remainder,
                    'eligible_coins':coins,'candidate_rows':len(candidates)}
    return None
