"""Release row-specific memo tables between independent proof states.

Every listed function is a pure mathematical function. Clearing its cache
changes only memory use; the next call recomputes the same exact value.
Small fixed-field bases and polynomial catalogues remain cached.
"""
import gc,sys
CACHES={
 'two_matrix_rows':('options','quadratic_matrix_choices','norm_box'),
 'two_matrix_words':('rational_determinants','rational_words','quadratic_words'),
 'fixed_field_rows':('fixed_orbit_pairs','rational_group_pairs','subgroup_pairs'),
 'power_trace_filter':('scalar_power_options','rational_multisets'),
 'field_power_polynomials':('field_power_options',),
 'coupled_rows':('rational_pairs',),
}

def clear_state_caches():
    for name,functions in CACHES.items():
        module=sys.modules.get(name)
        if module is None:continue
        for function in functions:
            getattr(module,function).cache_clear()
    gc.collect()
