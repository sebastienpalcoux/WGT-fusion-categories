"""Independent subgroup-closure audit of every large repeated-block field list."""
from generic_fields import fields,forms
from field_discriminant_profiles import kronecker
from collections import Counter
from functools import lru_cache
from math import gcd
from pathlib import Path
import hashlib,json,time
HERE=Path(__file__).resolve().parent

@lru_cache(None)
def all_subgroups(c):
    units=tuple(a for a in range(c)if gcd(a,c)==1)
    known={frozenset({1})};queue=[frozenset({1})]
    for h in queue:
        for a in units:
            if a in h:continue
            generated=set(h);power=a
            while power not in h:
                generated.update(power*b%c for b in h);power=power*a%c
            new=frozenset(generated)
            if new not in known:known.add(new);queue.append(new)
    assert frozenset(units)in known
    return tuple(known)

def lifted_kernel(label,c):
    units=[a for a in range(c)if gcd(a,c)==1]
    if label=='Q':return frozenset(units)
    if label=='Q(sqrt(-3))':label='quadratic_disc=-3'
    if label.startswith('quadratic_disc='):
        delta=int(label.split('=')[1]);return frozenset(a for a in units if kronecker(delta,a)==1)
    if label=='real_cubic_conductor9':return frozenset(a for a in units if a%9 in(1,8))
    cstr,hstr=label.split(':H=');ambient=int(cstr[4:]);h=set(map(int,hstr.split(',')))
    assert c%ambient==0
    return frozenset(a for a in units if a%ambient in h)

start=time.monotonic();inventory=set()
for record in json.loads((HERE/'input12257.json').read_text()):
    counts=Counter(record['profile'])
    for degree in record['nonlinear_degrees']:counts[degree]-=2
    assert sum(counts.values())==7 and all(k>=0 for k in counts.values())
    inventory.update((5400//a,k)for a,k in counts.items()if k)
blocks=sorted((f,k)for f,k in inventory if k>=3)
records=[]
for f,k in blocks:
    c=gcd(2*f,f*f);units=forms.phi(c);actual={h for h in all_subgroups(c)if units//len(h)<=k}
    listed={lifted_kernel(r[0],c)for r in fields(f,k)}
    if f==6:
        permitted={lifted_kernel('Q',c),lifted_kernel('Q(sqrt(-3))',c)}
        actual&=permitted
    assert listed==actual,(f,k,c,len(listed),len(actual),actual-listed,listed-actual)
    records.append({'f':f,'k':k,'conductor_bound':c,'fields':len(actual),'all_subgroups':len(all_subgroups(c))})
result={'status':'PASS','blocks_checked':len(records),'records':records,
        'input_sha256':hashlib.sha256((HERE/'input12257.json').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'field_catalogue_sha256':hashlib.sha256((HERE/'generic_fields.py').read_bytes()).hexdigest(),
        'seconds':time.monotonic()-start}
(HERE/'field_options_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
