"""Check recursive row enumeration by an independent meet-in-the-middle join."""
from pathlib import Path
from itertools import product
from collections import defaultdict
from math import prod
import hashlib,json,time
from two_matrix_rows import options,rows_for,build_pieces
from strong_certificates import regular_value
HERE=Path(__file__).resolve().parent

def independent_rows(pieces,q6,sd,d):
    choices=[options(p,d,sd,q6)for p in pieces]
    if any(not c for c in choices):return set(),0
    # Balance the Cartesian products using only their cardinalities.
    left=[];right=[];nl=nr=1
    for i in sorted(range(len(pieces)),key=lambda i:len(choices[i]),reverse=True):
        if nl<=nr:left.append(i);nl*=len(choices[i])
        else:right.append(i);nr*=len(choices[i])
    if max(nl,nr)>2000000:return None,nl+nr
    table=defaultdict(list);target=5400-d*d
    for values in product(*(choices[i]for i in left)):
        norm=sum(pieces[i][0]*v[1]for i,v in zip(left,values))
        if norm<=target:
            trace=sum(pieces[i][0]*v[0]for i,v in zip(left,values))
            table[trace,norm].append(values)
    result=set()
    for right_values in product(*(choices[i]for i in right)):
        norm=sum(pieces[i][0]*v[1]for i,v in zip(right,right_values))
        if norm>target:continue
        trace=sum(pieces[i][0]*v[0]for i,v in zip(right,right_values))
        for left_values in table.get((-d-trace,target-norm),()):
            values=[None]*len(pieces)
            for i,v in zip(left,left_values):values[i]=v
            for i,v in zip(right,right_values):values[i]=v
            values=tuple(values);row=(sd,d,values)
            if not 0<=regular_value(pieces,row)<=15*(d-1):continue
            if all(abs(s)==t for s,t,b in values):continue
            result.add(row)
    return result,nl+nr

def main():
    start=time.monotonic();data=[json.loads(x)for x in(HERE/'trace_two_matrix.jsonl').read_text().splitlines()]
    selected={}
    for case in data:
        for ai,assignment in enumerate(case['assignments']):
            for mi,matrix in enumerate(assignment['matrix_options']):
                family=matrix['field'],matrix['kind']
                selected.setdefault(family,(case,ai,mi))
    rows=[];cases=total=compared=skipped=0
    for family,(case,ai,mi)in sorted(selected.items()):
        assignment=case['assignments'][ai];matrix=assignment['matrix_options'][mi]
        pieces=build_pieces(assignment,case['nonlinear_degrees'],matrix)
        recursive=list(rows_for(pieces,assignment['q6']))
        samples=sorted({(sd,d) for sd,d,v in recursive})
        # Include empty and small-dimension boundary slices as well as
        # occupied slices spread over the dimension range.
        wanted={(True,3),(False,3),(True,8),(False,5),(True,72),(False,51)}
        if samples:
            wanted.update(samples[i]for i in {0,len(samples)//3,2*len(samples)//3,len(samples)-1})
        positive=0
        for sd,d in sorted(wanted):
            direct,cartesian=independent_rows(pieces,assignment['q6'],sd,d)
            if direct is None:skipped+=1;continue
            expected={r for r in recursive if r[:2]==(sd,d)}
            assert direct==expected,(family,sd,d,len(direct),len(expected))
            cases+=1;total+=cartesian;compared+=len(direct);positive+=bool(direct)
        rows.append({'field':family[0],'kind':family[1],'placement':case['placement_index'],
                     'positive_dimension_slices':positive,'base_rows':len(recursive)})
    assert cases>=60 and compared>0
    report={'status':'PASS','families':len(selected),'dimension_slices_checked':cases,
            'large_slices_skipped':skipped,'matched_rows':compared,
            'cartesian_half_assignments':total,'records':rows,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'row_generator_sha256':hashlib.sha256((HERE/'two_matrix_rows.py').read_bytes()).hexdigest(),
            'input_sha256':hashlib.sha256((HERE/'trace_two_matrix.jsonl').read_bytes()).hexdigest(),
            'seconds':time.monotonic()-start}
    (HERE/'row_enumeration_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='records'},indent=2))

if __name__=='__main__':main()
