#!/usr/bin/env python3
"""Exact independent audits of the central-remainder projection tests.

Uses actual Rep(A5) fusion products, rational symmetric matrices,
real quadratic/cubic fields, and paired complex matrix blocks.
These checks supplement the written proof, not an endpoint exclusion.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from random import Random
import hashlib,json,time

HERE=Path(__file__).resolve().parent

def add(a,b): return (a[0]+b[0],a[1]+b[1])
def neg(a): return (-a[0],-a[1])
def mul(a,b,rad): return (a[0]*b[0]+rad*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,c): return (a[0]*c,a[1]*c)
def conjugate(a): return (a[0],-a[1])
def rational(a):
 assert a[1]==0 and a[0].denominator==1,a
 return int(a[0])
ZERO=(F(0),F(0));ONE=(F(1),F(0))

def scalar_trace(a): return sum(a[i][i] for i in range(len(a)))
def scalar_mm(a,b): return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]
def scalar_q(a):
 n=len(a);s=scalar_trace(a);t=scalar_trace(scalar_mm(a,a))
 return s,t,n*t-s*s

def heron(q):
 a,b,c=q
 return 2*(a*b+b*c+c*a)-(a*a+b*b+c*c)

def matrix_checks():
 rng=Random(54003501);cases=0;strict=0
 for n in (1,2,3,4,6):
  for _ in range(80):
   def symmetric():
    a=[[0]*n for _ in range(n)]
    for i in range(n):
     for j in range(i,n): a[i][j]=a[j][i]=rng.randrange(-5,6)
    return a
   a,b=symmetric(),symmetric();lam=rng.randrange(-7,8)
   c=[[lam*(i==j)-a[i][j]-b[i][j] for j in range(n)] for i in range(n)]
   data=[scalar_q(x) for x in (a,b,c)]
   assert all(q>=0 for s,t,q in data)
   assert sum(s for s,t,q in data)==n*lam
   h=heron([q for s,t,q in data]);assert h>=0
   strict+=h>0
   # Direct projected-matrix Gram determinant, separately evaluated.
   u=[[[F(n*x[i][j]-(s if i==j else 0),n) for j in range(n)] for i in range(n)] for x,(s,t,q) in zip((a,b,c),data)]
   gram=[[n*sum(u[i][r][k]*u[j][r][k] for r in range(n) for k in range(n)) for j in range(2)] for i in range(2)]
   assert h==4*(gram[0][0]*gram[1][1]-gram[0][1]**2)
   z=[[lam*(i==j)-a[i][j] for j in range(n)] for i in range(n)]
   assert scalar_q(a)[2]==scalar_q(z)[2]
   cases+=1
 # Three nonnegative squared lengths that cannot close.
 assert heron([1,1,9])<0
 return {'closed_symmetric_matrix_triples':cases,'strict_triangle_cases':strict}

def complex_checks():
 rng=Random(54003502);cases=0
 for _ in range(160):
  a=[[(F(rng.randrange(-4,5)),F(rng.randrange(-4,5))) for j in range(2)] for i in range(2)]
  def mm(x,y):
   return [[add(mul(x[i][0],y[0][j],-1),mul(x[i][1],y[1][j],-1)) for j in range(2)] for i in range(2)]
  def tr(x): return add(x[0][0],x[1][1])
  ast=[[conjugate(a[j][i]) for j in range(2)] for i in range(2)]
  b=[[add(a[i][j],ast[i][j]) for j in range(2)] for i in range(2)]
  # Orbit consists of A and its entrywise complex conjugate.
  s=2*tr(a)[0];t=2*tr(mm(a,ast))[0];p2=2*tr(mm(a,a))[0]
  sb=2*tr(b)[0];tb=2*tr(mm(b,b))[0]
  assert sb==2*s and tb==2*(t+p2)
  assert 4*tb-sb*sb>=0
  cases+=1
 # The rational two-dimensional determinant shortcut.
 for a,b,c,d in product(range(-2,3),repeat=4):
  x=[[a,b],[c,d]];y=[[2*a,b+c],[b+c,2*d]]
  t=a*a+b*b+c*c+d*d;det=a*d-b*c
  assert scalar_q(y)[2]==4*(t-2*det)
 return {'paired_complex_matrix_atoms':cases,'rational_matrix_pair_atoms':625}

def cubic_mul(a,b):
 z=[0]*5
 for i,x in enumerate(a):
  for j,y in enumerate(b):z[i+j]+=x*y
 for k in (4,3):
  z[k-2]+=3*z[k];z[k-3]-=z[k]
 return tuple(z[:3])
def cubic_trace(a):return 3*a[0]+6*a[2]

def field_checks():
 rng=Random(54003503);quad=0;cubic=0
 for d in (2,3,5,13):
  for _ in range(100):
   pairs=[(rng.randrange(-5,6),rng.randrange(-5,6)) for j in range(2)]
   pairs.append((rng.randrange(-5,6)-pairs[0][0]-pairs[1][0],-pairs[0][1]-pairs[1][1]))
   qs=[]
   for a,b in pairs:
    s=2*a;t=2*(a*a+d*b*b);q=2*t-s*s
    assert q==4*d*b*b;qs.append(q)
   assert heron(qs)==0
   quad+=1
 for _ in range(240):
  a=tuple(rng.randrange(-4,5) for i in range(3));b=tuple(rng.randrange(-4,5) for i in range(3));lam=rng.randrange(-7,8)
  c=tuple(lam*(i==0)-a[i]-b[i] for i in range(3));qs=[];ss=[]
  for x in (a,b,c):
   s=cubic_trace(x);t=cubic_trace(cubic_mul(x,x));q=3*t-s*s
   assert q>=0;qs.append(q);ss.append(s)
  assert sum(ss)==3*lam and heron(qs)>=0
  cubic+=1
 return {'real_quadratic_closing_triples':quad,'real_cubic_closing_triples':cubic}

def a5_checks():
 half=F(1,2);phi=(half,half);phibar=(half,-half)
 q=lambda n:(F(n),F(0))
 chars=[list(map(q,[1,1,1,1,1])),[q(3),q(-1),q(0),phi,phibar],[q(3),q(-1),q(0),phibar,phi],list(map(q,[4,0,1,-1,-1])),list(map(q,[5,1,-1,0,0]))]
 sizes=[1,15,20,12,12];dims=[1,3,3,4,5]
 fusion=[[[0]*5 for j in range(5)] for i in range(5)]
 for i,j,k in product(range(5),repeat=3):
  z=ZERO
  for c,w in enumerate(sizes):z=add(z,scale(mul(mul(chars[i][c],chars[j][c],5),chars[k][c],5),F(w,60)))
  fusion[i][j][k]=rational(z);assert fusion[i][j][k]>=0
 for i,j,k,l in product(range(5),repeat=4):
  assert sum(fusion[i][j][a]*fusion[a][k][l] for a in range(5))==sum(fusion[j][k][a]*fusion[i][a][l] for a in range(5))
 def prod(a,b):return [sum(a[i]*b[j]*fusion[i][j][k] for i,j in product(range(5),repeat=2)) for k in range(5)]
 results=[]
 for coefficients in ([0,0,0,1,0],[0,0,0,0,1],[0,1,1,0,0],[0,1,1,1,0]):
  eig=[]
  for c in range(5):
   x=ZERO
   for i in range(5):x=add(x,scale(chars[i][c],coefficients[i]))
   eig.append(rational(x))
  dim=sum(x*d for x,d in zip(coefficients,dims));assert eig[0]==dim
  roots=sorted(set(eig[1:]));gap=1;poly=[1,0,0,0,0]
  for lam in roots:
   gap*=dim-lam
   nxt=prod(coefficients,poly);poly=[x-lam*y for x,y in zip(nxt,poly)]
  assert gap%60==0 and poly==[gap*d//60 for d in dims]
  atom_data=[]
  for i,mult in enumerate(coefficients):
   for _ in range(mult):
    s=rational(add(chars[i][3],chars[i][4]));t=rational(add(mul(chars[i][3],chars[i][3],5),mul(chars[i][4],chars[i][4],5)))
    atom_data.append((s,t,2*t-s*s))
  assert sum(s for s,t,qv in atom_data)%2==0
  if len(atom_data)==1:assert atom_data[0][2]==0
  if len(atom_data)==2:assert atom_data[0][2]==atom_data[1][2]
  if len(atom_data)==3:assert heron([qv for s,t,qv in atom_data])>=0
  results.append({'source_coefficients':coefficients,'dimension':dim,'distinct_nonperron_eigenvalues':roots,'gap_product':gap,'unit_coefficient_of_annihilator':poly[0],'quadratic_atom_q':[qv for s,t,qv in atom_data]})
 return {'fusion_ring':'Rep(A5)','dimension':60,'fusion_coefficients_checked':125,'associativity_equalities':625,'positive_rational_spectrum_elements':results}

def main():
 assert __debug__
 started=time.monotonic()
 report={'status':'PASS','matrix':matrix_checks(),'complex':complex_checks(),'fields':field_checks(),'actual_fusion_ring':a5_checks(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'proof_sha256':hashlib.sha256((HERE/'r35_central_remainder_geometry.tex').read_bytes()).hexdigest(),'scope':'Independent finite exact audits supplement the general proof; no 5400 endpoint exclusion is inferred from these examples.'}
 report['seconds']=time.monotonic()-started
 (HERE/'central_remainder_geometry_verification.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
