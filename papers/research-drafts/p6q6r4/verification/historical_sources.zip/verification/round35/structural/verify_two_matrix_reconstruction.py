#!/usr/bin/env python3
"""Independent exact commutator and reconstruction audits.

The group law supplies controls, then is withheld from reconstruction:
that routine receives only c, duality, and the complete linear table.
All calculations use the Python standard library and exact rationals.
Finite controls supplement, and do not replace, the written proof.
"""
from fractions import Fraction as F
from itertools import product, permutations
from math import isqrt
from pathlib import Path
import hashlib, json, time

HERE = Path(__file__).resolve().parent

def rref(rows):
    a = [list(map(F, row)) for row in rows]
    if not a:
        return a, []
    pivots = []; r = 0
    for j in range(len(a[0])):
        p = next((i for i in range(r, len(a)) if a[i][j]), None)
        if p is None:
            continue
        a[r], a[p] = a[p], a[r]
        z = a[r][j]; a[r] = [v/z for v in a[r]]
        for i in range(len(a)):
            if i != r and a[i][j]:
                z = a[i][j]; a[i] = [x-z*y for x,y in zip(a[i], a[r])]
        pivots.append(j); r += 1
        if r == len(a):
            break
    return a, pivots

def nullspace(a, n=None):
    if n is None:
        n = len(a[0])
    rr, piv = rref(a)
    ans = []
    for j in range(n):
        if j in piv:
            continue
        v = [F(0)]*n; v[j] = F(1)
        for i,p in enumerate(piv):
            v[p] = -rr[i][j]
        ans.append(v)
    return ans

def eye(n):
    return [[F(i == j) for j in range(n)] for i in range(n)]

def transpose(a):
    return [list(row) for row in zip(*a)]

def mm(a,b):
    bt = transpose(b)
    return [[sum(x*y for x,y in zip(row,col)) for col in bt] for row in a]

def mv(a,v):
    return [sum(x*y for x,y in zip(row,v)) for row in a]

def inverse(a):
    n = len(a)
    rr,p = rref([row+erow for row,erow in zip(a,eye(n))])
    assert p == list(range(n))
    return [row[n:] for row in rr]

def squareclass(x):
    """Return signed squarefree D and rational q with x = D*q*q."""
    x = F(x); assert x
    z = x.numerator*x.denominator; sign = 1 if z > 0 else -1
    z = abs(z); d = 1; p = 2
    while p*p <= z:
        k = 0
        while z % p == 0:
            z //= p; k += 1
        if k % 2:
            d *= p
        p += 1
    d *= z; d *= sign
    q2 = x/d
    q = F(isqrt(q2.numerator),isqrt(q2.denominator))
    assert q*q == q2
    return d,q

class Q:
    """Exact element a+b*sqrt(D); D is fixed within each audit case."""
    D = 1
    def __init__(self,a=0,b=0):
        if isinstance(a,Q):
            self.a,self.b = a.a,a.b
        else:
            self.a,self.b = F(a),F(b)
        if self.D == 1:
            self.a += self.b; self.b = F(0)
    def __add__(self,other):
        o = Q(other); return Q(self.a+o.a,self.b+o.b)
    __radd__ = __add__
    def __neg__(self):
        return Q(-self.a,-self.b)
    def __sub__(self,other):
        return self+-Q(other)
    def __rsub__(self,other):
        return Q(other)+-self
    def __mul__(self,other):
        o = Q(other)
        return Q(self.a*o.a+self.D*self.b*o.b,self.a*o.b+self.b*o.a)
    __rmul__ = __mul__
    def __truediv__(self,other):
        o=Q(other); den=o.a*o.a-self.D*o.b*o.b; assert den
        return self*Q(o.a/den,-o.b/den)
    def __rtruediv__(self,other):
        return Q(other)/self
    def __eq__(self,other):
        o=Q(other); return self.a==o.a and self.b==o.b
    def __bool__(self):
        return bool(self.a or self.b)
    def __repr__(self):
        return f'({self.a})+({self.b})sqrt({self.D})'

def make_group(name, elements, law, linears=None):
    index = {x:i for i,x in enumerate(elements)}
    table = [[index[law(x,y)] for y in elements] for x in elements]
    n = len(elements)
    assert table[0] == list(range(n))
    assert [row[0] for row in table] == list(range(n))
    inv = [next(j for j in range(n) if table[i][j]==table[j][i]==0) for i in range(n)]
    for a,b,c in product(range(n),repeat=3):
        assert table[table[a][b]][c] == table[a][table[b][c]]
    return {'name':name,'table':table,'inverse':inv,'linears':linears}

def dihedral(n):
    elements = list(product(range(n),range(2)))
    law = lambda x,y: ((x[0]+(-1)**x[1]*y[0])%n,(x[1]+y[1])%2)
    chars = [[((-1)**(u*a+v*b),0) for a,b in elements]
             for u in (range(2) if n%2==0 else range(1)) for v in range(2)]
    return make_group('D'+str(2*n),elements,law,chars)

def dicyclic3():
    elements=list(product(range(6),range(2)))
    law=lambda x,y: ((x[0]+(-1)**x[1]*y[0]+3*x[1]*y[1])%6,(x[1]+y[1])%2)
    ipow=[(1,0),(0,1),(-1,0),(0,-1)]
    chars=[[(ipow[(k*b)%4][0]*(-1)**(k*a),ipow[(k*b)%4][1]*(-1)**(k*a)) for a,b in elements] for k in range(4)]
    return make_group('Dic3',elements,law,chars)

def pauli16():
    elements=list(product(range(4),range(2),range(2)))
    law=lambda x,y: ((x[0]+y[0]+2*x[2]*y[1])%4,(x[1]+y[1])%2,(x[2]+y[2])%2)
    chars=[[((-1)**(u*a+v*b+w*c),0) for a,b,c in elements] for u,v,w in product(range(2),repeat=3)]
    return make_group('Pauli16',elements,law,chars)

def permutation_group(n, even=False):
    def sign(p):
        return (-1)**sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))
    elements=[p for p in permutations(range(n)) if not even or sign(p)==1]
    return make_group(('A' if even else 'S')+str(n),elements,lambda x,y:tuple(x[y[i]] for i in range(n)))

def gaussian_mul(x,y):
    return (x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0])

def rational_gaussian_sum(values, denominator):
    a=sum(x for x,y in values); b=sum(y for x,y in values)
    assert b==0
    return F(a,denominator)

def commutator_data(group):
    table=group['table']; inv=group['inverse']; n=len(table)
    c=[[[int(table[table[x][a]][b]==0)-int(table[table[a][x]][b]==0)
         for b in range(n)] for a in range(n)] for x in range(n)]
    pairs=[(a,b) for a in range(n) for b in range(a+1,n)]
    bmat=[[c[x][a][b] for a,b in pairs] for x in range(n)]
    gram=mm(bmat,transpose(bmat))
    classes=[]; unseen=set(range(n))
    while unseen:
        x=min(unseen)
        cl={table[table[g][x]][inv[g]] for g in range(n)}
        unseen-=cl; classes.append(cl)
    cls={x:cl for cl in classes for x in cl}
    expected=[[F(n*(x==y))- (F(n,len(cls[x])) if y in cls[x] else 0)
               for y in range(n)] for x in range(n)]
    assert gram==expected
    assert mm(gram,gram)==[[n*x for x in row] for row in gram]
    assert len(rref(gram)[1])==n-len(classes)
    assert sum(c[x][y][z]**2 for x in range(n) for y in range(x+1,n) for z in range(y+1,n))==F(n*(n-len(classes)),3)
    for x,y,z in product(range(n),repeat=3):
        assert c[x][y][z]==c[y][z][x]==-c[y][x][z]
        assert c[inv[x]][inv[y]][inv[z]]==-c[x][y][z]
        assert c[x][y][inv[z]]==int(table[x][y]==z)-int(table[y][x]==z)
    assert all(sum(c[x][y][z] for x in range(n))==0 for y,z in product(range(n),repeat=2))
    return c,gram,{'group':group['name'],'order':n,'conjugacy_classes':len(classes),
                   'gram_rank':n-len(classes),'gram_nonzero_eigenvalues':([n] if n>len(classes) else []),
                   'unordered_tensor_norm':int(F(n*(n-len(classes)),3)),
                   'associativity_control_equalities':n**3,'tensor_equalities':n**3}

def reconstruct(c, inv, linears):
    """Reconstruct using ONLY the three data specified in the theorem."""
    n=len(c); ell=len(linears); assert n==ell+8
    # Every linear formal codegree is recovered from its complete row.
    codegrees=[sum(a*a+b*b for a,b in chi) for chi in linears]
    assert codegrees==[n]*ell
    pairs=[(a,b) for a in range(n) for b in range(a+1,n)]
    gram=mm([[c[x][a][b] for a,b in pairs] for x in range(n)],
            transpose([[c[x][a][b] for a,b in pairs] for x in range(n)]))
    piv=rref(gram)[1]; assert len(piv)==6
    # The repeated nonzero eigenvalue follows from G^2=mu G.
    mu=F(sum(gram[i][i] for i in range(n)),6)
    assert mm(gram,gram)==[[mu*x for x in row] for row in gram]
    f=mu/2
    plin=[[rational_gaussian_sum([gaussian_mul((chi[x][0],-chi[x][1]),chi[y])
                                  for chi in linears],n) for y in range(n)] for x in range(n)]
    assert mm(plin,plin)==plin
    pure=[[F(x)/mu for x in row] for row in gram]
    pw=[[F(x==y)-pure[x][y]-plin[x][y] for y in range(n)] for x in range(n)]
    assert mm(pw,pw)==pw and len(rref(pw)[1])==2
    e=[F(x==0)-plin[x][0] for x in range(n)]
    t=e[0]; assert t==4/f
    v=None
    for col in transpose(pw):
        z=[x-col[0]/t*y for x,y in zip(col,e)]
        if any(z):
            v=z; break
    assert v is not None and v[0]==0
    beta=lambda x,y:sum(x[i]*y[inv[i]] for i in range(n))
    g=beta(v,v); assert g
    dcenter,_=squareclass(f*g)
    Q.D=dcenter
    du,qu=squareclass(1/(f*g)); assert du==dcenter
    u=Q(qu) if dcenter==1 else Q(0,qu)
    central=[[Q(x)/2+sign*u*y for x,y in zip(e,v)] for sign in (1,-1)]
    assert all(beta(z,z)==2/f for z in central)
    assert beta(central[0],central[1])==0
    # A rational basis of L from G, with a rational coordinate left inverse.
    vb=[[F(gram[x][j]) for j in piv] for x in range(n)]
    anchors=rref(transpose(vb))[1]; assert len(anchors)==6
    left=inverse([vb[x] for x in anchors])
    coords=lambda x:mv(left,[x[i] for i in anchors])
    brackets=[]
    for i in range(6):
        row=[]
        for j in range(6):
            bv=[sum(vb[x][i]*vb[y][j]*c[x][y][inv[z]]
                    for x,y in product(range(n),repeat=2) if vb[x][i] and vb[y][j]) for z in range(n)]
            bc=coords(bv); assert mv(vb,bc)==bv; row.append(bc)
        brackets.append(row)
    ads=[[[brackets[i][j][k] for j in range(6)] for k in range(6)] for i in range(6)]
    beta_l=[[beta([row[i] for row in vb],[row[j] for row in vb]) for j in range(6)] for i in range(6)]
    for i,j in product(range(6),repeat=2):
        aa=mm(ads[i],ads[j])
        assert sum(aa[k][k] for k in range(6))==4*f*beta_l[i][j]
    eq=[]
    for ad in ads:
        for i,j in product(range(6),repeat=2):
            rr=[F(0)]*36
            for k in range(6):
                rr[6*i+k]+=ad[k][j]; rr[6*k+j]-=ad[i][k]
            eq.append(rr)
    cent=nullspace(eq); assert len(cent)==2
    tt=None
    for flat in cent:
        mat=[flat[6*i:6*i+6] for i in range(6)]
        tr=sum(mat[i][i] for i in range(6))/6
        mat=[[mat[i][j]-tr*(i==j) for j in range(6)] for i in range(6)]
        if any(any(row) for row in mat):
            tt=mat; break
    assert tt is not None
    tt2=mm(tt,tt); delta=tt2[0][0]; assert delta
    assert tt2==[[delta*(i==j) for j in range(6)] for i in range(6)]
    dcentroid,qd=squareclass(delta); assert dcentroid==dcenter
    root=Q(qd) if dcenter==1 else Q(0,qd)
    lie_projectors=[[[Q(i==j)/2+sign*tt[i][j]/(2*root) for j in range(6)] for i in range(6)] for sign in (1,-1)]
    for pp in lie_projectors:
        assert mm(pp,pp)==pp
        assert sum(pp[i][i] for i in range(6))==3
    assert not any(any(row) for row in mm(lie_projectors[0],lie_projectors[1]))
    uparts=[]
    for pp in lie_projectors:
        uparts.append([mv(vb,mv(pp,coords([pure[z][x] for z in range(n)]))) for x in range(n)])
    # Complete linear contributions remain rational even when individual
    # linear values lie in Q(i), as in the dicyclic control.
    linear_products=[[[rational_gaussian_sum([
        gaussian_mul(gaussian_mul(chi[x],chi[y]),(chi[z][0],-chi[z][1]))
        for chi in linears],n) for z in range(n)] for y in range(n)] for x in range(n)]
    candidates=[]
    for attachment in ((0,1),(1,0)):
        table=[]
        for x in range(n):
            row=[]
            for y in range(n):
                result=[Q(linear_products[x][y][z])+F(c[x][y][inv[z]],2) for z in range(n)]
                for i,j in enumerate(attachment):
                    ei=central[i]; ux=uparts[j][x]; uy=uparts[j][y]
                    ax=ei[inv[x]]/(2/f); ay=ei[inv[y]]/(2/f)
                    scalar=ax*ay+(f/2)*beta(ux,uy)
                    result=[z+scalar*ez+ax*uyz+ay*uxz for z,ez,uxz,uyz in zip(result,ei,ux,uy)]
                assert result[0]==int(y==inv[x])
                row.append(result)
            table.append(row)
        candidates.append(table)
    return candidates,{'linear_count':ell,'linear_codegrees':[int(x) for x in codegrees],
        'nonlinear_codegree':str(f),'nonlinear_center_dimension':2,
        'lie_centroid_dimension':len(cent),'field_squareclass_from_center':dcenter,
        'field_squareclass_from_centroid':dcentroid,'center_norm_g':str(g),
        'centroid_square_delta':str(delta),'candidate_tables':2,
        'input_scope':'Only the integral commutator tensor, basis inverse, and full linear table.'}

def reconstruction_control(group):
    c,gram,report=commutator_data(group)
    candidates,details=reconstruct(c,group['inverse'],group['linears'])
    original=group['table']; n=len(original)
    candidate_info=[]; matches=0
    for candidate in candidates:
        exact=all(candidate[x][y][z]==int(original[x][y]==z)
                  for x,y,z in product(range(n),repeat=3))
        rational=all(not a.b for row in candidate for vec in row for a in vec)
        integral=rational and all(a.a.denominator==1 for row in candidate for vec in row for a in vec)
        nonnegative=integral and all(a.a>=0 for row in candidate for vec in row for a in vec)
        group_table_verified=False
        if nonnegative:
            assert all(sum(vec)==1 for row in candidate for vec in row)
            ct=[[next(z for z,a in enumerate(vec) if a==1) for vec in row] for row in candidate]
            assert ct[0]==list(range(n)) and [row[0] for row in ct]==list(range(n))
            for x,y,z in product(range(n),repeat=3):
                assert ct[ct[x][y]][z]==ct[x][ct[y][z]]
                assert int(ct[ct[x][y]][z]==0)-int(ct[ct[y][x]][z]==0)==c[x][y][z]
            for x in range(n):
                assert ct[x][group['inverse'][x]]==ct[group['inverse'][x]][x]==0
            for chi in group['linears']:
                assert all(chi[ct[x][y]]==gaussian_mul(chi[x],chi[y]) for x,y in product(range(n),repeat=2))
            group_table_verified=True
        matches+=exact
        candidate_info.append({'matches_original_group_products':exact,'rational':rational,
                               'integral':integral,'nonnegative':nonnegative,
                               'all_group_axioms_and_input_data_verified':group_table_verified})
    assert matches>=1
    assert candidates[0]!=candidates[1]
    if group['name']=='Pauli16':
        # Explicit sharpness: swap only z,z^3, keeping every other label.
        perm=list(range(n)); perm[4],perm[12]=12,4
        transported=[[[int(perm[original[perm[x]][perm[y]]]==z) for z in range(n)]
                       for y in range(n)] for x in range(n)]
        assert any(cand==transported for cand in candidates)
        assert perm[original[perm[4]][perm[2]]]==14 and original[4][2]==6
    report.update(details); report['candidates']=candidate_info
    report['original_products_recovered']=n*n
    return report

def unequal_codegree_control():
    """Independent weighted M2+M2 matrix identities, not a fusion ring."""
    from random import Random
    rng=Random(35005400); count=0
    for f1,f2 in ((3,5),(4,9),(6,10),(12,15)):
        t1,t2=F(2,f1),F(2,f2); t=t1+t2
        g=t1*t2*t; u2=t1*t2/(t*g)
        assert u2==1/(t*t)
        v=(t2,-t1)
        e1=(t1/t+v[0]/t,t1/t+v[1]/t)
        e2=(t2/t-v[0]/t,t2/t-v[1]/t)
        assert e1==(1,0) and e2==(0,1)
        for f in (f1,f2):
            for _ in range(40):
                a,b,c,d,e,h=[F(rng.randrange(-5,6)) for j in range(6)]
                x=[[a,b],[c,-a]]; y=[[d,e],[h,-d]]
                xy=mm(x,y); yx=mm(y,x); trace=xy[0][0]+xy[1][1]
                beta=trace/f
                predicted=[[F(f,2)*beta*(i==j)+(xy[i][j]-yx[i][j])/2 for j in range(2)] for i in range(2)]
                assert xy==predicted
                count+=1
    return {'weighted_matrix_products_checked':count,'distinct_rational_codegree_pairs':4,
            'scope':'Weighted matrix-algebra identities only; these are not asserted to be fusion rings.'}

def main():
    assert __debug__
    started=time.monotonic()
    controls=[]
    for group in (dihedral(3),permutation_group(4,True),permutation_group(4),
                  make_group('C4',list(range(4)),lambda x,y:(x+y)%4)):
        controls.append(commutator_data(group)[2])
    reconstruction=[]
    for group in (dihedral(5),dihedral(6),dicyclic3(),pauli16()):
        reconstruction.append(reconstruction_control(group))
    report={'status':'PASS','general_gram_controls':controls,
            'full_reconstruction_controls':reconstruction,'unequal_codegrees':unequal_codegree_control(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'proof_sha256':hashlib.sha256((HERE/'r35_two_matrix_reconstruction.tex').read_bytes()).hexdigest(),
            'scope':'Exact finite controls supplement the general proof. No rank-16 or dimension-5400 endpoint exclusion follows from these examples.',
            'seconds':time.monotonic()-started}
    (HERE/'two_matrix_reconstruction_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    main()
