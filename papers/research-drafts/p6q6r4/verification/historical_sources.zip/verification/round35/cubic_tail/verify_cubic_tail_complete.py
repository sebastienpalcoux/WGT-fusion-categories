#!/usr/bin/env python3
"""Complete exact replay of the dimension-three cubic rank<=16 exclusion.

The primary weighted-budget solver and independent row-domain solver
both regenerate every case. Assertions and standard library only.
"""
from concurrent.futures import ProcessPoolExecutor
from hashlib import sha256
from pathlib import Path
import argparse,gzip,json,subprocess,sys,time

HERE=Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0,str(HERE))
EXPECTED={'P13':{14:6523,15:33190,16:144857},
          'P4_9':{14:1112,15:7023,16:34277},
          'P6_7':{14:114,15:635,16:4805}}
INPUT_SHA='53070e15e6026257af466fbf783499c306de2085a3deb1e676498f0ffb6c5620'
INDEPENDENT_HANDOFF_SHA='38d6d021f4aaa37b1be7ba66d3758bbcd0118810ac4cf47b49e67777823dfcc1'

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def primary_case(key):
    from cubic_tail_solver import p67_case,other_case
    branch,rank=key; checked=nodes=choices=0; record_hash=sha256()
    with gzip.open(HERE/'cubic_d3_raw_types.jsonl.gz','rt') as stream:
        for line in stream:
            row=json.loads(line)
            if row['rank']!=rank or branch not in row['P_branches']:
                continue
            dimensions=row['dimensions']
            result=p67_case(dimensions) if branch=='P6_7' else other_case(dimensions,branch)
            assert result['status']=='EXCLUDED_BY_NX_RELAXATION',result
            checked+=1; nodes+=result['search_states'];choices+=result['row_choices']
            record_hash.update((json.dumps(result,sort_keys=True,separators=(',',':'))+'\n').encode())
    assert checked==EXPECTED[branch][rank]
    return {'branch':branch,'rank':rank,'types':checked,'excluded_types':checked,
            'search_states':nodes,'row_choices':choices,'complete_record_sha256':record_hash.hexdigest()}

def run(script,*args,log):
    with log.open('w') as output:
        subprocess.run([sys.executable,'-B','-S',str(script),*map(str,args)],
                       check=True,cwd=script.parent,stdout=output,stderr=subprocess.STDOUT)

def main():
    assert __debug__
    parser=argparse.ArgumentParser();parser.add_argument('--workers',type=int,default=1)
    parser.add_argument('--saved-independent',action='store_true')
    args=parser.parse_args();assert args.workers>=1
    started=time.monotonic(); bound={
        'verify_cubic_tail_complete.py':digest(Path(__file__)),
        'cubic_tail_solver.py':digest(HERE/'cubic_tail_solver.py'),
        'verify_cubic_type_counts.py':digest(HERE/'verify_cubic_type_counts.py'),
        'r35_cubic_tail_exclusion.tex':digest(HERE/'r35_cubic_tail_exclusion.tex'),
        'r35_cubic_three_closure.tex':digest(HERE/'r35_cubic_three_closure.tex'),
        'independent/verify_cubic_tail_row_domains.py':digest(HERE/'independent/verify_cubic_tail_row_domains.py'),
        'independent/audit_tail_row_domain_controls.py':digest(HERE/'independent/audit_tail_row_domain_controls.py')}
    run(HERE/'verify_cubic_type_counts.py',log=HERE/'type_counts_fresh_console.txt')
    assert digest(HERE/'cubic_d3_raw_types.jsonl.gz')==INPUT_SHA
    inputs=json.loads((HERE/'cubic_type_counts.json').read_text())
    assert inputs['status']=='PASS' and inputs['dataset_records']==224776
    keys=[(branch,rank) for branch in EXPECTED for rank in (14,15,16)]
    primary=[]
    if args.workers==1:
        for key in keys:
            primary.append(primary_case(key));print(json.dumps(primary[-1]),flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            for result in pool.map(primary_case,keys):
                primary.append(result);print(json.dumps(result),flush=True)
    ind=HERE/'independent'
    if not args.saved_independent:
        run(ind/'verify_cubic_tail_row_domains.py','--branch','all','--ranks',14,15,16,
            '--input',HERE/'cubic_d3_raw_types.jsonl.gz','--output',ind/'complete_fresh_row_domains.json',
            log=ind/'complete_fresh_row_domains_console.txt')
        independent=[json.loads((ind/'complete_fresh_row_domains.json').read_text())]
    else:
        handoff_path=ind/'CUBIC_TAIL_INDEPENDENT_HANDOFF.json'
        assert digest(handoff_path)==INDEPENDENT_HANDOFF_SHA
        handoff=json.loads(handoff_path.read_text())
        assert handoff['status']=='PASS'
        for branch in EXPECTED:
            name=f'cubic_tail_{branch}_row_domain_audit.json'
            assert digest(ind/name)==handoff['files'][name]
        independent=[json.loads((ind/f'cubic_tail_{branch}_row_domain_audit.json').read_text()) for branch in EXPECTED]
    observed={}
    for report in independent:
        assert report['status']=='PASS' and report['open_count']==0
        assert report['verifier_sha256']==bound['independent/verify_cubic_tail_row_domains.py']
        assert report['source_type_input_sha256']==INPUT_SHA
        assert report['frozen_cubic_closure_proof_sha256']==bound['r35_cubic_three_closure.tex']
        for record in report['reports']:
            if record['rank'] not in (14,15,16):
                continue
            key=record['branch'],record['rank'];assert key not in observed
            assert record['types']==EXPECTED[key[0]][key[1]]
            assert len(record['records'])==record['types']
            assert record['outcomes']=={'EXCLUDED':record['types']}
            assert all(x['status']=='EXCLUDED' for x in record['records'])
            observed[key]=record['types']
    assert set(observed)==set(keys)
    run(ind/'audit_tail_row_domain_controls.py',log=ind/'control_fresh_console.txt')
    controls=json.loads((ind/'tail_row_domain_controls.json').read_text())
    assert controls['status']=='PASS'
    for name,old in bound.items():
        assert digest(HERE/name)==old,('input changed during replay',name)
    result={'status':'PASS_COMPLETE_EXCLUSION','dimension':5400,'ranks_checked':[14,15,16],
            'cubic_triple_source_dimension':3,'cubic_formal_codegree':9,
            'primary_complete_cases':sum(x['types'] for x in primary),
            'independent_complete_cases':sum(observed.values()),'distinct_dimension_types':224776,
            'open_matrices':0,'primary_reports':primary,'independent_fresh_replay':not args.saved_independent,
            'source_type_input_sha256':INPUT_SHA,'frozen_inputs_sha256':bound,
            'scope':'Conditional exact exclusion of the full conductor9/codegree9 cubic branch with source triple dimension3 through rank16. No assertion about larger triple dimensions or categorification.',
            'seconds':time.monotonic()-started}
    assert result['primary_complete_cases']==result['independent_complete_cases']==232536
    (HERE/'cubic_tail_complete_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
