#!/usr/bin/env python3
"""Exact symmetric N_X tail completion for the cubic dimension-three branch."""
from collections import Counter
from pathlib import Path
from itertools import product
from math import gcd,isqrt
import argparse,gzip,json,time

HERE=Path(__file__).resolve().parent
BASE=Counter((1,3,3,3,5,6,12))

def solve_tail(dim,p,fixed_rows,limit=1,fixed_entries=(),row_norms=None,entry_caps=None,completion_test=None):
    n=len(dim); matrix=[[-1]*n for _ in range(n)]
    budget=[3*d-12*q for d,q in zip(dim,p)]
    states=0; choices=0
    row_norms=[8-q*q for q in p] if row_norms is None else row_norms
    entry_caps={} if entry_caps is None else entry_caps
    def fix(i,j,v):
        if matrix[i][j]>=0:
            return matrix[i][j]==v
        matrix[i][j]=matrix[j][i]=v
        budget[i]-=v*dim[j]
        if i!=j:
            budget[j]-=v*dim[i]
        return budget[i]>=0 and budget[j]>=0
    for i,row in fixed_rows.items():
        for j,v in enumerate(row):
            if not fix(i,j,v):
                return [],{'search_states':0,'row_choices':0}
    for i,j,v in fixed_entries:
        if not fix(i,j,v):
            return [],{'search_states':0,'row_choices':0}
    solutions=[]
    def connected():
        seen={i for i,q in enumerate(p) if q}; stack=list(seen)
        while stack:
            i=stack.pop()
            for j,v in enumerate(matrix[i]):
                if i!=j and v and j not in seen:
                    seen.add(j); stack.append(j)
        return len(seen)==n
    def options(i):
        unknown=[j for j in range(n) if matrix[i][j]<0]
        unknown.sort(key=lambda j:dim[j],reverse=True)
        norm=row_norms[i]-sum(v*v for v in matrix[i] if v>=0)
        target=budget[i]
        if norm<0 or target<0:
            return
        caps=[]
        for j in unknown:
            cap=min(2,target//dim[j],budget[j]//dim[i]) if j!=i else min(2,target//dim[i])
            cap=min(cap,entry_caps.get((min(i,j),max(i,j)),2))
            if j!=i:
                cap=min(cap,isqrt(row_norms[j]-sum(v*v for v in matrix[j] if v>=0)))
            caps.append(cap)
        suffix=[0]*(len(unknown)+1); suffix_gcd=[0]*(len(unknown)+1)
        for k in range(len(unknown)-1,-1,-1):
            suffix[k]=suffix[k+1]+caps[k]*dim[unknown[k]]
            suffix_gcd[k]=gcd(suffix_gcd[k+1],dim[unknown[k]]) if caps[k] else suffix_gcd[k+1]
        values=[]
        def rec(k,left,norm_left):
            if k==len(unknown):
                if left==0:
                    yield tuple(zip(unknown,values))
                return
            if left<0 or left>suffix[k] or (suffix_gcd[k] and left%suffix_gcd[k]):
                return
            j=unknown[k]
            for v in range(min(caps[k],left//dim[j])+1):
                if v*v>norm_left:
                    break
                # Proper principal 2x2 submatrices have radius below3.
                di=v if i==j else matrix[i][i]
                dj=v if i==j else matrix[j][j]
                if i!=j and di>=0 and dj>=0 and (3-di)*(3-dj)<=v*v:
                    continue
                values.append(v)
                yield from rec(k+1,left-v*dim[j],norm_left-v*v)
                values.pop()
        yield from rec(0,target,norm)
    def search():
        nonlocal states,choices
        states+=1
        if len(solutions)>=limit:
            return
        unfinished=[i for i in range(n) if -1 in matrix[i]]
        if not unfinished:
            if all(v==0 for v in budget) and connected() and (completion_test is None or completion_test(matrix)):
                solutions.append([row[:] for row in matrix])
            return
        # Find a restrictive row first; exact enumeration, without a cap.
        selected=None; opts=None
        for i in unfinished:
            current=list(options(i))
            if not current:
                return
            if opts is None or len(current)<len(opts):
                selected=i;opts=current
                if len(opts)==1:
                    break
        i=selected
        for values in opts:
            choices+=1
            for j,v in values:
                assert matrix[i][j]==-1
                matrix[i][j]=matrix[j][i]=v
                budget[i]-=v*dim[j]
                if i!=j:
                    budget[j]-=v*dim[i]
            # Check all now fixed principal pairs, including a diagonal
            # that was chosen after an already fixed off-diagonal entry.
            ok=all(matrix[a][a]<0 or matrix[b][b]<0 or matrix[a][b]<0 or
                   (3-matrix[a][a])*(3-matrix[b][b])>matrix[a][b]**2
                   for a in range(n) for b in range(a+1,n))
            if ok:
                search()
            for j,v in values:
                matrix[i][j]=matrix[j][i]=-1
                budget[i]+=v*dim[j]
                if i!=j:
                    budget[j]+=v*dim[i]
            if len(solutions)>=limit:
                return
    if all(sum(v*v for v in row if v>=0)<=row_norms[i] for i,row in enumerate(matrix)):
        search()
    return solutions,{'search_states':states,'row_choices':choices}

def p67_case(dimensions):
    counts=Counter(dimensions)-BASE; tail=list(sorted(counts.elements()))
    u=tail.index(6);v=tail.index(7);t9=tail.index(9)
    ts=[u]+[j for j,d in enumerate(tail) if d==6 and j!=u][:1]
    p=[int(j in (u,v)) for j in range(len(tail))]
    total={'search_states':0,'row_choices':0}
    for t6 in ts:
        ru=[int(j==t6) for j in range(len(tail))]
        rv=[int(j==t9) for j in range(len(tail))]
        solutions,stats=solve_tail(tail,p,{u:ru,v:rv})
        for key in total:
            total[key]+=stats[key]
        if solutions:
            return {'status':'OPEN_MATRIX','dimensions':dimensions,'tail':tail,'P':p,'T6_index':t6,
                    'matrix':solutions[0],**total}
    return {'status':'EXCLUDED_BY_NX_RELAXATION','dimensions':dimensions,**total}

def other_case(dimensions,branch):
    tail=list(sorted((Counter(dimensions)-BASE).elements()));n=len(tail)
    if branch=='P13':
        u=tail.index(13);p=[int(j==u) for j in range(n)]
        norms=[8-q*q for q in p];norms[u]=4
        entries=[(u,j,0) for j,d in enumerate(tail) if d==4]
        solutions,stats=solve_tail(tail,p,{},fixed_entries=entries,row_norms=norms,entry_caps={(u,u):1})
    else:
        u=tail.index(4);v=tail.index(9);p=[int(j in (u,v)) for j in range(n)]
        norms=[8-q*q for q in p];norms[v]=3
        entries=[(v,j,0) for j,d in enumerate(tail) if d==4]
        solutions,stats=solve_tail(tail,p,{u:[0]*n},fixed_entries=entries,row_norms=norms)
    if solutions:
        return {'status':'OPEN_MATRIX','dimensions':dimensions,'tail':tail,'P':p,'matrix':solutions[0],**stats}
    return {'status':'EXCLUDED_BY_NX_RELAXATION','dimensions':dimensions,**stats}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--rank',type=int,default=14)
    parser.add_argument('--branch',choices=tuple(('P13','P4_9','P6_7')),default='P6_7')
    args=parser.parse_args(); started=time.monotonic(); records=[]
    with gzip.open(HERE/'cubic_d3_raw_types.jsonl.gz','rt') as stream:
        for line in stream:
            row=json.loads(line)
            if row['rank']==args.rank and args.branch in row['P_branches']:
                result=p67_case(row['dimensions']) if args.branch=='P6_7' else other_case(row['dimensions'],args.branch)
                records.append(result)
    report={'status':'PRIMARY_MATRIX_SCAN','rank':args.rank,'branch':args.branch,'types':len(records),
            'outcomes':dict(Counter(x['status'] for x in records)),
            'search_states':sum(x['search_states'] for x in records),'seconds':time.monotonic()-started,
            'records':records}
    (HERE/f'cubic_{args.branch}_rank{args.rank}_probe.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2))

if __name__=='__main__':
    main()
