#!/usr/bin/env python3
"""Exact conditional type counts for the proved cubic d=3 branch.

Unordered integer dimension types only. No source-duality or global
fusion/character compatibility is inferred. Three P branches can overlap.
"""
from collections import Counter
from functools import lru_cache
from itertools import combinations
from math import isqrt
from pathlib import Path
import gzip, hashlib, json, time

HERE=Path(__file__).resolve().parent
N=5400; RANKS=(14,15,16)
CORES={
    'P13':(1,3,3,3,5,6,12,13),
    'P4_9':(1,3,3,3,4,5,6,9,12),
    'P6_7':(1,3,3,3,5,6,6,7,9,12),
}

def table():
    dp=[[0]*N for _ in range(9)]; dp[0][0]=1
    for d in range(4,73):
        for k in range(1,9):
            row=dp[k]; previous=dp[k-1]
            for s in range(d*d,N):
                row[s]+=previous[s-d*d]
    return dp

@lru_cache(None)
def count(k,s,lo):
    if k==0:
        return int(s==0)
    if s<k*lo*lo or s>k*72*72:
        return 0
    if k==1:
        d=isqrt(s)
        return int(d*d==s and lo<=d<=72)
    return sum(count(k-1,s-d*d,d) for d in range(lo,min(72,isqrt(s//k))+1))

def generate(k,s,lo=4):
    if k==0:
        if s==0:
            yield ()
        return
    if s<k*lo*lo or s>k*72*72:
        return
    if k==1:
        d=isqrt(s)
        if d*d==s and lo<=d<=72:
            yield (d,)
        return
    for d in range(lo,min(72,isqrt(s//k))+1):
        if count(k-1,s-d*d,d):
            for tail in generate(k-1,s-d*d,d):
                yield (d,)+tail

def merged_core(names):
    mult=Counter()
    for name in names:
        mult |= Counter(CORES[name])
    return tuple(sorted(mult.elements()))

def main():
    assert __debug__
    started=time.monotonic(); dp=table(); names=tuple(CORES)
    branches={name:{} for name in names}; intersections=[]; unions={}
    dataset=HERE/'cubic_d3_raw_types.jsonl.gz'
    payload_hash=hashlib.sha256(); line_count=0
    with dataset.open('wb') as binary, gzip.GzipFile(filename='',mode='wb',fileobj=binary,mtime=0) as output:
        for rank in RANKS:
            states={}
            for j,name in enumerate(names):
                core=CORES[name]; k=rank-len(core); s=N-sum(d*d for d in core)
                expected=dp[k][s]; assert expected==count(k,s,4)
                seen=0
                for tail in generate(k,s):
                    dims=tuple(sorted(core+tail)); assert len(dims)==rank and sum(d*d for d in dims)==N
                    assert dims.count(3)==3
                    states[dims]=states.get(dims,0)|(1<<j); seen+=1
                assert seen==expected; branches[name][rank]=seen
            inclusion=0
            for size in (1,2,3):
                for chosen in combinations(names,size):
                    core=merged_core(chosen); k=rank-len(core); s=N-sum(d*d for d in core)
                    n=dp[k][s] if k>=0 and s>=0 else 0
                    assert n==(count(k,s,4) if k>=0 and s>=0 else 0)
                    observed=sum(all(mask&(1<<names.index(name)) for name in chosen) for mask in states.values())
                    assert observed==n
                    inclusion+=(-1)**(size+1)*n
                    if size>1:
                        intersections.append({'rank':rank,'branches':chosen,'types':n})
            assert inclusion==len(states); unions[rank]=len(states)
            for dims,mask in sorted(states.items()):
                data={'rank':rank,'dimensions':dims,'P_branches':[name for j,name in enumerate(names) if mask&(1<<j)]}
                line=(json.dumps(data,separators=(',',':'))+'\n').encode()
                output.write(line); payload_hash.update(line); line_count+=1
    report={'status':'PASS','dimension':N,'hypotheses':'The full real cubic linear orbit of conductor9 and codegree9, with its forced equal-dimension triple of source dimension3.',
            'cores':CORES,'counts_by_branch_and_rank':branches,'intersection_counts':intersections,
            'union_counts_by_rank':unions,'dataset_records':line_count,
            'dataset_sha256':hashlib.sha256(dataset.read_bytes()).hexdigest(),
            'uncompressed_payload_sha256':payload_hash.hexdigest(),
            'scope':'Raw integer source-dimension types containing one proved core and exactly three dimension-three labels. Additional Q-support, source duality, full character and fusion equations are not imposed. No surviving or realizable type is asserted.',
            'verification':'Unbounded-square coefficient table, independent nondecreasing recursive count, actual type generation, and inclusion-exclusion all agree.',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'seconds':time.monotonic()-started}
    (HERE/'cubic_type_counts.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='intersection_counts'},indent=2))

if __name__=='__main__':
    main()
