#!/usr/bin/env python3
"""Exact standard-library replay for every higher-rank L12 assignment.

No floating-point optimizer is imported.  Proposed separating covectors are
evaluated against freshly regenerated integer rows.  The complete input is
regenerated and independently counted before any higher-rank certificate is
accepted.  Rank16 coverage is linked to the separately owned two-M2 proof;
this program alone does not claim that external proof has succeeded.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import argparse
import ast
import gc
import json
import time

from audit_canonical12_input import audit as independent_input_audit
from audit_canonical12_fields import audit as independent_field_audit
from enumerate_canonical12 import regenerate
from canonical12_rows import (bounded_remainder_scan, capacity_moment_data,
    cheap_certificate, moment_data, possible_pairs, rows_for)
from canonical12_words import word_possible
from exact_certificate_checks import verify_certificate
from odd_rational_forms import gate as odd_form_gate
import canonical12_rows
import cubic_trace_gate
import fixed_field_rows
import power_trace_filter

HERE = Path(__file__).resolve().parent


def normalized(value):
    return json.loads(json.dumps(value))


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def read_jsonl(path, allow_partial=False):
    data = path.read_bytes() if path.exists() else b''
    if data and not data.endswith(b'\n'):
        assert allow_partial, ('unterminated JSONL record', str(path))
        data = data[:data.rfind(b'\n')+1]
    records = [json.loads(line) for line in data.splitlines() if line]
    index = {r['assignment_index']: r for r in records}
    assert len(index) == len(records), ('duplicate assignment', str(path))
    return index


def mathematical_source_hashes():
    """Local import closure, including this verifier but excluding producers."""
    pending = ['verify_canonical12.py']
    found = {}
    while pending:
        name = pending.pop()
        if name in found:
            continue
        path = HERE/name
        data = path.read_bytes()
        found[name] = sha256(data).hexdigest()
        for node in ast.walk(ast.parse(data, filename=name)):
            imports = ([x.name for x in node.names] if isinstance(node, ast.Import)
                       else [node.module] if isinstance(node, ast.ImportFrom) and node.module
                       else [])
            for module in imports:
                local = module.split('.')[0] + '.py'
                if (HERE/local).is_file() and local not in found:
                    pending.append(local)
    return dict(sorted(found.items()))


def clear_caches():
    for function in (canonical12_rows.options, canonical12_rows.scalar_options,
            canonical12_rows.canonical_capacity_data, cubic_trace_gate.cubic_residues,
            cubic_trace_gate.linear_ws_map, fixed_field_rows.fixed_options,
            power_trace_filter.scalar_power_options):
        if hasattr(function, 'cache_clear'):
            function.cache_clear()
    gc.collect()


def check_rank16_link(records, link_path, external_path=None):
    rows = [r for r in records if r['rank'] == 16]
    assert len(rows) == 12257
    link = []
    for r in rows:
        nonlinear = [a for a, m, c in r['types'] if m > 1 for _ in range(c)]
        assert len(nonlinear) == 2 and all(m == 2 for a, m, c in r['types'] if m > 1)
        link.append({'assignment_index': r['assignment_index'], 'profile': r['profile'],
                     'nonlinear_degrees': sorted(nonlinear, reverse=True), 'retained': r['retained']})
    stored = json.loads(link_path.read_bytes())
    assert stored == link
    output = {'placements': len(link), 'preliminary_retained': sum(r['retained'] for r in link),
              'rank16_link_sha256': sha256(link_path.read_bytes()).hexdigest()}
    if external_path is not None:
        external_data = external_path.read_bytes()
        external = json.loads(external_data)
        if isinstance(external, dict):
            external = external['records']
        keys = lambda rr: {(tuple(r['profile']), tuple(sorted(r['nonlinear_degrees']))) for r in rr}
        assert len(external) == len(keys(external)) == len(link)
        assert keys(external) == keys(link)
        output['external_input_sha256'] = sha256(external_data).hexdigest()
    return output


def check_branch(branch, groups, rows, rank, allow_open=False):
    b = branch['pairs']
    if branch['moment_mode'] == 'base':
        target, vectors = moment_data(groups, rows, rank, b)
        assert branch['capacity_subsets'] == []
    else:
        assert branch['moment_mode'] == 'canonical_capacities'
        target, vectors, subsets = capacity_moment_data(groups, rows, rank, b)
        assert branch['capacity_subsets'] == normalized(subsets)
        assert branch['certificate'] is None or branch['certificate']['kind'] == 'integer_separator', \
            'capacity slack vectors require an unbounded-cone integer separator'
    assert branch['vectors'] == len(vectors)
    cert = branch['certificate']
    if cert is None:
        assert allow_open
        return False
    if cert['kind'] in ('regular_canonical_remainder', 'duality_dimension_squares'):
        assert cert == cheap_certificate(groups, rows, rank, b)
    else:
        assert verify_certificate(vectors, target, cert)
    return True


def check_record(raw, result, refinement=None, allow_open=False):
    started = time.monotonic()
    idx = raw['assignment_index']
    groups = tuple(tuple(g) for g in raw['types'])
    rank = raw['rank']
    assert raw['retained'] and rank > 16
    assert result['assignment_index'] == idx
    assert result['profile_index'] == raw['index'] and result['profile'] == raw['profile']
    assert result['rank'] == rank and result['groups'] == normalized(groups)
    pairs = possible_pairs(groups, rank)
    form = odd_form_gate(groups, rank)
    rows = []
    if form is not None and form['excluded']:
        common = {'kind': 'odd_rational_trace_form', 'counts': form['counts']}
    elif not pairs:
        common = {'kind': 'no_source_duality'}
    else:
        if form is not None:
            pairs = tuple(sorted({x['source_pairs'] for x in form['retained']}))
        common = bounded_remainder_scan(groups, rank)
        if common is None:
            rows = list(rows_for(groups, rank))
            common = cheap_certificate(groups, rows, rank)
    assert result['possible_pairs'] == list(pairs)
    assert result['rows'] == len(rows)
    assert result['common_certificate'] == common
    unresolved = []
    if common is not None:
        assert result['branches'] == [] and result['excluded']
    else:
        branches = result['branches']
        assert [x['pairs'] for x in branches] == list(pairs)
        for branch in branches:
            if not check_branch(branch, groups, rows, rank, True):
                unresolved.append(branch['pairs'])
        assert result['excluded'] == (not unresolved)
    row_hash = digest(rows)
    refined_count = None
    refined_hash = None
    if unresolved and refinement is not None:
        assert refinement['assignment_index'] == idx and refinement['rank'] == rank
        assert refinement['groups'] == normalized(groups)
        assert refinement['base_rows'] == len(rows)
        refined = [row for row in rows if word_possible(groups, row, rank)]
        assert refinement['rows'] == len(refined)
        refined_count = len(refined)
        refined_hash = digest(refined)
        common_word = cheap_certificate(groups, refined, rank)
        assert refinement['common_certificate'] == common_word
        if common_word is not None:
            assert refinement['branches'] == [] and refinement['excluded']
            unresolved = []
        else:
            assert [x['pairs'] for x in refinement['branches']] == unresolved
            unresolved = [branch['pairs'] for branch in refinement['branches']
                          if not check_branch(branch, groups, refined, rank, True)]
            assert refinement['excluded'] == (not unresolved)
    elif refinement is not None:
        raise AssertionError(('unexpected refinement', idx))
    assert allow_open or not unresolved, ('unexcluded branches', idx, unresolved)
    return {'assignment_index': idx, 'rank': rank, 'status': 'PASS_OPEN' if unresolved else 'PASS',
            'base_rows': len(rows), 'base_rows_sha256': row_hash,
            'refined_rows': refined_count, 'refined_rows_sha256': refined_hash,
            'open_pairs': unresolved, 'certificate_digest': digest([result, refinement]),
            'seconds': time.monotonic() - started}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=HERE/'input69312.json')
    parser.add_argument('--base', type=Path, default=HERE/'aggregate_results.jsonl')
    parser.add_argument('--words', type=Path, default=HERE/'word_results.jsonl')
    parser.add_argument('--rank16-input', type=Path)
    parser.add_argument('--output', type=Path, default=HERE/'canonical12_verification.json')
    parser.add_argument('--ledger', type=Path, default=HERE/'canonical12_replay.jsonl')
    parser.add_argument('--start', type=int, default=0)
    parser.add_argument('--stop', type=int)
    parser.add_argument('--modulus', type=int, default=1)
    parser.add_argument('--residue', type=int, default=0)
    parser.add_argument('--available', action='store_true', help='Check only currently complete producer records.')
    parser.add_argument('--allow-open', action='store_true')
    parser.add_argument('--input-only', action='store_true')
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    started = time.monotonic()
    assert 0 <= args.residue < args.modulus
    source_hashes = mathematical_source_hashes()
    data = args.input.read_bytes()
    records = json.loads(data)['records']
    regenerated = regenerate()
    assert records == regenerated
    del regenerated
    input_audit = independent_input_audit(records, data)
    field_audit = independent_field_audit(records)
    rank16 = check_rank16_link(records, HERE/'rank16_link.json', args.rank16_input)
    higher = [r for r in records if r['retained'] and r['rank'] > 16]
    assert len(higher) == 9379
    header = {'status': 'INPUT_PASS', 'input_sha256': sha256(data).hexdigest(),
              'mathematical_source_hashes': source_hashes, 'input_audit': input_audit,
              'field_coverage_audit': field_audit,
              'rank16_link': rank16, 'higher_rank_assignments': len(higher)}
    del records
    gc.collect()
    if args.input_only:
        header['seconds'] = time.monotonic() - started
        args.output.write_text(json.dumps(header, indent=2)+'\n')
        print(json.dumps({k:v for k,v in header.items()
                         if k not in ('mathematical_source_hashes', 'field_coverage_audit')}, indent=2))
        return
    base = read_jsonl(args.base, args.available)
    words = read_jsonl(args.words, args.available)
    expected = {r['assignment_index'] for r in higher}
    assert set(base) <= expected
    assert set(words) <= {i for i, r in base.items() if not r['excluded']}
    if not args.available:
        assert set(base) == expected
        assert set(words) == {i for i, r in base.items() if not r['excluded']}
    jobs = [r for position, r in enumerate(higher[args.start:args.stop], args.start)
            if position % args.modulus == args.residue and
            (not args.available or r['assignment_index'] in base)]
    old = read_jsonl(args.ledger) if args.resume else {}
    proof_hash = digest(source_hashes)
    for idx, entry in old.items():
        assert idx in base and entry['input_sha256'] == header['input_sha256']
        assert entry['mathematical_source_digest'] == proof_hash
        assert entry['certificate_digest'] == digest([base[idx], words.get(idx)])
    counts = Counter()
    ranks = Counter()
    checked = []
    with args.ledger.open('a' if args.resume else 'w') as ledger:
        for number, raw in enumerate(jobs):
            idx = raw['assignment_index']
            result = old.get(idx)
            if result is None:
                result = check_record(raw, base[idx], words.get(idx), args.allow_open)
                result['input_sha256'] = header['input_sha256']
                result['mathematical_source_digest'] = proof_hash
                ledger.write(json.dumps(result, separators=(',', ':'))+'\n')
                ledger.flush()
            counts['assignments'] += 1
            counts['excluded'] += result['status'] == 'PASS'
            counts['base_rows'] += result['base_rows']
            counts['refined_rows'] += result['refined_rows'] or 0
            ranks[raw['rank']] += 1
            checked.append(idx)
            if (number+1) % 30 == 0:
                clear_caches()
            if (number+1) % 50 == 0:
                print('CHECKED', number+1, '/', len(jobs), dict(counts), flush=True)
    complete = set(checked) == expected and counts['excluded'] == len(expected)
    result = {**header, 'status': 'HIGHER_RANK_PASS' if complete else 'PARTIAL_REPLAY_PASS',
              'counts': dict(counts), 'checked_rank_distribution': dict(sorted(ranks.items())),
              'checked_assignment_indices': checked, 'complete_higher_rank_coverage': complete,
              'mathematical_source_digest': proof_hash,
              'ledger_sha256': sha256(args.ledger.read_bytes()).hexdigest(),
              'seconds': time.monotonic()-started,
              'scope': 'L12 ranks above16 only; rank16 uses the separate two-M2 certificate.'}
    assert mathematical_source_hashes() == source_hashes, 'mathematical code changed during replay'
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()
                     if k not in ('mathematical_source_hashes', 'checked_assignment_indices', 'input_audit', 'field_coverage_audit')}, indent=2))


if __name__ == '__main__':
    main()
