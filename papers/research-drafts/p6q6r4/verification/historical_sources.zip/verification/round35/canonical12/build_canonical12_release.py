#!/usr/bin/env python3
"""Assemble a clean, portable proof directory after complete exact replay."""
from hashlib import sha256
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys

from verify_canonical12 import mathematical_source_hashes, digest

HERE = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise RuntimeError('Python assertion checks must be enabled')
    parser = argparse.ArgumentParser()
    parser.add_argument('--destination', type=Path, default=HERE/'release')
    args = parser.parse_args()
    subprocess.run([sys.executable, '-B', '-S', str(HERE/'summarize_canonical12.py')], check=True)
    summary = json.loads((HERE/'canonical12_summary.json').read_text())
    verification = json.loads((HERE/'complete_higher_verification.json').read_text())
    assert summary['producer_records'] == summary['exact_replayed'] == 9379
    assert verification['complete_higher_rank_coverage']
    assert summary['status'] == 'EXACT_HIGHER_RANK_COVERAGE_PASS'
    assert verification['status'] == 'HIGHER_RANK_PASS'
    hashes = mathematical_source_hashes()
    assert verification['mathematical_source_hashes'] == hashes
    assert verification['mathematical_source_digest'] == digest(hashes)
    integration_path = HERE/'canonical_length13_integration.json'
    theorem_path = HERE/'r35_canonical_length13.tex'
    assert integration_path.is_file() == theorem_path.is_file(), 'global theorem and complete integration report must occur together'
    global_integration = None
    if integration_path.is_file():
        global_integration = json.loads(integration_path.read_text())
        assert global_integration['status'] == 'PASS_COMPLETE_CANONICAL_LENGTH13_BRIDGE'
        assert global_integration['higher_assignments'] == 9379
        assert global_integration['rank16_states'] == 9268 and global_integration['open_cases'] == 0
        assert global_integration['higher_mathematical_source_digest'] == digest(hashes)
        assert global_integration['theorem_sha256'] == sha256(theorem_path.read_bytes()).hexdigest()
        assert global_integration['integration_script_sha256'] == sha256((HERE/'finalize_canonical_length13.py').read_bytes()).hexdigest()
        for name, expected in global_integration['authentication_artifact_sha256'].items():
            assert Path(name).name == name and sha256((HERE/name).read_bytes()).hexdigest() == expected
    files = set(hashes)
    files.update({
        'scan_canonical12.py', 'refine_canonical12.py', 'propose_certificates.py',
        'replay_canonical12_watch.py', 'bounded_canonical12_replay.py',
        'replay_all.py', 'summarize_canonical12.py',
        'build_canonical12_release.py', 'finalize_canonical_length13.py', 'audit_capacity_and_cubic.py',
        'canonical11_rows.py', 'input69312.json', 'rank16_link.json',
        'aggregate_results.jsonl', 'word_results.jsonl', 'complete_replay.jsonl',
        'complete_higher_verification.json', 'complete_input_verification.json',
        'replay_all_verification.json', 'replay_all_input_verification.json',
        'canonical12_summary.json', 'preliminary_summary.json',
        'independent_input_audit.json', 'field_coverage_audit.json',
        'capacity_cubic_audit.json', 'odd_form_results.json', 'odd_form_summary.json',
        'r35_canonical_capacity.tex', 'r35_odd_skew_determinant.tex',
        'r35_cubic_residue_filter.tex', 'r35_canonical12_enumeration.tex',
    })
    for optional in ('r35_canonical_length13.tex', 'HANDOFF.md'):
        if (HERE/optional).is_file():
            files.add(optional)
    if global_integration is not None:
        files.add('canonical_length13_integration.json')
        files.update(global_integration['authentication_artifact_sha256'])
    args.destination.mkdir(parents=True, exist_ok=True)
    for name in sorted(files):
        assert (HERE/name).is_file(), name
        shutil.copy2(HERE/name, args.destination/name)
    readme = f'''CANONICAL LENGTH TWELVE: COMPLETE HIGHER-RANK CERTIFICATE

Scope
-----
Standing hypotheses: C is simple integral of dimension 5400 and Z(C) is
simple integral modular. The complete L=12 universe has 6,547 weighted
profiles and 69,312 representation-multiplicity assignments. Preliminary
necessary tests leave 12,905 assignments, of which 3,526 have rank 16 and 9,379
have larger rank. This directory verifies the entire higher-rank branch.
The complete 12,257 placement rank 16 input link is checked, but its separate
two-matrix exclusion must also be verified before concluding L >= 13.

Frozen result
-------------
Higher-rank verification status: {verification['status']}
Assignments freshly replayed: {summary['exact_replayed']}
Assignments excluded: {summary['exact_excluded']}
Full source-row records: {summary['full_source_rows']}
Bounded-remainder source rows examined: {summary['bounded_remainder_rows']}
Assignments requiring full word refinement: {summary['word_records']}
Rows retained after word refinement: {summary['word_source_rows']}
Mathematical source digest: {digest(hashes)}
Input SHA256: {summary['input_sha256']}

Fresh verification, standard library only
----------------------------------------
Use Python 3.11 or later. Run on a working copy of this directory, with
the sibling rank16 input available, because verification writes new audit
reports. The combined Round 35 entrypoint creates its own isolated copies.

    python -B -S replay_all.py --fresh --workers 2

This regenerates every preliminary record, independently counts all
profiles and multiplicity partitions, independently audits all 99 actual
scalar-field catalogues, regenerates every higher-rank source row, and
checks every certificate using integers/rationals. It also replays every
needed positive-word refinement. It imports no numerical optimizer.
Each worker pool handles at most 100 assignments and is fully released.
Use --workers 1 for a more restrictive memory/CPU budget.

To authenticate the supplied completed fresh ledger without recomputing
its source rows, while still regenerating and auditing the full input:

    python -B -S replay_all.py

To compare the separate rank 16 raw input as well:

    python -B -S replay_all.py --rank16-input ../two_matrix16/input12257.json

The supplied complete_replay.jsonl records the
actual fresh replay; complete_higher_verification.json records its exact
coverage and hashes. A partial run never establishes the full conclusion.

Independent implementation audits
---------------------------------
    python -B -S audit_canonical12_input.py
    python -B -S audit_canonical12_fields.py
    python -B -S audit_capacity_and_cubic.py

The cubic boundary/bitset audit by the independent structural reviewer
is in the sibling cubic_structure/reviews directory in the combined
Round 35 package. It compares 15,432 exact interval cases and 90 explicit
modular sumsets, including 5,396 full-coset early exits.

Optional discovery
------------------
scan_canonical12.py and refine_canonical12.py use NumPy/SciPy only to
propose covectors; optimizer infeasibility flags are never proof inputs.
The supplied certificates are accepted only by exact integer evaluation.
Do not overwrite frozen producer files when merely checking the result.

Interpretation
--------------
These are necessary character/canonical data, not constructed fusion
rings. Nontrivial Galois orbits and all Schur indices remain covered.
No source simple dimension is assumed to divide 5400. The allocation
lift at the end of r35_canonical_capacity.tex is a proved additional
reconstruction condition and is explicitly not used in these exclusions.
'''
    if global_integration is not None:
        readme = readme.replace(
            'The complete 12,257 placement rank 16 input link is checked, but its separate\n'
            'two-matrix exclusion must also be verified before concluding L >= 13.',
            'The complete 12,257 placement rank 16 input link and its separate\n'
            'two-matrix exclusion have both now been authenticated. Together the\n'
            'complete higher and rank16 branches prove L >= 13. The higher-only\n'
            'replay command below retains its stated branch scope.')
        readme += '''
Completed global integration
----------------------------
The separate rank16 branch has now also completed fresh exact replay:
all 9,268 states PASS, with zero open records. The final integration gate
has authenticated both complete ledgers and their frozen mathematical
snapshots, giving L >= 13. The manuscript bridge and nonlinear-budget
corollary are in r35_canonical_length13.tex. The binding report is
canonical_length13_integration.json; its three authentication reports
are included alongside it.

The higher-only replay_all.py retains its stated scope. To reauthenticate
the complete bridge with the external rank16 replay available:

    python -B -S finalize_canonical_length13.py --check-only

Override --rank16-directory and --rank16-report when the external package
or completed replay is located elsewhere. The default report path is
../two_matrix16/fresh_replay/complete_replay.json. If the delivered rank16
package places that report directly in its root directory, use:

    python -B -S finalize_canonical_length13.py --check-only --rank16-report ../two_matrix16/complete_replay.json

The listed ledger shards and trace_replay.json must remain beside the
selected completed report. The integration invocation
authenticates completed fresh row replays and regenerates the higher
input; it does not claim to regenerate all source rows itself. Use the
combined Round 35 fresh entrypoint for a fresh replay of both branches.
'''
    (args.destination/'README.txt').write_text(readme)
    manifest = {'status': verification['status'], 'mathematical_source_digest':digest(hashes),
                'files':{p.name:sha256(p.read_bytes()).hexdigest()
                         for p in sorted(args.destination.iterdir())
                         if p.is_file() and p.name != 'MANIFEST_SHA256.json'}}
    (args.destination/'MANIFEST_SHA256.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps({'status':manifest['status'], 'files':len(manifest['files']),
                      'destination':str(args.destination)}, indent=2))


if __name__ == '__main__':
    main()
