"""Complete L=12 multiplicity enumeration with exact preliminary exclusions.

Only necessary field discriminant conditions are used. In particular no
odd-degree nonlinear character is declared rational merely from its degree.
"""
from pathlib import Path
from collections import Counter
from functools import lru_cache
from itertools import product
from math import gcd,prod
import json,time
from verify_two_blocks import PALETTE,squarefree_part,quadratic_discriminants,phi
from verify_length10 import subfield_orbits
from probe_length11 import residue_failure
HERE=Path(__file__).resolve().parent
N=5400;L=12

@lru_cache(None)
def partitions(left,maximum=None):
    if maximum is None:maximum=left
    if not left:return((),)
    return tuple((first,)+tail for first in range(min(left,maximum),0,-1)
                 for tail in partitions(left-first,first))

@lru_cache(None)
def profiles(start,slots,total):
    if not slots:return((),)if total==0 else()
    if start==len(PALETTE)or total<10*slots or total>slots*PALETTE[start]:return()
    out=[]
    for i in range(start,len(PALETTE)):
        a=PALETTE[i]
        if slots*a<total:break
        if a>total:continue
        out.extend((a,)+tail for tail in profiles(i,slots-1,total-a))
    return tuple(out)

@lru_cache(None)
def orbit_options(a,m,k):
    f=N//a;c=gcd(2*f,f*f)
    options=set()if a==10 else{(1,1)}
    if k>=2:options|={(2,squarefree_part(abs(D)))for D in quadratic_discriminants(c)}
    if k>=3 and c%9==0:options.add((3,1))
    if k>=4:
        ambient=gcd(c,240)
        options|={(e,s)for e,s,D,h in subfield_orbits(ambient,4)if e==4}
    if k>=5 and phi(c)%5==0:
        assert c==25,(a,m,k,c)
        options|={(e,s)for e,s,D,h in subfield_orbits(c,k)if e==5}
    if k>=6 and phi(c)%6==0:
        assert c==9,(a,m,k,c)
        options|={(e,s)for e,s,D,h in subfield_orbits(c,k)if e==6}
    assert k<=7,(a,m,k)
    return tuple(sorted(options))

@lru_cache(None)
def orbit_classes(a,m,k):
    options=orbit_options(a,m,k);states=[set()for _ in range(k+1)];states[0]={1}
    for n in range(k):
        for old in states[n]:
            for e,s in options:
                if n+e<=k:states[n+e].add(squarefree_part(old*s))
    return tuple(sorted(states[k]))

def regenerate():
    ps=tuple(sorted(profiles(0,L-1,N-1),reverse=True));assert len(ps)==6547
    records=[]
    for index,p in enumerate(ps):
        counts=Counter(p);aa=sorted(counts,reverse=True)
        baseline=squarefree_part((N if L%2 else 1)*prod(p))
        for parts in product(*(partitions(counts[a])for a in aa)):
            types=[(a,m,c)for a,part in zip(aa,parts)for m,c in Counter(part).items()]
            rank=1+sum(m*m*c for a,m,c in types);comm=all(m==1 for a,m,c in types)
            assert rank%2==0
            low=rank<(14 if comm else 16)
            rational_ten=any(a==10 and c==1 for a,m,c in types)
            classes={1}
            for a,m,c in types:
                if m%2:classes={squarefree_part(x*y)for x in classes for y in orbit_classes(a,m,c)}
            det=baseline in classes and not rational_ten
            forbidden=counts[24]==counts[200]==1 and all(a in(24,200)or a%225==0 for a in aa)
            residue=residue_failure(types)if det and not low and not forbidden else None
            capacity=[g for g in types if(rank-1)*(N//g[0]-1)<(N//g[0])*g[1]**2*g[2]-g[1]*g[2]]
            kept=det and not low and not forbidden and residue is None and not capacity
            records.append({'assignment_index':len(records),'index':index,'profile':p,
                'multiplicities':list(zip(aa,parts)),'rank':rank,'commutative':comm,'types':types,
                'baseline':baseline,'odd_component_field_classes':sorted(classes),
                'determinant_pass':det,'excluded_by_rank':low,'forbidden_24_200':forbidden,
                'rational_residue_failure':residue,'capacity_failure':capacity,'retained':kept})
    assert len(records)==69312
    return json.loads(json.dumps(records))

def main():
    started=time.monotonic();r=regenerate()
    summary={'dimension':N,'canonical_length':L,'profiles':6547,'assignments':len(r),
      'rank_distribution':dict(sorted(Counter(x['rank']for x in r).items())),
      'after_determinant_and_rational_ten':sum(x['determinant_pass']for x in r),
      'after_known_ranks':sum(x['determinant_pass']and not x['excluded_by_rank']for x in r),
      'after_forbidden_pattern':sum(x['determinant_pass']and not x['excluded_by_rank']and not x['forbidden_24_200']for x in r),
      'after_rational_residues':sum(x['determinant_pass']and not x['excluded_by_rank']and not x['forbidden_24_200']and x['rational_residue_failure']is None for x in r),
      'after_norm_capacity':sum(x['retained']for x in r),
      'retained_by_rank':dict(sorted(Counter(x['rank']for x in r if x['retained']).items())),
      'odd_orbit_inventory':[{'a':a,'m':m,'count':k,'options':orbit_options(a,m,k)}for a,m,k in sorted({tuple(g)for x in r for g in x['types']if g[1]%2})],
      'seconds':time.monotonic()-started}
    (HERE/'input69312.json').write_text(json.dumps({'status':'COMPLETE_NECESSARY_INPUT','summary':summary,'records':r},separators=(',',':'))+'\n')
    (HERE/'preliminary_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items()if k!='odd_orbit_inventory'},indent=2))
if __name__=='__main__':main()
