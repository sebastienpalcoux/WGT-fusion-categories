"""Optional certificate producer for the complete higher-rank L12 branch."""
from pathlib import Path
from collections import Counter
from concurrent.futures import ProcessPoolExecutor,as_completed
import json,time,argparse,os,hashlib,gc,resource
from multiprocessing import get_context
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
from canonical12_rows import rows_for,possible_pairs,moment_data,cheap_certificate,bounded_remainder_scan,capacity_moment_data
from odd_rational_forms import gate as odd_form_gate
import canonical12_rows,cubic_trace_gate,fixed_field_rows,power_trace_filter
_TASKS=0
from propose_certificates import certificate
HERE=Path(__file__).resolve().parent

def work(record):
    global _TASKS
    _TASKS+=1
    if _TASKS%10==0:
        for function in(canonical12_rows.options,canonical12_rows.scalar_options,canonical12_rows.canonical_capacity_data,cubic_trace_gate.cubic_residues,cubic_trace_gate.linear_ws_map,fixed_field_rows.fixed_options,power_trace_filter.scalar_power_options):
            if hasattr(function,"cache_clear"):function.cache_clear()
        gc.collect()
    started=time.monotonic();idx=record['assignment_index']
    print('JOB_START',os.getpid(),idx,'rss_kib',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,flush=True)
    groups=tuple(tuple(g)for g in record['types']);rank=record['rank']
    pairs=possible_pairs(groups,rank);rows=[];branches=[]
    form=odd_form_gate(groups,rank)
    if form is not None and form['excluded']:
        common={'kind':'odd_rational_trace_form','counts':form['counts']}
    elif not pairs:common={'kind':'no_source_duality'}
    else:
        if form is not None:pairs=tuple(sorted({x['source_pairs']for x in form['retained']}))
        common=bounded_remainder_scan(groups,rank)
        if common is None:
            rows=list(rows_for(groups,rank));common=cheap_certificate(groups,rows,rank)
    if common is None:
        for b in pairs:
            target,vectors=moment_data(groups,rows,rank,b)
            cert=cheap_certificate(groups,rows,rank,b)
            mode='base';subsets=[]
            if cert is None:cert=certificate(vectors,target)
            if cert is None:
                target,vectors,subsets=capacity_moment_data(groups,rows,rank,b)
                mode='canonical_capacities';cert=certificate(vectors,target)
            branches.append({'pairs':b,'vectors':len(vectors),'moment_mode':mode,
                             'capacity_subsets':subsets,'certificate':cert})
    excluded=common is not None or all(x['certificate']is not None for x in branches)
    result={'assignment_index':idx,'profile_index':record['index'],'profile':record['profile'],
           'rank':rank,'groups':groups,'rows':len(rows),'possible_pairs':pairs,
           'common_certificate':common,'branches':branches,'excluded':excluded,
           'seconds':time.monotonic()-started}
    print('JOB_DONE',os.getpid(),idx,'rss_kib',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,flush=True)
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=3)
    p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int)
    p.add_argument('--output',type=Path,default=HERE/'aggregate_results.jsonl')
    p.add_argument('--resume',action='store_true');a=p.parse_args()
    all_data=json.loads((HERE/'input69312.json').read_text())['records']
    data=[{k:r[k]for k in('assignment_index','index','profile','rank','types')}for r in all_data if r['retained']and r['rank']>16];assert len(data)==9379
    del all_data;gc.collect()
    data=data[a.start:a.stop];done=set();counts=Counter();started=time.monotonic()
    if a.resume and a.output.exists():
        for line in a.output.read_text().splitlines():
            r=json.loads(line);done.add(r['assignment_index'])
            counts['assignments']+=1;counts['excluded']+=r['excluded'];counts['rows']+=r['rows']
            counts['open_branches']+=sum(x['certificate']is None for x in r['branches'])
    data=[r for r in data if r['assignment_index']not in done]
    print('START remaining',len(data),'workers',a.workers,flush=True)
    with a.output.open('a'if a.resume else'w')as out:
      # Rebuild the pool between bounded batches. This bounds all inherited
      # caches and avoids ProcessPoolExecutor's max_tasks_per_child stall.
      for start in range(0,len(data),100):
        with ProcessPoolExecutor(max_workers=a.workers,mp_context=get_context("spawn"))as pool:
          futures=[pool.submit(work,r)for r in data[start:start+100]]
          for future in as_completed(futures):
            r=future.result();out.write(json.dumps(r,separators=(',',':'))+'\n');out.flush()
            counts['assignments']+=1;counts['excluded']+=r['excluded'];counts['rows']+=r['rows']
            counts['open_branches']+=sum(x['certificate']is None for x in r['branches'])
            if counts['assignments']%50==0 or not r['excluded']:
                print(r['assignment_index'],'rank',r['rank'],'rows',r['rows'],
                      'EXCLUDED'if r['excluded']else'OPEN',dict(counts),
                      'seconds',round(time.monotonic()-started,2),flush=True)
                (HERE/'scan_progress.json').write_text(json.dumps({'status':'RUNNING','counts':dict(counts),'last_index':r['assignment_index'],'seconds':time.monotonic()-started},indent=2)+'\n')
    result={'status':'PRODUCER_COMPLETE','counts':dict(counts),'seconds':time.monotonic()-started}
    (HERE/'scan_progress.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
