"""Full positive-word refinement of unresolved aggregate L12 assignments."""
from pathlib import Path
from collections import Counter
import json,time,argparse,os,gc
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
from canonical12_rows import rows_for,moment_data,cheap_certificate,capacity_moment_data
from canonical12_words import word_possible
import canonical12_words,canonical12_rows,cubic_trace_gate,power_trace_filter
from propose_certificates import certificate
HERE=Path(__file__).resolve().parent

def refine(old):
    start=time.monotonic();groups=tuple(tuple(g)for g in old['groups']);rank=old['rank']
    rows=list(rows_for(groups,rank));assert len(rows)==old['rows']
    refined=[r for r in rows if word_possible(groups,r,rank)]
    common=cheap_certificate(groups,refined,rank);branches=[]
    if common is None:
        for br in old['branches']:
            if br['certificate']is not None:continue
            b=br['pairs'];target,vectors=moment_data(groups,refined,rank,b)
            cert=cheap_certificate(groups,refined,rank,b);mode='base';subsets=[]
            if cert is None:cert=certificate(vectors,target)
            if cert is None:
                target,vectors,subsets=capacity_moment_data(groups,refined,rank,b)
                mode='canonical_capacities';cert=certificate(vectors,target)
            branches.append({'pairs':b,'vectors':len(vectors),'moment_mode':mode,'capacity_subsets':subsets,'certificate':cert})
    excluded=common is not None or all(x['certificate']is not None for x in branches)
    return{'assignment_index':old['assignment_index'],'rank':rank,'groups':groups,'base_rows':len(rows),'rows':len(refined),'common_certificate':common,'branches':branches,'excluded':excluded,'seconds':time.monotonic()-start}

def main():
    p=argparse.ArgumentParser();p.add_argument('--watch',action='store_true');p.add_argument('--index',type=int);a=p.parse_args()
    output=HERE/'word_results.jsonl';done={};started=time.monotonic()
    if output.exists():done={r['assignment_index']:r for r in map(json.loads,output.read_text().splitlines())}
    with output.open('a')as out:
        while True:
            snapshot=(HERE/'aggregate_results.jsonl').read_bytes()
            # The producer may currently be writing the last JSONL record.
            complete=snapshot if not snapshot or snapshot.endswith(b'\n') else snapshot[:snapshot.rfind(b'\n')+1]
            data=[json.loads(s)for s in complete.splitlines()]
            todo=[r for r in data if not r['excluded']and r['assignment_index']not in done and(a.index is None or r['assignment_index']==a.index)]
            for old in todo:
                if len(done)%10==0:
                    for fn in(canonical12_words.polynomial_powers,canonical12_rows.options,
                              canonical12_rows.scalar_options,canonical12_rows.canonical_capacity_data,
                              cubic_trace_gate.cubic_residues,cubic_trace_gate.linear_ws_map,
                              power_trace_filter.scalar_power_options):
                        if hasattr(fn,'cache_clear'):fn.cache_clear()
                    gc.collect()
                print('START',old['assignment_index'],'rank',old['rank'],'base_rows',old['rows'],flush=True)
                r=refine(old);done[r['assignment_index']]=r;out.write(json.dumps(r,separators=(',',':'))+'\n');out.flush()
                summary={'assignments':len(done),'excluded':sum(x['excluded']for x in done.values()),'open':sum(not x['excluded']for x in done.values()),'rows':sum(x['rows']for x in done.values())}
                print(r['assignment_index'],r['base_rows'],'->',r['rows'],'EXCLUDED'if r['excluded']else'OPEN',summary,'seconds',round(time.monotonic()-started,2),flush=True)
                (HERE/'word_progress.json').write_text(json.dumps(summary,indent=2)+'\n')
            state=json.loads((HERE/'scan_progress.json').read_text())if(HERE/'scan_progress.json').exists()else{}
            if not a.watch:break
            if state.get('status')=='PRODUCER_COMPLETE':
                # Drain records appended while the preceding batch refined.
                if (HERE/'aggregate_results.jsonl').stat().st_size==len(complete):break
                continue
            time.sleep(2)
if __name__=='__main__':main()
