#!/usr/bin/env python3
"""Statistics and exact coverage accounting for the L12 certificate files.

This reports producer/replay coverage.  It is not a replacement for the
fresh standard-library row replay in verify_canonical12.py.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json

from verify_canonical12 import read_jsonl, digest, mathematical_source_hashes

HERE = Path(__file__).resolve().parent


def main():
    data = (HERE/'input69312.json').read_bytes()
    input_sha256 = sha256(data).hexdigest()
    raw = json.loads(data)['records']
    higher = {r['assignment_index']:r for r in raw if r['retained'] and r['rank'] > 16}
    assert len(higher) == 9379
    base = read_jsonl(HERE/'aggregate_results.jsonl', True)
    words = read_jsonl(HERE/'word_results.jsonl', True)
    replay = read_jsonl(HERE/'complete_replay.jsonl', True)
    assert set(base) <= set(higher)
    assert set(words) <= {i for i,r in base.items() if not r['excluded']}
    assert set(replay) <= set(base)
    proof_digest = digest(mathematical_source_hashes())
    for idx, record in replay.items():
        assert record['input_sha256'] == input_sha256
        assert record['mathematical_source_digest'] == proof_digest
        assert record['certificate_digest'] == digest([base[idx], words.get(idx)])
    closed = {i for i,r in base.items() if r['excluded']}
    closed.update(i for i,r in words.items() if r['excluded'])
    row_counts = Counter()
    by_rank = {}
    for rank in sorted({r['rank'] for r in higher.values()}):
        ids = {i for i,r in higher.items() if r['rank'] == rank}
        by_rank[rank] = {'assignments':len(ids), 'produced':len(ids&set(base)),
                        'base_excluded':sum(base[i]['excluded'] for i in ids&set(base)),
                        'word_refinements':len(ids&set(words)),
                        'closed_after_words':len(ids&closed),
                        'exact_replayed':len(ids&set(replay)),
                        'replay_excluded':sum(replay[i]['status']=='PASS' for i in ids&set(replay))}
    common = Counter((r['common_certificate'] or {}).get('kind', 'moment_branches')
                     for r in base.values())
    word_common = Counter((r['common_certificate'] or {}).get('kind', 'moment_branches')
                          for r in words.values())
    branches = Counter((b['moment_mode'], (b['certificate'] or {}).get('kind', 'OPEN'))
                       for r in base.values() for b in r['branches'])
    word_branches = Counter((b['moment_mode'], (b['certificate'] or {}).get('kind', 'OPEN'))
                            for r in words.values() for b in r['branches'])
    complete = set(base) == set(higher) and set(words) == {i for i,r in base.items() if not r['excluded']}
    exact = set(replay) == set(higher) and all(r['status']=='PASS' for r in replay.values())
    result = {'status': 'EXACT_HIGHER_RANK_COVERAGE_PASS' if complete and exact
                        else 'PARTIAL_COVERAGE',
              'scope':'The complete higher-rank L12 branch; the rank16 input link is separate.',
              'expected_assignments':len(higher), 'producer_records':len(base),
              'base_excluded':sum(r['excluded'] for r in base.values()),
              'word_records':len(words), 'word_excluded':sum(r['excluded'] for r in words.values()),
              'closed_after_words':len(closed), 'exact_replayed':len(replay),
              'exact_excluded':sum(r['status']=='PASS' for r in replay.values()),
              'full_source_rows':sum(r['rows'] for r in base.values()),
              'bounded_remainder_rows':sum((r['common_certificate'] or {}).get('rows_examined',0) for r in base.values()),
              'word_source_rows':sum(r['rows'] for r in words.values()),
              'base_common_certificate_counts':dict(sorted(common.items())),
              'word_common_certificate_counts':dict(sorted(word_common.items())),
              'base_branch_counts':[{'mode':m,'kind':k,'count':v} for (m,k),v in sorted(branches.items())],
              'word_branch_counts':[{'mode':m,'kind':k,'count':v} for (m,k),v in sorted(word_branches.items())],
              'rank_summary':by_rank,
              'missing_producer_indices':sorted(set(higher)-set(base)),
              'missing_replay_indices':sorted(set(higher)-set(replay)),
              'open_after_words':sorted(set(base)-closed),
              'input_sha256':input_sha256,
              'mathematical_source_digest':proof_digest,
              'certificate_sha256':{name:sha256((HERE/name).read_bytes()).hexdigest() for name in
                                   ('aggregate_results.jsonl','word_results.jsonl','complete_replay.jsonl')}}
    (HERE/'canonical12_summary.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in
                     ('missing_producer_indices','missing_replay_indices','open_after_words','rank_summary')}, indent=2))


if __name__ == '__main__':
    main()
