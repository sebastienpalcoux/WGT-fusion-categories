"""Exact whole-form and skew-determinant gate for rational odd matrices.

The positive whole form of a rational odd-degree matrix component is
isometric to (1/f) I_(m^2), independently of the positive adjoint form. Its skew
form has dimension m(m-1)/2 and determinant squareclass
(2/f)^(m(m-1)/2). Full linear field possibilities remain explicit.
"""
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from math import prod
from pathlib import Path
import json,time
import generic_fields
import r32_trace_forms as forms
from linear_field_lattice import field_lattice_failure
N=5400;HERE=Path(__file__).resolve().parent

@lru_cache(None)
def scalar_choices(a,c):
    f=N//a
    return tuple(x for x in generic_fields.decompositions(f,c)
                 if not any(field_lattice_failure(f,label)for label in x[0]))

@lru_cache(None)
def gate(groups,rank):
    nonlinear=[g for g in groups if g[1]>1]
    if not nonlinear or not all(m%2 and c==1 for a,m,c in nonlinear):return None
    scalar=[(a,c)for a,m,c in groups if m==1]
    matrix_whole=tuple(Q(a,N)for a,m,c in nonlinear for _ in range(m*m))
    matrix_skew=prod(Q(2*a,N)**(m*(m-1)//2)for a,m,c in nonlinear)
    base_pairs=sum(m*(m-1)//2 for a,m,c in nonlinear)
    choices=[scalar_choices(a,c)for a,c in scalar]
    counts={'field_assignments':0,'pair_budget_exclusions':0,'whole_form_exclusions':0,'skew_determinant_exclusions':0,'retained_field_assignments':0}
    survivors=[]
    for assignment in product(*choices):
        counts['field_assignments']+=1
        q6=sum(x[4]for x in assignment);q=sum(len(x[3])for x in assignment);b=q+base_pairs
        if q6>2 or b<2*q6 or 2*b>rank-2:
            counts['pair_budget_exclusions']+=1;continue
        whole=(Q(1,N),)+matrix_whole+tuple(v for x in assignment for v in x[1])
        assert len(whole)==rank
        if not forms.isometric(whole,(Q(1),)*rank):
            counts['whole_form_exclusions']+=1;continue
        determinant=matrix_skew*prod(v for x in assignment for v in x[3])
        if forms.squareclass(determinant)!=forms.squareclass(Q(2)**b):
            counts['skew_determinant_exclusions']+=1;continue
        counts['retained_field_assignments']+=1
        survivors.append({'fields':[{'a':a,'count':c,'fields':list(x[0])}for(a,c),x in zip(scalar,assignment)],'source_pairs':b})
    return{'excluded':not survivors,'counts':counts,'retained':survivors}

def main():
    start=time.monotonic();records=json.loads((HERE/'input69312.json').read_text())['records'];out=[];totals={}
    for r in records:
        if not r['retained']or r['rank']<=16:continue
        result=gate(tuple(tuple(g)for g in r['types']),r['rank'])
        if result is None:continue
        out.append({'assignment_index':r['assignment_index'],'rank':r['rank'],'groups':r['types'],**result})
    report={'status':'NECESSARY_FORM_GATE_COMPLETE','assignments':len(out),'excluded_assignments':sum(r['excluded']for r in out),'retained_assignments':sum(not r['excluded']for r in out),'counts':{k:sum(r['counts'][k]for r in out)for k in out[0]['counts']},'seconds':time.monotonic()-start}
    (HERE/'odd_form_results.json').write_text(json.dumps({'summary':report,'records':out},separators=(',',':'))+'\n')
    (HERE/'odd_form_summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
