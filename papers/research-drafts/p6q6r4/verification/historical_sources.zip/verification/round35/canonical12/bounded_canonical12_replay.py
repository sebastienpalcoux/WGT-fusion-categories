#!/usr/bin/env python3
"""Fresh complete L12 higher-rank replay with bounded worker lifetimes.

Every assignment is replayed afresh; no saved ledger entry is consumed.
The complete input is regenerated once before row workers are started.
Each pool handles at most100 assignments and is then fully released.
"""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from hashlib import sha256
from multiprocessing import get_context
from pathlib import Path
import argparse
import gc
import json
import subprocess
import sys
import time

from verify_canonical12 import (check_record, clear_caches, digest,
    mathematical_source_hashes, read_jsonl)

HERE = Path(__file__).resolve().parent
TASKS = 0


def work(job):
    global TASKS
    TASKS += 1
    if TASKS % 10 == 0:
        clear_caches()
    raw, base, words = job
    return check_record(raw, base, words, allow_open=False)


def main():
    if not __debug__:
        raise RuntimeError('Python assertion checks must be enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, choices=(1,2), default=2)
    parser.add_argument('--rank16-input', type=Path, default=HERE.parent/'two_matrix16/input12257.json')
    parser.add_argument('--ledger', type=Path, default=HERE/'fresh_complete_replay.jsonl')
    parser.add_argument('--output', type=Path, default=HERE/'fresh_complete_verification.json')
    args = parser.parse_args()
    started = time.monotonic()
    own_sha256 = sha256(Path(__file__).read_bytes()).hexdigest()
    source_hashes = mathematical_source_hashes()
    source_digest = digest(source_hashes)
    input_report_path = HERE/'fresh_complete_input_verification.json'
    command = [sys.executable, '-B', '-S', str(HERE/'verify_canonical12.py'),
               '--input-only', '--rank16-input', str(args.rank16_input.resolve()),
               '--output', str(input_report_path)]
    with (HERE/'fresh_complete_input_console.txt').open('w') as log:
        subprocess.run(command, cwd=HERE, check=True, stdout=log, stderr=subprocess.STDOUT)
    header = json.loads(input_report_path.read_text())
    assert header['status'] == 'INPUT_PASS'
    assert header['mathematical_source_hashes'] == source_hashes
    assert header['higher_rank_assignments'] == 9379
    data = json.loads((HERE/'input69312.json').read_text())['records']
    raw = {r['assignment_index']:{k:r[k] for k in
           ('assignment_index','index','profile','rank','types','retained')}
           for r in data if r['retained'] and r['rank'] > 16}
    assert len(raw) == 9379
    del data
    gc.collect()
    base = read_jsonl(HERE/'aggregate_results.jsonl')
    words = read_jsonl(HERE/'word_results.jsonl')
    expected = sorted(raw)
    assert set(base) == set(raw)
    assert set(words) == {i for i,r in base.items() if not r['excluded']}
    args.output.write_text(json.dumps({'status':'RUNNING','fresh_row_replay':True,
                                      'mathematical_source_digest':source_digest},indent=2)+'\n')
    counts = Counter()
    ranks = Counter()
    done = set()
    with args.ledger.open('w') as ledger:
        for start in range(0,len(expected),100):
            batch = expected[start:start+100]
            with ProcessPoolExecutor(max_workers=args.workers,mp_context=get_context('spawn')) as pool:
                futures = {pool.submit(work,(raw[i],base[i],words.get(i))):i for i in batch}
                for future in as_completed(futures):
                    idx = futures[future]
                    entry = future.result()
                    assert entry['assignment_index'] == idx and idx not in done
                    assert entry['status'] == 'PASS' and entry['open_pairs'] == []
                    entry['input_sha256'] = header['input_sha256']
                    entry['mathematical_source_digest'] = source_digest
                    ledger.write(json.dumps(entry,separators=(',',':'))+'\n')
                    ledger.flush()
                    done.add(idx)
                    counts['assignments'] += 1
                    counts['excluded'] += 1
                    counts['base_rows'] += entry['base_rows']
                    counts['refined_rows'] += entry['refined_rows'] or 0
                    ranks[raw[idx]['rank']] += 1
            assert mathematical_source_hashes() == source_hashes, 'mathematical code changed during replay'
            progress = {'status':'RUNNING','counts':dict(counts),'workers':args.workers,
                        'maximum_assignments_per_pool':100,'seconds':time.monotonic()-started}
            (HERE/'fresh_replay_progress.json').write_text(json.dumps(progress,indent=2)+'\n')
            print('FRESH_REPLAY',dict(counts),flush=True)
    assert done == set(raw) and counts['assignments'] == counts['excluded'] == 9379
    assert sha256(Path(__file__).read_bytes()).hexdigest() == own_sha256, 'bounded replayer changed during execution'
    counts['open'] = 0
    result = {**header,'status':'HIGHER_RANK_PASS','complete_higher_rank_coverage':True,
              'fresh_row_replay':True,'saved_ledger_entries_consumed':0,
              'counts':dict(counts),'rank_distribution':dict(sorted(ranks.items())),
              'open_assignment_indices':[], 'workers':args.workers,
              'maximum_assignments_per_pool':100,
              'mathematical_source_digest':source_digest,
              'ledger_sha256':sha256(args.ledger.read_bytes()).hexdigest(),
              'bounded_replayer_sha256':own_sha256,
              'seconds':time.monotonic()-started,
              'scope':'Complete fresh L12 higher-rank exclusion; rank16 input equality only.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in
        ('mathematical_source_hashes','input_audit','field_coverage_audit')},indent=2),flush=True)


if __name__ == '__main__':
    main()
