"""Optional numerical proposals; every returned vector is checked exactly."""
from fractions import Fraction
from functools import reduce
from math import gcd,lcm
import numpy as np
from scipy.optimize import linprog,OptimizeWarning
import warnings
warnings.filterwarnings("ignore",message="Unrecognized options detected.*",category=OptimizeWarning)

def certificate(vectors,target):
    if not vectors:return {'kind':'empty'}
    mat=np.array(vectors,dtype=float)
    scales=np.maximum(np.max(np.abs(mat),axis=0),np.abs(target));scales=np.maximum(scales,1)
    result=linprog(np.array(target,dtype=float)/scales,A_ub=-mat/scales,b_ub=np.zeros(len(mat)),bounds=[(-1,1)]*len(target),method='highs',options={'threads':1})
    if not result.success or result.fun>=-1e-8:return None
    for denominator in [100,10000,1000000,1000000000]:
        y=[Fraction(float(v/s)).limit_denominator(denominator)for v,s in zip(result.x,scales)]
        for row in vectors:
            if row[0]==row[1]==0:
                negative=[i for i,v in enumerate(row)if v]
                assert len(negative)==1 and row[negative[0]]==-1
                j=negative[0];y[j]=min(y[j],Fraction(0))
        low=min(sum(a*b for a,b in zip(y,row))for row in vectors)
        if low<0:y[0]-=low;y[1]-=low
        value=sum(a*b for a,b in zip(y,target))
        if value<0:
            common=lcm(*(q.denominator for q in y));z=[int(q*common)for q in y]
            divisor=reduce(gcd,(abs(v)for v in z));z=[v//divisor for v in z]
            vals=[sum(a*b for a,b in zip(z,row))for row in vectors];val=sum(a*b for a,b in zip(z,target))
            assert min(vals)>=0 and val<0
            return {'kind':'integer_separator','coefficients':z,'minimum_row_value':min(vals),'target_value':val}
    return None
