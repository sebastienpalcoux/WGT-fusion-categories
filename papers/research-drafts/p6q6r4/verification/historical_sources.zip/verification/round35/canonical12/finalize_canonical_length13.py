#!/usr/bin/env python3
"""Publish the canonical-length bridge only after both complete exact proofs.

This is an authentication/integration command, not a fresh source-row replay.
The completed fresh ledgers are authenticated under their frozen mathematical
snapshots. No theorem or release file is written before both complete proofs
and the rank-sixteen endpoint label have been authenticated.
"""
from hashlib import sha256
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
HIGHER_MATH = '819c47777a9dab43845941a3adf595370fc95a2072f9b2bcd726e7f205ac3d1d'
RANK16_MATH = '03de54463be5a8cb03bd595de969aab57c135091471b8fff8f82508d8a615eb1'
HIGHER_PINNED = {
    'input69312.json': '981c3820166f826fc5e9b04129985d30087e7a1ab0de12c47d9fdbc844873875',
    'aggregate_results.jsonl': '6a4c87427c0a8d112fd6d609e8aa94acbbe2a563f547ec5d10c184adba6e4394',
    'word_results.jsonl': '1caf337851d0abff98b742226080d4d90931440c7c11a86f778019fcbe1925f5',
    'complete_replay.jsonl': 'b6dff2633c8cdcf6653e3cae9073964b67d5ae9a797b26546a0c5f8362d69e6b',
    'complete_higher_verification.json': '1789665e4fd85724bc88d6e614aa6d9671edff8ce96b58ea5b5aac6ffc620fcb',
    'rank16_link.json': 'bfbccf05a2cecfe66b613d2d4c9b55569e8e2600ae22a51fe41ba9387e2e5c2f',
    'replay_all.py': 'b271f87cdcb7e2f37b998ba8d468b43a82514976512e4fd1c5a5828f3634c6d1',
    'bounded_canonical12_replay.py': '662dbb2e96fe80cd056475d65410f5b5a5101ffca862e2031e96be3d549a1b45',
    'replay_canonical12_watch.py': 'c8ddeaa5f6aeb6b9eb13a500f605d71ea639c32d47899ef064f61294a3d3daef',
}
RANK16_INPUTS = {
    'input12257.json': '302a1f08659ee2e98000ede368c72e3dd86997d94b768e1ec40d2c5cf462edfa',
    'trace_two_matrix.jsonl': 'edc11c2fc74ba0a04281cc0cf73ab54a90474f02deecf3d686c13fb1dcafd100',
    'rank16_certificates.jsonl': '62753bb26b75651ef414f7c26fc48f0062e9380ebd9346de0d39c0ea9b334bdf',
}

# This draft is deliberately embedded here. Its manuscript fragment is not
# written until authenticate_both() has succeeded completely.
THEOREM = r'''\subsection{The canonical length is at least thirteen}
\label{r35:sec:canonical-length13}

\begin{theorem}[The canonical-length lower bound improves to thirteen]
\label{r35:canonical-length-at-least-thirteen}
Under the standing center hypotheses at dimension $5400$,
\[
 L=\operatorname{length}I(\mathbf1)=\sum_E\dim E\ge13.
\]
The exclusion of length twelve covers every representation-multiplicity
pattern and every source rank, including nonlinear characters in
nontrivial Galois orbits and nonsplit rational simple components.
\end{theorem}

\begin{proof}
The inherited lower bound is $L\ge12$ by
Theorem~\ref{r34:canonical-length-at-least-twelve}.
If $L=12$, Proposition~\ref{r35:canonical12-complete-universe}
enumerates all $6547$ weighted nonunit profiles and all $69312$
representation-multiplicity assignments, without a source-rank
cutoff. The preliminary necessary tests leave $12905$ assignments.
Of these, $9379$ have rank greater than sixteen and are excluded
by Proposition~\ref{r35:canonical12-higher-rank-exclusion}.

The other $3526$ assignments have rank sixteen and exactly two
degree-two representations. Their full pre-filter universe of
$12257$ placements agrees entry for entry with the independent
two-matrix input. Theorem~\ref{r35:rank16-two-matrix-exclusion}
excludes that entire universe, after retaining and checking all
$9268$ field/involution states that survive its exact trace tests.
Thus no multiplicity assignment at $L=12$ remains. This proves
$L\ge13$.

Both branches have complete fresh exact replay ledgers with zero
open cases. The global integration gate authenticates the frozen
mathematical source snapshots, all input and certificate hashes,
every required ledger identifier, the complete rank-sixteen input
link, and the two final PASS reports before enabling this theorem.
Numerical optimization is used only to propose certificates;
its infeasibility flags are not accepted as proof data.
\end{proof}

\begin{corollary}[The nonlinear representation budget at length thirteen]
\label{r35:nonlinear-budget-thirteen}
Every remaining source ring satisfies
\[
 \sum_E m_E(m_E-1)\le r-13,
 \qquad r=\operatorname{rank}(\mathcal C).
\]
Consequently, the presence of a degree-$m$ irreducible source-ring
representation implies
\[
                         r\ge13+m(m-1).
\]
All irreducible representations have degree at most two when
$r\le18$. A degree-three representation requires $r\ge19$,
and a degree-four representation requires $r\ge25$.
\end{corollary}

\begin{proof}
Subtract $L=\sum_E m_E\ge13$ from $r=\sum_E m_E^2$.
Any degree-$m$ representation contributes $m(m-1)$ to the
difference, and all other contributions are nonnegative.
The stated thresholds follow by substituting $m=3$ and $m=4$.
\end{proof}
'''


def file_sha(path):
    h = sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def canonical_sha(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def assert_files(directory, expected):
    for name, digest in expected.items():
        assert Path(name).name == name, ('nonlocal proof filename', name)
        assert file_sha(directory / name) == digest, ('frozen file changed', str(directory / name))


def run(command, cwd, log):
    with log.open('w') as stream:
        subprocess.run(command, cwd=cwd, check=True, stdout=stream, stderr=subprocess.STDOUT)


def authenticate_both(rank16_dir, rank16_report, work):
    """Authenticate full existing fresh ledgers without touching their sources."""
    assert_files(HERE, HIGHER_PINNED)
    higher_original = json.loads((HERE / 'complete_higher_verification.json').read_text())
    higher_sources = higher_original['mathematical_source_hashes']
    assert canonical_sha(higher_sources) == HIGHER_MATH
    assert_files(HERE, higher_sources)

    frozen = json.loads((rank16_dir / 'proof_freeze_manifest.json').read_text())
    assert frozen['status'] == 'FROZEN_BEFORE_COMPLETE_EXACT_REPLAY'
    assert frozen['proof_sha256'] == canonical_sha(frozen['files']) == RANK16_MATH
    assert frozen['inputs'] == RANK16_INPUTS
    assert_files(rank16_dir, frozen['files'])
    assert_files(rank16_dir, RANK16_INPUTS)
    external_bytes = rank16_report.read_bytes()
    external = json.loads(external_bytes)
    assert external['status'] == 'PASS_COMPLETE_EXCLUSION'
    assert external['dimension'] == 5400 and external['rank'] == 16
    assert external['complex_algebra'] == 'C^8+M2+M2'
    assert external['expected_states'] == external['closed_records'] == 9268
    assert external['exact_replays_checked'] == 9268 and external['open_records'] == 0
    assert external['proof_sha256'] == RANK16_MATH
    assert external['certificate_file_sha256'] == RANK16_INPUTS['rank16_certificates.jsonl']
    trace_path = rank16_report.parent / 'trace_replay.json'
    assert json.loads(trace_path.read_text()) == external['trace_replay']
    trace = external['trace_replay']
    assert trace['status'] == 'PASS_COMPLETE_TRACE_REPLAY'
    assert trace['proof_sha256'] == RANK16_MATH and trace['input_sha256'] == RANK16_INPUTS
    assert trace['profiles'] == 6547
    assert trace['counts']['placements'] == 12257 and trace['counts']['matrix_states'] == 9268
    assert external['ledger_sha256']
    assert_files(rank16_report.parent, external['ledger_sha256'])
    ledgers = [rank16_report.parent / name for name in sorted(external['ledger_sha256'])]

    framework_path = rank16_dir / 'r35_two_matrix16_framework.tex'
    framework = framework_path.read_bytes()
    assert br'\label{r35:rank16-two-matrix-exclusion}' in framework, 'rank16 endpoint theorem is not yet integrated'
    merged = work / 'canonical_length13_rank16_authentication.json'
    run([sys.executable, '-B', '-S', str(rank16_dir / 'merge_rank16.py'),
         '--ledgers', *map(str, ledgers), '--trace-report', str(trace_path), '--report', str(merged)],
        rank16_dir, work / 'rank16_merge_console.txt')
    assert json.loads(merged.read_text()) == external

    # Run the reviewed higher verifier in a disposable copy, preserving every
    # existing proof, input, report and ledger in the source/release directory.
    higher_copy = work / 'higher'
    higher_copy.mkdir()
    for name in sorted(set(higher_sources) | set(HIGHER_PINNED)):
        shutil.copy2(HERE / name, higher_copy / name)
    run([sys.executable, '-B', '-S', str(higher_copy / 'replay_all.py'),
         '--rank16-input', str(rank16_dir / 'input12257.json')],
        higher_copy, work / 'higher_authentication_console.txt')
    higher_path = higher_copy / 'replay_all_verification.json'
    higher = json.loads(higher_path.read_text())
    assert higher['status'] == 'PASS'
    assert higher['higher_rank_assignments'] == higher['excluded_assignments'] == 9379
    assert higher['all_assignment_ids_authenticated'] is True
    assert higher['partial_coverage_accepted'] is False and higher['open_branches_accepted'] is False
    assert higher['input_regenerated_this_invocation'] is True
    assert higher['rows_recomputed_this_invocation'] is False
    assert higher['mathematical_source_digest'] == HIGHER_MATH
    assert higher['input_sha256'] == HIGHER_PINNED['input69312.json']
    assert higher['rank16_link']['placements'] == 12257
    assert higher['rank16_link']['preliminary_retained'] == 3526
    assert higher['rank16_link']['external_input_sha256'] == RANK16_INPUTS['input12257.json']

    # Guard against a source/report changing while either authentication ran.
    assert_files(HERE, HIGHER_PINNED)
    assert_files(HERE, higher_sources)
    assert_files(rank16_dir, frozen['files'])
    assert_files(rank16_dir, RANK16_INPUTS)
    assert_files(rank16_report.parent, external['ledger_sha256'])
    assert rank16_report.read_bytes() == external_bytes
    assert framework_path.read_bytes() == framework
    return {
        'higher_authentication': higher_path,
        'higher_input_authentication': higher_copy / 'replay_all_input_verification.json',
        'rank16_authentication': merged,
        'higher_mathematical_sources': higher_sources,
        'rank16_mathematical_sources': frozen['files'],
        'rank16_report_sha256': sha256(external_bytes).hexdigest(),
        'rank16_framework_sha256': sha256(framework).hexdigest(),
        'rank16_ledger_sha256': external['ledger_sha256'],
        'rank16_base_rows': external['base_rows_regenerated'],
        'rank16_retained_rows': external['retained_rows'],
    }


def final_handoff(old):
    pending = 'The global theorem fragment `r35_canonical_length13.tex`, label `r35:canonical-length-at-least-thirteen`, is intentionally deferred until the rank-16 proof also has a complete authenticated PASS report.'
    completed = 'The global theorem fragment `r35_canonical_length13.tex`, label `r35:canonical-length-at-least-thirteen`, is now integrated after complete authenticated PASS for both branches. The nonlinear-budget corollary has label `r35:nonlinear-budget-thirteen`.'
    old = old.replace(pending, completed)
    start = 'The complete 12,257-placement rank-16 input agrees exactly with the separate two-matrix input.'
    stop = 'No such global conclusion is claimed by this directory\'s strict verifier alone.'
    if stop in old:
        i, j = old.index(start), old.index(stop) + len(stop)
        old = old[:i] + (
            'The complete 12,257-placement rank-16 input agrees exactly with the separate two-matrix input. '
            'All 9,268 surviving rank-16 field/involution states have now completed fresh exact replay, '
            'with no open record. The frozen rank-16 merger and the complete higher-rank ledger have '
            'both been reauthenticated by `finalize_canonical_length13.py`. Together they prove L >= 13. '
            'The higher-only `replay_all.py` remains scoped to its own branch; the global conclusion '
            'uses the separately authenticated rank-16 proof as well.'
        ) + old[j:]
    section = '\n## Completed global integration\n'
    if section not in old:
        old += section + '''
`canonical_length13_integration.json` binds the complete 9,379-assignment higher proof and the complete 9,268-state rank-16 proof, their frozen mathematical snapshots, certificate and ledger hashes, and the final theorem fragment. It records authentication of completed fresh row replays; it does not claim that the integration invocation regenerated source rows again.

The integration command is:

```text
python -B -S finalize_canonical_length13.py --rank16-directory ../two_matrix16 --rank16-report ../two_matrix16/fresh_replay/complete_replay.json
```

The command blocks without writing the theorem if the complete rank-16 report is absent. It also rejects partial coverage, open states, changed mathematical sources or inputs, changed certificates, changed ledgers, and a missing rank-16 endpoint label. The full rank-16 merger is rerun in authentication mode. The higher strict verifier runs in a disposable copy, preserving all original proof files. Only after both gates pass are the theorem, documentation, integration report, and release manifest refreshed.

The global result gives the necessary budget sum m(m-1) <= r-13. At rank sixteen the only remaining noncommutative algebra shape is C^12 plus one M_2(C). Degrees three and four require source rank at least nineteen and twenty-five, respectively. These are restrictions on hypothetical rings, not existence results or a classification of their structure constants.

The completed higher-rank proposition also passed the separate independent review `../cubic_structure/reviews/r35_canonical12_higher_completion_review.json`, SHA256 `004fbba3571ff8ea5f1a4b0ea9d0457140d1eaf7c26ede91c434cc2eb619c82b`.
'''
    return old


def main():
    if not __debug__:
        raise RuntimeError('Publication authentication requires assertions; do not use Python -O.')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rank16-directory', type=Path, default=HERE.parent / 'two_matrix16')
    parser.add_argument('--rank16-report', type=Path)
    parser.add_argument('--release-directory', type=Path, default=HERE / 'release')
    parser.add_argument('--check-only', action='store_true', help='Authenticate both complete proofs without writing any publication files.')
    args = parser.parse_args()
    rank16_dir = args.rank16_directory.resolve()
    rank16_report = (args.rank16_report or rank16_dir / 'fresh_replay/complete_replay.json').resolve()
    if not rank16_report.is_file():
        print(json.dumps({'status': 'BLOCKED_EXTERNAL_REPLAY_INCOMPLETE',
                          'required_rank16_states': 9268, 'required_open_states': 0,
                          'required_report': str(rank16_report),
                          'theorem_written': False, 'release_changed': False}, indent=2))
        return 2
    own_sha = file_sha(Path(__file__))
    with tempfile.TemporaryDirectory(prefix='canonical_length13_gate_') as name:
        work = Path(name)
        evidence = authenticate_both(rank16_dir, rank16_report, work)
        assert file_sha(Path(__file__)) == own_sha
        if args.check_only:
            print(json.dumps({'status': 'PASS_COMPLETE_CANONICAL_LENGTH13_GATE',
                              'higher_assignments': 9379, 'rank16_states': 9268,
                              'open_cases': 0, 'theorem_written': False,
                              'release_changed': False}, indent=2))
            return 0

        theorem_path = HERE / 'r35_canonical_length13.tex'
        if theorem_path.exists():
            assert theorem_path.read_text() == THEOREM, 'existing theorem fragment differs from the authenticated draft'
        final_artifacts = {
            'canonical_length13_higher_authentication.json': evidence['higher_authentication'],
            'canonical_length13_higher_input_authentication.json': evidence['higher_input_authentication'],
            'canonical_length13_rank16_authentication.json': evidence['rank16_authentication'],
        }
        integration = {
            'status': 'PASS_COMPLETE_CANONICAL_LENGTH13_BRIDGE',
            'conclusion': 'L >= 13', 'dimension': 5400,
            'all_profiles': 6547, 'all_multiplicity_assignments': 69312,
            'preliminary_survivors': 12905, 'higher_assignments': 9379,
            'rank16_preliminary_survivors': 3526, 'rank16_placements': 12257,
            'rank16_states': 9268, 'open_cases': 0,
            'rows_recomputed_this_invocation': False,
            'higher_input_regenerated_this_invocation': True,
            'all_completed_fresh_ledger_entries_authenticated': True,
            'higher_mathematical_source_digest': HIGHER_MATH,
            'rank16_mathematical_source_digest': RANK16_MATH,
            'higher_mathematical_sources': evidence['higher_mathematical_sources'],
            'rank16_mathematical_sources': evidence['rank16_mathematical_sources'],
            'higher_frozen_files': HIGHER_PINNED,
            'rank16_frozen_inputs': RANK16_INPUTS,
            'rank16_completed_report_sha256': evidence['rank16_report_sha256'],
            'rank16_framework_sha256': evidence['rank16_framework_sha256'],
            'rank16_ledger_sha256': evidence['rank16_ledger_sha256'],
            'rank16_base_rows_regenerated_in_completed_fresh_replay': evidence['rank16_base_rows'],
            'rank16_retained_rows': evidence['rank16_retained_rows'],
            'integration_script_sha256': own_sha,
            'theorem_sha256': sha256(THEOREM.encode()).hexdigest(),
            'authentication_artifact_sha256': {name: file_sha(path) for name, path in final_artifacts.items()},
        }
        # No publication mutation occurs before the complete authentication above.
        for artifact_name, source in final_artifacts.items():
            shutil.copy2(source, HERE / artifact_name)
        theorem_path.write_text(THEOREM)
        handoff = HERE / 'HANDOFF.md'
        handoff.write_text(final_handoff(handoff.read_text()))
        (HERE / 'canonical_length13_integration.json').write_text(json.dumps(integration, indent=2) + '\n')
        assert_files(HERE, HIGHER_PINNED)
        assert_files(HERE, evidence['higher_mathematical_sources'])
        subprocess.run([sys.executable, '-B', '-S', str(HERE / 'build_canonical12_release.py'),
                        '--destination', str(args.release_directory.resolve())], cwd=HERE, check=True)
        assert_files(HERE, HIGHER_PINNED)
        assert_files(HERE, evidence['higher_mathematical_sources'])
        print(json.dumps({'status': integration['status'], 'theorem_written': True,
                          'higher_assignments': 9379, 'rank16_states': 9268, 'open_cases': 0,
                          'release_directory': str(args.release_directory.resolve()),
                          'release_manifest_sha256': file_sha(args.release_directory / 'MANIFEST_SHA256.json')}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
