#!/usr/bin/env python3
"""Complete L12 higher-rank proof authentication, with optional fresh row replay.

Default: regenerate the complete input and authenticate the completed fresh
replay ledger, its source code, all certificate digests, and exact coverage.
--fresh: first recompute every source row and certificate in a new ledger.
Neither mode permits partial coverage or an open branch.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import argparse
import json
import subprocess
import sys
import time

from verify_canonical12 import digest, mathematical_source_hashes, read_jsonl

HERE = Path(__file__).resolve().parent
EXPECTED_INPUT_SHA256 = '981c3820166f826fc5e9b04129985d30087e7a1ab0de12c47d9fdbc844873875'
EXPECTED_MATHEMATICAL_DIGEST = '819c47777a9dab43845941a3adf595370fc95a2072f9b2bcd726e7f205ac3d1d'
EXPECTED_ASSIGNMENTS = 9379


def run_verifier(arguments, log_name):
    command = [sys.executable, '-B', '-S', str(HERE/'verify_canonical12.py'), *arguments]
    with (HERE/log_name).open('w') as log:
        subprocess.run(command, cwd=HERE, check=True, stdout=log, stderr=subprocess.STDOUT)


def main():
    if not __debug__:
        raise RuntimeError('Python assertion checks must be enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fresh', action='store_true', help='Regenerate every source row again in separate fresh output files.')
    parser.add_argument('--workers',type=int,choices=(1,2),default=2,
                        help='Bounded fresh-replay workers; used only with --fresh.')
    parser.add_argument('--rank16-input', type=Path, default=HERE.parent/'two_matrix16/input12257.json')
    args = parser.parse_args()
    started = time.monotonic()
    orchestration_hashes = {name:sha256((HERE/name).read_bytes()).hexdigest() for name in
        ('replay_all.py','bounded_canonical12_replay.py','replay_canonical12_watch.py')}
    assert args.rank16_input.is_file(), ('rank16 input is required for the complete link', str(args.rank16_input))
    source_hashes = mathematical_source_hashes()
    source_digest = digest(source_hashes)
    assert source_digest == EXPECTED_MATHEMATICAL_DIGEST, 'frozen mathematical source changed'
    input_bytes = (HERE/'input69312.json').read_bytes()
    assert sha256(input_bytes).hexdigest() == EXPECTED_INPUT_SHA256
    input_report_path = HERE/'replay_all_input_verification.json'
    run_verifier(['--input-only', '--rank16-input', str(args.rank16_input.resolve()),
                  '--output', str(input_report_path)], 'replay_all_input_console.txt')
    input_report = json.loads(input_report_path.read_text())
    assert input_report['status'] == 'INPUT_PASS'
    assert input_report['input_sha256'] == EXPECTED_INPUT_SHA256
    assert input_report['mathematical_source_hashes'] == source_hashes
    assert input_report['input_audit']['status'] == 'PASS'
    assert input_report['input_audit']['assignments'] == 69312
    assert input_report['input_audit']['profiles'] == 6547
    assert input_report['field_coverage_audit']['status'] == 'PASS'
    assert input_report['field_coverage_audit']['scalar_block_parameters'] == 99
    assert input_report['rank16_link']['placements'] == 12257
    assert input_report['rank16_link']['preliminary_retained'] == 3526
    assert input_report['higher_rank_assignments'] == EXPECTED_ASSIGNMENTS
    if args.fresh:
        ledger_path = HERE/'fresh_complete_replay.jsonl'
        report_path = HERE/'fresh_complete_verification.json'
        command = [sys.executable,'-B','-S',str(HERE/'bounded_canonical12_replay.py'),
                   '--workers',str(args.workers),'--rank16-input',str(args.rank16_input.resolve()),
                   '--ledger',str(ledger_path),'--output',str(report_path)]
        with (HERE/'fresh_complete_replay_console.txt').open('w') as log:
            subprocess.run(command,cwd=HERE,check=True,stdout=log,stderr=subprocess.STDOUT)
    else:
        ledger_path = HERE/'complete_replay.jsonl'
        report_path = HERE/'complete_higher_verification.json'
    report = json.loads(report_path.read_text())
    assert report['status'] == 'HIGHER_RANK_PASS'
    assert report['complete_higher_rank_coverage'] is True
    assert report['higher_rank_assignments'] == EXPECTED_ASSIGNMENTS
    assert report['input_sha256'] == EXPECTED_INPUT_SHA256
    assert report['mathematical_source_hashes'] == source_hashes
    assert report['mathematical_source_digest'] == source_digest
    assert report['rank16_link'] == input_report['rank16_link']
    if args.fresh:
        assert report['bounded_replayer_sha256'] == orchestration_hashes['bounded_canonical12_replay.py']
        assert report['fresh_row_replay'] is True and report['saved_ledger_entries_consumed'] == 0
        assert report['maximum_assignments_per_pool'] == 100 and report['workers'] == args.workers
    else:
        assert report['watcher_sha256'] == orchestration_hashes['replay_canonical12_watch.py']
    ledger_bytes = ledger_path.read_bytes()
    assert report['ledger_sha256'] == sha256(ledger_bytes).hexdigest()
    data = json.loads(input_bytes)['records']
    raw = {r['assignment_index']:r for r in data if r['retained'] and r['rank'] > 16}
    assert len(raw) == EXPECTED_ASSIGNMENTS
    base = read_jsonl(HERE/'aggregate_results.jsonl')
    words = read_jsonl(HERE/'word_results.jsonl')
    ledger = read_jsonl(ledger_path)
    expected = set(raw)
    assert set(base) == set(ledger) == expected
    assert set(words) == {i for i,r in base.items() if not r['excluded']}
    counts = Counter()
    ranks = Counter()
    for idx in sorted(expected):
        original = raw[idx]
        certificate = base[idx]
        refinement = words.get(idx)
        entry = ledger[idx]
        assert certificate['assignment_index'] == entry['assignment_index'] == idx
        assert certificate['rank'] == entry['rank'] == original['rank']
        assert certificate['profile_index'] == original['index']
        assert certificate['profile'] == original['profile']
        assert certificate['groups'] == original['types']
        assert entry['status'] == 'PASS' and entry['open_pairs'] == []
        assert entry['input_sha256'] == EXPECTED_INPUT_SHA256
        assert entry['mathematical_source_digest'] == source_digest
        assert entry['certificate_digest'] == digest([certificate, refinement])
        assert entry['base_rows'] == certificate['rows']
        assert isinstance(entry['base_rows_sha256'], str) and len(entry['base_rows_sha256']) == 64
        if refinement is None:
            assert certificate['excluded'] is True
            assert entry['refined_rows'] is None and entry['refined_rows_sha256'] is None
        else:
            assert certificate['excluded'] is False and refinement['excluded'] is True
            assert refinement['assignment_index'] == idx
            assert refinement['rank'] == original['rank']
            assert refinement['groups'] == original['types']
            assert refinement['base_rows'] == certificate['rows']
            assert entry['refined_rows'] == refinement['rows']
            assert isinstance(entry['refined_rows_sha256'], str) and len(entry['refined_rows_sha256']) == 64
        counts['assignments'] += 1
        counts['excluded'] += 1
        counts['base_rows'] += entry['base_rows']
        counts['refined_rows'] += entry['refined_rows'] or 0
        ranks[original['rank']] += 1
    assert counts['assignments'] == counts['excluded'] == EXPECTED_ASSIGNMENTS
    for key, value in counts.items():
        assert report['counts'][key] == value
    assert report['counts'].get('open', 0) == 0
    expected_ranks = {str(k):v for k,v in sorted(ranks.items())}
    if 'rank_distribution' in report:
        assert report['rank_distribution'] == expected_ranks
    if 'checked_rank_distribution' in report:
        assert report['checked_rank_distribution'] == expected_ranks
    if 'checked_assignment_indices' in report:
        assert report['checked_assignment_indices'] == sorted(expected)
    assert mathematical_source_hashes() == source_hashes, 'mathematical source changed during authentication'
    assert orchestration_hashes == {name:sha256((HERE/name).read_bytes()).hexdigest()
                                    for name in orchestration_hashes}, 'orchestration source changed during authentication'
    result = {
        'status':'PASS', 'scope':'Complete higher-rank L12 exclusion, linked to the complete rank16 input.',
        'mode':'fresh_row_replay' if args.fresh else 'authenticated_completed_fresh_replay',
        'rows_recomputed_this_invocation':args.fresh,
        'input_regenerated_this_invocation':True,
        'all_assignment_ids_authenticated':True,
        'partial_coverage_accepted':False, 'open_branches_accepted':False,
        'profiles':6547, 'all_multiplicity_assignments':69312,
        'higher_rank_assignments':EXPECTED_ASSIGNMENTS, 'excluded_assignments':EXPECTED_ASSIGNMENTS,
        'counts':dict(counts), 'rank_distribution':expected_ranks,
        'rank16_link':input_report['rank16_link'],
        'input_sha256':EXPECTED_INPUT_SHA256,
        'mathematical_source_digest':source_digest,
        'mathematical_source_hashes':source_hashes,
        'orchestration_source_hashes':orchestration_hashes,
        'proof_file_sha256':{
            'aggregate_results.jsonl':sha256((HERE/'aggregate_results.jsonl').read_bytes()).hexdigest(),
            'word_results.jsonl':sha256((HERE/'word_results.jsonl').read_bytes()).hexdigest(),
            ledger_path.name:sha256(ledger_bytes).hexdigest(),
            report_path.name:sha256(report_path.read_bytes()).hexdigest(),
            input_report_path.name:sha256(input_report_path.read_bytes()).hexdigest(),
            'replay_all.py':sha256(Path(__file__).read_bytes()).hexdigest(),
            'bounded_canonical12_replay.py':sha256((HERE/'bounded_canonical12_replay.py').read_bytes()).hexdigest(),
        },
        'rank16_exclusion_claimed_here':False,
        'seconds':time.monotonic()-started,
    }
    (HERE/'replay_all_verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'mathematical_source_hashes'}, indent=2))


if __name__ == '__main__':
    main()
