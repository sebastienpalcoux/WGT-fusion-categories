"""Independent finite checks of the new capacity and cubic arithmetic."""
from itertools import product
from pathlib import Path
import hashlib,json,random,time
from canonical12_rows import canonical_capacity_data,options as compact
from canonical11_rows import options as explicit
from cubic_trace_gate import cubic_residues
HERE=Path(__file__).resolve().parent

def multiply(a,b):
    n=len(a);return [[sum(a[i][k]*b[k][j]for k in range(n))for j in range(n)]for i in range(n)]

def main():
    start=time.monotonic();knapsacks=intervals=matrices=0
    for groups in [((10,1,2),(24,3,1)),((12,1,1),(30,2,2)),((20,2,1),(36,3,1)),((15,1,3),(18,2,1),(40,3,1))]:
        for d in range(3,16):
            for sd in(False,True):
                caps,bits=canonical_capacity_data(groups,d,sd)
                brute={sum(g[1]*b for g,b in zip(groups,bb))for bb in product(*(range(c+1)for c in caps))}
                assert {i for i in range(bits.bit_length())if(bits>>i)&1}==brute
                knapsacks+=1
    for a,m,c in [(900,2,1),(900,3,1),(900,5,1),(675,2,1),(675,3,1),(675,3,2),(600,2,3),(450,2,1),(450,3,2),(12,2,1)]:
        for d in range(3,7 if a==12 else 10):
            for sd in(False,True):
                assert tuple((s,t,tuple(ws))for s,t,ws in compact((a,m,c),d,sd))==explicit((a,m,c),d,sd)
                intervals+=1
    rng=random.Random(540035)
    for k in range(1,8):
        for _ in range(120):
            a=[[rng.choice((-1,0,0,0,1))for j in range(k)]for i in range(k)]
            aa=multiply(a,a);aaa=multiply(aa,a)
            s=sum(a[i][i]for i in range(k));t=sum(x*x for row in a for x in row)
            p2=sum(aa[i][i]for i in range(k));p3=sum(aaa[i][i]for i in range(k));w=t-p2
            assert w>=0 and(w-t+s)%2==0
            for f in(6,8,9,10,12,15,20,450):
                assert p3%f in cubic_residues(k,s,t,(w,),f),(k,s,t,w,p3,f)
            matrices+=1
    files=('canonical12_rows.py','canonical11_rows.py','cubic_trace_gate.py','audit_capacity_and_cubic.py')
    result={'status':'PASS','bounded_knapsack_cases':knapsacks,'skew_interval_cases':intervals,
            'direct_integer_matrix_cases':matrices,'moduli_per_matrix':8,
            'source_sha256':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()for name in files},
            'seconds':time.monotonic()-start}
    (HERE/'capacity_cubic_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
