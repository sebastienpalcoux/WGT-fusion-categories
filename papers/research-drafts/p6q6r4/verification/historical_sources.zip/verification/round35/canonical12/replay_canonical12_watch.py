#!/usr/bin/env python3
"""Fresh, parallel, standard-library replay of completed producer records.

The row/certificate checker is verify_canonical12.check_record.  The watcher
only schedules complete records and writes a per-assignment replay ledger.
It exits with a complete-coverage report only after all 9,379 higher-rank
assignments have been checked.  No numerical package is imported.
"""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from hashlib import sha256
from multiprocessing import get_context
from pathlib import Path
import argparse
import gc
import json
import subprocess
import sys
import time

from verify_canonical12 import (check_record, clear_caches, digest,
    mathematical_source_hashes, read_jsonl)

HERE = Path(__file__).resolve().parent
TASKS = 0


def work(job):
    global TASKS
    TASKS += 1
    if TASKS % 10 == 0:
        clear_caches()
    raw, base, words = job
    return check_record(raw, base, words, allow_open=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=2)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--once', action='store_true', help='Drain the currently ready snapshot only.')
    parser.add_argument('--rank16-input', type=Path)
    args = parser.parse_args()
    started = time.monotonic()
    command = [sys.executable, '-B', '-S', str(HERE/'verify_canonical12.py'),
               '--input-only', '--output', str(HERE/'complete_input_verification.json')]
    if args.rank16_input is not None:
        command.extend(['--rank16-input', str(args.rank16_input)])
    with (HERE/'complete_input_verification_console.txt').open('w') as log:
        subprocess.run(command, check=True, cwd=HERE, stdout=log, stderr=subprocess.STDOUT)
    header = json.loads((HERE/'complete_input_verification.json').read_text())
    source_hashes = mathematical_source_hashes()
    assert header['mathematical_source_hashes'] == source_hashes
    source_digest = digest(source_hashes)
    data = json.loads((HERE/'input69312.json').read_text())['records']
    raw = {r['assignment_index']: {k:r[k] for k in
           ('assignment_index', 'index', 'profile', 'rank', 'types', 'retained')}
           for r in data if r['retained'] and r['rank'] > 16}
    assert len(raw) == 9379
    del data
    gc.collect()
    ledger_path = HERE/'complete_replay.jsonl'
    done = read_jsonl(ledger_path) if args.resume else {}
    base = read_jsonl(HERE/'aggregate_results.jsonl', True)
    words = read_jsonl(HERE/'word_results.jsonl', True)
    for idx, entry in done.items():
        assert idx in raw and idx in base
        assert entry['input_sha256'] == header['input_sha256']
        assert entry['mathematical_source_digest'] == source_digest
        assert entry['certificate_digest'] == digest([base[idx], words.get(idx)])
    counts = Counter()
    for entry in done.values():
        counts['assignments'] += 1
        counts['excluded'] += entry['status'] == 'PASS'
        counts['open'] += entry['status'] != 'PASS'
        counts['base_rows'] += entry['base_rows']
        counts['refined_rows'] += entry['refined_rows'] or 0
    announced = -1
    snapshot_ready = None
    with ledger_path.open('a' if args.resume else 'w') as ledger:
        while True:
            base = read_jsonl(HERE/'aggregate_results.jsonl', True)
            words = read_jsonl(HERE/'word_results.jsonl', True)
            assert set(base) <= set(raw)
            assert set(words) <= {i for i,r in base.items() if not r['excluded']}
            ready = {i for i,r in base.items() if r['excluded'] or i in words}
            if snapshot_ready is None:
                snapshot_ready = set(ready)
            if args.once:
                ready &= snapshot_ready
            waiting = sorted(ready-set(done))
            if len(done) == len(raw):
                assert set(done) == set(raw) == set(base)
                assert set(words) == {i for i,r in base.items() if not r['excluded']}
                break
            if not waiting:
                if args.once:
                    break
                time.sleep(2)
                continue
            # Fully release every worker after at most100 assignments. This
            # bounds inherited caches without max_tasks_per_child respawns.
            with ProcessPoolExecutor(max_workers=args.workers, mp_context=get_context('spawn')) as pool:
                futures = {pool.submit(work, (raw[i], base[i], words.get(i))):i
                           for i in waiting[:100]}
                for future in as_completed(futures):
                    idx = futures[future]
                    entry = future.result()
                    assert entry['assignment_index'] == idx and idx not in done
                    entry['input_sha256'] = header['input_sha256']
                    entry['mathematical_source_digest'] = source_digest
                    ledger.write(json.dumps(entry, separators=(',', ':'))+'\n')
                    ledger.flush()
                    done[idx] = entry
                    counts['assignments'] += 1
                    counts['excluded'] += entry['status'] == 'PASS'
                    counts['open'] += entry['status'] != 'PASS'
                    counts['base_rows'] += entry['base_rows']
                    counts['refined_rows'] += entry['refined_rows'] or 0
                    if counts['assignments']//50 != announced:
                        announced = counts['assignments']//50
                        progress = {'status': 'RUNNING', 'counts': dict(counts),
                                    'producer_records': len(base), 'ready_records': len(ready),
                                    'batch_size': len(futures), 'seconds': time.monotonic()-started,
                                    'mathematical_source_digest': source_digest}
                        (HERE/'replay_progress.json').write_text(json.dumps(progress, indent=2)+'\n')
                        print('REPLAY', dict(counts), 'ready', len(ready), flush=True)
                        assert mathematical_source_hashes() == source_hashes, 'mathematical code changed during replay'
    assert mathematical_source_hashes() == source_hashes, 'mathematical code changed during replay'
    complete = set(done) == set(raw)
    result = {**header, 'status': ('HIGHER_RANK_PASS' if counts['excluded'] == len(raw)
                                  else 'COMPLETE_REPLAY_WITH_OPEN_BRANCHES') if complete
                                 else 'PARTIAL_REPLAY_PASS',
              'complete_higher_rank_coverage': complete, 'counts': dict(counts),
              'rank_distribution': dict(sorted(Counter(raw[i]['rank'] for i in done).items())),
              'open_assignment_indices': sorted(i for i,x in done.items() if x['status'] != 'PASS'),
              'mathematical_source_digest': source_digest,
              'ledger_sha256': sha256(ledger_path.read_bytes()).hexdigest(),
              'watcher_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
              'seconds': time.monotonic()-started,
              'scope': 'Complete L12 higher-rank branch only; rank16 is linked to its separate certificate.'}
    (HERE/'complete_higher_verification.json').write_text(json.dumps(result, indent=2)+'\n')
    (HERE/'replay_progress.json').write_text(json.dumps({k:result[k] for k in
        ('status', 'complete_higher_rank_coverage', 'counts', 'open_assignment_indices', 'seconds')}, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in
        ('mathematical_source_hashes', 'input_audit', 'field_coverage_audit')}, indent=2), flush=True)


if __name__ == '__main__':
    main()
