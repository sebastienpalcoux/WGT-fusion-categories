#!/usr/bin/env python3
"""Independent count-vector audit of the entire canonical-length12 input.

The production enumeration chooses successive bounded entries.  This audit
instead chooses multiplicities of each canonical degree and then counts of
each representation degree.  No stored determinant outcome is used to
enumerate the universe.
"""
from collections import Counter
from hashlib import sha256
from itertools import product
from pathlib import Path
import argparse
import json
import time

from probe_length11 import profiles_rec
from verify_length10 import partitions

HERE = Path(__file__).resolve().parent


def audit(records, input_bytes):
    started = time.monotonic()
    profiles = tuple(sorted(profiles_rec(0, 11, 5399), reverse=True))
    assert len(profiles) == len(set(profiles)) == 6547
    expected = set()
    distribution = Counter()
    for profile in profiles:
        counts = Counter(profile)
        degrees = sorted(counts, reverse=True)
        for parts in product(*(partitions(counts[a]) for a in degrees)):
            groups = tuple(sorted((a, m, c)
                for a, part in zip(degrees, parts)
                for m, c in Counter(part).items()))
            key = (profile, groups)
            assert key not in expected
            expected.add(key)
            distribution[1 + sum(m*m*c for a, m, c in groups)] += 1
    actual = {(tuple(r['profile']), tuple(sorted(tuple(g) for g in r['types'])))
              for r in records}
    assert len(records) == len(actual) == len(expected) == 69312
    assert actual == expected
    assert all(r['assignment_index'] == i for i, r in enumerate(records))
    assert distribution == Counter(r['rank'] for r in records)
    assert all(r['rank'] == 1 + sum(m*m*c for a, m, c in r['types'])
               and sum(m*c for a, m, c in r['types']) == 11
               and sum(a*m*c for a, m, c in r['types']) == 5399
               for r in records)
    return {
        'status': 'PASS', 'profiles': len(profiles),
        'assignments': len(records),
        'rank_distribution': dict(sorted(distribution.items())),
        'maximum_rank': max(distribution),
        'maximum_nonlinear_degree': max(m for r in records for a, m, c in r['types']),
        'max_repeated_character_count': max(c for r in records for a, m, c in r['types']),
        'method': 'Independent count-vector profiles and representation-degree count vectors, compared with every bounded-entry assignment.',
        'input_sha256': sha256(input_bytes).hexdigest(),
        'seconds': time.monotonic() - started,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, default=HERE/'input69312.json')
    parser.add_argument('--output', type=Path, default=HERE/'independent_input_audit.json')
    args = parser.parse_args()
    data = args.input.read_bytes()
    result = audit(json.loads(data)['records'], data)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
