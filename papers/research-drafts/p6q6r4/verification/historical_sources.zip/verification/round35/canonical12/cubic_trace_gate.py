"""Exact necessary third-power residues for Galois-stable matrix sums.

Only the first three elementary symmetric coefficients are used. Every
actual polynomial remains included; later coefficients are unrestricted.
"""
from functools import lru_cache
from math import comb,gcd,isqrt
N=5400;MASK=(1<<N)-1

@lru_cache(maxsize=100000)
def cubic_residues(k,s,t,ws,f):
    norm_bound=isqrt(t*t*t)
    bound=0 if k<3 else isqrt(comb(k,3)**2*t**3//k**3)
    residues=set();period=f//gcd(3,f)
    for w in ws:
        p2=t-w
        assert(s*s-p2)%2==0
        e2=(s*s-p2)//2;base=s*p2-e2*s
        lo=max(-bound,-((norm_bound+base)//3))
        hi=min(bound,(norm_bound-base)//3)
        if lo>hi:continue
        residues.update((base+3*e)%f for e in range(lo,min(hi+1,lo+period)))
        # All w have one parity; changing w by2 changes the Newton base
        # by-3s. Thus every w contributes to the same coset modulo gcd(3,f),
        # and period distinct residues exhaust every admissible residue.
        if len(residues)==period:break
    return tuple(sorted(residues))

@lru_cache(maxsize=64)
def linear_ws_map(group,d,sd):
    from canonical12_rows import options
    return {(s,t):ws for s,t,ws in options(group,d,sd)}

def residue_choices(group,d,sd,s,t):
    a,m,c=group;k=m*c;f=N//a
    if sd:ws=(0,)
    elif m>1:
        first=(t-s)%2;top=min(f,(2*k*t-2*s*s)//k)
        ws=range(first,top+1,2)
    else:ws=linear_ws_map(group,d,sd)[(s,t)]
    return cubic_residues(k,s,t,ws,f)

def cubic_trace_possible(groups,row):
    sd,d,values=row;choices=[]
    for group,(s,t)in zip(groups,values):
        rs=residue_choices(group,d,sd,s,t)
        if not rs:return False
        choices.append((group[0],rs))
    choices.sort(key=lambda item:len(item[1]))
    bits=1
    for a,residues in choices:
        new=0
        for v in residues:
            shift=(a*v)%N
            new|=((bits<<shift)|(bits>>(N-shift)))&MASK
        bits=new
    return bool((bits>>((-d**3)%N))&1)
