#!/usr/bin/env python3
"""Independent low-rank coefficients and maximum-rank audit for raw L13 data."""
from hashlib import sha256
from itertools import combinations_with_replacement
from pathlib import Path
import argparse
import json


A = (10, 12, 15, 18, 20, 24, 30, 36, 40, 45, 50, 54, 60, 72,
     75, 90, 100, 108, 120, 135, 150, 180, 200, 216, 225, 270,
     300, 360, 450, 540, 600, 675, 900)
D = 5400
HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target-dir", type=Path, default=HERE.parents[1]/"next_inputs")
    args = parser.parse_args()
    target = args.target_dir
    report = json.loads((target/"length13_counts.json").read_text())
    assert report["status"] == "PASS" and tuple(report["canonical_palette"]) == A
    assert report["weighted_profiles"] == 62776
    assert report["multiplicity_assignments"] == 807656
    assert report["independent_euler_product_assignments"] == 807656
    distribution = {int(k): v for k, v in report["assignment_rank_distribution"].items()}
    assert sum(distribution.values()) == 807656
    assert min(distribution) == 13 and max(distribution) == 69
    assert all(r % 2 == 1 for r in distribution)

    # Count all-linear residual profiles once.  Inserting one or two
    # unordered M2 characters then counts ranks15 and17 independently of
    # the target verifier's complete partition-polynomial convolution.
    f = [[0]*D for _ in range(13)]
    f[0][0] = 1
    for a in A:
        for k in range(1, 13):
            for total in range(a, D):
                f[k][total] += f[k-1][total-a]
    n13 = f[12][5399]
    n15 = sum(f[10][5399-2*a] for a in A if 2*a <= 5399)
    n17 = sum(f[8][5399-2*a-2*b]
              for a, b in combinations_with_replacement(A, 2)
              if 2*a+2*b <= 5399)
    assert (n13, n15, n17) == (62776, 143657, 148110)
    assert all(distribution[r] == n for r, n in ((13, n13), (15, n15), (17, n17)))

    # For a fixed repetition k at canonical degree a, the largest possible
    # rank contribution is k^2.  A separate max-valued coefficient table
    # over degrees computes the global maximum without profile recursion.
    maximum = [[-1]*D for _ in range(13)]
    maximum[0][0] = 0
    for a in A:
        updated = [row[:] for row in maximum]
        for k in range(12):
            for total, value in enumerate(maximum[k]):
                if value < 0:
                    continue
                for repeats in range(1, min(12-k, (5399-total)//a)+1):
                    index = total+repeats*a
                    updated[k+repeats][index] = max(updated[k+repeats][index],
                                                   value+repeats*repeats)
        maximum = updated
    assert 1+maximum[12][5399] == 69
    witness = [600]*8+[450, 75, 54, 20]
    assert sum(witness) == 5399 and len(witness) == 12
    assert 1+8**2+4 == 69
    assert 807656-n13-n15 == 601223
    assert sum(v for r, v in distribution.items() if r >= 19) == 453113

    target_code_hash = sha256((target/"verify_length13_counts.py").read_bytes()).hexdigest()
    assert target_code_hash == report["script_sha256"]
    result = {
        "status": "PASS",
        "reviewer": "/root/round35_cubic_structure",
        "target_verifier_sha256": target_code_hash,
        "target_proof_sha256": sha256((target/"r35_length13_checkpoint.tex").read_bytes()).hexdigest(),
        "target_report_sha256": sha256((target/"length13_counts.json").read_bytes()).hexdigest(),
        "independent_audit_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "profile_partition_bijection_review": "PASS: each repeated canonical degree has an unordered partition into representation degrees; the unit supplies one to rank and is removed from the 12-entry profile.",
        "euler_product_review": "PASS: each generator (a,m) contributes x^m y^(ma), with unbounded multiplicity; the in-place ascending-degree DP counts the stated coefficient exactly.",
        "independent_rank13_count": n13,
        "independent_rank15_count": n15,
        "independent_rank17_count": n17,
        "independent_maximum_rank": 69,
        "rank69_profile_witness": witness,
        "total_raw_assignments": 807656,
        "raw_assignments_after_inherited_rank_exclusions": 601223,
        "raw_assignments_at_ranks19_to69": 453113,
        "rank_shapes_review": "PASS: r-L=sum m(m-1); defects 0,2,4 force C^13, C^11+M2, C^9+M2^2 respectively.",
        "inherited_exclusion_labels_checked": ["r34:commutative-rank-thirteen-excluded", "r34:noncommutative-rank15-exclusion"],
        "scope_review": "PASS: raw necessary multiplicity assignments only, before field, duality, source-type, fusion, or categorification tests; no survival or realizability claim.",
    }
    output = HERE/"length13_checkpoint_review.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
