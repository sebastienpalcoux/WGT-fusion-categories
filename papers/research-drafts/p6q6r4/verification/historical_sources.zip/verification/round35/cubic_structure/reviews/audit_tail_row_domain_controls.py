#!/usr/bin/env python3
"""Positive and negative controls: row domains versus direct matrix boxes."""

from hashlib import sha256
from itertools import combinations_with_replacement, product
from pathlib import Path
import json

from verify_cubic_tail_row_domains import solve_domains


HERE = Path(__file__).resolve().parent


def direct_solutions(dim, p, fixed=None, special=None, forbidden=None):
    n = len(dim)
    fixed, special, forbidden = fixed or {}, special or {}, forbidden or {}
    places = [(i, j) for i in range(n) for j in range(i, n)]
    answers = set()
    checked = 0
    for values in product(range(3), repeat=len(places)):
        checked += 1
        matrix = [[0]*n for _ in range(n)]
        for (i, j), v in zip(places, values):
            matrix[i][j] = matrix[j][i] = v
        if any(tuple(matrix[i]) != tuple(row) for i, row in fixed.items()):
            continue
        if any(matrix[i][j] != 0 for i, columns in forbidden.items() for j in columns):
            continue
        if any(sum(matrix[i][j]*dim[j] for j in range(n)) != 3*dim[i]-12*p[i]
               for i in range(n)):
            continue
        if any(sum(v*v for v in matrix[i]) > min(8-p[i]*p[i], special.get(i, 8))
               for i in range(n)):
            continue
        seen = {i for i, value in enumerate(p) if value}
        for _ in range(n):
            seen |= {j for i in tuple(seen) for j, v in enumerate(matrix[i]) if v}
        if len(seen) != n:
            continue
        answers.add(tuple(tuple(row) for row in matrix))
    return answers, checked


def main():
    cases = matrices = positive = negative = returned = 0
    sample_witnesses = []
    enriched = []

    def compare(dim, p, fixed=None, special=None, forbidden=None):
        nonlocal cases, matrices, positive, negative, returned
        exact, count = direct_solutions(dim, p, fixed, special, forbidden)
        witness, stats = solve_domains(dim, p, fixed or {}, special, forbidden)
        assert (witness is not None) == bool(exact), (dim, p, fixed, special, forbidden)
        if witness is not None:
            assert witness in exact
            returned += 1
        cases += 1
        matrices += count
        positive += bool(exact)
        negative += not exact
        return exact

    for n in (1, 2, 3):
        for dim in combinations_with_replacement((4, 6, 8, 12), n):
            for p in product((0, 1), repeat=n):
                if not any(p):
                    continue
                exact = compare(dim, p)
                if exact:
                    first = min(exact)
                    enriched.append((dim, p, first))
                    if len(sample_witnesses) < 8:
                        sample_witnesses.append({"dimensions": dim, "P": p, "matrix": first})
    base_cases = cases
    assert base_cases == 174
    for dim, p, witness in enriched:
        # Fix one entire valid row; then tighten an independent norm bound.
        compare(dim, p, fixed={0: witness[0]})
        compare(dim, p, special={len(dim)-1: 2})
        # Forbid an off-diagonal edge (or the one diagonal in rank one).
        compare(dim, p, forbidden={0: (len(dim)-1,)})
        # One fixed row with the wrong dimension equation must be rejected.
        wrong = list(witness[0])
        wrong[0] = (wrong[0]+1) % 3
        assert sum(wrong[j]*dim[j] for j in range(len(dim))) != 3*dim[0]-12*p[0]
        assert not compare(dim, p, fixed={0: tuple(wrong)})
    assert positive > 0 and negative > 0 and returned == positive
    result = {
        "status": "PASS",
        "method": "Complete direct boxes of symmetric matrices of orders1,2,3 versus row-domain solver existence and returned witnesses.",
        "base_parameter_cases": base_cases,
        "total_parameter_cases": cases,
        "direct_bounded_matrix_instances": matrices,
        "positive_cases_with_verified_witnesses": positive,
        "negative_cases": negative,
        "sample_positive_witnesses": sample_witnesses,
        "row_domain_verifier_sha256": sha256((HERE/"verify_cubic_tail_row_domains.py").read_bytes()).hexdigest(),
        "control_verifier_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    output = HERE/"tail_row_domain_controls.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print(json.dumps({k: v for k, v in result.items() if k != "sample_positive_witnesses"}, sort_keys=True))


if __name__ == "__main__":
    main()
