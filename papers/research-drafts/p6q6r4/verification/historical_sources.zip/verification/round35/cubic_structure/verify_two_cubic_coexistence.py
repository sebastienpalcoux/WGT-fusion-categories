#!/usr/bin/env python3
"""Exact standalone audit of the two-cubic coexistence extension.

Python standard library only.  This checks the finite arithmetic and
coefficient calculations in the accompanying proof; it does not replace
the positivity, reciprocity, or fusion-simplicity arguments in that proof.
No prior enumerator, computer algebra system, or endpoint data is imported.
"""

from hashlib import sha256
from itertools import combinations_with_replacement, product
import json
from math import isqrt
from pathlib import Path


HERE = Path(__file__).resolve().parent
EXPECTED_TRIPLES = (
    (4, 23, 65), (5, 11, 68), (5, 16, 67), (5, 32, 61),
    (5, 44, 53), (7, 25, 64), (8, 35, 59), (8, 41, 55),
    (9, 33, 60), (12, 45, 51), (15, 24, 63), (15, 36, 57),
    (16, 17, 65), (19, 40, 53), (21, 27, 60), (21, 45, 48),
    (25, 44, 47), (28, 31, 55), (29, 35, 52), (31, 40, 47),
)
PALETTE = (
    10, 12, 15, 18, 20, 24, 30, 36, 40, 45, 50, 54, 60, 72,
    75, 90, 100, 108, 120, 135, 150, 180, 200, 216, 225, 270,
    300, 360, 450, 540, 600, 675, 900,
)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def coefficients():
    # t1=t, t2=t^2-2, t3=2-t-t^2 in Q[t]/(t^3-3t+1).
    # The nonrational coordinates force n1=n2=n3 exactly.
    checked = 0
    solutions = []
    for a, z, n1, n2, n3 in product(range(6), repeat=5):
        value = (a-z-2*n2+2*n3, n1-n3, n2-n3)
        expected = z == a+1 and n1 == n2 == n3
        assert (value == (-1, 0, 0)) == expected
        if expected:
            solutions.append((a, z, n1, n2, n3))
        checked += 1

    remainder_patterns = {}
    for h in (4, 5):
        for sign, target in ((1, h*(h-1)-5), (-1, h*(h-2)-5)):
            raw = []
            for a in range(target//11+1):
                for c in range(target//9+1):
                    residual = target-6-11*a-9*c
                    if residual >= 0:
                        raw.append((a, c, residual))
            admissible = [t for t in raw if t[2] == 0 or t[2] >= 4]
            remainder_patterns[f"h{h}_sign{sign}"] = {
                "dimension": target,
                "nonnegative_patterns": raw,
                "unit_free_minimum_dimension_patterns": admissible,
            }
    assert remainder_patterns["h4_sign1"]["nonnegative_patterns"] == [(0, 0, 1)]
    assert remainder_patterns["h4_sign1"]["unit_free_minimum_dimension_patterns"] == []
    assert remainder_patterns["h4_sign-1"]["nonnegative_patterns"] == []
    assert remainder_patterns["h5_sign1"]["nonnegative_patterns"] == [(0, 0, 9), (0, 1, 0)]
    assert remainder_patterns["h5_sign-1"]["nonnegative_patterns"] == [(0, 0, 4)]
    # Norm(X_i A_j)=1+c, and the three A_j coefficients are c.
    assert [c for c in (0, 1) if 3*c*c <= 1+c] == [0]

    # At the (6,7) endpoint extension, second values Y=0,Z=1.
    # At the (4,5) extension, second values Y=-1,Z=0.
    endpoint_values = {
        "6_7": 0**2-1-0-1,
        "4_5": (-1)**2-1-(-1)-0,
    }
    assert endpoint_values == {"6_7": -2, "4_5": 1}
    assert 2*7 > 13
    assert 405 == 1 + 3*3**2 + 4**2 + 5**2 + 6**2 + 9**2 + 12**2 + 3*5**2
    assert 630 == 405 + 15**2
    assert 855 == 405 + 2*15**2
    return {
        "checked_coefficient_tuples": checked,
        "coefficient_rule_solutions": len(solutions),
        "endpoint_character_values": endpoint_values,
        "second_remainder_patterns": remainder_patterns,
        "cross_product_norm_one": True,
    }


def square_pair_isqrt(total):
    ans = []
    for a in range(4, isqrt(total//2)+1):
        b2 = total-a*a
        b = isqrt(b2)
        if b >= a and b*b == b2:
            ans.append((a, b))
    return ans


def square_pair_direct(total):
    return [(a, b) for a, b in combinations_with_replacement(
        range(4, isqrt(total)+1), 2) if a*a+b*b == total]


def small_square_checks():
    nonsquares = (4545, 4770, 2385)
    for n in nonsquares:
        assert isqrt(n)**2 != n
    eq4545 = square_pair_isqrt(4545)
    eq4770 = square_pair_isqrt(4770)
    assert eq4545 == square_pair_direct(4545) == [(24, 63), (36, 57)]
    assert eq4770 == square_pair_direct(4770) == [(39, 57)]
    weighted1 = []
    for u in range(4, isqrt(4770//2)+1):
        t2 = 4770-2*u*u
        t = isqrt(t2)
        if t >= 4 and t*t == t2:
            weighted1.append((t, u))
    weighted2 = [(t, u) for t in range(4, isqrt(4770)+1)
                 for u in range(4, isqrt(4770//2)+1)
                 if t*t+2*u*u == 4770]
    assert weighted1 == weighted2 == []
    # Residual dimension twenty-one after S'+B in the rank-15 case.
    assert not any(15*a+39*b+57*c == 21
                   for a in range(2) for b in range(1) for c in range(1))
    return {
        "nonsquares": nonsquares,
        "u2_plus_v2_4545": eq4545,
        "u2_plus_v2_4770": eq4770,
        "t2_plus_2u2_4770": weighted1,
        "residual21_not_in_semigroup_15_39_57": True,
    }


def triples_by_isqrt():
    ans = []
    for a in range(4, isqrt(4770//3)+1):
        for b in range(a, isqrt((4770-a*a)//2)+1):
            c2 = 4770-a*a-b*b
            c = isqrt(c2)
            if c >= b and c*c == c2:
                ans.append((a, b, c))
    return tuple(ans)


def triples_direct():
    return tuple(d for d in combinations_with_replacement(
        range(4, isqrt(4770)+1), 3) if sum(x*x for x in d) == 4770)


def coin_recursion(weights, total):
    if total < 0:
        return
    if not weights:
        if total == 0:
            yield ()
        return
    for n in range(total//weights[0]+1):
        for rest in coin_recursion(weights[1:], total-n*weights[0]):
            yield (n,) + rest


def budget_states_recursive(d):
    states = []
    for q in coin_recursion((9, 15)+d, 15):
        for r in coin_recursion((15,)+d, 30-9*q[1]):
            rho = tuple(3*d[j]-9*q[j+2]-15*r[j+1] for j in range(3))
            states.append((q, r, rho))
    return tuple(sorted(states))


def budget_states_box(d):
    # Separate direct bounding-box enumeration.  The ranges depend only
    # on each budget's positive coefficients, not on the recursive solver.
    q_weights = (9, 15)+d
    r_weights = (15,)+d
    q_candidates = [q for q in product(*(range(15//w+1) for w in q_weights))
                    if sum(x*w for x, w in zip(q, q_weights)) == 15]
    r_candidates = tuple(product(*(range(30//w+1) for w in r_weights)))
    states = []
    for q in q_candidates:
        for r in r_candidates:
            if 9*q[1] + sum(x*w for x, w in zip(r, r_weights)) != 30:
                continue
            rho = tuple(3*d[j]-9*q[j+2]-15*r[j+1] for j in range(3))
            states.append((q, r, rho))
    return tuple(sorted(states))


def matrices_by_residual(d, rho):
    a, b, c = d
    x, y, z = rho
    ans = []
    for ab in range(min(3, x//b, y//a)+1):
        for ac in range(min(3, (x-ab*b)//c, z//a)+1):
            aa_value = x-ab*b-ac*c
            if aa_value % a or not 0 <= aa_value//a <= 2:
                continue
            for bc in range(min(3, (y-ab*a)//c, (z-ac*a)//b)+1):
                bb_value = y-ab*a-bc*c
                cc_value = z-ac*a-bc*b
                if bb_value % b or cc_value % c:
                    continue
                aa, bb, cc = aa_value//a, bb_value//b, cc_value//c
                if 0 <= bb <= 2 and 0 <= cc <= 2:
                    ans.append((aa, bb, cc, ab, ac, bc))
    return tuple(sorted(ans))


def matrices_by_full_box(d, rho):
    a, b, c = d
    ans = []
    checked = 0
    for aa, bb, cc in product(range(3), repeat=3):
        for ab, ac, bc in product(range(4), repeat=3):
            checked += 1
            image = (aa*a+ab*b+ac*c, ab*a+bb*b+bc*c, ac*a+bc*b+cc*c)
            if image == rho:
                ans.append((aa, bb, cc, ab, ac, bc))
    assert checked == 1728
    return tuple(sorted(ans)), checked


def tail_completion():
    triples = triples_by_isqrt()
    assert triples == triples_direct() == EXPECTED_TRIPLES
    all_states = []
    nonnegative_states = []
    checked_matrices = 0
    survivors = []
    type_counts = []
    for d in triples:
        states = budget_states_recursive(d)
        assert states == budget_states_box(d)
        nonnegative_count = 0
        for q, r, rho in states:
            record = {"dimensions": d, "q": q, "r": r, "rho": rho}
            all_states.append(record)
            if min(rho) < 0:
                continue
            nonnegative_count += 1
            nonnegative_states.append(record)
            residual_solutions = matrices_by_residual(d, rho)
            box_solutions, count = matrices_by_full_box(d, rho)
            checked_matrices += count
            assert residual_solutions == box_solutions
            if box_solutions:
                survivors.append({**record, "matrices": box_solutions})
        type_counts.append({"dimensions": d, "budget_states": len(states),
                            "nonnegative_states": nonnegative_count})
    assert len(all_states) == 23
    assert len(nonnegative_states) == 9
    assert checked_matrices == 9*1728 == 15552
    assert not survivors
    expected_rhs = {
        ((5, 16, 67), (0, 33, 201)),
        *((((15, 24, 63), (p, 72, 189))) for p in (6, 21, 36)),
        *((((15, 36, 57), (p, 108, 171))) for p in (6, 21, 36)),
        ((21, 27, 60), (48, 81, 180)),
        ((21, 45, 48), (48, 135, 144)),
    }
    assert {(s["dimensions"], s["rho"]) for s in nonnegative_states} == expected_rhs
    return {
        "dimension_triples": triples,
        "dimension_triple_count": len(triples),
        "budget_state_count": len(all_states),
        "negative_rhs_count": len(all_states)-len(nonnegative_states),
        "nonnegative_rhs_count": len(nonnegative_states),
        "bounded_matrices_per_nonnegative_state": 1728,
        "bounded_matrix_instances_checked": checked_matrices,
        "matrix_survivors": survivors,
        "per_type_counts": type_counts,
        "all_budget_states": all_states,
        "independent_dimension_and_budget_generators_agree": True,
        "independent_matrix_solvers_agree": True,
    }


def palette_check():
    odd = [a for a in PALETTE if a % 2]
    assert odd == [15, 45, 75, 135, 225, 675]
    assert all(a % 3 == 0 or a % 5 == 0 for a in PALETTE)
    congruence_pairs = [(b, c) for b in PALETTE for c in PALETTE
                        if (b+c) % 3 == 1 and (b+c) % 5 == 2]
    oriented = {(b, c) if b % 3 else (c, b) for b, c in congruence_pairs}
    assert oriented == set(product((10, 40, 100), (12, 72)))
    assert max(b+c for b, c in congruence_pairs) == 172
    assert min((1799-a)//2 for a in odd) == 562
    solutions = [(a, b, c) for a in PALETTE for b in PALETTE
                 for c in PALETTE if a+2*b+2*c == 1799]
    assert not solutions
    return {
        "palette_count": len(PALETTE),
        "odd_degrees": odd,
        "oriented_congruence_pairs": sorted(oriented),
        "maximum_congruence_pair_sum": 172,
        "minimum_required_pair_sum": 562,
        "mass_identity_solutions": solutions,
    }


def main():
    report = {
        "status": "PASS",
        "scope": "Exact coefficient and finite arithmetic audit; written proof supplies structural hypotheses.",
        "proof_sha256": digest(HERE / "r35_two_cubic_coexistence.tex"),
        "verifier_sha256": digest(Path(__file__).resolve()),
        "frozen_closure_proof_sha256": digest(HERE / "r35_cubic_three_closure.tex"),
        "coefficients": coefficients(),
        "small_square_checks": small_square_checks(),
        "rank16_tail_completion": tail_completion(),
        "two_matrix_palette_check": palette_check(),
    }
    output = HERE / "two_cubic_coexistence_verification.json"
    output.write_text(json.dumps(report, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "output": str(output),
                      "proof_sha256": report["proof_sha256"],
                      "verifier_sha256": report["verifier_sha256"],
                      "coefficient_tuples": report["coefficients"]["checked_coefficient_tuples"],
                      "dimension_triples": 20, "budget_states": 23,
                      "nonnegative_rhs": 9, "bounded_matrix_checks": 15552,
                      "matrix_survivors": 0, "palette_solutions": 0}, sort_keys=True))


if __name__ == "__main__":
    main()
