#!/usr/bin/env python3
"""Exact audit of the conditional dimension-three cubic closure.

Only Python's standard library is used.  The universal polynomial model
checks identities and is not asserted to be a fusion ring.  Positivity,
reciprocity, and support arguments are supplied in the accompanying proof.
The report is deterministic so that a fresh replay preserves its hash.
"""
from collections import Counter
from itertools import combinations_with_replacement, product
from math import isqrt
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent


def trim(p):
    p = list(p)
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return tuple(p)


def padd(p, q):
    return trim(tuple((p[i] if i < len(p) else 0) +
                      (q[i] if i < len(q) else 0)
                      for i in range(max(len(p), len(q)))))


def pscale(p, a):
    return trim(tuple(a*x for x in p))


def pmul(p, q):
    ans = [0]*(len(p)+len(q)-1)
    for i, x in enumerate(p):
        for j, y in enumerate(q):
            ans[i+j] += x*y
    return trim(ans)


def kreduce(p):
    p = list(p) + [0]*max(0, 3-len(p))
    for i in range(len(p)-1, 2, -1):
        a = p[i]
        p[i] = 0
        p[i-2] += 3*a
        p[i-3] -= a
    return tuple(p[:3])


def kadd(p, q):
    return tuple(x+y for x, y in zip(p, q))


def kscale(p, a):
    return tuple(a*x for x in p)


def kmul(p, q):
    return kreduce(pmul(p, q))


def add(a, b):
    return (padd(a[0], b[0]), kadd(a[1], b[1]))


def scale(a, s):
    return (pscale(a[0], s), kscale(a[1], s))


def sub(a, b):
    return add(a, scale(b, -1))


def mul(a, b):
    return (pmul(a[0], b[0]), kmul(a[1], b[1]))


def total(items):
    ans = ((0,), (0, 0, 0))
    for item in items:
        ans = add(ans, item)
    return ans


def dim(a):
    return sum(x*3**i for i, x in enumerate(a[0]))


def partitions(n, minimum=4):
    """All unordered positive dimension multisets with entries >= minimum."""
    if n == 0:
        yield ()
    for first in range(minimum, n+1):
        for rest in partitions(n-first, first):
            yield (first,)+rest


def coordinate_checks():
    eta = ((0, 1, 0), (-2, 0, 1), (2, -1, -1))
    one = (1, 0, 0)
    zero = (0, 0, 0)
    assert kadd(kadd(eta[0], eta[1]), eta[2]) == zero
    assert all(kadd(kadd(kmul(kmul(t, t), t), kscale(t, -3)), one) == zero
               for t in eta)
    # Independent coefficient calculation: the rational and t,t^2
    # coefficients of n+sum c_i t_i vanish exactly for n=0,c1=c2=c3.
    checked = 0
    for n, a, b, c in product(range(-5, 6), repeat=4):
        v = kadd(kscale(one, n),
                 kadd(kscale(eta[0], a),
                      kadd(kscale(eta[1], b), kscale(eta[2], c))))
        assert (v == zero) == (n == 0 and a == b == c)
        checked += 1
    # The exact coefficient matrix gives the general, unbounded relation.
    # Coordinates: (n-2b+2c, a-c, b-c).
    assert eta[0][1] == eta[1][2] == 1
    return eta, checked


def universal_identity_checks(eta):
    one = ((1,), (1, 0, 0))
    x = [((0, 1), t) for t in eta]
    y = ((-1, -1, 1), (1, 0, 0))
    z = ((0, -1, 1), (-1, 0, 0))
    s = total(x)
    w = sub(mul(y, x[0]), x[0])
    p = sub(mul(y, y), total((one, y, z)))
    assert w[1] == p[1] == (0, 0, 0)
    assert [dim(a) for a in (one, *x, y, z, w, p)] == [1, 3, 3, 3, 5, 6, 12, 13]
    checks = 0
    for i in range(3):
        assert mul(x[i], x[i]) == total((one, y, x[(i+1) % 3]))
        assert mul(x[i], x[(i+1) % 3]) == add(z, x[i])
        assert mul(y, x[i]) == add(x[i], w)
        assert mul(z, x[i]) == add(sub(s, x[i]), w)
        assert mul(x[i], w) == total((y, z, w, p))
        assert mul(x[i], p) == sub(mul(y, w), add(s, w))
        checks += 6
    assert mul(z, w) == add(mul(y, w), w)
    checks += 1
    for k in (1, 2, 3):
        q = sub(mul(x[0], p), scale(w, k))
        assert mul(y, w) == total((s, scale(w, k+1), q))
        assert mul(z, w) == total((s, scale(w, k+2), q))
        assert dim(q) == 39-12*k
        # A further positive identity, useful as an arithmetic control.
        assert mul(w, w) == total((one, s, y, scale(z, 2),
                                  scale(w, k), p, q, mul(y, p)))
        checks += 4
    return checks


def low_dimension_checks():
    possibilities = {}
    for d in (3, 4):
        choices = []
        for a in range(d*d//11+1):
            for c in range(d*d//9+1):
                rem = d*d-7-11*a-9*c
                minimum = 3 if d == 3 else 4
                if rem < 0 or (rem != 0 and rem < minimum):
                    continue
                choices.append((a, c, rem))
        possibilities[d] = choices
    assert possibilities[3] == []
    assert possibilities[4] == [(0, 0, 9), (0, 1, 0)]
    for a, c, rem in possibilities[4]:
        norm = 1+a+c
        assert norm == 1+c and c in (0, 1)
        assert 12-4*c in (12, 8)
    assert list(partitions(6)) == [(6,)]
    assert list(partitions(8)) == [(4, 4), (8,)]
    assert list(partitions(9)) == [(4, 5), (9,)]
    return possibilities


def remainder_checks():
    # Method 1: positive dimension multisets and their multiplicity norms.
    preliminary = [p for p in partitions(13)
                   if sum(m*m for m in Counter(p).values()) <= 2]
    # Method 2: direct coefficient vectors on dimensions 4,...,13.
    independent = []
    for multiplicities in product(range(3), repeat=10):
        if sum(m*m for m in multiplicities) > 2:
            continue
        if sum((4+i)*m for i, m in enumerate(multiplicities)) != 13:
            continue
        independent.append(tuple(d for d, m in zip(range(4, 14), multiplicities)
                                 for _ in range(m)))
    assert set(preliminary) == set(independent) == {(13,), (4, 9), (5, 8), (6, 7)}
    final = [p for p in preliminary if 5 not in p]
    assert set(final) == {(13,), (4, 9), (6, 7)}
    for k in (1, 2, 3):
        q = 39-12*k
        assert q >= 0
        assert (q >= 4) == (k <= 2)
    # A dimension-five summand in P would leave three after removing W.
    assert 3*5-12 == 3
    # In the (6,7) case the only nonsimple residual9 would use a4.
    assert [p for p in partitions(9) if 4 not in p] == [(9,)]
    return {'preliminary': sorted(preliminary), 'final': sorted(final)}


def rank16_checks():
    # With exactly eight selfdual labels, P must be the one simple13.
    assert 1+6+2 > 8 and 1+6+1 == 8
    q_patterns = []
    for multiplicity13 in range(3):
        rem = 27-13*multiplicity13
        if rem < 0 or rem % 2:
            continue
        for pairs in partitions(rem//2):
            q_patterns.append((multiplicity13, pairs))
    assert q_patterns == [(1, (7,))]
    residual8 = list(partitions(3*7-13))
    assert residual8 == [(4, 4), (8,)]
    assert [p for p in residual8 if 4 not in p] == [(8,)]
    known = 1+3*3**2+5**2+6**2+12**2+13**2+2*7**2+2*8**2
    assert known == 628
    target = (5400-known)//2
    assert target == 2386
    squares = []
    for u in range(4, isqrt(target//2)+1):
        v2 = target-u*u
        v = isqrt(v2)
        if v*v == v2 and v >= u:
            squares.append((u, v))
    # Separate direct Cartesian enumeration of the complete dimension range.
    square_pairs = [(u, v) for u in range(4, 49) for v in range(u, 49)
                    if u*u+v*v == target]
    assert squares == square_pairs == [(19, 45)]
    dimensions = (1, 3, 3, 3, 5, 6, 12, 13, 7, 7, 8, 8, 19, 19, 45, 45)
    assert len(dimensions) == 16 and sum(d*d for d in dimensions) == 5400
    # Removing the forced7 from Xi*T8 leaves an impossible semigroup sum.
    assert 3*8-7 == 17
    semigroup_solutions = [(a, b, c, d)
                          for a in range(17//7+1)
                          for b in range(17//8+1)
                          for c in range(17//19+1)
                          for d in range(17//45+1)
                          if 7*a+8*b+19*c+45*d == 17]
    assert not semigroup_solutions
    # Independently form reachable sums up to17 by an unbounded coin DP.
    reached = {0}
    for n in range(18):
        if n in reached:
            reached.update(n+d for d in (7, 8, 19, 45) if n+d <= 17)
    assert 17 not in reached
    return {'q_pattern': q_patterns,
            'square_equation': target, 'square_solutions': squares,
            'hypothetical_source_dimensions': dimensions,
            'remaining_dimension': 17,
            'semigroup_solutions': semigroup_solutions}


def low_rank_selfduality_checks():
    # For simple P13, p=[Q:P] is 0 or1 and dimension(Y P)=65 bounds
    # the squared norm.  This is a check of the exact derived inequality.
    norm_options = [(p, norm) for p in (0, 1) for norm in range(1, 28)
                    if 11+13*norm-p <= 65]
    assert max(norm for p, norm in norm_options) == 4
    assert not any(13*m <= 27 and 0 < 27-13*m < 4 for m in (0, 1))
    assert 27-2*13 == 1  # explains why p=2 is forbidden

    # With nine selfdual labels the one additional selfdual dimension
    # is even.  Enumerate every Q-P pattern of dimension14 and norm<=3.
    q_forms = set()
    for t in range(4, 73, 2):
        for h in range(4):
            if h and t == 4:
                continue  # no dimension4 may occur in Q
            remaining = 14-h*t
            if remaining < 0 or remaining % 2:
                continue
            for pair_dimensions in partitions(remaining//2, 5):
                norm = h*h+2*sum(m*m for m in Counter(pair_dimensions).values())
                if norm <= 3:
                    q_forms.add((h, t if h else None, pair_dimensions))
    assert q_forms == {(1, 14, ()), (0, None, (7,))}
    # Q=P+T14 would give a selfdual product Xi*T14 with one P13
    # and residual odd dimension29 supported only on even mass.
    assert 3*14-13 == 29 and 29 % 2 == 1

    # If the forced8 is selfdual, the remainder10 in Xi*T8 must be
    # one nonselfdual5-pair; copies of the selfdual8 cannot occur.
    residual10 = []
    for h in range(2):
        remaining = 10-8*h
        if remaining < 0 or remaining % 2:
            continue
        for ds in partitions(remaining//2):
            residual10.append((h, ds))
    assert residual10 == [(0, (5,))]
    assert 402+8**2+2*7**2+2*5**2 == 614
    assert (5400-614)//2 == 2393
    for n in (2386, 2393, 4772):
        assert isqrt(n)**2 != n

    # If the forced8 is nonselfdual, at rank<=16 only one additional
    # pair can remain.  Verify the mixed square equation by two routes.
    mixed = []
    for t in range(4, 69, 2):
        remainder = 4772-t*t
        if remainder < 0 or remainder % 2:
            continue
        u = isqrt(remainder//2)
        if u >= 4 and 2*u*u == remainder:
            mixed.append((t, u))
    direct = [(t, u) for t in range(4, 70, 2) for u in range(4, 49)
              if t*t+2*u*u == 4772]
    assert mixed == direct == [(30, 44)]
    dims = (1, 3, 3, 3, 5, 6, 12, 13, 30, 7, 7, 8, 8, 44, 44)
    assert len(dims) == 15 and sum(d*d for d in dims) == 5400
    reached = {0}
    for n in range(18):
        if n in reached:
            reached.update(n+d for d in (7, 8, 30, 44) if n+d <= 17)
    brute = [(a, b, c, d) for a in range(3) for b in range(3)
             for c in range(1) for d in range(1)
             if 7*a+8*b+30*c+44*d == 17]
    assert 17 not in reached and brute == []
    return {'simple13_q_norm_maximum': 4,
            'nine_selfdual_q_forms': [[h, t, list(ds)] for h, t, ds in
                                      sorted(q_forms, key=repr)],
            'nonsquares_checked': [2386, 2393, 4772],
            'mixed_square_solutions': mixed,
            'hypothetical_rank15_dimensions': dims,
            'rank14_pair_bound': 2, 'rank15_pair_bound': 2,
            'rank16_pair_bound': 3,
            'eight_selfdual_minimum_rank': 18,
            'nine_selfdual_minimum_rank': 17}


def involution_checks():
    one_orth = [q for q in range(7) if q+1 <= 3]
    one_symp = [q for q in range(7) if q+3 <= 3]
    two_fixed = [(q, s) for q in range(5) for s in range(3)
                 if q+2+2*s <= 3]
    two_exchanged = [q for q in range(5) if q+4 <= 3]
    assert one_orth == [0, 1, 2] and one_symp == [0]
    assert two_fixed == [(0, 0), (1, 0)] and two_exchanged == []
    return {'one_orthogonal_q': one_orth, 'one_symplectic_q': one_symp,
            'two_fixed_q_symplectic_count': two_fixed,
            'two_exchanged_q': two_exchanged}


def main():
    assert __debug__, 'Keep assertions enabled.'
    eta, coefficient_cases = coordinate_checks()
    identity_cases = universal_identity_checks(eta)
    low = low_dimension_checks()
    remainders = remainder_checks()
    endpoint = rank16_checks()
    low_rank = low_rank_selfduality_checks()
    involutions = involution_checks()
    report = {
        'status': 'PASS',
        'scope': ('Exact finite and identity audit of the written conditional '
                  'cubic d=3 proof; not a complete rank16 category enumeration.'),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'proof_sha256': hashlib.sha256((HERE/'r35_cubic_three_closure.tex').read_bytes()).hexdigest(),
        'cubic_coefficient_instances': coefficient_cases,
        'universal_polynomial_identities': identity_cases,
        'zero_value_low_dimension_alternatives': low,
        'dimension_thirteen_remainders': remainders,
        'rank16_four_pair_exclusion': endpoint,
        'unified_low_rank_selfduality': low_rank,
        'matrix_involution_consequences': involutions,
        'no_category_existence_claim': True,
    }
    destination = HERE/'cubic_three_closure_verification.json'
    destination.write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
