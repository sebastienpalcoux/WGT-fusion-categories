#!/usr/bin/env python3
"""Independent exact cubic tail-matrix exclusion by row-domain consistency.

This does not import the mutable-budget search used by the producer.
It independently generates complete row domains, enforces symmetry by
arc consistency, then branches on a whole row.  No floating point or
principal-minor pruning is used.  Every square-partition source type is
regenerated independently before comparison with the published input.

Assertions must be enabled.  Python standard library only.
"""

from collections import Counter
from functools import lru_cache
from hashlib import sha256
from itertools import product
from math import gcd, isqrt
from pathlib import Path
import argparse
import gzip
import json
import time


HERE = Path(__file__).resolve().parent
ROUND35 = HERE.parents[1]
COMMON_CORE = (1, 3, 3, 3, 5, 6, 12)
BRANCH_CORES = {
    "P13": tuple(sorted(COMMON_CORE+(13,))),
    "P4_9": tuple(sorted(COMMON_CORE+(4, 9))),
    "P6_7": tuple(sorted(COMMON_CORE+(6, 7, 9))),
}
EXPECTED = {
    "P13": {14: 6523, 15: 33190, 16: 144857},
    "P4_9": {14: 1112, 15: 7023, 16: 34277},
    "P6_7": {14: 114, 15: 635, 16: 4805},
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


@lru_cache(None)
def ordered_square_partitions(total, length, minimum=4):
    if length == 0:
        return ((),) if total == 0 else ()
    if total < length*minimum*minimum:
        return ()
    if length == 1:
        d = isqrt(total)
        return ((d,),) if d >= minimum and d*d == total else ()
    out = []
    for d in range(minimum, isqrt(total//length)+1):
        for rest in ordered_square_partitions(total-d*d, length-1, d):
            out.append((d,)+rest)
    return tuple(out)


def source_types(branch, rank):
    core = BRANCH_CORES[branch]
    if rank < len(core):
        return ()
    extras = ordered_square_partitions(5400-sum(d*d for d in core), rank-len(core))
    answer = tuple(sorted(tuple(sorted(core+extra)) for extra in extras))
    assert len(answer) == len(set(answer))
    if rank in EXPECTED[branch]:
        assert len(answer) == EXPECTED[branch][rank]
    return answer


def row_domain(dim, target, square_cap, allowed):
    """Every bounded nonnegative row with given weighted sum and norm cap."""
    n = len(dim)
    order = sorted(range(n), key=lambda j: (len(allowed[j]), -dim[j]))
    lower = [0]*(n+1)
    upper = [0]*(n+1)
    for k in range(n-1, -1, -1):
        j = order[k]
        if not allowed[j]:
            return ()
        lower[k] = lower[k+1]+min(allowed[j])*dim[j]
        upper[k] = upper[k+1]+max(allowed[j])*dim[j]
    values = [0]*n
    out = []

    def generate(k, left, norm_left):
        if norm_left < 0 or not lower[k] <= left <= upper[k]:
            return
        if k == n:
            if left == 0:
                out.append(tuple(values))
            return
        j = order[k]
        for v in allowed[j]:
            if v*v <= norm_left:
                values[j] = v
                generate(k+1, left-v*dim[j], norm_left-v*v)

    generate(0, target, square_cap)
    return tuple(out)


def possible_connection(domains, roots):
    seen = set(roots)
    queue = list(roots)
    while queue:
        i = queue.pop()
        for j in range(len(domains)):
            if j not in seen and any(row[j] for row in domains[i]):
                seen.add(j)
                queue.append(j)
    return len(seen) == len(domains)


def arc_consistency(domains, roots, statistics):
    """Exact pairwise symmetry support propagation over complete row domains."""
    domains = list(domains)
    while True:
        if any(not domain for domain in domains):
            return None
        allowed = [[{row[j] for row in domain} for j in range(len(domains))]
                   for domain in domains]
        revised = []
        for i, domain in enumerate(domains):
            revised.append(tuple(row for row in domain
                                 if all(row[j] in allowed[j][i]
                                        for j in range(len(domains)))))
        statistics["arc_passes"] += 1
        if any(not domain for domain in revised):
            return None
        if revised == domains:
            return tuple(revised) if possible_connection(revised, roots) else None
        domains = revised


def solve_domains(dim, p, fixed_rows, special_norms=None, forbidden=None):
    n = len(dim)
    special_norms = special_norms or {}
    forbidden = forbidden or {}
    caps = [min(8-p[i]*p[i], special_norms.get(i, 8)) for i in range(n)]
    targets = [3*dim[i]-12*p[i] for i in range(n)]
    roots = tuple(i for i, value in enumerate(p) if value)
    statistics = {"row_patterns": 0, "search_nodes": 0, "arc_passes": 0}
    domains = [None]*n
    # Fixed and specially bounded rows are generated first.  Previously
    # generated complete domains can restrict symmetry support safely.
    order = sorted(range(n), key=lambda i: (i not in fixed_rows,
                    i not in special_norms, targets[i], dim[i]))
    for i in order:
        allowed = []
        for j in range(n):
            values = {0, 1, 2}
            if i in fixed_rows:
                values.intersection_update((fixed_rows[i][j],))
            if j in fixed_rows:
                values.intersection_update((fixed_rows[j][i],))
            if j in forbidden.get(i, ()) or i in forbidden.get(j, ()):
                values.intersection_update((0,))
            if domains[j] is not None:
                values.intersection_update(row[i] for row in domains[j])
            allowed.append(tuple(sorted(values)))
        domains[i] = row_domain(dim, targets[i], caps[i], allowed)
        statistics["row_patterns"] += len(domains[i])
        if not domains[i]:
            return None, statistics

    def search(current):
        statistics["search_nodes"] += 1
        current = arc_consistency(current, roots, statistics)
        if current is None:
            return None
        if all(len(domain) == 1 for domain in current):
            matrix = tuple(domain[0] for domain in current)
            assert all(matrix[i][j] == matrix[j][i] for i in range(n) for j in range(n))
            assert all(sum(matrix[i][j]*dim[j] for j in range(n)) == targets[i]
                       for i in range(n))
            assert all(sum(v*v for v in matrix[i]) <= caps[i] for i in range(n))
            assert possible_connection(current, roots)
            return matrix
        i = min((i for i in range(n) if len(current[i]) > 1),
                key=lambda i: len(current[i]))
        for row in current[i]:
            restricted = list(current)
            restricted[i] = (row,)
            result = search(tuple(restricted))
            if result is not None:
                return result
        return None

    return search(tuple(domains)), statistics


def branch_cases(dimensions, branch):
    tail = tuple(sorted((Counter(dimensions)-Counter(COMMON_CORE)).elements()))
    n = len(tail)
    if branch == "P13":
        p_index = tail.index(13)
        p = tuple(int(i == p_index) for i in range(n))
        yield tail, p, {}, {p_index: 4}, {p_index: tuple(i for i, d in enumerate(tail) if d == 4)}, {}
    elif branch == "P4_9":
        u, v = tail.index(4), tail.index(9)
        p = tuple(int(i in (u, v)) for i in range(n))
        yield tail, p, {u: (0,)*n}, {v: 3}, {v: tuple(i for i, d in enumerate(tail) if d == 4)}, {}
    elif branch == "P6_7":
        u, v = tail.index(6), tail.index(7)
        p = tuple(int(i in (u, v)) for i in range(n))
        # Enumerate every T6 and T9 position, including equal-dimensional
        # relabelings that the production scan quotients out.
        for t6 in (i for i, d in enumerate(tail) if d == 6):
            for t9 in (i for i, d in enumerate(tail) if d == 9):
                fixed = {u: tuple(int(i == t6) for i in range(n)),
                         v: tuple(int(i == t9) for i in range(n))}
                yield tail, p, fixed, {}, {}, {"T6_index": t6, "T9_index": t9}
    else:
        raise AssertionError(branch)


def check_type(dimensions, branch):
    counts = Counter()
    for tail, p, fixed, norms, forbidden, labels in branch_cases(dimensions, branch):
        counts["label_cases"] += 1
        matrix, statistics = solve_domains(tail, p, fixed, norms, forbidden)
        counts.update(statistics)
        if matrix is not None:
            return {"status": "OPEN_NECESSARY_MATRIX", "dimensions": dimensions,
                    "tail": tail, "P": p, "matrix": matrix,
                    "label_choices": labels, **dict(counts)}
    return {"status": "EXCLUDED", "dimensions": dimensions, **dict(counts)}


def check_dataset(input_path, requested):
    expected = {key: set(source_types(*key)) for key in requested if key[1] >= 14}
    observed = {key: set() for key in expected}
    with gzip.open(input_path, "rt", encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            for branch in row["P_branches"]:
                key = branch, row["rank"]
                if key in observed:
                    value = tuple(row["dimensions"])
                    assert value not in observed[key]
                    observed[key].add(value)
    assert expected == observed
    return {f"{branch}_rank{rank}": len(values)
            for (branch, rank), values in sorted(expected.items())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--branch", choices=("P13", "P4_9", "P6_7", "all"), default="P6_7")
    parser.add_argument("--ranks", type=int, nargs="+", default=list(range(10, 17)))
    parser.add_argument("--input", type=Path, default=ROUND35/"next_inputs/cubic_d3_raw_types.jsonl.gz")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    started = time.monotonic()
    branches = tuple(BRANCH_CORES) if args.branch == "all" else (args.branch,)
    requested = tuple((branch, rank) for branch in branches for rank in sorted(set(args.ranks)))
    dataset_counts = check_dataset(args.input, requested)
    output = args.output or HERE/f"cubic_tail_{args.branch}_row_domain_audit.json"
    reports = []
    for branch, rank in requested:
        records = []
        for number, dimensions in enumerate(source_types(branch, rank), 1):
            records.append(check_type(dimensions, branch))
            if number % 10000 == 0:
                print(json.dumps({"branch": branch, "rank": rank, "checked": number,
                                  "open": sum(r["status"] != "EXCLUDED" for r in records)}), flush=True)
        summary = {"branch": branch, "rank": rank, "types": len(records),
                   "outcomes": dict(Counter(r["status"] for r in records)),
                   "label_cases": sum(r["label_cases"] for r in records),
                   "row_patterns": sum(r["row_patterns"] for r in records),
                   "search_nodes": sum(r["search_nodes"] for r in records),
                   "arc_passes": sum(r["arc_passes"] for r in records),
                   "records": records}
        reports.append(summary)
        print(json.dumps({k: v for k, v in summary.items() if k != "records"}, sort_keys=True), flush=True)
    open_count = sum(sum(r["status"] != "EXCLUDED" for r in s["records"]) for s in reports)
    result = {"status": "PASS" if not open_count else "OPEN_NECESSARY_MATRICES",
              "scope": "Independent complete necessary tail-matrix audit; no actual fusion ring is constructed.",
              "method": "Independent square partitions and row-domain arc consistency; all T6/T9 positions; no producer import, floating point, or principal-minor pruning.",
              "verifier_sha256": digest(Path(__file__).resolve()),
              "source_type_input_sha256": digest(args.input),
              "frozen_cubic_closure_proof_sha256": digest(HERE.parent/"r35_cubic_three_closure.tex"),
              "independently_regenerated_dataset_counts": dataset_counts,
              "total_types": sum(s["types"] for s in reports),
              "open_count": open_count,
              "reports": reports,
              "seconds": time.monotonic()-started}
    output.write_text(json.dumps(result, separators=(",", ":"), sort_keys=True)+"\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in ("reports", "independently_regenerated_dataset_counts")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
