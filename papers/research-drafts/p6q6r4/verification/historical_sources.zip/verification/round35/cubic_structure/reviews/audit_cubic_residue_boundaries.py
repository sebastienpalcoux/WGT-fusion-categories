#!/usr/bin/env python3
"""Independent bounded audit of the Round35 optimized cubic residue gate.

Reads the sibling code without modifying it. Direct enumeration checks the
interval endpoints, period truncation and early full-coset exit. Explicit
modular sumsets independently check the 5400-bit circular-shift combination.
"""
from pathlib import Path
from math import comb, gcd, isqrt
import hashlib
import importlib.util
import json
import random
import sys

HERE = Path(__file__).resolve().parent
TARGET = HERE.parents[1]/'canonical12/cubic_trace_gate.py'
spec = importlib.util.spec_from_file_location('r35_reviewed_cubic_gate', TARGET)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


def direct_residues(k, s, t, ws, f):
    B = 0 if k < 3 else isqrt(comb(k, 3)**2*t**3//k**3)
    bound = isqrt(t**3)
    result = set()
    for w in ws:
        p2 = t-w
        assert (s*s-p2) % 2 == 0
        # Use the displayed Newton formula, not the optimized e2 form.
        numerator = 3*s*p2-s**3
        assert numerator % 2 == 0
        base = numerator//2
        for e3 in range(-B, B+1):
            p3 = base+3*e3
            if -bound <= p3 <= bound:
                result.add(p3 % f)
    return result


def main():
    assert __debug__
    before = hashlib.sha256(TARGET.read_bytes()).hexdigest()
    interval_cases = 0
    early_cosets = 0
    for k in (1, 2, 3, 4, 6, 8):
        for t in (0, 1, 2, 3, 4, 5, 8, 9, 16, 25):
            S = isqrt(k*t)
            ss = sorted({-S, -max(0, S-1), -1, 0, 1, max(0, S-1), S})
            for s in ss:
                if s*s > k*t:
                    continue
                for f in (6, 8, 9, 10, 12, 15, 18, 27, 30, 54, 100, 540):
                    first = (t-s) % 2
                    full = tuple(range(first, min(2*t, f)+1, 2))
                    samples = {full}
                    if full:
                        samples.add((full[0],))
                        samples.add((full[-1],))
                        samples.add(tuple(full[::2]))
                    for ws in samples:
                        expected = direct_residues(k, s, t, ws, f)
                        actual = set(gate.cubic_residues(k, s, t, ws, f))
                        assert actual == expected, (k, s, t, ws, f, actual, expected)
                        period = f//gcd(3, f)
                        if len(actual) == period:
                            early_cosets += 1
                        interval_cases += 1
    # Complete Cartesian set sums on artificial aggregate rows. These need
    # not be fusion rows; the comparison audits only the residue combiner.
    rng = random.Random(35)
    sumset_cases = 0
    for index in range(90):
        sd = bool(index % 2)
        groups = []
        values = []
        residue_lists = []
        for _ in range(1+index % 4):
            f = rng.choice((6, 8, 9, 10, 12, 15, 18, 20, 27, 30, 36, 40))
            c = rng.choice((1, 2, 3))
            m = 2
            k = m*c
            t = rng.randrange(0, 9)
            s = rng.randrange(-isqrt(k*t), isqrt(k*t)+1)
            if sd and (t-s) % 2:
                s = s+1 if s < isqrt(k*t) else s-1
            if s*s > k*t:
                s = 0 if t % 2 == 0 or not sd else 1
            if sd:
                ws = (0,)
            else:
                top = min(f, (2*k*t-2*s*s)//k)
                ws = tuple(range((t-s) % 2, top+1, 2))
            rs = direct_residues(k, s, t, ws, f)
            a = 5400//f
            groups.append((a, m, c))
            values.append((s, t))
            residue_lists.append({a*v % 5400 for v in rs})
        expected = {0}
        for rs in residue_lists:
            expected = {(x+y) % 5400 for x in expected for y in rs}
        d = rng.randrange(3, 73)
        actual = gate.cubic_trace_possible(tuple(groups), (sd, d, tuple(values)))
        assert actual == ((-d**3) % 5400 in expected), (groups, values, d, sd)
        sumset_cases += 1
    assert hashlib.sha256(TARGET.read_bytes()).hexdigest() == before
    report = {'status': 'PASS', 'target_sha256': before,
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'direct_interval_and_period_cases': interval_cases,
              'full_coset_cases': early_cosets,
              'explicit_modular_sumset_cases': sumset_cases,
              'target_file_unchanged': True,
              'scope': 'Independent bounded implementation audit; general necessity follows from the written proof.'}
    (HERE/'cubic_residue_boundary_audit.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
