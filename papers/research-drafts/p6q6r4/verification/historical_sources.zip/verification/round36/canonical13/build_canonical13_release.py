#!/usr/bin/env python3
"""Freeze the complete verified canonical13 module and its release file list."""
from pathlib import Path
from hashlib import sha256
import json,shutil
from write_canonical13_notes import main as write_notes
from replay_all13 import bind_release,authenticate,PAYLOADS
HERE=Path(__file__).resolve().parent

def main():
    high=json.loads((HERE/'complete_higher_verification.json').read_bytes())
    assert high['complete_high_tail_coverage'] and high['counts']['excluded']==9438
    write_notes();bind_release();authenticate()
    progress=json.loads((HERE/'scan_progress.json').read_bytes())
    assert progress['status']=='PRODUCER_COMPLETE' and progress['assignments']==9438
    shutil.copyfile(HERE/'scan_progress.json',HERE/'producer_summary.json')
    selected={p.name for p in HERE.glob('*.py')}|{p.name for p in HERE.glob('r36_*.tex')}|set(PAYLOADS)|{
        'canonical13_release_verification.json','README.txt','HANDOFF.txt',
        'inherited_source_snapshot.json','root_structural_review.json','producer_summary.json',
        'word_summary.json','small_central_results.jsonl','small_central_summary.json'}
    if (HERE/'small_central_fresh_replay.json').exists():
        selected.update(('small_central_fresh_replay.json','small_central_replay.jsonl'))
    layout_path=HERE/'fresh_shards/layout.json'
    if layout_path.exists():
        layout=json.loads(layout_path.read_bytes());selected.add('fresh_shards/layout.json')
        for item in layout:selected.update(('fresh_shards/'+item['ledger'],'fresh_shards/'+item['report']))
    for name in selected:assert (HERE/name).is_file(),name
    release=sorted(selected|{'RELEASE_FILES.txt','MANIFEST_SHA256.json'})
    (HERE/'RELEASE_FILES.txt').write_text('\n'.join(release)+'\n')
    hashes={name:sha256((HERE/name).read_bytes()).hexdigest() for name in sorted(selected|{'RELEASE_FILES.txt'})}
    (HERE/'MANIFEST_SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps({'status':'FROZEN_COMPLETE_CANONICAL13_RELEASE','release_files':len(release),
        'hashed_payloads':len(hashes),'raw_assignments':807656,'preliminary':185421,
        'high_tail_excluded':9438,'remaining_assignments':146923,'remaining_profiles':25477},indent=2))

if __name__=='__main__':main()
