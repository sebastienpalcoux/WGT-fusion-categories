#!/usr/bin/env python3
"""Complete rational odd-matrix form gate; nonrational groups stay outside."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip,json,time,argparse
from enumerate_canonical13 import read_records
from odd_rational_forms import gate
HERE=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--verify',action='store_true');a=p.parse_args()
    path=HERE/'odd_form_results.jsonl.gz';started=time.monotonic();counts=Counter();ranks=Counter()
    source=HERE/'preliminary185421.jsonl.gz'
    expected=iter(read_records(path)) if a.verify else None
    stream=None if a.verify else gzip.GzipFile(filename=str(path),mode='wb',mtime=0)
    digest=sha256()
    for raw in read_records(source):
        groups=tuple(tuple(g) for g in raw['types']);nonlinear=[g for g in groups if g[1]>1]
        if nonlinear and all(m%2 for aa,m,c in nonlinear):counts['all_odd_nonlinear_assignments']+=1
        result=gate(groups,raw['rank'])
        if result is None:continue
        record={'assignment_index':raw['assignment_index'],'rank':raw['rank'],'groups':raw['types'],**result}
        data=(json.dumps(record,separators=(',',':'))+'\n').encode();digest.update(data)
        if expected is not None:assert record==next(expected)
        else:stream.write(data)
        counts['eligible_assignments']+=1
        counts['excluded_assignments' if result['excluded'] else 'retained_assignments']+=1
        if result['excluded']:ranks[raw['rank']]+=1
        for k,v in result['counts'].items():counts[k]+=v
        if counts['eligible_assignments']%100==0:print('ODD',counts['eligible_assignments'],counts['excluded_assignments'],'seconds',time.monotonic()-started,flush=True)
    if expected is not None:assert next(expected,None) is None
    else:stream.close()
    assert counts['all_odd_nonlinear_assignments']==37966 and counts['eligible_assignments']==37438 and counts['excluded_assignments']==32180,counts
    report={'status':'EXACT_ODD_FORM_FRESH_REPLAY_PASS' if a.verify else 'EXACT_ODD_FORM_GATE_COMPLETE',
        'counts':dict(counts),'excluded_rank_distribution':dict(sorted(ranks.items())),
        'input_sha256':sha256(source.read_bytes()).hexdigest(),'certificate_sha256':sha256(path.read_bytes()).hexdigest(),
        'uncompressed_records_sha256':digest.hexdigest(),'seconds':time.monotonic()-started}
    (HERE/('odd_form_fresh_replay.json' if a.verify else 'odd_form_summary.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':main()
