#!/usr/bin/env python3
"""Produce the complete rank>=31 L13 tail certificates.

Floating point is used only to propose integer separators; every returned
separator is checked exactly by the proposal module and again on replay.
"""
from pathlib import Path
from collections import Counter
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,time,os,gc,multiprocessing
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
from enumerate_canonical13 import read_records
from canonical12_rows import (rows_for,possible_pairs,moment_data,cheap_certificate,
    bounded_remainder_scan,capacity_moment_data)
from central_atom13 import small_central_atoms
from propose_certificates import certificate
import canonical12_rows,cubic_trace_gate,fixed_field_rows,power_trace_filter,central_atom13
HERE=Path(__file__).resolve().parent
WORKED=0

def clear_caches():
    for function in (canonical12_rows.options,canonical12_rows.scalar_options,
        canonical12_rows.canonical_capacity_data,cubic_trace_gate.cubic_residues,
        cubic_trace_gate.linear_ws_map,fixed_field_rows.fixed_options,
        power_trace_filter.scalar_power_options,central_atom13.trace_completion,
        central_atom13.scalar_multisets):
        if hasattr(function,'cache_clear'):function.cache_clear()
    gc.collect()

def work(job):
    global WORKED
    raw,form,spectrum=job;started=time.monotonic();groups=tuple(map(tuple,raw['types']));rank=raw['rank']
    common=None;rows=[];branches=[];pairs=None
    if form is not None and form['excluded']:
        common={'kind':'odd_rational_trace_form','counts':form['counts']}
    elif spectrum is not None:common=spectrum
    else:
        common=bounded_remainder_scan(groups,rank)
        if common is None:common=small_central_atoms(groups,rank)
    if common is None:
        pairs=possible_pairs(groups,rank)
        if form is not None:pairs=tuple(sorted({r['source_pairs'] for r in form['retained']}))
        if not pairs:common={'kind':'no_source_duality'}
        else:
            rows=list(rows_for(groups,rank));common=cheap_certificate(groups,rows,rank)
    if common is None:
        for b in pairs:
            target,vectors=moment_data(groups,rows,rank,b)
            cert=cheap_certificate(groups,rows,rank,b);mode='base';subsets=[]
            if cert is None:cert=certificate(vectors,target)
            if cert is None:
                target,vectors,subsets=capacity_moment_data(groups,rows,rank,b)
                mode='canonical_capacities';cert=certificate(vectors,target)
            branches.append({'pairs':b,'vectors':len(vectors),'moment_mode':mode,
                'capacity_subsets':subsets,'certificate':cert})
    result={'assignment_index':raw['assignment_index'],'profile_index':raw['index'],
        'profile':raw['profile'],'rank':rank,'groups':groups,'rows':len(rows),
        'possible_pairs':pairs,'common_certificate':common,'branches':branches,
        'excluded':common is not None or all(x['certificate'] is not None for x in branches),
        'seconds':time.monotonic()-started}
    WORKED+=1
    if WORKED%5==0:clear_caches()
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=2);p.add_argument('--index',type=int);args=p.parse_args()
    started=time.monotonic();output=HERE/'aggregate_results.jsonl'
    old={r['assignment_index']:r for r in read_records(output)} if output.exists() else {}
    odd={r['assignment_index']:r for r in read_records(HERE/'odd_form_results.jsonl.gz') if r['rank']>=31}
    small={r['assignment_index']:r['certificate'] for r in read_records(HERE/'small_central_results.jsonl')}
    jobs=[(r,odd.get(r['assignment_index']),small[r['assignment_index']])
        for r in read_records(HERE/'preliminary185421.jsonl.gz') if r['rank']>=31]
    assert len(jobs)==9438 and len(small)==9438
    todo=[job for job in jobs if job[0]['assignment_index'] not in old and (args.index is None or job[0]['assignment_index']==args.index)]
    context=multiprocessing.get_context('spawn')
    with output.open('a') as out:
        for start in range(0,len(todo),100):
            with ProcessPoolExecutor(max_workers=args.workers,mp_context=context) as executor:
                futures=[executor.submit(work,job) for job in todo[start:start+100]]
                for future in as_completed(futures):
                    result=future.result();idx=result['assignment_index'];assert idx not in old
                    old[idx]=result;out.write(json.dumps(result,separators=(',',':'))+'\n');out.flush()
                    kind=result['common_certificate']['kind'] if result['common_certificate'] else 'source_moment_branches' if result['excluded'] else 'OPEN'
                    print('TAIL',idx,'rank',result['rank'],'rows',result['rows'],kind,'seconds',round(result['seconds'],3),'done',len(old),flush=True)
            counts=Counter(r['common_certificate']['kind'] if r['common_certificate'] else 'source_moment_branches' if r['excluded'] else 'OPEN' for r in old.values())
            report={'status':'PRODUCER_COMPLETE' if len(old)==9438 else 'PARTIAL','assignments':len(old),
                'counts':dict(counts),'base_rows':sum(r['rows'] for r in old.values()),'seconds':time.monotonic()-started}
            (HERE/'scan_progress.json').write_text(json.dumps(report,indent=2)+'\n')
            print(json.dumps(report),flush=True)

if __name__=='__main__':main()
