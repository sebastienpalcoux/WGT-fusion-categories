#!/usr/bin/env python3
"""Independent universe, full-conductor fields, and exact input replay."""
from collections import Counter
from functools import lru_cache
from hashlib import sha256
from itertools import groupby,product
from math import gcd,prod
from pathlib import Path
import argparse,json,time
from enumerate_canonical13 import read_records,regenerate,orbit_options
from probe_length11 import profiles_rec
from verify_length10 import partitions,permutation_sign,kronecker
from verify_two_blocks import phi,quadratic_discriminants,squarefree_part
import generic_fields
import r32_trace_forms as forms
HERE=Path(__file__).resolve().parent

def input_audit():
    started=time.monotonic();raw=HERE/'input807656.jsonl.gz';kept=HERE/'preliminary185421.jsonl.gz'
    profiles=tuple(sorted(profiles_rec(0,12,5399),reverse=True));assert len(profiles)==len(set(profiles))==62776
    grouped=groupby(read_records(raw),key=lambda r:r['index']);counts=Counter();ranks=Counter();retained_ranks=Counter()
    inventory=set();scalar_inventory=set();kept_iterator=iter(read_records(kept));regenerated=iter(regenerate())
    for index,profile in enumerate(profiles):
        actual_index,records=next(grouped);assert actual_index==index
        cc=Counter(profile);degrees=sorted(cc,reverse=True)
        expected={tuple(sorted((a,m,c) for a,part in zip(degrees,parts) for m,c in Counter(part).items()))
            for parts in product(*(partitions(cc[a]) for a in degrees))}
        found=set()
        for r in records:
            assert r==json.loads(json.dumps(next(regenerated)))
            assert r['assignment_index']==counts['assignments'] and tuple(r['profile'])==profile
            groups=tuple(sorted(map(tuple,r['types'])));assert groups in expected and groups not in found;found.add(groups)
            assert sum(a*m*c for a,m,c in groups)==5399 and sum(m*c for a,m,c in groups)==12
            assert r['rank']==1+sum(m*m*c for a,m,c in groups)
            inventory.update(groups);scalar_inventory.update((a,c) for a,m,c in groups if m==1)
            counts['assignments']+=1;ranks[r['rank']]+=1
            if r['retained']:
                assert next(kept_iterator)==r;counts['retained']+=1;retained_ranks[r['rank']]+=1
            counts['retained_high_tail']+=r['retained'] and r['rank']>=31
        assert found==expected
    assert next(grouped,None) is next(regenerated,None) is next(kept_iterator,None) is None
    assert counts['assignments']==807656 and counts['retained']==185421 and counts['retained_high_tail']==9438
    result={'status':'INDEPENDENT_COMPLETE_INPUT_REPLAY_PASS','profiles':len(profiles),'counts':dict(counts),
        'rank_distribution':dict(sorted(ranks.items())),'retained_rank_distribution':dict(sorted(retained_ranks.items())),
        'group_catalogue':sorted(inventory),'scalar_catalogue':sorted(scalar_inventory),
        'input_sha256':sha256(raw.read_bytes()).hexdigest(),'retained_sha256':sha256(kept.read_bytes()).hexdigest(),
        'method':'Independent count-vector profiles and representation-degree count vectors; every stored gate record regenerated and compared.',
        'seconds':time.monotonic()-started}
    (HERE/'complete_input_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ('group_catalogue','scalar_catalogue')},flush=True)
    return result

@lru_cache(None)
def full_index_subgroups(conductor,index):
    """Full conductor audit through G/G^index, independent of small-conductor reductions."""
    units=tuple(a for a in range(conductor) if gcd(a,conductor)==1)
    if len(units)%index:return ()
    powers={pow(a,index,conductor) for a in units}
    cosets=tuple(sorted({tuple(sorted(a*b%conductor for b in powers)) for a in units}))
    where={a:i for i,C in enumerate(cosets) for a in C};identity=where[1]
    multiplication=tuple(tuple(where[A[0]*B[0]%conductor] for B in cosets) for A in cosets)
    seen={frozenset((identity,))};queue=list(seen);target=len(cosets)//index
    for subgroup in queue:
        if len(subgroup)==target:continue
        for generator in range(len(cosets)):
            if generator in subgroup:continue
            new=set(subgroup);power=generator
            while power not in subgroup:
                new.update(multiplication[power][b] for b in subgroup)
                power=multiplication[power][generator]
            new=frozenset(new)
            if len(new)<=target and target%len(new)==0 and new not in seen:seen.add(new);queue.append(new)
    return tuple(sorted(tuple(sorted(a for i in H for a in cosets[i])) for H in seen if len(H)==target))

def field_squareclass(conductor,subgroup):
    units=tuple(a for a in range(conductor) if gcd(a,conductor)==1)
    cosets=tuple(sorted({tuple(sorted(a*b%conductor for b in subgroup)) for a in units}))
    where={a:i for i,C in enumerate(cosets) for a in C}
    signs=tuple(permutation_sign([where[a*C[0]%conductor] for C in cosets]) for a in units)
    if all(s==1 for s in signs):return 1
    matches=[D for D in quadratic_discriminants(conductor) if all(kronecker(D,a)==s for a,s in zip(units,signs))]
    assert len(matches)==1
    return squarefree_part(abs(matches[0]))

def label_subgroup(label,conductor):
    units=tuple(a for a in range(conductor) if gcd(a,conductor)==1)
    if label=='Q':return units
    if label=='Q(sqrt(-3))':return tuple(a for a in units if kronecker(-3,a)==1)
    if label.startswith('quadratic_disc='):
        D=int(label.split('=')[1]);return tuple(a for a in units if kronecker(D,a)==1)
    if label=='real_cubic_conductor9':return tuple(a for a in units if a%9 in (1,8))
    c,h=label.split(':H=');ambient=int(c[4:]);subgroup=set(map(int,h.split(',')))
    assert conductor%ambient==0
    return tuple(a for a in units if a%ambient in subgroup)

def field_audit(input_result=None):
    started=time.monotonic()
    data=input_result or json.loads((HERE/'complete_input_verification.json').read_text())
    groups=data['group_catalogue'];scalar=data['scalar_catalogue'];checks=[];scalar_checks=[]
    for a,m,c in groups:
        f=5400//a;conductor=gcd(2*f,f*f);expected=set()
        for e in range(1,c+1):
            if e==1 and a==10:continue
            expected.update((e,field_squareclass(conductor,H)) for H in full_index_subgroups(conductor,e))
        actual=set(orbit_options(a,m,c));assert actual==expected,(a,m,c,actual,expected)
        checks.append({'group':[a,m,c],'conductor':conductor,'orbit_options':sorted(actual)})
    for a,c in scalar:
        f=5400//a;conductor=gcd(2*f,f*f)
        actual=generic_fields.fields(f,c);actual_H={label_subgroup(x[0],conductor) for x in actual}
        if f==6:expected_H={label_subgroup('Q',conductor),label_subgroup('Q(sqrt(-3))',conductor)}
        else:expected_H={H for e in range(1,c+1) if not(e==1 and f==540) for H in full_index_subgroups(conductor,e)}
        assert actual_H==expected_H and len(actual)==len(actual_H),(a,c,actual_H^expected_H)
        scalar_checks.append({'a':a,'count':c,'conductor':conductor,'fields':[x[0] for x in actual]})
    result={'status':'FULL_CONDUCTOR_FIELD_AUDIT_PASS','determinant_catalogues':len(groups),
        'scalar_catalogues':len(scalar),'maximum_orbit_capacity':max(c for a,m,c in groups),
        'method':'Generate every index-e subgroup of the FULL conductor unit group through G/G^e; compare orbit discriminants and full scalar fields.',
        'determinant_checks':checks,'scalar_checks':scalar_checks,'seconds':time.monotonic()-started}
    (HERE/'field_coverage_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ('determinant_checks','scalar_checks')},flush=True)
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--fields-only',action='store_true');args=p.parse_args()
    field_audit(None if args.fields_only else input_audit())

if __name__=='__main__':main()
