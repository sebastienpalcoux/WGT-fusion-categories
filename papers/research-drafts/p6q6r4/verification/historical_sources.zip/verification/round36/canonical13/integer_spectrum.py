"""Exact arithmetic for signed integral spectra; standard library only."""
from math import factorial

def prime_powers(n):
    result=[];p=2
    while p*p<=n:
        if n%p==0:
            exponent=0
            while n%p==0:n//=p;exponent+=1
            result.append((p,exponent))
        p+=1
    if n>1:result.append((n,1))
    return tuple(result)

def factorial_window(denominator):
    n=0;remainder=1
    while remainder%denominator:
        n+=1;remainder*=n
    return n

def primary_residues(spectrum,denominator=5400,reduce_binary=True):
    """Each entry is (p,t,j,modulus,residue); spectrum=(weight,integer)."""
    out=[]
    for p,v in prime_powers(denominator):
        for t in range(p):
            for j in range(v):
                if reduce_binary and p==2 and v==3 and j==2:continue
                modulus=p**(v-j)
                value=sum(w*((lam-t)//p)**j for w,lam in spectrum if lam%p==t)
                out.append((p,t,j,modulus,value%modulus))
    return tuple(out)

def all_moments_integral(spectrum,denominator=5400):
    return all(residue==0 for p,t,j,modulus,residue in primary_residues(spectrum,denominator))

def window_integral(spectrum,denominator=5400):
    return all(sum(w*lam**k for w,lam in spectrum)%denominator==0
               for k in range(factorial_window(denominator)))
