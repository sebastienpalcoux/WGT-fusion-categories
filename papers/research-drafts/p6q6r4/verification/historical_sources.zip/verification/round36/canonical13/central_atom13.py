"""Small rational canonical columns as at most three source-duality atoms.

The zero-sum norm test is applied only to groups c=1, which are full
rational orbits.  Repeated (a,m) groups retain separate possible integer
central scalars; no unproved equality across their orbits is imposed.
"""
from bisect import bisect_left
from functools import lru_cache
from itertools import product
from math import isqrt,prod
from canonical12_rows import rows_for,regular_character,options
N=5400

def closing_norms(qsets):
    if len(qsets)==1:return 0 in qsets[0]
    if len(qsets)==2:return bool(set(qsets[0]).intersection(qsets[1]))
    assert len(qsets)==3
    first,second,last=sorted(qsets,key=len)
    for x in first:
        for y in second:
            radius=isqrt(4*x*y);low=x+y-radius;high=x+y+radius
            pos=bisect_left(last,low)
            if pos<len(last) and last[pos]<=high:return True
    return False

@lru_cache(maxsize=8192)
def scalar_multisets(count,total,R):
    out=[]
    def rec(left,remaining,low,chosen):
        if left==0:
            if remaining==0:out.append(tuple(chosen))
            return
        upper=min(R-1,remaining//left)
        for value in range(max(low,remaining-(left-1)*(R-1)),upper+1):
            rec(left-1,remaining-value,value,chosen+[value])
    rec(count,total,1-R,[])
    return tuple(out)

@lru_cache(maxsize=8192)
def trace_completion(groups,traces,R):
    """True includes the safe unsearched cases with >4 repeated characters."""
    known=[(1,R)];unknown=[]
    for (a,m,c),s in zip(groups,traces):
        if s%m:return False
        total=s//m
        if abs(total)>c*(R-1):return False
        if c==1:known.append((a*m,total))
        else:unknown.append((a*m,c,total))
    if sum(c for w,c,s in unknown)>4:return True
    lists=[scalar_multisets(c,s,R) for w,c,s in unknown]
    if any(not values for values in lists):return False
    base=tuple(sum(w*pow(lam,k,N) for w,lam in known)%N for k in range(1,10))
    for selected in product(*lists):
        spectrum=known+[(w,lam) for (w,c,s),values in zip(unknown,selected) for lam in values]
        if any((base[k-1]+sum(w*pow(lam,k,N) for (w,c,s),values in zip(unknown,selected) for lam in values))%N for k in range(1,10)):continue
        if prod(R-lam for lam in {lam for w,lam in spectrum[1:]})%N:continue
        return True
    return False

def atom_options(groups,rows,R,multiplicity):
    rational_matrix_indices=tuple(i for i,(a,m,c) in enumerate(groups) if c==1 and m>1)
    atoms=set()
    for row in rows:
        sd,d,values=row;epsilon=1 if sd else 2;dimension=epsilon*d
        if dimension>R or regular_character(groups,row)<multiplicity:continue
        traces=tuple(epsilon*s for s,t in values);qsets=[]
        for i in rational_matrix_indices:
            a,m,c=groups[i];s,t=values[i]
            if sd:qs=(m*t-s*s,)
            else:
                ws=next(ws for ss,tt,ws in options(groups[i],d,sd) if (ss,tt)==(s,t))
                qs=tuple(sorted({m*(4*t-2*w)-4*s*s for w in ws if m*(4*t-2*w)>=4*s*s}))
            if not qs:break
            qsets.append(qs)
        else:atoms.add((dimension,traces,tuple(qsets)))
    return tuple(sorted(atoms))

def small_central_atoms(groups,rank,maximum_remainder=35,multiset_limit=100000):
    groups=tuple(groups)
    targets=sorted((g for g in groups if g[2]==1 and g[0]-g[1]<=maximum_remainder),key=lambda g:(g[0]-g[1],g))
    if not targets:return None
    for target in targets:
        a,m,c=target;R=a-m
        # The first small column often already excludes the assignment.
        # Enumerate only its actual dimension range before moving upward.
        rows=list(rows_for(groups,rank,dimension_cap=R))
        atoms=atom_options(groups,rows,R,m)
        if atoms and R>=4*atoms[0][0]:continue
        tested=0;possible=False;budget=False
        def visit(start,left,selected):
            nonlocal tested,possible,budget
            if possible or budget:return
            if left==0:
                tested+=1
                if tested>multiset_limit:budget=True;return
                if any(not closing_norms(tuple(atom[2][j] for atom in selected)) for j in range(len(selected[0][2]))):return
                traces=tuple(sum(atom[1][j] for atom in selected) for j in range(len(groups)))
                if trace_completion(groups,traces,R):possible=True
                return
            if len(selected)==3:return
            for i in range(start,len(atoms)):
                atom=atoms[i]
                if atom[0]>left:break
                visit(i,left-atom[0],selected+[atom])
                if possible or budget:return
        visit(0,R,[])
        if not possible and not budget:
            return {'kind':'small_central_atom_geometry','group':list(target),'remainder':R,
                'dimension_cap':R,'bounded_rows':len(rows),'eligible_atoms':len(atoms),
                'multisets_checked':tested,'maximum_atoms':3,'multiset_limit':multiset_limit,
                'geometry_groups':[list(g) for g in groups if g[2]==1 and g[1]>1]}
    return None
