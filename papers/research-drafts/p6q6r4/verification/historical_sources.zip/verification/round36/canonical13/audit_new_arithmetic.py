#!/usr/bin/env python3
"""Independent small exhaustive controls for the Round36 arithmetic."""
from collections import Counter
from hashlib import sha256
from itertools import product
from math import comb,factorial,prod
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json,random,time
from integer_spectrum import (primary_residues,all_moments_integral,
    factorial_window,window_integral)
from small_central13 import spectrum_possible
import small_central13
from allocation_lift import bounded_minimum
import r32_trace_forms as forms
HERE=Path(__file__).resolve().parent

def primary_audit():
    count=0
    for D in range(2,61):
        for weights in product((-1,0,1),repeat=5):
            spectrum=tuple(zip(weights,range(-2,3)))
            expected=window_integral(spectrum,D)
            assert all_moments_integral(spectrum,D)==expected,(D,spectrum)
            assert all(x[-1]==0 for x in primary_residues(spectrum,D,False))==expected
            count+=1
    rng=random.Random(360013);random_count=0
    for _ in range(5500):
        spectrum=tuple((rng.randrange(-2000,2001),rng.randrange(-50,51)) for i in range(rng.randrange(1,10)))
        assert all_moments_integral(spectrum)==window_integral(spectrum)
        random_count+=1
    assert len(primary_residues(((1,0),),5400,False))==25
    assert len(primary_residues(((1,0),),5400,True))==23
    return {'signed_exhaustive_cases':count,'signed_random_5400_cases':random_count,
        'raw_5400_conditions':25,'reduced_5400_conditions':23}

def factorial_audit():
    nulls=optimal=0
    for D in range(2,101):
        n=factorial_window(D);assert factorial(n)%D==0 and factorial(n-1)%D!=0
        for x in range(-50,51):
            assert prod(x-i for i in range(n))%D==0;nulls+=1
        spectrum=tuple(((-1)**(n-1-i)*comb(n-1,i),i) for i in range(n))
        assert all(sum(w*x**k for w,x in spectrum)==0 for k in range(n-1))
        assert sum(w*x**(n-1) for w,x in spectrum)==factorial(n-1)
        assert not window_integral(spectrum,D);optimal+=1
    assert factorial_window(5400)==10
    return {'null_polynomial_evaluations':nulls,'optimality_controls':optimal,'window_at_5400':10}

def allocation_audit():
    cases=allocations=0
    for n in range(1,4):
        for weights in product((1,2,3),repeat=n):
            for caps in product((0,1,2),repeat=n):
                feasible=list(product(*(range(c+1) for c in caps)))
                for costs in product((-2,0,3),repeat=n):
                    expected={}
                    for x in feasible:
                        total=sum(w*y for w,y in zip(weights,x));value=sum(z*y for z,y in zip(costs,x))
                        expected[total]=min(expected.get(total,value),value);allocations+=1
                    for total in range(sum(w*c for w,c in zip(weights,caps))+2):
                        result=bounded_minimum(weights,caps,costs,total,True)
                        assert (None if result is None else result[0])==expected.get(total)
                        if result is not None:assert all(0<=x<=c for x,c in zip(result[1],caps))
                        cases+=1
    return {'bounded_minimization_problems':cases,'explicit_allocations':allocations}

def central_audit():
    rng=random.Random(13135400);cases=tuples=0
    for n in range(1,5):
        for R in range(2,7):
            for repeat in range(25):
                cuts=sorted(rng.sample(range(1,5399),n-1));weights=tuple(b-a for a,b in zip((0,*cuts),(*cuts,5399)))
                witness=None
                for lambdas in product(range(1-R,R),repeat=n):
                    tuples+=1
                    if R+sum(w*x for w,x in zip(weights,lambdas)):continue
                    spectrum=((1,R),)+tuple(zip(weights,lambdas))
                    if not window_integral(spectrum):continue
                    if prod(R-x for x in set(lambdas))%5400:continue
                    witness=spectrum;break
                actual=spectrum_possible(weights,R)
                assert (actual is None)==(witness is None),(weights,R,actual,witness)
                cases+=1
    positive=negative=0
    try:
        for D in (3,4,5,6,8,9,10,12,15,16,18,24,25,27,30,36,40,45,50,54,60):
            small_central13.N=D;spectrum_possible.cache_clear()
            for n in range(1,min(D,4)):
                for R in range(2,7):
                    for repeat in range(8):
                        cuts=sorted(rng.sample(range(1,D-1),n-1))
                        weights=tuple(b-a for a,b in zip((0,*cuts),(*cuts,D-1)))
                        witness=None
                        for lambdas in product(range(1-R,R),repeat=n):
                            tuples+=1
                            if R+sum(w*x for w,x in zip(weights,lambdas)):continue
                            spectrum=((1,R),)+tuple(zip(weights,lambdas))
                            if not window_integral(spectrum,D):continue
                            if prod(R-x for x in set(lambdas))%D:continue
                            witness=spectrum;break
                        actual=spectrum_possible(weights,R)
                        assert (actual is None)==(witness is None),(D,weights,R,actual,witness)
                        cases+=1;positive+=actual is not None;negative+=actual is None
    finally:
        small_central13.N=5400;spectrum_possible.cache_clear()
    assert positive and negative
    return {'independent_cartesian_spectrum_cases':cases,'cartesian_tuples_checked':tuples,
        'small_denominator_positive_controls':positive,'small_denominator_negative_controls':negative}

def hasse_grouping_audit():
    rng=random.Random(365400);cases=0
    pool=tuple(Fraction(a,b) for a in (1,2,3,5,7,11) for b in (1,2,3,5,8,9))
    for _ in range(500):
        alphabet=rng.sample(pool,rng.randrange(1,9))
        diagonal=tuple(rng.choice(alphabet) for i in range(rng.randrange(1,70)))
        primes={2}
        for x in diagonal:primes.update(forms.prime_factors(x.numerator));primes.update(forms.prime_factors(x.denominator))
        bad=[]
        for p in sorted(primes):
            original=prod(forms.hilbert(a,b,p) for a,b in combinations(diagonal,2))
            assert forms.hasse(diagonal,p)==original;cases+=1
            if original==-1:bad.append(p)
        original=(len(diagonal),forms.squareclass(prod(diagonal)),tuple(bad))
        assert forms.invariants(diagonal)==original
    return {'pairwise_hasse_products_compared':cases,'complete_form_invariant_controls':500}

def main():
    started=time.monotonic();result={'status':'PASS'}
    for name,fn in (('primary',primary_audit),('factorial',factorial_audit),('allocation',allocation_audit),('central_spectrum',central_audit),('hasse_grouping',hasse_grouping_audit)):
        result[name]=fn();print(name,result[name],flush=True)
    result['source_hashes']={name:sha256((HERE/name).read_bytes()).hexdigest() for name in
        ('integer_spectrum.py','small_central13.py','allocation_lift.py','r32_trace_forms.py','audit_new_arithmetic.py')}
    result['seconds']=time.monotonic()-started
    (HERE/'new_arithmetic_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
