#!/usr/bin/env python3
"""Join exact fresh ledgers and construct the precise surviving L13 input."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import argparse,gzip,json
from enumerate_canonical13 import read_records
from verify_canonical13 import load_records,digest,mathematical_source_hashes
HERE=Path(__file__).resolve().parent

def merge_ledgers(folder=None,workers=3,layout=None):
    folder=Path(folder) if folder is not None else HERE/'fresh_shards'
    source_hashes=mathematical_source_hashes();source_digest=digest(source_hashes)
    input_path=HERE/'preliminary185421.jsonl.gz';input_hash=sha256(input_path.read_bytes()).hexdigest()
    expected=[r['assignment_index'] for r in read_records(input_path) if r['rank']>=31];assert len(expected)==9438
    base=load_records(HERE/'aggregate_results.jsonl');words=load_records(HERE/'word_results.jsonl')
    assert set(base)==set(expected) and set(words)=={i for i,r in base.items() if not r['excluded']}
    merged={};shards=[]
    definitions=layout if layout is not None else [
        {'modulus':workers,'residue':residue,'ledger':f'ledger_{residue}.jsonl','report':f'report_{residue}.json'}
        for residue in range(workers)]
    for definition in definitions:
        modulus=definition['modulus'];residue=definition['residue'];assert 0<=residue<modulus
        ledger_path=folder/definition['ledger'];report_path=folder/definition['report']
        ledger=load_records(ledger_path);report=json.loads(report_path.read_bytes())
        selected={idx for pos,idx in enumerate(expected) if pos%modulus==residue}
        assert set(ledger)==selected==set(report['checked_assignment_indices'])
        assert report['counts']['assignments']==report['counts']['excluded']==len(selected)
        assert report['mathematical_source_hashes']==source_hashes and report['mathematical_source_digest']==source_digest
        assert report['input_sha256']==input_hash and report['ledger_sha256']==sha256(ledger_path.read_bytes()).hexdigest()
        assert not set(merged).intersection(ledger)
        for idx,entry in ledger.items():
            assert entry['status']=='PASS' and not entry['open_pairs']
            assert entry['input_sha256']==input_hash and entry['mathematical_source_digest']==source_digest
            assert entry['certificate_digest']==digest([base[idx],words.get(idx)])
        merged.update(ledger)
        shards.append({'modulus':modulus,'residue':residue,'assignments':len(selected),
            'ledger_sha256':sha256(ledger_path.read_bytes()).hexdigest(),'report_sha256':sha256(report_path.read_bytes()).hexdigest()})
    assert set(merged)==set(expected)
    output=HERE/'complete_replay.jsonl'
    output.write_text(''.join(json.dumps(merged[idx],separators=(',',':'))+'\n' for idx in sorted(merged)))
    stages=Counter(r['stage'] for r in merged.values())
    report={'status':'COMPLETE_HIGH_TAIL_FRESH_REPLAY_PASS','complete_high_tail_coverage':True,
        'counts':{'assignments':9438,'excluded':9438,'base_rows':sum(r['base_rows'] for r in merged.values()),
            'refined_rows':sum(r['refined_rows'] or 0 for r in merged.values())},
        'stage_counts':dict(sorted(stages.items())),'input_sha256':input_hash,
        'mathematical_source_hashes':source_hashes,'mathematical_source_digest':source_digest,
        'ledger_sha256':sha256(output.read_bytes()).hexdigest(),'checked_assignment_indices':sorted(merged),
        'fresh_shards':shards,'sum_record_seconds':sum(r['seconds'] for r in merged.values())}
    (HERE/'complete_higher_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print({k:v for k,v in report.items() if k not in ('mathematical_source_hashes','checked_assignment_indices')},flush=True)
    return report

def remaining_input(write=True):
    report=json.loads((HERE/'complete_higher_verification.json').read_bytes())
    assert report['status']=='COMPLETE_HIGH_TAIL_FRESH_REPLAY_PASS' and report['complete_high_tail_coverage']
    assert report['counts']['assignments']==report['counts']['excluded']==9438
    ledger=load_records(HERE/'complete_replay.jsonl');assert len(ledger)==9438 and all(r['status']=='PASS' for r in ledger.values())
    assert report['ledger_sha256']==sha256((HERE/'complete_replay.jsonl').read_bytes()).hexdigest()
    odd={r['assignment_index'] for r in read_records(HERE/'odd_form_results.jsonl.gz') if r['excluded']}
    assert len(odd)==32180
    output=HERE/'remaining146923.jsonl.gz';stream=gzip.GzipFile(filename=str(output),mode='wb',mtime=0) if write else None
    stored=None if write else iter(read_records(output));counts=Counter();ranks=Counter();shapes=Counter();profiles=set();maximum_degree=0
    high=set();preliminary=0
    for r in read_records(HERE/'preliminary185421.jsonl.gz'):
        idx=r['assignment_index'];preliminary+=1
        if r['rank']>=31:high.add(idx)
        if idx in odd or idx in ledger:continue
        counts['assignments']+=1;ranks[r['rank']]+=1;profiles.add(r['index'])
        degrees=Counter({1:1})
        for a,m,c in r['types']:degrees[m]+=c;maximum_degree=max(maximum_degree,m)
        shape=tuple(sorted(degrees.items()));assert sum(m*c for m,c in shape)==13 and sum(m*m*c for m,c in shape)==r['rank']
        shapes[shape]+=1
        if write:stream.write((json.dumps(r,separators=(',',':'))+'\n').encode())
        else:assert next(stored)==r
    if write:stream.close()
    else:assert next(stored,None) is None
    assert preliminary==185421 and high==set(ledger)
    assert len(odd&high)==3120 and len(odd|high)==38498
    assert counts['assignments']==146923 and len(profiles)==25477 and len(shapes)==15 and maximum_degree==4
    assert dict(sorted(ranks.items()))=={17:52481,19:21423,21:34731,23:10071,25:15450,27:10984,29:1783}
    result={'status':'VERIFIED_NECESSARY_L13_REMAINDER','canonical_length':13,'raw_profiles':62776,'raw_assignments':807656,
        'preliminary_assignments':preliminary,'rational_odd_excluded':len(odd),'high_tail_excluded':len(high),
        'overlap':len(odd&high),'union_excluded':len(odd|high),'remaining_assignments':counts['assignments'],
        'remaining_weighted_profiles':len(profiles),'rank_distribution':dict(sorted(ranks.items())),
        'maximum_representation_degree':maximum_degree,
        'complex_algebra_shapes':[{'rank':sum(m*m*c for m,c in shape),'degree_multiplicities':list(shape),'assignments':count}
            for shape,count in sorted(shapes.items(),key=lambda item:(sum(m*m*c for m,c in item[0]),item[0]))],
        'remaining_input_sha256':sha256(output.read_bytes()).hexdigest(),
        'scope':'Necessary canonical numerical assignments under the standing simple integral center hypotheses and L=13. These are not realized rings, categories, or source dimension types. The rank bound 29 is conditional on L=13.'}
    result=json.loads(json.dumps(result))
    summary=HERE/'canonical13_summary.json'
    if write:summary.write_text(json.dumps(result,indent=2)+'\n')
    else:assert json.loads(summary.read_bytes())==result
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=3);p.add_argument('--folder',type=Path);p.add_argument('--layout',type=Path);p.add_argument('--remaining-only',action='store_true');args=p.parse_args()
    if not args.remaining_only:merge_ledgers(args.folder,args.workers,None if args.layout is None else json.loads(args.layout.read_bytes()))
    print(json.dumps(remaining_input(),indent=2),flush=True)

if __name__=='__main__':main()
