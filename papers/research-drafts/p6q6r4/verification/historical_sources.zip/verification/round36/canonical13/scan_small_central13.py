#!/usr/bin/env python3
"""Exhaust all bounded integer central spectra in the complete high tail."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import json,time,argparse
from enumerate_canonical13 import read_records
from small_central13 import small_central_spectrum
HERE=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--verify',action='store_true');args=p.parse_args()
    source=HERE/'preliminary185421.jsonl.gz';path=HERE/'small_central_results.jsonl'
    old={r['assignment_index']:r for r in read_records(path)} if path.exists() else {}
    started=time.monotonic();counts=Counter();checked=[]
    with (HERE/'small_central_replay.jsonl' if args.verify else path).open('w' if args.verify else 'a') as out:
        for r in read_records(source):
            if r['rank']<31:continue
            idx=r['assignment_index'];groups=tuple(map(tuple,r['types']))
            if not args.verify and idx in old:result=old[idx]
            else:
                t=time.monotonic();cert=small_central_spectrum(groups)
                result={'assignment_index':idx,'rank':r['rank'],'groups':r['types'],
                    'certificate':cert,'excluded':cert is not None,'seconds':time.monotonic()-t}
                if args.verify:
                    assert all(result[k]==old[idx][k] for k in result if k!='seconds')
                out.write(json.dumps(result,separators=(',',':'))+'\n');out.flush()
            counts['assignments']+=1;counts['excluded']+=result['excluded'];checked.append(idx)
            if counts['assignments']%100==0:print('SMALL',dict(counts),'seconds',time.monotonic()-started,flush=True)
    assert counts['assignments']==9438
    report={'status':'EXACT_SMALL_CENTRAL_FRESH_REPLAY_PASS' if args.verify else 'EXACT_SMALL_CENTRAL_SCAN_COMPLETE',
        'counts':dict(counts),'input_sha256':sha256(source.read_bytes()).hexdigest(),
        'certificate_sha256':sha256(path.read_bytes()).hexdigest(),'seconds':time.monotonic()-started}
    (HERE/('small_central_fresh_replay.json' if args.verify else 'small_central_summary.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':main()
