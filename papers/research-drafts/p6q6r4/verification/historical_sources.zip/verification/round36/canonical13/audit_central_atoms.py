#!/usr/bin/env python3
"""Independent finite controls for the source-atom geometry routines."""
from itertools import product,combinations_with_replacement
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import random,json,time
from central_atom13 import closing_norms,scalar_multisets
HERE=Path(__file__).resolve().parent

def main():
    started=time.monotonic();rng=random.Random(360035);norm_tests=multiset_tests=matrix_tests=0
    for h in (1,2,3):
        for repeat in range(2000):
            sets=tuple(tuple(sorted(rng.sample(range(21),rng.randrange(1,6)))) for j in range(h))
            expected=False
            for values in product(*sets):
                if h==1:ok=values[0]==0
                elif h==2:ok=values[0]==values[1]
                else:
                    x,y,z=values;ok=2*(x*y+y*z+z*x)-x*x-y*y-z*z>=0
                expected|=ok
            assert closing_norms(sets)==expected;norm_tests+=1
    for R in range(2,8):
        for count in range(1,5):
            explicit=defaultdict(list)
            for values in combinations_with_replacement(range(1-R,R),count):explicit[sum(values)].append(values)
            for total in range(-count*R,count*R+1):
                assert scalar_multisets(count,total,R)==tuple(explicit[total]);multiset_tests+=1
    for n in range(2,6):
        for repeat in range(500):
            A=[[rng.randrange(-2,3) for j in range(n)] for i in range(n)]
            s=sum(A[i][i] for i in range(n));t=sum(A[i][j]**2 for i in range(n) for j in range(n))
            p2=sum(A[i][j]*A[j][i] for i in range(n) for j in range(n));w=t-p2
            B=[[A[i][j]+A[j][i] for j in range(n)] for i in range(n)]
            sb=sum(B[i][i] for i in range(n));tb=sum(B[i][j]**2 for i in range(n) for j in range(n))
            assert sb==2*s and tb==4*t-2*w
            assert n*tb-sb*sb>=0;matrix_tests+=1
            U=[[rng.randrange(-2,3) if i<=j else 0 for j in range(n)] for i in range(n)]
            V=[[rng.randrange(-2,3) if i<=j else 0 for j in range(n)] for i in range(n)]
            U=[[U[i][j] if i<=j else U[j][i] for j in range(n)] for i in range(n)]
            V=[[V[i][j] if i<=j else V[j][i] for j in range(n)] for i in range(n)]
            scalar=rng.randrange(-3,4)
            W=[[scalar*(i==j)-U[i][j]-V[i][j] for j in range(n)] for i in range(n)]
            qs=[]
            for M in (U,V,W):
                tr=sum(M[i][i] for i in range(n));norm=sum(M[i][j]**2 for i in range(n) for j in range(n))
                qs.append(n*norm-tr*tr)
            assert closing_norms(tuple((q,) for q in qs));matrix_tests+=1
    report={'status':'PASS','independent_norm_set_tests':norm_tests,'bounded_scalar_sum_tests':multiset_tests,
        'matrix_pair_and_closed_triangle_controls':matrix_tests,
        'source_hashes':{name:sha256((HERE/name).read_bytes()).hexdigest() for name in ('central_atom13.py','audit_central_atoms.py')},
        'seconds':time.monotonic()-started}
    (HERE/'central_atom_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
