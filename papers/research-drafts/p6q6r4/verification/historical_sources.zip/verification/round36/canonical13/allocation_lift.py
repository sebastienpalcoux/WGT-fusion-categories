"""Exact bounded allocation oracle for the canonical coefficient lift."""
from collections import deque
from canonical12_rows import canonical_capacity_data,regular_character,moment_data
from exact_certificate_checks import dot

def bounded_minimum(weights,caps,costs,total,with_witness=False):
    """min sum(cost_i*x_i): 0<=x_i<=cap_i, sum(weight_i*x_i)=total.

    A sliding minimum on each residue class gives an exact bounded
    integer dynamic program in O(total*number_of_groups) arithmetic.
    Negative objective coefficients are allowed.
    """
    assert len(weights)==len(caps)==len(costs)
    assert all(type(w)is int and w>0 for w in weights)
    assert all(type(c)is int and c>=0 for c in caps)
    assert all(type(z)is int for z in costs) and type(total)is int and total>=0
    dp=[None]*(total+1);dp[0]=0;parents=[]
    for w,cap,cost in zip(weights,caps,costs):
        out=[None]*(total+1);parent=[None]*(total+1)
        for residue in range(min(w,total+1)):
            queue=deque()
            for q,value in enumerate(range(residue,total+1,w)):
                while queue and queue[0][0]<q-cap:queue.popleft()
                if dp[value] is not None:
                    adjusted=dp[value]-q*cost
                    while queue and queue[-1][1]>adjusted:queue.pop()
                    queue.append((q,adjusted))
                if queue:
                    p,adjusted=queue[0];out[value]=adjusted+q*cost;parent[value]=q-p
        dp=out
        if with_witness:parents.append(parent)
    answer=dp[total]
    if not with_witness:return answer
    if answer is None:return None
    allocation=[];remaining=total
    for i in reversed(range(len(weights))):
        x=parents[i][remaining];assert x is not None
        allocation.append(x);remaining-=weights[i]*x
    allocation=tuple(reversed(allocation));assert remaining==0
    assert sum(w*x for w,x in zip(weights,allocation))==total
    assert sum(z*x for z,x in zip(costs,allocation))==answer
    return answer,allocation

def lifted_target(groups,rows,rank,pairs):
    target,_=moment_data(groups,rows,rank,pairs)
    return target+tuple(c*(a-m) for a,m,c in groups)

def lifted_row_minimum(groups,row,rank,pairs,coefficients,with_witness=False):
    target,vectors=moment_data(groups,[row],rank,pairs);assert len(vectors)==1
    width=len(target);base=dot(coefficients[:width],vectors[0]);sd,d,_=row
    caps=canonical_capacity_data(groups,d,sd)[0];regular=regular_character(groups,row)
    minimum=bounded_minimum(tuple(m for a,m,c in groups),caps,
        tuple(coefficients[width:]),regular,with_witness)
    assert minimum is not None
    if with_witness:
        value,allocation=minimum
        return base+(1 if sd else 2)*d*value,allocation
    return base+(1 if sd else 2)*d*minimum

def verify_lift_separator(groups,rows,rank,pairs,certificate):
    assert certificate['kind']=='bounded_allocation_separator'
    target=lifted_target(groups,rows,rank,pairs);z=certificate['coefficients']
    assert len(z)==len(target) and all(type(x)is int for x in z)
    goal=dot(z,target);minimum=min(lifted_row_minimum(groups,row,rank,pairs,z) for row in rows)
    assert minimum>=0 and goal<0
    assert certificate['minimum_row_value']==minimum and certificate['target_value']==goal
    return True
