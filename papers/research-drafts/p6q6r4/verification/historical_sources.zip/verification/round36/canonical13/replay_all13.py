#!/usr/bin/env python3
"""Portable stdlib replay/authentication of the complete canonical-L13 release.

Default: authenticate the full fresh mathematical replay and independently
rebuild the exact remaining-input comparison.  --fresh redoes every input,
field, rational-form, spectral/atom and source-word certificate calculation.
"""
from pathlib import Path
from hashlib import sha256
import argparse,json,subprocess,sys,time
from finalize_canonical13 import merge_ledgers,remaining_input
from verify_canonical13 import mathematical_source_hashes,digest,load_records
from enumerate_canonical13 import read_records
HERE=Path(__file__).resolve().parent
PAYLOADS=('input807656.jsonl.gz','preliminary185421.jsonl.gz','preliminary_summary.json',
    'complete_input_verification.json','field_coverage_audit.json','odd_form_results.jsonl.gz',
    'odd_form_summary.json','odd_form_fresh_replay.json','aggregate_results.jsonl','word_results.jsonl',
    'complete_replay.jsonl','complete_higher_verification.json','remaining146923.jsonl.gz',
    'canonical13_summary.json','new_arithmetic_audit.json','central_atom_audit.json',
    'primary_example_verification.json')

def all_sources():
    return {p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.glob('*.py'))}

def run_script(name,*args):
    subprocess.run([sys.executable,'-B','-S',str(HERE/name),*map(str,args)],cwd=HERE,check=True)

def bind_release():
    high=json.loads((HERE/'complete_higher_verification.json').read_bytes());assert high['complete_high_tail_coverage']
    assert high['mathematical_source_hashes']==mathematical_source_hashes()
    audit=json.loads((HERE/'complete_input_verification.json').read_bytes());assert audit['status']=='INDEPENDENT_COMPLETE_INPUT_REPLAY_PASS'
    field=json.loads((HERE/'field_coverage_audit.json').read_bytes());assert field['status']=='FULL_CONDUCTOR_FIELD_AUDIT_PASS'
    odd=json.loads((HERE/'odd_form_fresh_replay.json').read_bytes());assert odd['status']=='EXACT_ODD_FORM_FRESH_REPLAY_PASS'
    for name in ('new_arithmetic_audit.json','central_atom_audit.json','primary_example_verification.json'):
        report=json.loads((HERE/name).read_bytes());assert report['status']=='PASS'
        for filename,expected in report['source_hashes'].items():assert sha256((HERE/filename).read_bytes()).hexdigest()==expected
    result={'status':'COMPLETE_CANONICAL13_RELEASE_PASS','source_hashes':all_sources(),
        'payload_hashes':{name:sha256((HERE/name).read_bytes()).hexdigest() for name in PAYLOADS},
        'high_tail_mathematical_source_digest':high['mathematical_source_digest'],
        'counts':{'raw_profiles':62776,'raw_assignments':807656,'preliminary':185421,
            'rational_odd_eligible':37438,'rational_odd_excluded':32180,'high_tail':9438,
            'high_tail_excluded':9438,'remaining_assignments':146923,'remaining_profiles':25477,
            'complex_algebra_shapes':15},
        'scope':'Necessary canonical data only; source rank17..29 is conditional on L=13; no ring or category is asserted to exist.'}
    (HERE/'canonical13_release_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def authenticate():
    report=json.loads((HERE/'canonical13_release_verification.json').read_bytes())
    assert report['status']=='COMPLETE_CANONICAL13_RELEASE_PASS' and report['source_hashes']==all_sources()
    for name,expected in report['payload_hashes'].items():assert sha256((HERE/name).read_bytes()).hexdigest()==expected,name
    high=json.loads((HERE/'complete_higher_verification.json').read_bytes())
    sources=mathematical_source_hashes();assert high['mathematical_source_hashes']==sources and high['mathematical_source_digest']==digest(sources)
    base=load_records(HERE/'aggregate_results.jsonl');words=load_records(HERE/'word_results.jsonl');ledger=load_records(HERE/'complete_replay.jsonl')
    expected={r['assignment_index'] for r in read_records(HERE/'preliminary185421.jsonl.gz') if r['rank']>=31}
    assert len(expected)==9438 and set(base)==set(ledger)==expected
    assert set(words)=={i for i,r in base.items() if not r['excluded']}
    input_hash=sha256((HERE/'preliminary185421.jsonl.gz').read_bytes()).hexdigest()
    for idx,entry in ledger.items():
        assert entry['status']=='PASS' and not entry['open_pairs']
        assert entry['input_sha256']==input_hash and entry['mathematical_source_digest']==high['mathematical_source_digest']
        assert entry['certificate_digest']==digest([base[idx],words.get(idx)])
    remaining_input(write=False)
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--fresh',action='store_true');p.add_argument('--workers',type=int,default=2)
    p.add_argument('--bind-existing',action='store_true',help='Maintainer: bind already completed, checked fresh ledgers and audits.')
    args=p.parse_args();started=time.monotonic();assert args.workers>=1
    if args.fresh:
        sources=all_sources()
        run_script('audit_canonical13.py')
        run_script('run_odd13.py','--verify')
        run_script('audit_new_arithmetic.py');run_script('audit_central_atoms.py')
        folder=HERE/'fresh_shards';folder.mkdir(exist_ok=True)
        processes=[];logs=[]
        for residue in range(args.workers):
            log=(folder/f'replay_{residue}.log').open('w');logs.append(log)
            command=[sys.executable,'-B','-S',str(HERE/'verify_canonical13.py'),
                '--modulus',str(args.workers),'--residue',str(residue),
                '--ledger',str(folder/f'ledger_{residue}.jsonl'),'--output',str(folder/f'report_{residue}.json')]
            processes.append(subprocess.Popen(command,cwd=HERE,stdout=log,stderr=subprocess.STDOUT))
        for process in processes:assert process.wait()==0,'fresh high-tail subprocess failed; inspect fresh_shards logs'
        for log in logs:log.close()
        merge_ledgers(folder,args.workers);remaining_input(write=True)
        run_script('audit_primary_example.py')
        assert all_sources()==sources,'source changed during fresh replay'
        report=bind_release()
    elif args.bind_existing:
        remaining_input(write=False);report=bind_release()
    else:report=authenticate()
    print(json.dumps({'status':report['status'],'mode':'FRESH_REPLAY' if args.fresh else 'BINDING' if args.bind_existing else 'AUTHENTICATED_COMPLETE_FRESH_REPLAY',
        'counts':report['counts'],'seconds':time.monotonic()-started,'scope':report['scope']},indent=2),flush=True)

if __name__=='__main__':main()
