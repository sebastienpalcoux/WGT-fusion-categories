#!/usr/bin/env python3
"""Write release notes only after the complete exact high-tail replay."""
from pathlib import Path
from itertools import product
import json
HERE=Path(__file__).resolve().parent

def main():
    summary=json.loads((HERE/'canonical13_summary.json').read_bytes())
    high=json.loads((HERE/'complete_higher_verification.json').read_bytes())
    assert summary['status']=='VERIFIED_NECESSARY_L13_REMAINDER' and high['complete_high_tail_coverage']
    assert high['counts']['assignments']==high['counts']['excluded']==9438
    abstract_shapes=set()
    for counts in product(range(1,14),range(7),range(5),range(4)):
        if sum(m*c for m,c in enumerate(counts,1))!=13:continue
        rank=sum(m*m*c for m,c in enumerate(counts,1))
        if not 17<=rank<=29 or counts==(1,6,0,0):continue
        abstract_shapes.add(tuple((m,c) for m,c in enumerate(counts,1) if c))
    assert len(abstract_shapes)==15
    assert abstract_shapes=={tuple(map(tuple,r['degree_multiplicities'])) for r in summary['complex_algebra_shapes']}
    stage_labels={'odd_rational_trace_form':'Rational odd-matrix trace forms',
        'small_rational_central_spectrum':'Complete small integer central spectra',
        'bounded_regular_canonical_remainder':'Bounded regular canonical remainders',
        'small_central_atom_geometry':'Small central atom geometry and spectra',
        'regular_canonical_remainder':'Full-row regular canonical remainders',
        'no_source_duality':'No admissible source duality',
        'source_moment_branches':'Exact source-moment separators',
        'word_refinement':'Full-length positive-word refinement'}
    stage_rows='\n'.join(r'\text{'+stage_labels[k]+r'}'+f'&{v:,}'+r'\\' for k,v in high['stage_counts'].items())
    rank_rows='\n'.join(str(k)+f'&{v:,}'+r'\\' for k,v in summary['rank_distribution'].items())
    shape_rows=[]
    for item in summary['complex_algebra_shapes']:
        terms=[]
        for m,c in item['degree_multiplicities']:
            term=(r'\mathbb C' if c==1 else r'\mathbb C^{'+str(c)+'}') if m==1 else ((str(c)+r'\,') if c>1 else '')+r'M_{'+str(m)+r'}(\mathbb C)'
            terms.append(term)
        shape_rows.append(str(item['rank'])+'&'+r'\oplus '.join(terms)+'&'+f"{item['assignments']:,}"+r'\\')
    tex=r'''\subsection{The completed canonical-length-thirteen reduction}
\label{r36:sec:canonical13-complete}

\begin{theorem}[The complete high-rank tail at canonical length thirteen]
\label{r36:canonical13-high-tail}
Under the standing simple integral center hypotheses at dimension
$5400^2$, suppose the source canonical length is $L=13$.
Then the source rank is at most $29$.
\end{theorem}

\begin{proof}
Write a group as $(a,m,c)$ when $c$ distinct source representations
have ordinary degree $m$ and associated canonical dimension $a$.
The complete bounded-entry enumeration, and independently the
count-vector enumeration, give $62,776$ weighted canonical profiles
and $807,656$ representation-multiplicity assignments.  The inherited
rank, determinant, forbidden-pattern, rational-residue and capacity
conditions retain exactly $185,421$ assignments.  Every actual full
conductor was audited: $322$ determinant catalogues and $154$ scalar
catalogues, retaining the possible degrees five, six and eight.

There are exactly $9,438$ preliminary assignments of rank at least
$31$.  Each has an exact negative certificate, and all $9,438$ were
replayed with the Python standard library, including complete
source-row or finite spectral/atom regeneration as needed.  The
disjoint verified terminal stages are
\[
\begin{array}{l|r}
\text{terminal certificate}&\text{assignments}\\\hline
''' + stage_rows + r'''
\end{array}
\]
The moment separators are integer covectors checked on every
regenerated necessary row; a numerical optimizer is not part of the
negative verifier.  Source-word refinement uses the full return
cutoff $13$.  A search limit or a surviving necessary row never
counts as a negative certificate.  The complete input has odd rank,
so excluding the entire tail beginning at $31$ proves the bound.
\end{proof}

\begin{theorem}[The exact necessary remainder and complex algebra shapes]
\label{r36:canonical13-final-ranks-shapes}
At $L=13$, the remaining necessary input has $146,923$ assignments
on $25,477$ weighted canonical profiles.  Its rank distribution is
\[
\begin{array}{c|r}
\text{source rank}&\text{necessary assignments}\\\hline
''' + rank_rows + r'''
\end{array}
\]
Every irreducible source representation has degree at most four.
The complexified Grothendieck algebra has one of the following
fifteen possible shapes:
\[
\begin{array}{c|l|r}
r&\text{complex algebra shape}&\text{necessary assignments}\\\hline
''' + '\n'.join(shape_rows) + r'''
\end{array}
\]
The table counts numerical necessary inputs.  It does not assert
the existence of a based ring, fusion category, or source dimension
type for any row.
\end{theorem}

\begin{proof}
Among $37,966$ preliminary assignments with all nonlinear degrees
odd, $37,438$ have rationality forced by singleton nonlinear groups
and are eligible for the rational odd-matrix trace-form gate.  The
other $528$ inputs have repeated nonlinear groups and are retained
outside this gate; their individual fields are not declared rational
or nonrational by this test.  The gate excludes $32,180$ assignments.  Its overlap
with the high-rank tail is exactly $3,120$, so the union of the two
verified exclusions has size
\[
 32,180+9,438-3,120=38,498,
 \qquad 185,421-38,498=146,923.
\]
An independent streamed subtraction produces the asserted ranks,
profiles and shapes.  For the degree bound, the identities
$\sum_E m_E=13$ and $\sum_E m_E^2=r\le29$ imply
$\sum_E m_E(m_E-1)\le16$, excluding any $m_E\ge5$.
The remaining algebra shapes follow by enumerating degrees one
through four, with the Perron representation included.  The apparent
extra shape $\mathbb C\oplus6M_2(\mathbb C)$ is impossible because
the canonical dimension equation would read
$5400=1+2\sum_E a_E$, an odd integer.
\end{proof}

The rank bound is conditional on $L=13$.  The weighted profiles in
this theorem describe the canonical object $I(\mathbf1)$; they are
not the Frobenius--Perron dimension types of the source category.
Reconstructing a Grothendieck ring still requires integral structure
constants, associativity, duality and all the remaining categorical
conditions.
'''
    (HERE/'r36_canonical13_complete.tex').write_text(tex)
    readme=f'''ROUND 36: COMPLETE CANONICAL-LENGTH-13 NECESSARY INPUT

Status: every one of the 9438 preliminary rank>=31 assignments has an
exact negative certificate and a complete fresh standard-library replay.

Run from this directory, or use an absolute path to the script:

    python -B -S replay_all13.py

This default authenticates all source and certificate hashes, every fresh
ledger entry and coverage identity, and independently streams the exact
remaining-input comparison. It does not rerun every source-row search.

For a complete fresh mathematical replay (no NumPy/SciPy required):

    python -B -S replay_all13.py --fresh --workers 2

The fresh command independently enumerates all 807656 inputs, audits full
conductor fields, replays all 37438 eligible rational odd-matrix cases,
runs the finite arithmetic/geometry controls, and regenerates every
negative high-tail row/spectrum/atom/word certificate. Worker count may
be increased if memory permits. Reports are written locally. The parent
Round36 release runner copies this tree before invoking fresh replay.

Verified counts
---------------
Raw weighted profiles:              62776
Raw multiplicity assignments:      807656
After preliminary necessary gates: 185421
Rational odd gate eligible:         37438
Rational odd gate excluded:         32180
Odd inputs with repeated nonlinear groups kept outside: 528
Complete high-rank tail excluded:    9438
Overlap of the two exclusions:       3120
Remaining necessary assignments:   146923
Remaining weighted profiles:        25477
Complex algebra shapes:                15
Ranks: 17,19,21,23,25,27,29; maximum ordinary representation degree 4.

Remaining input
---------------
remaining146923.jsonl.gz contains the complete surviving necessary
records, with stable assignment_index values from input807656.jsonl.gz.
canonical13_summary.json gives exact rank and shape counts. These data
are canonical numerical assignments, not realized fusion rings, source
dimension types, or categories. The rank bound 29 assumes L=13.

Exact versus numerical work
--------------------------
The negative replay imports 27 local mathematical Python modules and
only the Python standard library. Optional producer scripts import SciPy
to propose integer separating covectors; proposals are accepted only
after exact integer verification. No optimizer status is an exclusion.

Finite integer central spectra keep separate variables for repeated
(a,m) characters. A search budget yields no exclusion. The source atom
geometry applies zero-sum norms only to known full rational groups c=1.
Higher-degree full fields (including degrees 5,6,8) remain present in the
complete conductor audits. General source words use return cutoff13;
the integer-spectrum window1..9 is not substituted for that cutoff.
The characteristic-polynomial cache is bounded at8 entries.

Source provenance
-----------------
inherited_source_snapshot.json records the immutable R35 sources used
to reconstruct this work. Historical filenames canonical12_rows.py and
canonical12_words.py are retained in the import closure; their active
APIs take the full L13 group data, and the latter now derives its return
cutoff as1+sum(m*c). Unused inherited driver scripts remain as provenance;
the supported complete entrypoint for this directory is replay_all13.py.

Verified high-tail terminal stages
---------------------------------
''' + '\n'.join(f'{stage_labels[k]}: {v}' for k,v in high['stage_counts'].items()) + f'''

Full-moment-stage source rows: {high['counts']['base_rows']}
Rows retained by word refinement: {high['counts']['refined_rows']}
These totals do not include the additional bounded rows inspected inside
canonical-remainder and atom certificates.
'''
    (HERE/'README.txt').write_text(readme)
    (HERE/'HANDOFF.txt').write_text(readme+'\nThe theorem fragment is r36_canonical13_complete.tex; static arithmetic\nfragments are r36_integer_spectral_moments.tex, r36_bounded_allocation.tex,\nand r36_small_central_spectra.tex. All numerical claims must stay necessary\nand conditional as stated.\n')
    print('Wrote verified canonical13 theorem and release notes.',flush=True)

if __name__=='__main__':main()
