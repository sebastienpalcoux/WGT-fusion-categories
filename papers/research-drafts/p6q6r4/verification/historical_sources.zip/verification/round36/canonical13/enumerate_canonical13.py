#!/usr/bin/env python3
"""Complete exact L=13 canonical input, streamed in deterministic order.

All fields occur through their complete Galois orbit, including degrees
five, six and eight.  These are necessary numerical data, not rings.
"""
from collections import Counter
from functools import lru_cache
from itertools import product
from math import gcd, prod
from pathlib import Path
from hashlib import sha256
import gzip, json, time
from verify_two_blocks import PALETTE, squarefree_part, quadratic_discriminants, phi
from verify_length10 import subfield_orbits
from probe_length11 import residue_failure
from enumerate_canonical12 import partitions, profiles

HERE=Path(__file__).resolve().parent
N=5400; L=13

@lru_cache(None)
def orbit_options(a,m,k):
    f=N//a; conductor=gcd(2*f,f*f)
    options=set() if a==10 else {(1,1)}
    if k>=2:
        options.update((2,squarefree_part(abs(D))) for D in quadratic_discriminants(conductor))
    if k>=3 and conductor%9==0: options.add((3,1))
    if k>=4:
        options.update((e,s) for e,s,D,h in subfield_orbits(gcd(conductor,240),4) if e==4)
    if k>=5 and phi(conductor)%5==0:
        assert conductor==25,(a,m,k,conductor)
        options.update((e,s) for e,s,D,h in subfield_orbits(conductor,k) if e==5)
    if k>=6 and phi(conductor)%6==0:
        assert conductor in (9,36),(a,m,k,conductor)
        options.update((e,s) for e,s,D,h in subfield_orbits(conductor,k) if e==6)
    if k>=8 and phi(conductor)%8==0:
        assert conductor in (20,24),(a,m,k,conductor)
        options.update((e,s) for e,s,D,h in subfield_orbits(conductor,k) if e==8)
    assert k<=8,(a,m,k)
    return tuple(sorted(options))

@lru_cache(None)
def orbit_classes(a,m,k):
    states=[set() for _ in range(k+1)];states[0]={1}
    for n in range(k):
        for old in states[n]:
            for e,s in orbit_options(a,m,k):
                if n+e<=k:states[n+e].add(squarefree_part(old*s))
    return tuple(sorted(states[k]))

def regenerate():
    ps=tuple(sorted(profiles(0,L-1,N-1),reverse=True))
    assert len(ps)==62776
    assignment_index=0
    for index,p in enumerate(ps):
        counts=Counter(p);aa=sorted(counts,reverse=True)
        baseline=squarefree_part(N*prod(p))
        for parts in product(*(partitions(counts[a]) for a in aa)):
            types=[(a,m,c) for a,part in zip(aa,parts) for m,c in Counter(part).items()]
            rank=1+sum(m*m*c for a,m,c in types);comm=all(m==1 for a,m,c in types)
            assert rank%2==1
            low=rank<(14 if comm else 16)
            rational_ten=any(a==10 and c==1 for a,m,c in types)
            classes={1}
            for a,m,c in types:
                if m%2:classes={squarefree_part(x*y) for x in classes for y in orbit_classes(a,m,c)}
            det=baseline in classes and not rational_ten
            forbidden=counts[24]==counts[200]==1 and all(a in (24,200) or a%225==0 for a in aa)
            residue=residue_failure(types) if det and not low and not forbidden else None
            capacity=[g for g in types if (rank-1)*(N//g[0]-1)<(N//g[0])*g[1]**2*g[2]-g[1]*g[2]]
            kept=det and not low and not forbidden and residue is None and not capacity
            yield {'assignment_index':assignment_index,'index':index,'profile':p,
                'multiplicities':list(zip(aa,parts)),'rank':rank,'commutative':comm,
                'types':types,'baseline':baseline,'odd_component_field_classes':sorted(classes),
                'determinant_pass':det,'excluded_by_rank':low,'forbidden_24_200':forbidden,
                'rational_residue_failure':residue,'capacity_failure':capacity,'retained':kept}
            assignment_index+=1
    assert assignment_index==807656

def read_records(path):
    opener=gzip.open if str(path).endswith('.gz') else open
    with opener(path,'rt',encoding='utf8') as stream:
        for line in stream:
            if line.strip():yield json.loads(line)

def main():
    started=time.monotonic();counts=Counter();ranks=Counter();raw_ranks=Counter();profiles_kept=set()
    raw_path=HERE/'input807656.jsonl.gz';kept_path=HERE/'preliminary185421.jsonl.gz'
    with gzip.GzipFile(filename=str(raw_path),mode='wb',mtime=0) as raw, gzip.GzipFile(filename=str(kept_path),mode='wb',mtime=0) as kept:
        for r in regenerate():
            data=(json.dumps(r,separators=(',',':'))+'\n').encode();raw.write(data)
            counts['assignments']+=1;raw_ranks[r['rank']]+=1
            if r['determinant_pass']:
                counts['after_determinant']+=1
                if not r['excluded_by_rank']:
                    counts['after_known_rank_bounds']+=1
                    if not r['forbidden_24_200']:
                        counts['after_forbidden_pattern']+=1
                        if r['rational_residue_failure'] is None:counts['after_rational_residues']+=1
            if r['retained']:
                kept.write(data);counts['preliminary_retained']+=1;ranks[r['rank']]+=1;profiles_kept.add(r['index'])
            if counts['assignments']%100000==0:print('ENUMERATED',counts['assignments'],dict(counts),flush=True)
    assert counts['assignments']==807656 and counts['preliminary_retained']==185421,counts
    result={'status':'EXACT_PRELIMINARY_INPUT_COMPLETE','canonical_length':L,'profiles':62776,
        'counts':dict(counts),'retained_profiles':len(profiles_kept),'raw_rank_distribution':dict(sorted(raw_ranks.items())),
        'retained_rank_distribution':dict(sorted(ranks.items())),
        'input_sha256':sha256(raw_path.read_bytes()).hexdigest(),
        'retained_sha256':sha256(kept_path.read_bytes()).hexdigest(),'seconds':time.monotonic()-started}
    (HERE/'preliminary_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
