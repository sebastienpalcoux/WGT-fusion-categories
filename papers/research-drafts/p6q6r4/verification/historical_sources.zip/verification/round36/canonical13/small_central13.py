"""Complete bounded integer spectra for rational canonical columns.

An individual representation receives its own scalar.  No equality is
inferred merely from a shared (a,m) pair.  Allowing the scalars within a
full Galois orbit to differ only enlarges this necessary search universe.
"""
from collections import Counter
from functools import lru_cache
from math import gcd,prod
from integer_spectrum import all_moments_integral
N=5400

class SpectrumBudgetExceeded(Exception):
    """An unfinished necessary search is not an exclusion."""

def weight_order(weights,R):
    # Prefer an order that extracts the exceptional prime factors early.
    # Equal weights are exchangeable for these spectral conditions.
    counts=Counter(weights);values=tuple(sorted(counts));size=len(values)
    @lru_cache(None)
    def best(mask):
        if not mask:return (1,())
        answer=None
        for i,w in enumerate(values):
            if not (mask>>i)&1:continue
            rest=mask^(1<<i);score,seq=best(rest)
            g=gcd(N,*(v for j,v in enumerate(values) if (rest>>j)&1))
            modulus=g//gcd(w,g)
            score*=(2*R-1)**(counts[w]-1)*max(1,(2*R-1+modulus-1)//modulus)
            key=(score,(w,)*counts[w]+seq)
            if answer is None or key<answer:answer=key
        return answer
    return best((1<<size)-1)[1]

@lru_cache(maxsize=512)
def spectrum_possible(weights,R,node_limit=None):
    """Returns a spectrum witness or None after complete finite exhaustion."""
    weights=weight_order(tuple(weights),R);n=len(weights)
    suffix_mass=[0]*(n+1);suffix_gcd=[N]*(n+1)
    for i in reversed(range(n)):
        suffix_mass[i]=suffix_mass[i+1]+weights[i]
        suffix_gcd[i]=gcd(suffix_gcd[i+1],weights[i])
    if R%suffix_gcd[0]:return None
    values=range(1-R,R)
    powers={lam:tuple(pow(lam,k,N) for k in range(1,10)) for lam in values}
    indexed={}
    for i,w in enumerate(weights[:-1]):
        g=suffix_gcd[i+1];lookup={}
        for lam in values:
            key=tuple((w*p)%g for p in powers[lam])
            lookup.setdefault(key,[]).append(lam)
        indexed[i]=lookup
    chosen=[];nodes=0
    def visit(i,linear,residues):
        nonlocal nodes
        nodes+=1
        if node_limit is not None and nodes>node_limit:raise SpectrumBudgetExceeded
        if abs(linear)>(R-1)*suffix_mass[i] or linear%suffix_gcd[i]:return None
        w=weights[i]
        low=chosen[-1] if i and weights[i-1]==w else 1-R
        if i==n-1:
            if linear%w:return None
            lam=-linear//w
            if lam<low or lam>=R:return None
            if any((old+w*p)%N for old,p in zip(residues,powers[lam])):return None
            spectrum=((1,R),)+tuple(zip(weights,chosen+[lam]))
            assert all_moments_integral(spectrum,N)
            if prod(R-lam for lam in {x[1] for x in spectrum[1:]})%N:return None
            return spectrum
        g=suffix_gcd[i+1]
        key=tuple((-x)%g for x in residues)
        for lam in indexed[i].get(key,()):
            if lam<low:continue
            newlinear=linear+w*lam
            if abs(newlinear)>(R-1)*suffix_mass[i+1]:continue
            newres=tuple((old+w*p)%N for old,p in zip(residues,powers[lam]))
            chosen.append(lam)
            result=visit(i+1,newlinear,newres)
            chosen.pop()
            if result is not None:return result
        return None
    return visit(0,R,tuple(pow(R,k,N) for k in range(1,10)))

def small_central_spectrum(groups,maximum_remainder=35,node_limit=20000):
    weights=tuple(sorted(a*m for a,m,c in groups for _ in range(c)))
    columns=sorted((a,m,c) for a,m,c in groups if c==1 and a-m<=maximum_remainder)
    for a,m,c in sorted(columns,key=lambda g:(g[0]-g[1],g)):
        R=a-m
        try:possible=spectrum_possible(weights,R,node_limit)
        except SpectrumBudgetExceeded:continue
        if possible is None:
            return {'kind':'small_rational_central_spectrum','group':[a,m,c],
                'remainder':R,'weights':list(weights),'power_bound':9,
                'node_limit':node_limit,'complete_integer_spectrum_exhaustion':True}
    return None
