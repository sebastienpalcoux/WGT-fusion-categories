#!/usr/bin/env python3
"""Fresh exact negative replay of every L13 high-tail certificate.

Only the Python standard library is imported.  Every source row or
finite spectral/atom exhaustion used by a certificate is regenerated.
The complete input and full-field audits are separately source-bound
by replay_all13.py; the present verifier handles the high tail itself.
"""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import argparse,ast,gc,json,time
from enumerate_canonical13 import read_records
from canonical12_rows import (rows_for,possible_pairs,moment_data,cheap_certificate,
    bounded_remainder_scan,capacity_moment_data)
from canonical12_words import word_possible
from odd_rational_forms import gate as odd_form_gate
from small_central13 import small_central_spectrum
from central_atom13 import small_central_atoms
from exact_certificate_checks import verify_certificate
import canonical12_rows,canonical12_words,cubic_trace_gate,fixed_field_rows,power_trace_filter,central_atom13
HERE=Path(__file__).resolve().parent

def normalized(value):return json.loads(json.dumps(value))
def digest(value):return sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def mathematical_source_hashes():
    pending=['verify_canonical13.py'];found={}
    while pending:
        name=pending.pop()
        if name in found:continue
        data=(HERE/name).read_bytes();found[name]=sha256(data).hexdigest()
        for node in ast.walk(ast.parse(data,filename=name)):
            imports=[x.name for x in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in imports:
                local=module.split('.')[0]+'.py'
                if (HERE/local).is_file() and local not in found:pending.append(local)
    return dict(sorted(found.items()))

def clear_caches():
    for fn in (canonical12_rows.options,canonical12_rows.scalar_options,
        canonical12_rows.canonical_capacity_data,canonical12_words.polynomial_powers,
        cubic_trace_gate.cubic_residues,cubic_trace_gate.linear_ws_map,
        fixed_field_rows.fixed_options,power_trace_filter.scalar_power_options,
        central_atom13.trace_completion,central_atom13.scalar_multisets):
        if hasattr(fn,'cache_clear'):fn.cache_clear()
    gc.collect()

def load_records(path,partial=False):
    if not path.exists():return {}
    data=path.read_bytes()
    if data and not data.endswith(b'\n'):
        assert partial;data=data[:data.rfind(b'\n')+1]
    records=[json.loads(line) for line in data.splitlines() if line];result={r['assignment_index']:r for r in records}
    assert len(result)==len(records)
    return result

def check_branch(branch,groups,rows,rank):
    b=branch['pairs']
    if branch['moment_mode']=='base':
        target,vectors=moment_data(groups,rows,rank,b);assert branch['capacity_subsets']==[]
    else:
        assert branch['moment_mode']=='canonical_capacities'
        target,vectors,subsets=capacity_moment_data(groups,rows,rank,b)
        assert branch['capacity_subsets']==normalized(subsets)
        assert branch['certificate'] is None or branch['certificate']['kind']=='integer_separator'
    assert branch['vectors']==len(vectors)
    cert=branch['certificate']
    if cert is None:return False
    if cert['kind'] in ('regular_canonical_remainder','duality_dimension_squares'):
        assert cert==cheap_certificate(groups,rows,rank,b)
    else:assert verify_certificate(vectors,target,cert)
    return True

def check_record(raw,result,refinement=None,allow_open=False):
    started=time.monotonic();idx=raw['assignment_index'];groups=tuple(map(tuple,raw['types']));rank=raw['rank']
    assert raw['retained'] and rank>=31
    assert result['assignment_index']==idx and result['profile_index']==raw['index'] and result['profile']==raw['profile']
    assert result['rank']==rank and result['groups']==normalized(groups)
    common=result['common_certificate'];rows=[];unresolved=[]
    if common is not None and common['kind'] in ('odd_rational_trace_form','small_rational_central_spectrum',
        'bounded_regular_canonical_remainder','small_central_atom_geometry'):
        assert result['possible_pairs'] is None and result['rows']==0 and result['branches']==[] and result['excluded']
        kind=common['kind']
        if kind=='odd_rational_trace_form':
            form=odd_form_gate(groups,rank);assert form is not None and form['excluded']
            assert common=={'kind':kind,'counts':form['counts']}
        elif kind=='small_rational_central_spectrum':assert common==small_central_spectrum(groups)
        elif kind=='bounded_regular_canonical_remainder':assert common==bounded_remainder_scan(groups,rank)
        else:assert common==small_central_atoms(groups,rank)
    else:
        pairs=possible_pairs(groups,rank);form=odd_form_gate(groups,rank)
        if form is not None:
            assert not form['excluded'];pairs=tuple(sorted({r['source_pairs'] for r in form['retained']}))
        assert result['possible_pairs']==list(pairs)
        if not pairs:
            assert common=={'kind':'no_source_duality'} and result['rows']==0 and result['excluded'] and result['branches']==[]
        else:
            rows=list(rows_for(groups,rank));assert result['rows']==len(rows)
            expected=cheap_certificate(groups,rows,rank);assert common==expected
            if common is not None:assert result['excluded'] and result['branches']==[]
            else:
                assert [br['pairs'] for br in result['branches']]==list(pairs)
                unresolved=[br['pairs'] for br in result['branches'] if not check_branch(br,groups,rows,rank)]
                assert result['excluded']==(not unresolved)
    refined_count=None;refined_hash=None
    if refinement is not None:
        assert unresolved
        assert refinement['assignment_index']==idx and refinement['rank']==rank and refinement['groups']==normalized(groups)
        assert refinement['base_rows']==len(rows)
        refined=[row for row in rows if word_possible(groups,row,rank)]
        assert refinement['rows']==len(refined);refined_count=len(refined);refined_hash=digest(refined)
        expected=cheap_certificate(groups,refined,rank);assert refinement['common_certificate']==expected
        if expected is not None:
            assert refinement['branches']==[] and refinement['excluded'];unresolved=[]
        else:
            assert [br['pairs'] for br in refinement['branches']]==unresolved
            unresolved=[br['pairs'] for br in refinement['branches'] if not check_branch(br,groups,refined,rank)]
            assert refinement['excluded']==(not unresolved)
    assert allow_open or not unresolved,(idx,unresolved)
    return {'assignment_index':idx,'rank':rank,'status':'PASS_OPEN' if unresolved else 'PASS',
        'stage':common['kind'] if common is not None else 'word_refinement' if refinement is not None else 'source_moment_branches',
        'base_rows':len(rows),'base_rows_sha256':digest(rows),'refined_rows':refined_count,'refined_rows_sha256':refined_hash,
        'open_pairs':unresolved,'certificate_digest':digest([result,refinement]),'seconds':time.monotonic()-started}

def main():
    p=argparse.ArgumentParser();p.add_argument('--modulus',type=int,default=1);p.add_argument('--residue',type=int,default=0)
    p.add_argument('--available',action='store_true');p.add_argument('--allow-open',action='store_true');p.add_argument('--resume',action='store_true');p.add_argument('--watch',action='store_true')
    p.add_argument('--ledger',type=Path,default=HERE/'complete_replay.jsonl');p.add_argument('--output',type=Path,default=HERE/'complete_higher_verification.json')
    args=p.parse_args();assert 0<=args.residue<args.modulus;started=time.monotonic()
    if args.watch:args.available=True
    source_hashes=mathematical_source_hashes();source_digest=digest(source_hashes)
    input_path=HERE/'preliminary185421.jsonl.gz';input_hash=sha256(input_path.read_bytes()).hexdigest()
    raw={r['assignment_index']:r for r in read_records(input_path) if r['rank']>=31};assert len(raw)==9438
    done=load_records(args.ledger) if args.resume else {}
    selected={idx for position,idx in enumerate(sorted(raw)) if position%args.modulus==args.residue}
    with args.ledger.open('a' if args.resume else 'w') as ledger:
        while True:
            base=load_records(HERE/'aggregate_results.jsonl',args.available);words=load_records(HERE/'word_results.jsonl',args.available)
            assert set(base)<=set(raw) and set(words)<={i for i,r in base.items() if not r['excluded']}
            if not args.available:
                assert set(base)==set(raw) and set(words)=={i for i,r in base.items() if not r['excluded']}
            for idx,entry in done.items():
                assert idx in selected and entry['input_sha256']==input_hash and entry['mathematical_source_digest']==source_digest
                assert entry['certificate_digest']==digest([base[idx],words.get(idx)])
            for idx in sorted(selected-set(done)):
                if idx not in base:continue
                if args.available and not args.allow_open and not base[idx]['excluded'] and idx not in words:continue
                entry=check_record(raw[idx],base[idx],words.get(idx),args.allow_open)
                entry['input_sha256']=input_hash;entry['mathematical_source_digest']=source_digest
                ledger.write(json.dumps(entry,separators=(',',':'))+'\n');ledger.flush()
                done[idx]=entry
                if len(done)%20==0:clear_caches()
                if len(done)%50==0:print('REPLAY',len(done),'/',len(selected),'seconds',time.monotonic()-started,flush=True)
            if not args.watch or set(done)==selected:break
            time.sleep(5)
    checked=sorted(done);counts=Counter();stages=Counter()
    for entry in done.values():
        counts['assignments']+=1;counts['excluded']+=entry['status']=='PASS';counts['base_rows']+=entry['base_rows'];counts['refined_rows']+=entry['refined_rows'] or 0
        stages[entry['stage']]+=1
    complete=set(checked)==set(raw) and counts['excluded']==9438
    assert mathematical_source_hashes()==source_hashes
    report={'status':'COMPLETE_HIGH_TAIL_FRESH_REPLAY_PASS' if complete else 'PARTIAL_HIGH_TAIL_REPLAY_PASS',
        'complete_high_tail_coverage':complete,'counts':dict(counts),'stage_counts':dict(stages),
        'input_sha256':input_hash,'mathematical_source_hashes':source_hashes,'mathematical_source_digest':source_digest,
        'ledger_sha256':sha256(args.ledger.read_bytes()).hexdigest(),'checked_assignment_indices':checked,
        'seconds':time.monotonic()-started}
    args.output.write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ('mathematical_source_hashes','checked_assignment_indices')},flush=True)

if __name__=='__main__':main()
