#!/usr/bin/env python3
"""Independently check the worked two-prime exclusion of input 145816.

This is an explanatory check of an already replayed negative certificate.
It does not add or modify any numerical screening gate.
"""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import gzip,json

HERE=Path(__file__).resolve().parent

def main():
    input_path=HERE/'preliminary185421.jsonl.gz'
    with gzip.open(input_path,'rt') as handle:
        records=(json.loads(line) for line in handle)
        record=next(r for r in records if r['assignment_index']==145816)
    groups=tuple(tuple(group) for group in record['types'])
    assert groups==((900,4,1),(675,1,1),(540,1,1),(450,1,1),
                    (50,1,1),(24,1,1),(20,3,1))
    assert record['rank']==1+sum(m*m*c for a,m,c in groups)==31
    assert 1+sum(m*c for a,m,c in groups)==13
    weights=(1,)+tuple(a*m for a,m,c in groups)
    assert sum(weights)==5400 and all(c==1 for a,m,c in groups)
    R=20-3
    assert R==17
    # Modulo 5 only the Perron weight 1 and the weight 24 survive.
    assert tuple(w for w in weights if w%5)==(1,24)
    perron_residue=R%5
    first=[x for x in range(1-R,R) if x%5==perron_residue]
    second=[x for x in first
            if ((R-perron_residue)//5+24*((x-perron_residue)//5))%5==0]
    assert second==[-8]
    x=second[0]
    # Modulo 3 only the Perron weight 1 and the weight 50 survive.
    # Their residue classes must agree; they cannot be in x's class.
    assert tuple(w for w in weights if w%3)==(1,50)
    assert (1+50)%3==0 and x%3!=R%3
    other=tuple(w for w in weights if w not in (1,24,50))
    residues=sorted({sum(subset)%27 for n in range(len(other)+1)
                     for subset in combinations(other,n)})
    assert residues==[0,6,9,15,18,24]
    assert (-24)%27 not in residues
    with (HERE/'complete_replay.jsonl').open() as handle:
        ledger_record=next(r for r in map(json.loads,handle)
                           if r['assignment_index']==145816)
    assert ledger_record['status']=='PASS'
    assert ledger_record['stage']=='small_rational_central_spectrum'
    report={
        'status':'PASS','assignment_index':145816,'rank':31,
        'canonical_length':13,'canonical_column':[20,3,1],
        'remainder_dimension':R,'spectral_weights':weights,
        'weight_24_scalars_after_primary_5_conditions':second,
        'primary_3_residue_for_weight_24':x%3,
        'primary_3_residue_for_perron_and_weight_50':R%3,
        'other_weight_subset_mass_residues_modulo_27':residues,
        'required_residue_modulo_27':(-24)%27,
        'conclusion':'The required residue is absent; this canonical input is impossible.',
        'input_sha256':sha256(input_path.read_bytes()).hexdigest(),
        'source_hashes':{name:sha256((HERE/name).read_bytes()).hexdigest()
                         for name in ('audit_primary_example.py','integer_spectrum.py')},
        'fresh_ledger_certificate_digest':ledger_record['certificate_digest']}
    (HERE/'primary_example_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
