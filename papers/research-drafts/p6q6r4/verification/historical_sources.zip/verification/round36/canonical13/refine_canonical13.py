#!/usr/bin/env python3
"""Full-L13 positive-word refinement of unresolved high-tail cases."""
from pathlib import Path
from collections import Counter
import argparse,json,time,gc
from enumerate_canonical13 import read_records
from refine_canonical12 import refine
import canonical12_words,canonical12_rows,cubic_trace_gate,power_trace_filter
HERE=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--watch',action='store_true');args=p.parse_args()
    path=HERE/'word_results.jsonl';done={r['assignment_index']:r for r in read_records(path)} if path.exists() else {}
    with path.open('a') as out:
        while True:
            data=(HERE/'aggregate_results.jsonl').read_bytes() if (HERE/'aggregate_results.jsonl').exists() else b''
            if data and not data.endswith(b'\n'):data=data[:data.rfind(b'\n')+1]
            records=[json.loads(line) for line in data.splitlines() if line]
            for old in records:
                if old['excluded'] or old['assignment_index'] in done:continue
                print('WORD START',old['assignment_index'],'rows',old['rows'],flush=True)
                result=refine(old);done[result['assignment_index']]=result
                out.write(json.dumps(result,separators=(',',':'))+'\n');out.flush()
                print('WORD END',result['assignment_index'],'rows',result['rows'],'excluded',result['excluded'],'seconds',result['seconds'],flush=True)
                for fn in (canonical12_words.polynomial_powers,canonical12_rows.options,
                    canonical12_rows.scalar_options,canonical12_rows.canonical_capacity_data,
                    cubic_trace_gate.cubic_residues,cubic_trace_gate.linear_ws_map,
                    power_trace_filter.scalar_power_options):
                    if hasattr(fn,'cache_clear'):fn.cache_clear()
                gc.collect()
            report={'assignments':len(done),'excluded':sum(r['excluded'] for r in done.values()),
                'open':sum(not r['excluded'] for r in done.values()),'refined_rows':sum(r['rows'] for r in done.values()),
                'positive_return_cutoff':13,'polynomial_cache_limit':8}
            (HERE/'word_summary.json').write_text(json.dumps(report,indent=2)+'\n')
            if not args.watch or len(records)==9438:break
            time.sleep(5)

if __name__=='__main__':main()
