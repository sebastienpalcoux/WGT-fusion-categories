#!/usr/bin/env python3
"""Finite final checks for the negative cubic dimension-four pattern.

The analytic reductions preceding these inventories are in the companion TeX:
A same-sign pairs are excluded without computation, A opposite-sign pairs
reduce to a two-square inventory, and B reduces to 56 complete types.  The
B test is a necessary individual-product test, never an existence claim.
"""
from collections import Counter
from math import isqrt
from pathlib import Path
import json
from cubic_four_e11_B import product_rows,trace_semigroup,square_tails
from cubic_four_e11_A import row_allocations

HERE=Path(__file__).resolve().parent

def A_descriptions():
    for p in range(9,17):
        q=p-6
        for a in range(4,40,2):
            rem=4662-3*a*a-2*p*p-2*q*q
            if rem<18:continue
            for d in range(3,isqrt(rem//2)+1,2):
                e=isqrt(rem-d*d)
                if e<d or e%2==0 or d*d+e*e!=rem:continue
                yield (a,p,q,d,e)

def A_check():
    records=[];counts=Counter()
    for case in A_descriptions():
        counts['dimension_types']+=1;a,p,q,d,e=case;allocs=[]
        for h,u,v in row_allocations(33-2*p,(3*a,d,e)):
            counts['P33_allocations']+=1
            if any(24*n>4*dim for n,dim in ((h,a),(u,d),(v,e))):
                reason={'reason':'forced_W_mass'}
            else:
                xn=list(row_allocations(4*q,(3*a,p+q,d,e)))
                if not xn:reason={'reason':'missing_XN_dimension','target':4*q,'generators':(3*a,p+q,d,e)}
                else:
                    assert case==(36,13,7,7,17) and (h,u,v)==(0,1,0)
                    assert xn==[(0,0,4,0)]
                    assert 8*q>4*d
                    reason={'reason':'reciprocity_overflow','XN_rows':xn,'forced_XD_mass':8*q,'available_XD_mass':4*d}
            counts[reason['reason']]+=1;allocs.append({'P_allocation':(h,u,v),'certificate':reason})
        records.append({'dimensions':case,'allocations':allocs})
    assert counts==Counter(dimension_types=55,P33_allocations=6,missing_XN_dimension=5,reciprocity_overflow=1)
    return {'counts':dict(counts),'certificates':records}

def B_descriptions():
    for p in range(5,14):
        for z in range(p+14,28,2):
            x=((z+6+p)//2,(z+6-p)//2,(6-z+p)//2,(6-z-p)//2)
            assert min(map(abs,x))>=4
            residual=27-z
            for k in range(4):
                for extra in square_tails(4626-z*z-3*p*p,k,5):
                    if residual and residual not in extra:continue
                    yield {'rank':13+k,'p':p,'z':z,'signed_dimensions':x,'extras':extra,
                           'P_residual':residual,'w_dimension':24}

def B_check_case(case):
    x=case['signed_dimensions'];p=case['p'];ex=case['extras'];r=case['P_residual']
    dims=(24,)+tuple(map(abs,x))+(p,p)+tuple(ex)
    # P=A1+A2+R_(27-z); a nonzero R is a single zero-image label.
    residual_positions=[None] if not r else [7+j for j,d in enumerate(ex) if d==r]
    all_allocs=[];stats=Counter()
    for pos in residual_positions:
        required_W=[0]*len(dims);required_W[1]=required_W[2]=1
        if pos is not None:required_W[pos]=1
        indices=list(range(1,5))+[5]+list(range(7,len(dims)))
        indices.sort(key=lambda i:(dims[i],i))
        bits,offset=trace_semigroup(case,max(dims[i]**2 for i in indices));tested=[]
        for index in indices:
            d=dims[index];t=3 if 1<=index<=4 else (4 if index==5 else 0)
            hit=False;rows=0;eligible=0
            for row in product_rows(case,4*d):
                if row[0]!=required_W[index]:continue
                rows+=1;stats['coefficient_rows']+=1
                c=row[index]
                if c>3:continue
                norm=sum(a*a for a in row);a=norm-1-2*c
                if a<0:continue
                mass=d*d-9-15*a-12*c
                if mass<0:continue
                eligible+=1;stats['norm_eligible_rows']+=1
                trace=t-2+2*a
                if offset+trace>=0 and (bits[mass]>>(offset+trace))&1:
                    hit=True;break
            tested.append({'index':index,'dimension':d,'coefficient_rows':rows,'norm_eligible_rows':eligible,'necessary_row_exists':hit})
            if not hit:
                all_allocs.append({'P_residual_index':pos,'missing_index':index,'missing_dimension':d,'tested':tested})
                break
        else:
            return {'excluded':False,'P_residual_index':pos,'tested':tested}
    return {'excluded':True,'allocations':all_allocs,'statistics':dict(stats)}

def B_check():
    records=[];counts=Counter();hist=Counter()
    for case in B_descriptions():
        cert=B_check_case(case)
        assert cert['excluded'],(case,cert)
        counts[str(case['rank'])]+=1
        hist.update(c['missing_dimension'] for c in cert['allocations'])
        records.append({'input':case,'certificate':cert})
    assert counts==Counter({'16':56})
    return {'rank_counts':dict(counts),'missing_dimension_histogram':dict(sorted(hist.items())),'certificates':records}

def main():
    result={'scope':'negative cubic dimension-four e7 T0, unique degree-two component f6, ranks <=16',
            'A':A_check(),'B':B_check(),'all_excluded':True}
    (HERE/'cubic_four_negative_certificates.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(json.dumps({'all_excluded':True,'A':result['A']['counts'],'B':{k:v for k,v in result['B'].items() if k!='certificates'}},indent=2,sort_keys=True))

if __name__=='__main__':main()
