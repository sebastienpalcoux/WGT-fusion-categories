#!/usr/bin/env python3
"""Complete individual-product exclusion of the e=11, orthogonal-B branch.

Inputs are regenerated from the full dimension equation; no list of previously
surviving types is imported.  All source ranks at most sixteen are included.
The explicit kernel equations and exact unbounded dimension/trace semigroup
are only necessary conditions, so permitting extra zero-image duality choices
does not threaten the exclusion.
"""
from collections import Counter
from functools import lru_cache
from math import isqrt
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent

@lru_cache(None)
def square_tails(mass,count,lower=5):
    if count==0:return ((),) if mass==0 else ()
    if mass<count*lower*lower:return ()
    out=[]
    for d in range(lower,isqrt(mass//count)+1):
        out.extend((d,)+rest for rest in square_tails(mass-d*d,count-1,d))
    return tuple(out)

def descriptions():
    for rank in range(13,17):
        for p in range(5,34):
            for z in range(59):
                if (z-p)%2:continue
                x=((z+10+p)//2,(z+10-p)//2,(10-z+p)//2,(10-z-p)//2)
                if min(map(abs,x))<5:continue
                if z>=p+20:minimum=z+10;regime='z_large'
                elif p>=z+20:minimum=3*p+10;regime='p_large'
                else:
                    assert z==p
                    minimum=p+10;regime='equal'
                if minimum>97:continue
                for extra in square_tails(3386-z*z-3*p*p,rank-13):
                    yield {'rank':rank,'p':p,'z':z,'signed_dimensions':x,
                           'extras':extra,'minimum_scalar_remainder_mass':minimum,
                           'regime':regime}

def zero_tail_rows(target,dims):
    if not dims:
        if target==0:yield ()
        return
    d,*rest=dims
    for n in range(target//d+1):
        for row in zero_tail_rows(target-n*d,rest):yield (n,)+row

def product_rows(case,target):
    """Rows on [W,A1,A2,A3,A4,M,M*,D,E,F]."""
    x=case['signed_dimensions'];d=tuple(map(abs,x));s=tuple(1 if t>0 else -1 for t in x);p=case['p']
    for n1 in range(target//d[0]+1):
        for n2 in range((target-n1*d[0])//d[1]+1):
            f1=s[0]*n1;f2=s[1]*n2;k=f1-f2
            if k<0:continue
            n3=-s[2]*f2;n4=-s[3]*f1
            if min(n3,n4)<0:continue
            active=(n1,n2,n3,n4)
            mass=sum(a*b for a,b in zip(active,d))+2*p*k
            if mass>target:continue
            for zero in zero_tail_rows(target-mass,(case.get('w_dimension',40),)+tuple(case['extras'])):
                yield (zero[0],)+active+(k,k)+zero[1:]

def trace_semigroup(case,maximum):
    """At each dimension, all integral trace values as one signed bitset."""
    x=case['signed_dimensions'];p=case['p']
    generators=set((abs(a),1 if a>0 else -1) for a in x)
    generators|={(2*p,0),(case.get('w_dimension',40),0)}|{(d,0) for d in case['extras']}
    radius=maximum//min(abs(a) for a in x);mask=(1<<(2*radius+1))-1
    bits=[0]*(maximum+1);bits[0]=1<<radius
    for mass in range(1,maximum+1):
        b=0
        for d,s in generators:
            if d>mass:continue
            value=bits[mass-d]
            b|=value<<s if s>=0 else value>>(-s)
        bits[mass]=b&mask
    return bits,radius

def check_description(case):
    x=case['signed_dimensions'];p=case['p'];ex=case['extras']
    dims=(40,)+tuple(map(abs,x))+(p,p)+tuple(ex)
    # U=W is deliberately omitted: its products have known support on Y,Z.
    indices=list(range(1,5))+[5]+list(range(7,len(dims)))
    indices.sort(key=lambda j:(dims[j],j))
    bits,offset=trace_semigroup(case,max(dims[j]**2 for j in indices))
    stats=Counter();tested=[]
    for index in indices:
        dimension=dims[index];t=3 if index in range(1,5) else (4 if index==5 else 0)
        accepted=False;rows=0;norm_eligible=0;witness=None
        for row in product_rows(case,4*dimension):
            rows+=1;stats['coefficient_rows']+=1
            c=row[index]
            if c>3:continue
            norm=sum(a*a for a in row);a=norm-1-c
            if a<0:continue
            remainder_mass=dimension*dimension-13-23*a-12*c
            if remainder_mass<0:continue
            norm_eligible+=1;stats['norm_eligible_rows']+=1
            remainder_trace=t-2+2*a
            hit=offset+remainder_trace
            if hit>=0 and (bits[remainder_mass]>>hit)&1:
                accepted=True
                witness={'row':row,'a':a,'c':c,'remainder_mass':remainder_mass,'remainder_trace':remainder_trace}
                break
        tested.append({'index':index,'dimension':dimension,'t':t,'coefficient_rows':rows,
                       'norm_eligible_rows':norm_eligible,'necessary_row_exists':accepted,
                       'witness':witness})
        if not accepted:
            return {'excluded':True,'missing_index':index,'missing_dimension':dimension,
                    'tested':tested,'stats':dict(stats)}
    return {'excluded':False,'tested':tested,'stats':dict(stats)}

def main():
    records=[];counts=Counter();hist=Counter();stats=Counter()
    for case in descriptions():
        cert=check_description(case)
        assert cert['excluded'],case
        records.append({'input':case,'certificate':cert})
        counts[str(case['rank'])]+=1
        if case['rank']==16:hist[cert['missing_dimension']]+=1
        stats.update(cert['stats'])
    result={'scope':'e11 cubic dimension-four, W40 simple, pattern B, source ranks <=16',
            'rank_counts':dict(sorted(counts.items())),
            'all_excluded':True,'rank16_missing_dimension_histogram':dict(sorted(hist.items())),
            'statistics':dict(stats),'certificates':records}
    (HERE/'cubic_four_e11_B_certificates.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='certificates'},indent=2,sort_keys=True))

if __name__=='__main__':main()
