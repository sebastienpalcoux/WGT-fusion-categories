#!/usr/bin/env python3
"""Exact audit of dimension couplings and the final fourteen signatures."""
from collections import Counter
from fractions import Fraction
from itertools import combinations,product
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent

def hilbert(a,b,p):
    alpha=beta=0
    while a%p==0:a//=p;alpha+=1
    while b%p==0:b//=p;beta+=1
    if p==2:return (-1)**(((a-1)*(b-1)//4+alpha*(b*b-1)//8+beta*(a*a-1)//8)%2)
    def legendre(x):
        v=pow(x%p,(p-1)//2,p)
        return -1 if v==p-1 else v
    return (-1)**(alpha*beta*(p-1)//2)*legendre(a)**beta*legendre(b)**alpha

def main():
    data=json.loads((HERE/'orthogonal_six_catalogue.json').read_text())
    counts=Counter();signatures=set();final_states=Counter();e_checks=0
    for rec in data['states']:
        if not rec['positive']:continue
        g=rec['gram'];s=rec['traces'];dual=rec['duality'];name=rec['family']
        d=list(map(Fraction,rec['positive_witness']));n=len(d)
        sd=[i for i in range(n) if dual[i]==i]
        pairs=[i for i in range(n) if i<dual[i]]
        counts[name]+=1
        if name=='A':
            assert len(set(d[i] for i in sd))==1
        elif name=='B':
            i=sd[0]
            j=next(j for j in sd if j!=i and s[i]*s[j]*g[i][j]==-5)
            k,l=[h for h in sd if h not in (i,j)]
            assert s[k]*s[l]*g[k][l]==-5
            assert abs(s[i]*d[i]-s[j]*d[j])==d[pairs[0]]
            assert abs(s[k]*d[k]-s[l]*d[l])==d[pairs[0]]
        elif name=='D':
            i,j=[h for h in sd if s[h]];q=next(h for h in sd if not s[h]);p=pairs[0]
            assert s[i]*d[i]+s[j]*d[j]==2*s[p]*d[p]
            assert abs(s[i]*d[i]-s[j]*d[j])==2*d[q]
        else:
            assert name=='E'
            i=next(i for i in sd if s[i]);j=next(i for i in sd if not s[i]);p,q=pairs
            tau=s[i]//2;epsilon=s[p]
            assert s[p]==s[q] and d[p]==d[q]
            assert d[j]==abs(d[i]-2*epsilon*tau*d[p])
            if epsilon==tau:continue
            assert epsilon==-tau
            # Test every allowed dimension parameter directly in every
            # retained normalized frame, including the affine unit equation.
            for parameter in range(3,16 if tau==1 else 15):
                dims=[parameter]*n;dims[i]=2*parameter-tau;dims[j]=4*parameter-tau
                assert all(sum(g[a][b]*dims[b] for b in range(n))==0 for a in range(n))
                assert 2+sum(s[a]*dims[a] for a in range(n))==0
                assert 24*parameter*parameter-12*tau*parameter+84<=5400
                e_checks+=1
        final_states[name]+=1
        sig=[]
        for i,j in enumerate(dual):
            if i>j:continue
            sig.append((i==j,(g[i][i]+g[i][j])//2,(g[i][i]-g[i][j])//2,s[i]))
        signatures.add(tuple(sorted(sig)))
    assert counts==Counter(A=72,B=216,D=96,E=144)
    assert final_states==Counter(A=72,B=216,D=96,E=48)
    assert len(signatures)==14 and e_checks==600
    forms={}
    for name,delta,J in [('A',3,8),('B',6,2),('D',6,3),('E',3,4)]:
        ram=[p for p in (2,3) if hilbert(-delta,J,p)==-1]
        assert ram==([] if name=='E' else [2,3])
        forms[name]={'delta':delta,'presentation':[-delta,J],'finite_ramification':ram}
    result={'passed':True,'positive_states_checked':dict(counts),'unit_compatible_states':dict(final_states),
            'final_signed_signatures':sorted(signatures),'signature_count':14,
            'E_parameter_pairs':25,'E_frame_parameter_kernel_checks':e_checks,'rational_forms':forms}
    (HERE/'orthogonal_six_refinement_audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='final_signed_signatures'},indent=2,sort_keys=True))

if __name__=='__main__':main()
