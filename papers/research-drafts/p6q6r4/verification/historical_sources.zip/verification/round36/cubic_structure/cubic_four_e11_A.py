#!/usr/bin/env python3
"""Exhaustive dimension and reciprocity certificate for the e11 A branch."""
from collections import Counter
from math import isqrt
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent

def descriptions():
    for q in range(5,42):
        p=q+10
        for a in range(6,35,2):
            remainder=3486-3*a*a-2*p*p-2*q*q
            if remainder<98:continue
            for d in range(7,isqrt(remainder//2)+1,2):
                e=isqrt(remainder-d*d)
                if e<d or e%2==0 or d*d+e*e!=remainder:continue
                yield (a,p,q,d,e)

def allocations(case):
    a,p,q,d,e=case
    # P= h(A1+A2+A3)+(k+1)(M+M*)+k(N+N*)+wW+uD+vE.
    for k in range((97-2*p)//(2*(p+q))+1):
        for h in range((97-2*p-2*k*(p+q))//(3*a)+1):
            for w in range((97-2*p-2*k*(p+q)-3*a*h)//40+1):
                left=97-2*p-2*k*(p+q)-3*a*h-40*w
                for u in range(left//d+1):
                    if (left-u*d)%e:continue
                    v=(left-u*d)//e
                    yield (h,k,w,u,v)

def row_allocations(target,dims):
    if not dims:
        if target==0:yield ()
        return
    for x in range(target//dims[0]+1):
        for rest in row_allocations(target-x*dims[0],dims[1:]):yield (x,)+rest

def certificate(case,allocation):
    a,p,q,d,e=case;h,k,w,u,v=allocation
    # Reciprocity [XU:W]=[XW:U]=[P:U].
    for label,dimension,coefficient in [('A',a,h),('M',p,k+1),('N',q,k),('D',d,u),('E',e,v)]:
        if 40*coefficient>4*dimension:
            return {'reason':'forced_W_mass','label':label,'forced_mass':40*coefficient,'available_mass':4*dimension}
    # For XN, fix its W coefficient at k.  Every remaining zero-image row
    # has dimension in the semigroup <3a,p+q,d,e>.
    rows=list(row_allocations(4*q-40*k,(3*a,p+q,d,e)))
    if not rows:return {'reason':'missing_XN_dimension','target':4*q-40*k,'generators':(3*a,p+q,d,e)}
    # Any actual XA_i is selfdual, has W coefficient h, and zero matrix image.
    active_rows=list(row_allocations(4*a-40*h,(3*a,2*(p+q),d,e)))
    assert active_rows==[(0,0,3,1)],(case,allocation,active_rows)
    assert 9*a>4*d
    return {'reason':'reciprocity_overflow','XA_rows':active_rows,
            'forced_XD_mass':9*a,'available_XD_mass':4*d}

def main():
    records=[];counts=Counter()
    for case in descriptions():
        counts['dimension_descriptions']+=1
        aa=list(allocations(case))
        if aa:counts['descriptions_with_P97']+=1
        certs=[]
        for allocation in aa:
            counts['P97_allocations']+=1
            cert=certificate(case,allocation);counts[cert['reason']]+=1
            certs.append({'allocation':allocation,'certificate':cert})
        records.append({'dimensions':case,'allocations':certs})
    assert counts['dimension_descriptions']==74
    assert counts['descriptions_with_P97']==19 and counts['P97_allocations']==23
    assert counts['forced_W_mass']==15 and counts['missing_XN_dimension']==7 and counts['reciprocity_overflow']==1
    result={'scope':'e11 cubic dimension-four, W40 simple, pattern A, ranks <=16',
            'counts':dict(counts),'all_excluded':True,'certificates':records}
    (HERE/'cubic_four_e11_A_certificates.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='certificates'},indent=2,sort_keys=True))

if __name__=='__main__':main()
