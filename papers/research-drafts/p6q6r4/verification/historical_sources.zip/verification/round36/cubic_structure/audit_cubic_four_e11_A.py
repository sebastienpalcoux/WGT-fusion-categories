#!/usr/bin/env python3
"""Independent square-table and finite-set replay of the e11 A certificate."""
from collections import Counter
from itertools import combinations_with_replacement,product
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent

def all_coefficients(target,coins):
    out=[(0,())]
    for coin in coins:
        out=[(mass+n*coin,coeff+(n,)) for mass,coeff in out for n in range((target-mass)//coin+1)]
    return [coeff for mass,coeff in out if mass==target]

def main():
    data=json.loads((HERE/'cubic_four_e11_A_certificates.json').read_text())
    records={tuple(r['dimensions']):r for r in data['certificates']}
    pairs={}
    for d,e in combinations_with_replacement(range(7,59,2),2):pairs.setdefault(d*d+e*e,[]).append((d,e))
    regenerated=set()
    for a,q in product(range(6,35,2),range(5,42)):
        p=q+10
        for d,e in pairs.get(3486-3*a*a-2*p*p-2*q*q,[]):regenerated.add((a,p,q,d,e))
    assert regenerated==set(records)
    counts=Counter(dimension_descriptions=len(regenerated))
    for case in sorted(regenerated):
        a,p,q,d,e=case;r=records[case]
        # Independent bounded Cartesian allocation, with a different order.
        allocs=[]
        for w,h,k,u,v in product(range(3),range(97//(3*a)+1),range(97//(2*(p+q))+1),range(97//d+1),range(97//e+1)):
            if 40*w+3*a*h+2*p+2*(p+q)*k+d*u+e*v==97:allocs.append((h,k,w,u,v))
        assert set(allocs)=={tuple(x['allocation']) for x in r['allocations']}
        if allocs:counts['descriptions_with_P97']+=1
        counts['P97_allocations']+=len(allocs)
        certs={tuple(x['allocation']):x['certificate'] for x in r['allocations']}
        for al in allocs:
            h,k,w,u,v=al;cert=certs[al];reason=cert['reason'];counts[reason]+=1
            if reason=='forced_W_mass':
                assert any(10*n>dim for n,dim in ((h,a),(k+1,p),(k,q),(u,d),(v,e)))
            elif reason=='missing_XN_dimension':
                assert not all_coefficients(4*q-40*k,(d,e,p+q,3*a))
            else:
                assert reason=='reciprocity_overflow'
                rows=all_coefficients(4*a-40*h,(d,e,2*(p+q),3*a))
                assert rows==[(3,1,0,0)] and 3*3*a>4*d
    assert dict(counts)==data['counts']
    result={'passed':True,'independent_methods':['two-square table','Cartesian coefficient enumeration','finite semigroup coefficient sets'],
            'counts':dict(counts)}
    (HERE/'cubic_four_e11_A_independent_audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':main()
