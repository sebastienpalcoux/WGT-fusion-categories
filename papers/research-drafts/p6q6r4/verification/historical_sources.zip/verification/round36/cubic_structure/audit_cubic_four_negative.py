#!/usr/bin/env python3
"""Independent direct-row audit of every final negative-pattern certificate."""
from collections import Counter
from itertools import combinations_with_replacement,product
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent

def coefficients(target,coins):
    states=[(0,())]
    for d in coins:
        states=[(m+k*d,c+(k,)) for m,c in states for k in range((target-m)//d+1)]
    return [c for m,c in states if m==target]

def direct_rows(dims,signs,p,target,forced_W):
    # Unlike the producer's solved n1,n2 kernel, inspect all four active
    # coefficients and then check the three displayed linear equations.
    for n in product(*(range(target//d+1) for d in dims[1:5])):
        mass=sum(a*b for a,b in zip(n,dims[1:5]));f=tuple(a*b for a,b in zip(n,signs))
        k=f[0]-f[1]
        if k<0 or f[2]-f[3]!=k or sum(f):continue
        mass+=2*p*k+24*forced_W
        if mass>target:continue
        for tail in coefficients(target-mass,dims[7:]):
            yield (forced_W,)+n+(k,k)+tail

def remainder_states(dims,signs,p,maximum):
    gens=list(zip(dims[1:5],signs))+[(2*p,0),(24,0)]+[(d,0) for d in dims[7:]]
    states=[set() for _ in range(maximum+1)];states[0].add(0)
    for m in range(1,maximum+1):
        for d,s in gens:
            if d<=m:states[m].update(t+s for t in states[m-d])
    return states

def main():
    data=json.loads((HERE/'cubic_four_negative_certificates.json').read_text())
    # A: separate square lookup, followed by Cartesian coefficient checks.
    pair_table={}
    for d,e in combinations_with_replacement(range(3,69,2),2):pair_table.setdefault(d*d+e*e,[]).append((d,e))
    regenerated_A=set()
    for a,p in product(range(4,40,2),range(9,17)):
        q=p-6
        for d,e in pair_table.get(4662-3*a*a-2*p*p-2*q*q,[]):regenerated_A.add((a,p,q,d,e))
    frozen_A={tuple(r['dimensions']):r for r in data['A']['certificates']}
    assert regenerated_A==set(frozen_A)
    counts=Counter(dimension_types=len(regenerated_A))
    for case in sorted(regenerated_A):
        a,p,q,d,e=case;r=frozen_A[case]
        allocs=coefficients(33-2*p,(3*a,d,e))
        assert set(allocs)=={tuple(t['P_allocation']) for t in r['allocations']}
        counts['P33_allocations']+=len(allocs)
        for item in r['allocations']:
            cert=item['certificate'];reason=cert['reason'];counts[reason]+=1
            if reason=='missing_XN_dimension':assert not coefficients(4*q,(d,e,p+q,3*a))
            else:
                assert reason=='reciprocity_overflow'
                assert coefficients(4*q,(d,e,p+q,3*a))==[(4,0,0,0)]
                assert 8*q>4*d
    assert dict(counts)==data['A']['counts']
    # B: raw square inventories of every possible zero-image tail length.
    inventories={}
    for length in range(4):
        for ex in combinations_with_replacement(range(5,69),length):
            mass=sum(d*d for d in ex)
            if mass<=4626:inventories.setdefault(mass,[]).append(ex)
    regenerated_B=set()
    for p,z in product(range(5,14),range(19,28)):
        if z<p+14 or (p-z)%2:continue
        for ex in inventories.get(4626-z*z-3*p*p,[]):
            if z!=27 and 27-z not in ex:continue
            regenerated_B.add((p,z,ex))
    frozen_B={(r['input']['p'],r['input']['z'],tuple(r['input']['extras'])):r for r in data['B']['certificates']}
    assert regenerated_B==set(frozen_B)
    checked=0;hist=Counter()
    for key in sorted(regenerated_B):
        p,z,ex=key;rec=frozen_B[key];case=rec['input']
        x=((z+6+p)//2,(z+6-p)//2,(6-z+p)//2,(6-z-p)//2)
        assert list(x)==case['signed_dimensions']
        dims=(24,)+tuple(abs(a) for a in x)+(p,p)+ex;s=tuple(1 if a>0 else -1 for a in x)
        expected=[None] if z==27 else [7+j for j,d in enumerate(ex) if d==27-z]
        certs={r['P_residual_index']:r for r in rec['certificate']['allocations']}
        assert set(expected)==set(certs)
        for pos in expected:
            cert=certs[pos];i=cert['missing_index'];d=dims[i];t=3 if 1<=i<=4 else (4 if i==5 else 0)
            forced=int(i in (1,2) or i==pos)
            states=remainder_states(dims,s,p,d*d)
            for row in direct_rows(dims,s,p,4*d,forced):
                c=row[i]
                if c>3:continue
                a=sum(n*n for n in row)-1-2*c
                if a<0:continue
                mass=d*d-9-15*a-12*c
                if mass<0:continue
                assert t-2+2*a not in states[mass],(key,pos,i,row)
            checked+=1;hist[d]+=1
    assert dict(hist)=={int(k):v for k,v in data['B']['missing_dimension_histogram'].items()}
    result={'passed':True,'A_counts':dict(counts),'B_inputs':len(regenerated_B),'B_missing_row_certificates':checked,
            'B_missing_dimension_histogram':dict(sorted(hist.items())),
            'independent_methods':['raw square inventories','Cartesian scalar coefficients','four-variable direct matrix-kernel test','plain-set dimension-trace semigroups']}
    (HERE/'cubic_four_negative_independent_audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':main()
