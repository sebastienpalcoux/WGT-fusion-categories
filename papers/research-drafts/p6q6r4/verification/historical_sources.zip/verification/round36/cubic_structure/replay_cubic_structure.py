#!/usr/bin/env python3
"""Regenerate every local cubic/orthogonal result and run its independent audit.

The final e11-B audit lives in the sibling structural directory because the
same independently implemented engine also audits the pre-W40 reduction.
Run this script in the release's writable replay copy, as the main runner does.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
ENTRIES=(
    'orthogonal_six_catalogue.py',
    'audit_orthogonal_six.py',
    'audit_orthogonal_six_refinement.py',
    'cubic_four_e3.py','audit_cubic_four_e3.py',
    'cubic_four_e4.py','audit_cubic_four_e4.py',
    'cubic_four_negative.py','audit_cubic_four_negative.py',
    'cubic_four_e11_A.py','audit_cubic_four_e11_A.py',
    'cubic_four_e11_B.py',
)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--include-sibling-B-audit',action='store_true',help='Also run the independently implemented sibling structural B/pre-W audit; its pre-W producer must already have run.')
    args=ap.parse_args();records=[]
    entries=[HERE/name for name in ENTRIES]
    if args.include_sibling_B_audit:entries.append(HERE.parent/'structural'/'audit_cubic_four_B_and_pre_w.py')
    for entry in entries:
        start=time.monotonic()
        result=subprocess.run([sys.executable,str(entry)],cwd=entry.parent,text=True,capture_output=True)
        record={'script':str(entry.relative_to(HERE.parent)),
                'script_sha256':hashlib.sha256(entry.read_bytes()).hexdigest(),
                'returncode':result.returncode,'seconds':round(time.monotonic()-start,6)}
        records.append(record)
        if result.returncode:
            print(result.stdout);print(result.stderr,file=sys.stderr)
            raise SystemExit(result.returncode)
        print('PASS '+record['script'],flush=True)
    report={'status':'PASS','scope':'Complete local inputs regenerated; independent local audits checked; sibling B audit included only when requested.',
            'includes_sibling_B_audit':args.include_sibling_B_audit,'runs':records}
    (HERE/'cubic_structure_replay.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')

if __name__=='__main__':main()
