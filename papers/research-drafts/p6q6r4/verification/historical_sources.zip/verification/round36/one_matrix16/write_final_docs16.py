#!/usr/bin/env python3
"""Create final mathematical/report fragments only after complete scope audit."""
from pathlib import Path
import json
from finish_reduction16 import load_mode
from run_rows16 import source_digest
HERE=Path(__file__).resolve().parent

def n(x):return f'{x:,}'
def main():
 s=json.loads((HERE/'rank16_reduction_summary.json').read_text());coverage=json.loads((HERE/'rank16_completion_coverage_replay.json').read_text())
 assert s['status']=='PASS_COMPLETE_RANK16_NECESSARY_DATA_REDUCTION'and coverage['status']=='PASS_COMPLETE_CERTIFICATE_COVERAGE_AND_OPEN_SCOPE'
 for audit in coverage['mode_audits'].values():
  expected={'original':audit['replayed_exclusions']}if audit['replayed_exclusions']else{}
  assert audit['replay_kernels']==expected,'Final release claims require the preserved original checker.'
 E,audit=load_mode('E',HERE/'E_batches',True);assert len(E)==59761 and all(r['certificate']is not None for r in E.values())
 ebase=dict(orthogonal_f6_states=529475,structural_exclusions=223552,public_E_states=59761,public_E_exclusions=59761,remaining_orthogonal_f6=246162,A_states=62518,B_D_states=183644,proof_sha256=source_digest())
 (HERE/'orthogonal_six_E_completion.json').write_text(json.dumps(dict(status='PASS_COMPLETE_RANK16_SPLIT_SIX_EXCLUSION',**ebase),indent=2)+'\n')
 (HERE/'orthogonal_six_E_0_59761_replay.json').write_text(json.dumps(dict(status='PASS_COMPLETE_PUBLIC_E_ROW_REPLAY',scope_start=0,scope_stop=59761,certificate_records=59761,replayed_exclusions=audit['replayed_exclusions'],raw_rows_examined=audit['raw_rows_examined'],proof_sha256=source_digest(),batch_reports=audit['files']),indent=2)+'\n')
 tex=r'''\subsection{Complete exclusion of the public split branch of codegree six}
\label{r36:sec:one-matrix16-E}
The complete orthogonal trace input at matrix formal codegree six contains
$529475$ states. The integral commutator catalogue and positive Perron
kernel eliminate $52236$ states of skew squareclass one or two, $171261$
states of squareclass six with split rational algebra, and $55$ states
whose source self-dual budget cannot accommodate a catalogue pattern.
The remaining public split branch E has exactly $59761$ states.

By the Perron relations and parameter bound in
\ref{r36:orthogonal-six-perron-relations} and
\ref{r36:orthogonal-six-fp-parameters}, E has two source pairs of the same
dimension $p$, both with matrix trace $-\tau$, and two self-dual nonunit
labels of dimensions $2p-\tau$ and $4p-\tau$. Their matrix data are
\[
 (s,t,n)=(-\tau,4,0),\quad(2\tau,4,0),\quad(0,2,-1),
\]
respectively. All other nonunit matrix images vanish. The source-dimension
bound leaves precisely twenty-five pairs $(\tau,p)$: $3\le p\le15$ for
$\tau=1$, and $3\le p\le14$ for $\tau=-1$.

For every E state and every one of these twenty-five parameter pairs,
the certificate identifies at least one required signed source row which
is absent. Every such absence is freshly replayed with the preserved
original recursive row kernel. Testing only one row for the shared pair
category, and ignoring simultaneous compatibility of the three rows,
enlarges the feasible set; absence in this relaxation is therefore
sufficient. No E state remains OPEN. Consequently the
remaining orthogonal formal-codegree-six input is exactly
\[
 246162=62518\ ({\rm A})+183644\ ({\rm B/D}).
\]
Every remaining rational matrix algebra is the nonsplit quaternion algebra
$B_{2,3}$, with skew squareclass three in A and six in B/D. These are
necessary local input states; the computation does not construct their
fusion multiplication.
'''
 tex+=r'''
An independent, rank-independent exclusion of E is provided by
Theorem~\ref{r36:orthogonal-E-cone-exclusion}. That proof uses the positive
fusion cone and the global squared-dimension bound without assigning the
linear character fields. The complete signed-row replay above separately
checks all $59761$ selected rank-sixteen input states.
'''
 (HERE/'r36_one_matrix16_orthogonal_six_exclusion.tex').write_text(tex)
 phases=[('Primary source-row gates','symplectic_primary_exclusions'),('Small-pair tensor refinement','symplectic_small_pair_additional_exclusions'),('Norm-nine, ten and fifteen refinement','symplectic_tensor_additional_exclusions'),('Norm-eighteen, twenty-five and twenty-seven refinement','symplectic_higher_tensor_additional_exclusions'),('Formal-codegree-eight Perron refinement','symplectic_f8_perron_additional_exclusions'),('Previously proved cubic-support gate','cubic_support_additional_exclusions')]
 sop=sum(x['states']for x in s['remaining_by_codegree_and_kind']if x['kind']=='symplectic')
 tex=r'''\subsection{Completed symplectic scope and deduplicated residual input}
\label{r36:sec:one-matrix16-symplectic-completion}
Every one of the $67041$ symplectic full-field states receives a primary
source-row result. The subsequent scopes are selected from the complete
primary-OPEN list: every formal codegree for $b=3,4$; $f=36,40,60$ and
$f=72,100,108$ for $5\le b\le7$; and every primary-OPEN state with $f=8$.
All negative certificates are freshly checked by the original exact row
kernel. The following counts are additional exclusions after earlier rows
of the table, so overlaps are counted once.
\begin{center}\begin{tabular}{lr}
Gate & Additional exclusions\\\hline
'''
 for label,key in phases:tex+=label+' & $'+str(s[key])+r'$\\'+'\n'
 tex+=r'\end{tabular}\end{center}'+'\n'
 tex+=f'The residual symplectic input has ${sop}$ OPEN states. Together with\n$974802$ orthogonal OPEN states, the complete residual input has\n${s["remaining_OPEN_states"]}$ field-duality states.\n'
 tex+=r'''The old cubic-support test is applied to its exact twenty-seven input
states and is credited only when the state was not already excluded.
The new general cubic degree-four theorem is not automatically assigned
any additional numerical exclusion here.

An early OPEN result in a tensor refinement is a safe non-exclusion in the
chosen necessary relaxation. It can occur once a mass-bound pattern uses
only categories whose exact minimum row dimensions have already been
found: later searches cannot raise that particular bound above $5399$.
It is not a source type or a multiplication certificate. Every reported
negative exhausts all lower rows asserted absent, and the complete list
of remaining field-duality identifiers is exported and hash-bound.
'''
 (HERE/'r36_one_matrix16_symplectic_reduction.tex').write_text(tex)
 lines=['# Round36: rank sixteen with one degree-two block','','This package proves a complete reduction of the explicitly defined necessary full-field/duality input for the algebra `C^12 + M2(C)` at source dimension 5400 and canonical length 14. Source dimensions and canonical dimensions are distinct. No source-dimension divisibility by 5400 is assumed.','','## Exact input and outcome','','| Quantity | Count |','|---|---:|','| Weighted canonical profiles |470,747|','| Matrix placements |1,224,166|','| Full field assignments after preliminary gates |59,570,432|','| After integral column gates |34,321,026|','| After determinant squareclass |4,320,306|','| Final field-duality input |1,325,156|','| Orthogonal input |1,258,115|','| Symplectic input |67,041|',f'| Excluded by the recorded gates |{n(s["total_excluded_states"])}|',f'| Residual OPEN input |{n(s["remaining_OPEN_states"])}|','','The full conductor catalogue includes degrees 1,2,3,4,5,6,8. It is independently checked by enumerating index-e subgroups in the ORIGINAL conductor via G/G^e. Integral coordinate-column witnesses are checked exactly. Two real-quadratic support contradictions are recorded separately after the general trace forms. The general formal-codegree-six trace gate intentionally precedes the new commutator catalogue; no rank-fifteen special case silently removes the split squareclass-six branch.','','## Complete scopes','','All 67,041 symplectic states receive a primary result. Primary bounded and canonical-remainder queries use the complete source dimension domains needed by their remainder; its optional tensor-prefix gate uses dimensions through 30. Subsequent tensor/Perron refinements use the full finite dimension domain, with the safe early OPEN rule below. The selected secondary scopes are always taken from primary OPEN, not narrowed by earlier secondary results.','','| Secondary scope | Input records | Additional exclusions |','|---|---:|---:|']
 for mode,key in(('small_pairs','symplectic_small_pair_additional_exclusions'),('tensor','symplectic_tensor_additional_exclusions'),('higher_tensor','symplectic_higher_tensor_additional_exclusions'),('f8','symplectic_f8_perron_additional_exclusions')):
  lines.append(f'| {mode} | {n(s["additional_refinement_counts"][mode]["scope_records"])} | {n(s[key])} |')
 lines+=['','The small-pair scope is b=3,4 at all codegrees. The tensor scope is b=5,6,7 at f=36,40,60; the higher tensor scope uses f=72,100,108. The f8 Perron scope includes every primary-OPEN f8 state, including overlaps. The union is deduplicated by the original field-duality identifier. All 59,761 public E states are excluded after a complete 25-parameter signed-row check. Orthogonal A and B/D remain OPEN at this stage.','','A producer can stop OPEN when a necessary mass-bound pattern uses only categories whose exact minimum dimensions have already been found. Further searches cannot increase that particular lower bound above 5399. This is a safe non-exclusion in a relaxation. It supplies no fusion ring or category. A runtime budget, missing row implementation or unfinished search is never credited as an exclusion. Every negative is independently exhausted by the original row checker.','','## Portable replay','','Python 3.10 or later and its standard library suffice. Keep this module beside the bound `structural/` and `cubic_structure/` siblings in the Round36 package. Source files and payloads are authenticated before work begins; runtime copies are refreshed, and every output is placed under the chosen destination.','','```bash','python replay_release16.py --part all --output /tmp/r36-one-matrix16-replay','python replay_release16.py --part coverage --output /tmp/r36-one-matrix16-coverage','python replay_release16.py --part audits --output /tmp/r36-one-matrix16-audits','python replay_release16.py --part rows --scope-start 0 --scope-stop 500 --output /tmp/r36-one-matrix16-bounded','```','','The default row kernel is `original`. `--kernel fast` is an optional exact implementation whose residue join, per-option Cauchy restriction, trace filter and fixed-(s,t) filter have independent controls. Trace replay uses five bounded 100,000-profile subprocesses to avoid unbounded cache accumulation. Complete row replay uses each saved bounded batch. A bounded run has an explicitly bounded status and cannot claim full coverage.','','The optional refinement producer cache reuses exact pure-profile minima when every relevant category bound is unchanged, with a fixed maximum of 16,384 entries. Independent controls compare both masses and minimizing patterns with the uncached dynamic program, including actual query traces. Every negative certificate still receives the complete preserved original row replay. The core producer remains directly callable.','','## Files and evidence','','`RELEASE_FILES.txt` and `RELEASE_MANIFEST.json` select the current source closure and authoritative data. Exploratory traces, unsuccessful runs and logs are omitted. `rank16_trace_complete.jsonl.gz` is the single authoritative complete trace stream. The three derived input/exclusion streams are regenerated from it and their uncompressed hashes are compared with the actual frozen certificate inputs.','','Each producer record names its complete input hash. Every negative ledger names the certificate hash, proof-source digest, original state identifier and raw-row count. The complete coverage audit checks all primary IDs, every selected secondary ID, every E ID, all negative ledgers, all overlaps, and the exported OPEN list. The complete deliverable intentionally preserves OPEN states as necessary input data for further work.','','Imported historical helper modules retain their original module names. Only the new documented entrypoints are package CLIs; unused historical `main` routines are not replay dependencies. The mathematical proof files and external sibling bindings are listed separately.']
 (HERE/'README_one_matrix16.md').write_text('\n'.join(lines)+'\n')
 external='''This module is packaged as verification/round36/one_matrix16 beside structural/ and cubic_structure/.
The RELEASE_MANIFEST external_bindings bind exact sibling sources, catalogues, independent audit reports and mathematical TeX for:
- the integral symplectic commutator-Gram divisibility theorem and complete three-form slice catalogues;
- the complete orthogonal formal-codegree-six catalogue and signed positive-Perron dimension relations.
The one- and two-conductor-nine cubic support bounds are inherited from the authenticated Round35 proof, included in the full manuscript and immutable provenance/round35_release tree. This module only rechecks the exact 27 applicable new input IDs and their deduplicated contribution.
No dynamic external package, remote service, numerical optimizer, or unpublished local source is required by the row replay.
'''
 (HERE/'EXTERNAL_DEPENDENCIES.txt').write_text(external)
 print(json.dumps(dict(status='PASS_FINAL_DOCUMENTS_FROM_COMPLETE_COVERAGE',remaining_OPEN=s['remaining_OPEN_states'],remaining_symplectic_OPEN=sop),indent=2))
if __name__=='__main__':main()
