#!/usr/bin/env python3
"""Canonical coverage of every full-field duality state and derived scope."""
from collections import Counter
from pathlib import Path
import argparse,gzip,json,hashlib,time
from context16 import context
from post_trace_columns16 import finalize_case
from orthogonal_six_catalogue import profiles as orth_profiles

HERE=Path(__file__).resolve().parent

def canonical_dump(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
def digest(x):return hashlib.sha256(canonical_dump(x).encode()).hexdigest()
def write(out,x,h=None):
 text=json.dumps(x,separators=(',',':'))+'\n';out.write(text)
 if h:h.update(text.encode())

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--sources',type=Path,nargs='+',default=[HERE/'corrected_trace_0_235374.jsonl.gz',HERE/'corrected_trace_235374_470747.jsonl.gz']);ap.add_argument('--output',type=Path,default=HERE);args=ap.parse_args()
 outdir=args.output;outdir.mkdir(parents=True,exist_ok=True);start=time.monotonic()
 profiles=json.loads((HERE/'profiles16.json').read_text());expected=iter((i,a)for i,p in enumerate(profiles)for a,n in Counter(p).items()if n>=2)
 counts=Counter();types=Counter();f6=Counter();hashes={x:hashlib.sha256()for x in('trace','S','E','structural')};globalid=si=ei=0
 with gzip.open(outdir/'rank16_trace_complete.jsonl.gz','wt')as out,gzip.open(outdir/'rank16_symplectic_input.jsonl.gz','wt')as sout,gzip.open(outdir/'rank16_orthogonal_E_input.jsonl.gz','wt')as eout,gzip.open(outdir/'rank16_f6_structural_exclusions.jsonl.gz','wt')as xout:
  for source in args.sources:
   with gzip.open(source,'rt')as inp:
    for line in inp:
     case=finalize_case(json.loads(line));i,a=next(expected)
     counts['post_trace_column_exclusions']+=len(case.get('post_trace_column_exclusions',()))
     assert(case['index'],case['double_degree'])==(i,a)and case['profile']==profiles[i]
     write(out,case,hashes['trace']);counts['placements']+=1
     for key in('total_assignments','column_assignments','determinant_assignments','removed_nonfour_symplectic'):counts[key]+=case[key]
     counts['surviving_placements']+=not case['excluded'];counts['surviving_assignments']+=len(case['surviving_assignments'])
     for ai,assignment in enumerate(case['surviving_assignments']):
      for kind in assignment['duality_types']:
       f=5400//a;types[(f,kind)]+=1
       record=dict(state=globalid,index=i,profile=case['profile'],double_degree=a,assignment_index=ai,kind=kind,assignment=assignment)
       if kind=='symplectic':
        assert f%4==0
        write(sout,dict(record,scope_index=si),hashes['S']);si+=1
       elif f==6:
        ctx=context(assignment,a,kind,audit=True);delta,classes=ctx[2],ctx[3];reason=None;b=assignment['q']+1
        if delta in(1,2):reason='orthogonal_f6_squareclass_1_or_2'
        elif delta==6 and classes==((),):reason='orthogonal_f6_delta6_split'
        else:
         pp=list(orth_profiles(b,delta,classes))
         if not pp:reason='orthogonal_f6_selfdual_budget'
        if reason:
         write(xout,dict(state=globalid,index=i,double_degree=a,assignment_index=ai,kind=kind,certificate=dict(kind=reason,delta=delta,classes=classes,source_pairs=b)),hashes['structural']);f6[reason]+=1
        elif delta==3 and classes==((),):
         write(eout,dict(record,scope_index=ei),hashes['E']);ei+=1;f6['E']+=1
        elif delta==3 and classes==((2,3),):f6['A']+=1
        else:
         assert delta==6 and classes==((2,3),),(ctx,record)
         f6['B_D']+=1
       globalid+=1
     if counts['placements']%100000==0:print('covered',counts['placements'],'states',globalid,'S',si,'E',ei,'seconds',round(time.monotonic()-start,2),flush=True)
 assert next(expected,None)is None
 assert counts['placements']==1224166
 report=dict(status='PASS_COMPLETE_DERIVED_INPUT_COVERAGE',profiles=len(profiles),counts=dict(counts),field_duality_states=globalid,symplectic_states=si,orthogonal_E_states=ei,orthogonal_f6=dict(f6),by_codegree_and_kind=[dict(f=f,kind=k,states=n)for(f,k),n in sorted(types.items())],uncompressed_sha256={k:h.hexdigest()for k,h in hashes.items()},sources=[dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in args.sources],seconds=time.monotonic()-start)
 (outdir/'derived_input_coverage_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
