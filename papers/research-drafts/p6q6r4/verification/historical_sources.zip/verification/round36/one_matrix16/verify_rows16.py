#!/usr/bin/env python3
"""Fresh exact replay of every claimed row exclusion, with explicit coverage.

The default original kernel retains the pre-optimization recursive join.
The independently audited fast kernel is optionally available. Neither
kernel uses a numerical optimizer; every asserted absence is exhausted.
"""
from collections import Counter
from pathlib import Path
import resource
import argparse,json,gzip,time,hashlib
from run_rows16 import records,canonical_digest,source_digest
from row_engine16 import Engine,pure_profiles,categories,pure_mass,f8_perron_mass,E_parameters
from bounded_remainder import canonical_requirements,reachable
from orthogonal_six_catalogue import profiles as orth_profiles
HERE=Path(__file__).resolve().parent

def replay(record,rec,kernel='original'):
 cert=record['certificate'];assert cert is not None
 assert record['input_record_sha256']==canonical_digest(rec)
 assert all(record[k]==rec[k]for k in('state','scope_index','index','double_degree','assignment_index','kind'))
 e=Engine(rec,rec['assignment'],rec['kind'],kernel,record['level']);kind=cert['kind']
 requirements=set(canonical_requirements(rec['assignment'],rec['double_degree']))
 if kind=='bounded_canonical_remainder':
  R=cert['remainder'];assert any(r==R for r,a,m,sd in requirements)
  bound=cert['dimension_bound'];assert bound==min(R,72)
  ds=set(cert['eligible_dimensions']);assert all(type(d)is int and 3<=d<=bound for d in ds)
  assert not reachable(R,ds)
  for d in range(3,bound+1):
   if d not in ds:assert not e.exists(d,True)and not e.exists(d,False),(record['state'],d)
 elif kind=='source_dimension_density':
  bound=cert['dimension_bound'];minimum=cert['minimum_forced_dimension']
  assert minimum==bound+1 and cert['nonunit_count']==15 and not cert['eligible_dimensions']
  assert 15*minimum*minimum>5399
  for d in range(3,bound+1):assert not e.exists(d,True)and not e.exists(d,False),(record['state'],d)
 elif kind in('canonical_remainder_with_duality','central_canonical_atom'):
  R=cert['remainder'];a=cert['canonical_degree'];m=cert['multiplicity'];sd=cert['canonical_selfdual']
  assert(R,a,m,sd)in requirements and cert['regular_trace_minimum']==m
  bound=min(R,102 if sd else 72);assert cert['contribution_bound']==bound
  ds=set(cert['eligible_contributions']);assert all(type(c)is int and 3<=c<=bound for c in ds)
  if kind=='canonical_remainder_with_duality':
   assert not reachable(R,ds)
   for c in range(3,bound+1):
    if c not in ds:assert not e.coin(c,sd,m),(record['state'],c)
  else:
   minimum=cert['minimum_contribution'];assert ds and minimum==min(ds)and R<2*minimum
   for c in range(3,minimum):assert not e.coin(c,sd,m),(record['state'],c)
   assert not e.coin(R,sd,m,True),(record['state'],'central')
 elif kind=='orthogonal_six_E_forced_rows':
  assert e.kind=='orthogonal'and e.ctx[1:4]==(6,3,((),))
  witnesses=cert['parameter_witnesses'];assert[(x['tau'],x['p'])for x in witnesses]==list(E_parameters())
  assert len(witnesses)==25
  for x in witnesses:
   tau,p=x['tau'],x['p'];row=tuple(x['missing_row'])
   assert row in((False,p,-tau,4,0),(True,2*p-tau,2*tau,4,0),(True,4*p-tau,0,2,-1))
   sd,d,s,t,n=row;assert not e.exact_matrix_row(d,sd,s,t,n),(record['state'],tau,p,row)
 elif kind in('symplectic_pure_pattern_dimension_minimum','symplectic_f8_perron_mass','orthogonal_six_pattern_dimension_minimum'):
  lower={tuple(x['category']):x['minimum']for x in cert['lower_bounds']};assert len(lower)==len(cert['lower_bounds'])
  assert all(type(v)is int and 3<=v<=73 for v in lower.values())
  if kind=='orthogonal_six_pattern_dimension_minimum':
   assert e.kind=='orthogonal'and e.ctx[1]==6
   b=rec['assignment']['q']+1;pp=list(orth_profiles(b,e.ctx[2],e.ctx[3]));cats={cat for p in pp for cat in p}
   mass=min((sum(n*(1 if cat[0]else 2)*lower[cat]**2 for cat,n in p.items())for p in pp),default=10**18)
  else:
   assert e.kind=='symplectic';f=e.ctx[1];k=f//4;b=rec['assignment']['q']+3;cats=set(categories(k,b))
   if kind=='symplectic_pure_pattern_dimension_minimum':
    assert cert['formal_codegree']==f
    mass=pure_mass(k,b,lower)
   else:
    assert f==8
    mass=f8_perron_mass(b,lower)
  assert cert['source_pairs']==b and set(lower)==cats and mass==cert['mass_lower_bound']>5399
  for cat,low in lower.items():
   for d in range(3,low):assert not e.exists(d,cat[0],cat=cat),(record['state'],cat,d,low)
 else:raise AssertionError(('unknown certificate',kind))
 return e.raw

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--certificates',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--ledger',type=Path,required=True);p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,required=True);p.add_argument('--kernel',choices=('original','fast'),default='original');p.add_argument('--resume',action='store_true');args=p.parse_args()
 certs={};hist=Counter();start=time.monotonic();proof=source_digest();done=set();raw=0
 with args.certificates.open()as inp:
  for line in inp:
   r=json.loads(line);i=r['scope_index'];assert i not in certs;certs[i]=r;hist[r['certificate']['kind']if r['certificate']else'OPEN']+=1
 if args.resume and args.ledger.exists():
  for line in args.ledger.read_text().splitlines():
   x=json.loads(line);i=x['scope_index'];assert i not in done and x['status']=='PASS'and x['proof_sha256']==proof and x['certificate_sha256']==canonical_digest(certs[i]);done.add(i);raw+=x['raw_rows_examined']
 wanted={i for i,r in certs.items()if args.start<=i<args.stop and r['certificate']is not None};seen=set()
 with args.ledger.open('a'if args.resume else'w')as out:
  for rec in records(args.source):
   i=rec['scope_index']
   if i not in wanted:continue
   seen.add(i)
   if i in done:continue
   r=certs[i];n=replay(r,rec,args.kernel);raw+=n;done.add(i)
   x=dict(scope_index=i,state=rec['state'],status='PASS',proof_sha256=proof,certificate_sha256=canonical_digest(r),input_record_sha256=canonical_digest(rec),kernel=args.kernel,raw_rows_examined=n)
   out.write(json.dumps(x,separators=(',',':'))+'\n');out.flush()
   if len(done)%100==0:print('replayed',len(done),'last',i,'raw',raw,'seconds',round(time.monotonic()-start,2),flush=True)
 assert seen==wanted and done==wanted,(len(seen),len(wanted),len(done))
 assert proof==source_digest(),'Proof sources changed during replay.'
 report=dict(status='PASS_COMPLETE_SELECTED_ROW_EXCLUSION_REPLAY',certificate_records=len(certs),scope_start=args.start,scope_stop=args.stop,replayed_exclusions=len(done),histogram=dict(hist),raw_rows_examined=raw,kernel=args.kernel,proof_sha256=proof,certificates_sha256=hashlib.sha256(args.certificates.read_bytes()).hexdigest(),ledger_sha256=hashlib.sha256(args.ledger.read_bytes()).hexdigest(),maximum_resident_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,seconds=time.monotonic()-start)
 args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
