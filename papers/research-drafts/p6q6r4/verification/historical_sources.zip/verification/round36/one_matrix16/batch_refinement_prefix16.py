#!/usr/bin/env python3
"""One bounded secondary child at a time, with disjoint interval owners.

The selected IDs may describe an authenticated primary prefix or the
complete final primary-OPEN scopes. Empty intervals are skipped. All
claimed negatives use the unmodified original row checker.
"""
from pathlib import Path
from bisect import bisect_left
import argparse,json,subprocess,sys,time
from run_rows16 import records
HERE=Path(__file__).resolve().parent
MODES=('small_pairs','tensor','higher_tensor','f8')

def main():
 p=argparse.ArgumentParser();p.add_argument('--selected-dir',type=Path,required=True);p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,required=True);p.add_argument('--worker',type=int,default=0);p.add_argument('--workers',type=int,default=1);p.add_argument('--cached',action='store_true');args=p.parse_args()
 selected_dir=args.selected_dir.resolve();assert 0<=args.worker<args.workers
 assert args.start%500==0 and 0<=args.start<args.stop<=67041 and(args.stop%500==0 or args.stop==67041)
 selected={mode:set(json.loads((selected_dir/(mode+'_selected_state_ids.json')).read_text()))for mode in MODES}
 indices={mode:[]for mode in MODES};seen={mode:set()for mode in MODES}
 for r in records(HERE/'rank16_symplectic_input.jsonl.gz'):
  for mode in MODES:
   if r['state']in selected[mode]:indices[mode].append(r['scope_index']);seen[mode].add(r['state'])
 assert seen==selected
 started=time.monotonic();done=[]
 for j,start in enumerate(range(args.start,args.stop,500)):
  if j%args.workers!=args.worker:continue
  stop=min(start+500,args.stop)
  for mode in MODES:
   active=bisect_left(indices[mode],stop)-bisect_left(indices[mode],start)
   if not active:continue
   output=HERE/(mode+'_batches');output.mkdir(exist_ok=True)
   cmd=[sys.executable,HERE/'batch_rows16.py','--mode',mode,'--source',HERE/'rank16_symplectic_input.jsonl.gz','--count','67041','--range-start',str(start),'--range-stop',str(stop),'--batch-size','500','--worker','0','--workers','1','--output',output,'--selected',selected_dir/(mode+'_selected_state_ids.json'),'--refinement-runner','--max-dimension','72','--kernel','original']
   if args.cached:cmd+=['--refinement-cache']
   print('RUN',mode,start,stop,'selected',active,flush=True)
   with(output/f'driver_{start}_{stop}.log').open('w')as log:subprocess.run([str(x)for x in cmd],cwd=HERE,stdout=log,stderr=subprocess.STDOUT,check=True)
   report=json.loads((output/f'{mode}_{start}_{stop}.report.json').read_text());assert report['records']==active
   done.append(dict(mode=mode,start=start,stop=stop,records=active,histogram=report['histogram']))
   checkpoint=dict(status='COMPLETE_BOUNDED_SECONDARY_WORKER_PREFIX',worker=args.worker,workers=args.workers,scope_start=args.start,scope_stop=args.stop,source_count=67041,batches=done,seconds=time.monotonic()-started)
   (selected_dir/f'worker_{args.start}_{args.stop}_{args.worker}_checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
   print('DONE',mode,start,stop,report['histogram'],flush=True)
 print('WORKER_COMPLETE',args.worker,'bounded scope',args.start,args.stop,'seconds',round(time.monotonic()-started,2),flush=True)

if __name__=='__main__':main()
