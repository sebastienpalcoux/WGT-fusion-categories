#!/usr/bin/env python3
from collections import Counter
from functools import lru_cache
from itertools import product
from math import prod
from linear_field_lattice import field_lattice_failure,verify_field_lattice
from fractions import Fraction as Q
from pathlib import Path
import argparse,gzip,json,time,hashlib
import trace_signature16 as sig
from trace_rank16 import residue_pass,pair_modulus_pass,rational_counts,skew_diagonal_values

HERE=Path(__file__).resolve().parent

def analyze(profile,double,verify=True):
 empty=dict(excluded=True,total_assignments=0,column_assignments=0,determinant_assignments=0,surviving_assignments=[],removed_nonfour_symplectic=0)
 if double==10:return dict(empty,reason='rational central degree10')
 ok,why=residue_pass(profile,double)
 if not ok:return dict(empty,reason='rational residue',residue_obstruction=why)
 ok,why=pair_modulus_pass(profile,double,rational_counts(profile,double))
 if not ok:return dict(empty,reason='two-rational canonical modulus',modulus_obstruction=why)
 counts=Counter(profile);counts[double]-=2
 blocks=[(5400//a,k)for a,k in counts.items()if k];alts=[sig.decomposition_signatures(f,k)for f,k in blocks]
 total=prod(len(x)for x in alts);column=det=removed=0;kept=[];fE=5400//double
 alts=[tuple(x for x in xx if all(field_lattice_failure(f,label)is None for label in x[0][0]))for(f,k),xx in zip(blocks,alts)]
 columns={};perron=sig.signature((Q(1,5400),))
 for packed in product(*alts):
  assignment=tuple(x[0]for x in packed)
  rat=tuple(x[0].count('Q')for x in assignment)
  if rat not in columns:
   descriptions=[{'formal_codegree':f,'fields':list(x[0])}for(f,k),x in zip(blocks,assignment)]
   columns[rat]=residue_pass(profile,double,descriptions)[0]and pair_modulus_pass(profile,double,rational_counts(profile,double,descriptions))[0]
  if not columns[rat]:continue
  column+=1
  determinant=perron[1]
  for x in packed:determinant^=x[1][1]
  if determinant:continue
  det+=1;q6=sum(x[4]for x in assignment);q=sum(x[3][0]for x in packed)
  assert q<=5 and q6<=2
  whole=perron;plus=perron;minus=(0,0,0)
  for x in packed:whole=sig.add(whole,x[1]);plus=sig.add(plus,x[2]);minus=sig.add(minus,x[3])
  kinds=[kind for kind in('orthogonal','symplectic')if(sig.checked(assignment,whole,plus,minus,q,q6,fE,kind)if verify else sig.fast(whole,plus,minus,q,q6,fE,kind))]
  descriptions=None
  if q==2 and q6==1 and any(f==8 and 'quadratic_disc=-8'in x[0]for(f,k),x in zip(blocks,assignment)):
   if fE%2 or fE==6:kinds=[kind for kind in kinds if kind!='orthogonal']
  if 'symplectic'in kinds and fE%4:
   kinds.remove('symplectic');removed+=1
  if not kinds:continue
  descriptions=[{'formal_codegree':f,'fields':list(x[0])}for(f,k),x in zip(blocks,assignment)]
  item=dict(fields=descriptions,q6=q6,q=q,duality_types=kinds)
  if 'orthogonal'in kinds:
   delta=sig.SQUARECLASSES[sig.signature((Q(fE,2),))[1]^((q+1)%2)^minus[1]]
   item['orthogonal_delta']=delta;item['orthogonal_skew_diagonals']=list(skew_diagonal_values(delta,fE,q+1))
  kept.append(item)
 return dict(excluded=not kept,total_assignments=total,column_assignments=column,determinant_assignments=det,surviving_assignments=kept,removed_nonfour_symplectic=removed)

def main():
 p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=0);p.add_argument('--end',type=int,default=470747);p.add_argument('--output',type=Path,required=True);p.add_argument('--no-direct-audit',action='store_true');args=p.parse_args()
 start=time.monotonic();profiles=json.loads((HERE/'profiles16.json').read_text());counts=Counter();kindcounts=Counter();reasons=Counter();inv=Counter();codegrees=Counter();h=hashlib.sha256()
 with gzip.open(args.output,'wt')as out:
  for pi in range(args.start,args.end):
   profile=profiles[pi]
   for a,k in Counter(profile).items():
    if k<2:continue
    r=analyze(tuple(profile),a,not args.no_direct_audit);r.update(index=pi,profile=profile,double_degree=a)
    text=json.dumps(r,separators=(',',':'))+'\n';out.write(text);h.update(text.encode());counts['placements']+=1
    for key in('total_assignments','column_assignments','determinant_assignments','removed_nonfour_symplectic'):counts[key]+=r[key]
    counts['surviving_placements']+=not r['excluded'];counts['surviving_assignments']+=len(r['surviving_assignments'])
    if r['excluded']:reasons[r.get('reason','full-field/trace')]+=1
    for x in r['surviving_assignments']:
     for kind in x['duality_types']:kindcounts[kind]+=1;codegrees[(5400//a,kind)]+=1
   if pi%1000==0:print(pi,dict(counts),dict(kindcounts),'seconds',round(time.monotonic()-start,2),flush=True)
 report=dict(status='PASS_COMPLETE_FIELD_TRACE_SHARD',profile_start=args.start,profile_end=args.end,counts=dict(counts),duality_counts=dict(kindcounts),codegree_duality_counts=[dict(f=f,kind=k,states=n)for(f,k),n in sorted(codegrees.items())],reasons=dict(reasons),direct_form_audits=sig.CHECK_COUNTS,uncompressed_sha256=h.hexdigest(),seconds=time.monotonic()-start)
 args.output.with_suffix('.report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
