#!/usr/bin/env python3
"""Exact scope and exclusion-union audit. OPEN identities are fully exported."""
from pathlib import Path
from collections import Counter
import argparse,gzip,json,re,hashlib,time
from run_rows16 import records,canonical_digest,source_digest
HERE=Path(__file__).resolve().parent
MODES=('primary','E','small_pairs','tensor','higher_tensor','f8')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def gunzip_sha(p):
 h=hashlib.sha256()
 with gzip.open(p,'rb')as inp:
  for block in iter(lambda:inp.read(1<<20),b''):h.update(block)
 return h.hexdigest()

def load_mode(mode,directory,require_replay=True):
 certs={};proof=source_digest();hist=Counter();kernels=Counter();replayed=0;raw=0;files=[]
 pattern=re.compile(rf'{mode}_(\d+)_(\d+)\.jsonl$')
 for path in sorted(directory.glob(mode+'_*.jsonl')):
  match=pattern.fullmatch(path.name)
  if not match:continue
  start,stop=map(int,match.groups());local={};local_hist=Counter()
  for line in path.read_text().splitlines():
   r=json.loads(line);state=r['state'];assert state not in certs and start<=r['scope_index']<stop and r['mode']==mode
   assert r['scope_index']not in local
   local[r['scope_index']]=r;certs[state]=r;local_hist[r['certificate']['kind']if r['certificate']else'OPEN']+=1
  hist.update(local_hist)
  producer=path.with_suffix('.report.json');pr=json.loads(producer.read_text())
  assert pr['status']=='COMPLETE_SELECTED_SOURCE_ROW_PRODUCER'and pr['records']==len(local)and pr['proof_unchanged']
  assert(pr['mode'],pr['start'],pr['stop'])==(mode,start,stop)and pr['source_proof_sha256']==proof and pr['histogram']==dict(local_hist)
  if mode in('small_pairs','tensor','higher_tensor','f8'):assert pr['max_dimension']==72,'Secondary completion requires the full source-dimension domain.'
  if require_replay:
   ledger=path.with_name(path.stem+'_ledger.jsonl');rp=path.with_name(path.stem+'_replay.json');report=json.loads(rp.read_text())
   assert report['status']=='PASS_COMPLETE_SELECTED_ROW_EXCLUSION_REPLAY'and report['proof_sha256']==proof
   assert(report['scope_start'],report['scope_stop'],report['certificate_records'])==(start,stop,len(local))and report['histogram']==dict(local_hist)
   assert report['kernel']in('original','fast')
   assert report['certificates_sha256']==sha(path)and report['ledger_sha256']==sha(ledger)
   seen=set();local_raw=0
   for line in ledger.read_text().splitlines():
    x=json.loads(line);i=x['scope_index'];r=local[i]
    assert i not in seen and r['certificate']is not None and x['state']==r['state']and x['status']=='PASS'and x['proof_sha256']==proof
    assert x['certificate_sha256']==canonical_digest(r)and x['input_record_sha256']==r['input_record_sha256']and x['kernel']==report['kernel']
    seen.add(i);raw+=x['raw_rows_examined'];local_raw+=x['raw_rows_examined'];kernels[x['kernel']]+=1
   expected={i for i,r in local.items()if r['certificate']is not None};assert seen==expected
   assert report['replayed_exclusions']==len(expected)and report['raw_rows_examined']==local_raw
   replayed+=len(seen);files.extend([path,producer,ledger,rp])
  else:files.extend([path,producer])
 return certs,dict(status='PASS_COMPLETE_MODE_CERTIFICATE_AND_REPLAY_LEDGER_COVERAGE'if require_replay else'DIAGNOSTIC_CERTIFICATE_RECORDS_ONLY',mode=mode,records=len(certs),histogram=dict(hist),replayed_exclusions=replayed,replay_kernels=dict(kernels),raw_rows_examined=raw,files=[dict(file=str(p.relative_to(HERE)),sha256=sha(p))for p in files])

def selected_scopes(S,primary):
 opened={s for s,r in primary.items()if r['certificate']is None};out={k:set()for k in('small_pairs','tensor','higher_tensor','f8')}
 for state in opened:
  r=S[state];b=r['assignment']['q']+3;f=5400//r['double_degree']
  if b in(3,4):out['small_pairs'].add(state)
  if b in(5,6,7)and f in(36,40,60):out['tensor'].add(state)
  if b in(5,6,7)and f in(72,100,108):out['higher_tensor'].add(state)
  if f==8:out['f8'].add(state)
 return out

def validate_records(certs,inputs):
 assert set(certs)<=set(inputs)
 for s,r in certs.items():
  source=inputs[s];assert r['input_record_sha256']==canonical_digest(source)
  assert all(r[k]==source[k]for k in('state','scope_index','index','double_degree','assignment_index','kind'))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--output',type=Path,default=HERE);args=ap.parse_args();start=time.monotonic();outdir=args.output;outdir.mkdir(parents=True,exist_ok=True)
 S={r['state']:r for r in records(HERE/'rank16_symplectic_input.jsonl.gz')};E={r['state']:r for r in records(HERE/'rank16_orthogonal_E_input.jsonl.gz')}
 assert len(S)==67041 and len(E)==59761
 primary,pr=load_mode('primary',HERE/'primary_batches',True);assert set(primary)==set(S);validate_records(primary,S)
 scopes=selected_scopes(S,primary)
 for mode,ids in scopes.items():(outdir/(mode+'_selected_state_ids.json')).write_text(json.dumps(sorted(ids),separators=(',',':'))+'\n')
 if args.prepare:
  report=dict(status='PASS_COMPLETE_PRIMARY_AND_SELECTED_REFINEMENT_INPUTS',primary=pr,selected_scope_counts={k:len(v)for k,v in scopes.items()},seconds=time.monotonic()-start)
  (outdir/'primary_completion_and_refinement_scopes.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='primary'},indent=2));return
 allrecords={'primary':primary};audits={'primary':pr}
 for mode,expected in dict(E=set(E),**scopes).items():
  cc,audit=load_mode(mode,HERE/(mode+'_batches'),True);assert set(cc)==expected,(mode,len(cc),len(expected),len(set(cc)^expected));validate_records(cc,E if mode=='E'else S);allrecords[mode]=cc;audits[mode]=audit
 assert all(r['certificate']is not None for r in allrecords['E'].values())
 structural={r['state']:r for r in records(HERE/'rank16_f6_structural_exclusions.jsonl.gz')};assert len(structural)==223552
 closed=set(structural);counts=dict(initial_field_duality_states=1325156,orthogonal_f6_structural_exclusions=len(closed));stages={}
 for mode in('E','primary','small_pairs','tensor','higher_tensor','f8'):
  ids={s for s,r in allrecords[mode].items()if r['certificate']is not None};additional=ids-closed;closed|=ids;stages[mode]=dict(scope_records=len(allrecords[mode]),exclusions=len(ids),previously_excluded=len(ids)-len(additional),additional_exclusions=len(additional))
 name={'E':'orthogonal_f6_public_E_exclusions','primary':'symplectic_primary_exclusions','small_pairs':'symplectic_small_pair_additional_exclusions','tensor':'symplectic_tensor_additional_exclusions','higher_tensor':'symplectic_higher_tensor_additional_exclusions','f8':'symplectic_f8_perron_additional_exclusions'}
 counts.update({name[k]:v['additional_exclusions']for k,v in stages.items()})
 cubic=set();cubic_records=[]
 for state,r in S.items():
  b=r['assignment']['q']+3;n=sum(block['fields'].count('real_cubic_conductor9')for block in r['assignment']['fields']if block['formal_codegree']==9)
  if n and 15-2*b<4*n+1:
   assert n in(1,2);cubic.add(state);cubic_records.append(dict(state=state,source_pairs=b,cubic_orbits=n,selfdual_nonunits=15-2*b,required_selfdual_nonunits=4*n+1,already_excluded=state in closed))
 assert len(cubic)==27
 counts.update(cubic_support_applicable_exclusions=len(cubic),cubic_support_previously_excluded=len(cubic&closed),cubic_support_additional_exclusions=len(cubic-closed));closed|=cubic
 (outdir/'cubic_support_replay16.json').write_text(json.dumps(dict(status='PASS_COMPLETE_CUBIC_SUPPORT_SCOPE',records=cubic_records),indent=2)+'\n')
 by=Counter();placements=set();profiles=set();state=0;h=hashlib.sha256();orth_f6=Counter();fielddegrees=set();fields=set()
 with gzip.open(outdir/'rank16_open_state_ids.jsonl.gz','wt')as out,gzip.open(HERE/'rank16_trace_complete.jsonl.gz','rt')as inp:
  for line in inp:
   case=json.loads(line)
   for ai,a in enumerate(case['surviving_assignments']):
    for kind in a['duality_types']:
     if state not in closed:
      rec=dict(state=state,index=case['index'],double_degree=case['double_degree'],assignment_index=ai,kind=kind)
      text=json.dumps(rec,separators=(',',':'))+'\n';out.write(text);h.update(text.encode());f=5400//case['double_degree'];by[f,kind]+=1;placements.add((case['index'],case['double_degree']));profiles.add(case['index'])
      if kind=='orthogonal'and f==6:orth_f6[a['orthogonal_delta']]+=1
      for block in a['fields']:
       for label in block['fields']:fields.add((block['formal_codegree'],label))
     state+=1
 assert state==1325156 and sum(by.values())==state-len(closed)
 assert sum(v for(f,k),v in by.items()if k=='orthogonal')==974802
 assert orth_f6==Counter({3:62518,6:183644})
 counts.update(total_excluded_states=len(closed),remaining_OPEN_states=state-len(closed),primary_symplectic_counts=pr['histogram'],additional_refinement_counts=stages,remaining_by_codegree_and_kind=[dict(f=f,kind=k,states=n)for(f,k),n in sorted(by.items())],OPEN_state_identifiers_uncompressed_sha256=h.hexdigest())
 summary=dict(status='PASS_COMPLETE_RANK16_NECESSARY_DATA_REDUCTION',**counts)
 (outdir/'rank16_reduction_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 inventory=dict(status='PASS_COMPLETE_OPEN_INPUT_INVENTORY',rank=16,canonical_length=14,open_states=state-len(closed),orthogonal_states=974802,symplectic_states=sum(v for(f,k),v in by.items()if k=='symplectic'),canonical_profiles=len(profiles),matrix_placements=len(placements),orthogonal_f6_A=62518,orthogonal_f6_B_D=183644,linear_fields=[dict(formal_codegree=f,field=label)for f,label in sorted(fields)],scope='Necessary field-duality data only; no fusion ring or category is certified.')
 (outdir/'remaining_input_inventory16.json').write_text(json.dumps(inventory,indent=2)+'\n')
 coverage=dict(status='PASS_COMPLETE_CERTIFICATE_COVERAGE_AND_OPEN_SCOPE',mode_audits=audits,selected_scope_counts={k:len(v)for k,v in scopes.items()},structural_f6_exclusions=len(structural),union_exclusions=len(closed),OPEN_states=state-len(closed),OPEN_state_identifiers_uncompressed_sha256=h.hexdigest(),proof_sha256=source_digest(),seconds=time.monotonic()-start)
 (outdir/'rank16_completion_coverage_replay.json').write_text(json.dumps(coverage,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
