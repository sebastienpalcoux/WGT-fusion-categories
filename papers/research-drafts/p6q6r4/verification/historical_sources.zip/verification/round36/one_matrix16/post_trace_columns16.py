"""Exact residual real-quadratic support gate at source rank sixteen.

A full real quadratic orbit with discriminant equal to formal codegree
has a primitive integer difference column of norm two, orthogonal to the
Perron column. It is supported on two self-dual nonunit simples of equal
dimension. Distinct such columns have disjoint two-element supports.
"""
from quadratic_character_gate import real_obstruction

def finalize_case(case):
 kept=[];removed=[]
 for ai,assignment in enumerate(case['surviving_assignments']):
  kinds=[]
  for kind in assignment['duality_types']:
   cert=real_obstruction(assignment,kind)
   if cert:
    assert cert['kind']=='real_quadratic_norm_two_supports'
    assert 2*cert['orbit_count']>cert['selfdual_nonunits']
    removed.append(dict(assignment_index=ai,kind=kind,certificate=cert))
   else:kinds.append(kind)
  if kinds:
   a=dict(assignment);a['duality_types']=kinds;kept.append(a)
 result=dict(case);result['surviving_assignments']=kept;result['excluded']=not kept
 if removed:result['post_trace_column_exclusions']=removed
 return result
