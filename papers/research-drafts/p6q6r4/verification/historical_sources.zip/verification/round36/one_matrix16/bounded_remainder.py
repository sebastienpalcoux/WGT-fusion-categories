#!/usr/bin/env python3
"""Exact bounded-source canonical-remainder exclusions at rank fifteen.

This is both a producer and a replayable standard-library proof procedure.
A certificate for remainder R only inspects 3 <= d <= min(R,72): larger
positive source dimensions cannot occur in an object of dimension R.
Existence searches stop at the first admissible row for a dimension.  A
dimension declared absent is exhausted completely.  An open record is
expressly not an exclusion or a candidate fusion ring.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import argparse,json,time
from fixed_field_rows import fixed_blocks,fixed_rows
from matrix_spectral_filter import context
from norm_word_filter import determinant_options,norm_word_possible
from gap_filter import noncommutative_gap_possible
from power_trace_filter import power_trace_possible
from mixed_trace_filter import mixed_trace_possible
from linear_field_gate import obstruction as quadratic_skew_obstruction

HERE=Path(__file__).resolve().parent

def parity_index(assignment,pieces,kind):
    if kind!='orthogonal' or assignment['q6']!=1:return None
    if assignment['q']==1:pass
    elif assignment['q']==2:
        if not any(b['formal_codegree']==8 and 'quadratic_disc=-8'in b['fields']
                   for b in assignment['fields']):return None
    else:return None
    return next(i for i,p in enumerate(pieces)if p[2]=='complex6')

def reachable(R,dimensions):
    bits=1;mask=(1<<(R+1))-1
    for d in dimensions:
        for _ in range(R//d):bits|=(bits<<d)&mask
    return bool(bits>>R&1)

def row_allowed(pieces,mi,assignment,kind,ctx,parity,row,level=1):
    return _row_allowed(tuple(pieces),mi,kind,ctx,parity,row,level)

@lru_cache(maxsize=65536)
def _row_allowed(pieces,mi,kind,ctx,parity,row,level):
    sd,d,values=row
    if d+sum((2 if i==mi else 1)*s for i,(s,t)in enumerate(values))<0:return False
    if parity is not None and(values[mi][0]-values[parity][0])%2:return False
    # Includes tau(X^2), the local quaternion class, the integral skew
    # diagonal, and f | Trd([A,A*]^2)/2.
    if not determinant_options(pieces,d,values,sd,kind,ctx)[1]:return False
    if level==0:return True
    if not noncommutative_gap_possible(pieces,d,values,sd,kind):return False
    if not power_trace_possible(pieces,d,values,sd,kind,max_power=15,
                                higher_fields=(level>=2),matrix_context=ctx):return False
    if not mixed_trace_possible(pieces,d,values,sd,kind,bound=14,
                                matrix_context=ctx):return False
    if level>=2 and not norm_word_possible(pieces,d,values,sd,kind,bound=15,
                                         matrix_context=ctx):return False
    return True

def analyze(case,assignment,kind,level=1,first_only=False):
    structural=quadratic_skew_obstruction(assignment,kind)
    if structural:return dict(certificate=structural,tested_dimensions=[],raw_rows=0,queries=0)
    doubled=case['double_degree'];pieces,mi=fixed_blocks(assignment,doubled)
    ctx=context(assignment,doubled,kind);parity=parity_index(assignment,pieces,kind)
    counts=Counter(case['profile'])
    remainders=sorted({a-1 for a,k in counts.items()if k-2*(a==doubled)>0}|{doubled-2})
    if first_only:remainders=remainders[:1]
    eligible=[];tested=[];raw=0;queries=0
    for R in remainders:
        if reachable(R,eligible):continue
        for d in range(3,min(R,72)+1):
            if d in tested:continue
            queries+=1;exists=False
            for row in fixed_rows(pieces,mi,assignment['q6'],assignment['q'],kind,
                                  context=ctx,dimensions=(d,)):
                raw+=1
                if row_allowed(pieces,mi,assignment,kind,ctx,parity,row,level):
                    exists=True;break
            tested.append(d)
            if exists:eligible.append(d)
            if d==19 and not eligible:
                return dict(certificate={'kind':'source_dimension_density',
                            'dimension_bound':19,'eligible_dimensions':[],
                            'nonunit_count':15,'minimum_forced_dimension':20},
                            tested_dimensions=tested,raw_rows=raw,queries=queries)
            if reachable(R,eligible):break
        if not reachable(R,eligible):
            assert tested==list(range(3,min(R,72)+1))
            return dict(certificate={'kind':'bounded_canonical_remainder',
                        'remainder':R,'dimension_bound':min(R,72),
                        'eligible_dimensions':eligible},
                        tested_dimensions=tested,raw_rows=raw,queries=queries)
    return dict(certificate=None,tested_dimensions=tested,
                eligible_dimensions=eligible,raw_rows=raw,queries=queries)

def real_label(label):
    if label in('Q','real_cubic_conductor9'):return True
    if label=='Q(sqrt(-3))':return False
    if label.startswith('quadratic_disc='):return int(label.split('=')[1])>0
    cc,hh=label.split(':H=');c=int(cc[4:]);h=tuple(map(int,hh.split(',')))
    return c-1 in h

def canonical_requirements(assignment,doubled):
    # If a degree has both real and nonreal linear constituents, its real
    # constituent supplies the stronger self-dual requirement.
    req=[(doubled-2,doubled,2,True)]
    req.extend((5400//b['formal_codegree']-1,5400//b['formal_codegree'],1,
                any(real_label(label)for label in b['fields']))
               for b in assignment['fields'])
    return sorted(set(req))

def analyze_canonical(case,assignment,kind,level=1,first_only=False):
    structural=quadratic_skew_obstruction(assignment,kind)
    if structural:return dict(certificate=structural,raw_rows=0,queries=0)
    doubled=case['double_degree'];pieces,mi=fixed_blocks(assignment,doubled)
    ctx=context(assignment,doubled,kind);parity=parity_index(assignment,pieces,kind)
    requirements=canonical_requirements(assignment,doubled)
    if first_only:requirements=requirements[:1]
    source_cache={};contribution_cache={};raw=queries=0
    def source_eligible(d,sd,m,central=None):
        nonlocal raw,queries
        key=(d,sd,m,central)
        if key in source_cache:return source_cache[key]
        if d<3 or d>(72 if sd else 51):return False
        queries+=1
        for row in fixed_rows(pieces,mi,assignment['q6'],assignment['q'],kind,
                              context=ctx,dimensions=(d,),source_dualities=(sd,)):
            raw+=1
            regular=d+sum((2 if i==mi else 1)*s for i,(s,t)in enumerate(row[2]))
            if regular<m:continue
            s,t=row[2][mi]
            if central=='single'and(s%2 or 2*t!=s*s):continue
            if central=='pair_sum':
                if t%2 or t//2 not in determinant_options(pieces,d,row[2],sd,kind,ctx)[1]:continue
            if row_allowed(pieces,mi,assignment,kind,ctx,parity,row,level):
                for threshold in range(1,min(regular,2)+1):source_cache[(d,sd,threshold,central)]=True
                return True
        for threshold in range(m,3):source_cache[(d,sd,threshold,central)]=False
        return False
    def contribution_eligible(c,selfdual,m):
        key=(c,selfdual,m)
        if key not in contribution_cache:
            possible=source_eligible(c,True,m)
            if not possible:
                if selfdual:
                    possible=c%2==0 and source_eligible(c//2,False,m)
                else:possible=source_eligible(c,False,m)
            contribution_cache[key]=possible
        return contribution_cache[key]
    checked=[]
    for R,a,m,selfdual in requirements:
        eligible=[];bound=min(R,102 if selfdual else 72)
        for c in range(3,bound+1):
            if contribution_eligible(c,selfdual,m):eligible.append(c)
            if reachable(R,eligible):break
        checked.append({'canonical_degree':a,'multiplicity':m,
                        'canonical_selfdual':selfdual,'remainder':R,
                        'eligible_contributions':eligible})
        if not reachable(R,eligible):
            cert={'kind':'canonical_remainder_with_duality',
                  'canonical_degree':a,'multiplicity':m,
                  'canonical_selfdual':selfdual,'remainder':R,
                  'contribution_bound':bound,'regular_trace_minimum':m,
                  'eligible_contributions':eligible}
            return dict(certificate=cert,raw_rows=raw,queries=queries)
        if R<2*min(eligible):
            central=source_eligible(R,True,m,'single')
            if not central:
                if selfdual:
                    central=R%2==0 and source_eligible(R//2,False,m,'pair_sum')
                else:central=source_eligible(R,False,m,'single')
            if not central:
                cert={'kind':'central_canonical_atom',
                      'canonical_degree':a,'multiplicity':m,
                      'canonical_selfdual':selfdual,'remainder':R,
                      'contribution_bound':bound,'regular_trace_minimum':m,
                      'eligible_contributions':eligible,
                      'minimum_contribution':min(eligible)}
                return dict(certificate=cert,raw_rows=raw,queries=queries)
    return dict(certificate=None,checked_requirements=checked,
                raw_rows=raw,queries=queries)

def states(source):
    ordinal=0
    with source.open()as inp:
      for line in inp:
        case=json.loads(line)
        if case['excluded']:continue
        for ai,assignment in enumerate(case['surviving_assignments']):
          for kind in assignment['duality_types']:
            yield ordinal,case,ai,assignment,kind
            ordinal+=1

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--stop',type=int,default=125545)
    ap.add_argument('--source',type=Path,default=HERE/'rank15_trace_final.jsonl')
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--level',type=int,choices=(0,1,2),default=1)
    ap.add_argument('--selected',type=Path,
                    help='JSON list of state ordinals, for a later exact refinement')
    ap.add_argument('--first-only',action='store_true')
    ap.add_argument('--resume',action='store_true')
    ap.add_argument('--canonical-real',action='store_true')
    args=ap.parse_args();t0=time.monotonic();n=closed=raw=0
    selected=set(json.loads(args.selected.read_text()))if args.selected else None
    if args.resume and args.output.exists():
        previous=[json.loads(line)for line in args.output.read_text().splitlines()]
        assert [r['state']for r in previous]==list(range(args.start,args.start+len(previous)))
        assert all(r['level']==args.level and r['scope']==('first_remainder'if args.first_only else'all_remainders')for r in previous)
        args.start+=len(previous)
    with args.output.open('a'if args.resume else'w')as out:
      for ordinal,case,ai,assignment,kind in states(args.source):
        if ordinal<args.start:continue
        if ordinal>=args.stop:break
        if selected is not None and ordinal not in selected:continue
        began=time.monotonic()
        analyze_function=analyze_canonical if args.canonical_real else analyze
        ans=analyze_function(case,assignment,kind,args.level,args.first_only)
        ans.update(state=ordinal,index=case['index'],double_degree=case['double_degree'],
                   assignment_index=ai,kind=kind,level=args.level,
                   scope='first_remainder'if args.first_only else'all_remainders',
                   filter_version=3,canonical_real=args.canonical_real,
                   seconds=round(time.monotonic()-began,6))
        out.write(json.dumps(ans,separators=(',',':'))+'\n');out.flush()
        n+=1;closed+=ans['certificate']is not None;raw+=ans['raw_rows']
        if n%100==0:print('states',n,'excluded',closed,'open',n-closed,
                         'raw',raw,'state',ordinal,'seconds',round(time.monotonic()-t0,2),flush=True)
    print('FINAL states',n,'excluded',closed,'open',n-closed,'raw',raw,
          'seconds',round(time.monotonic()-t0,2),flush=True)

if __name__=='__main__':main()
