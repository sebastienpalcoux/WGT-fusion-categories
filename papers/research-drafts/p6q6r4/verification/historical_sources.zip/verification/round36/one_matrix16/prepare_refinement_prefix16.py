#!/usr/bin/env python3
"""Authenticate a completed primary prefix and select its secondary scopes.

This is explicitly a bounded preparation, never a complete rank16 result.
Every selected ID is already final for the prefix. Later full preparation
adds tail IDs; final coverage still checks exact equality with all scopes.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,tempfile
from finish_reduction16 import load_mode,selected_scopes,validate_records
from run_rows16 import records,source_digest
HERE=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--stop',type=int);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 directory=HERE/'primary_batches';pattern=re.compile(r'primary_(\d+)_(\d+)_replay\.json$');spans=[]
 for path in directory.glob('*_replay.json'):
  match=pattern.fullmatch(path.name)
  if match:
   start,stop=map(int,match.groups());spans.append((start,stop))
 end=0;chosen=[]
 for start,stop in sorted(spans):
  if start!=end:break
  if args.stop is not None and stop>args.stop:break
  chosen.append((start,stop));end=stop
 assert end>0 and(end%500==0 or end==67041)
 if args.stop is not None:assert end==args.stop,'Requested prefix is not completely replayed.'
 with tempfile.TemporaryDirectory(prefix='validated_primary_prefix_',dir=HERE)as temp:
  for start,stop in chosen:
   for suffix in('.jsonl','.report.json','_ledger.jsonl','_replay.json'):
    source=directory/f'primary_{start}_{stop}{suffix}';os.link(source,Path(temp)/source.name)
  primary,audit=load_mode('primary',Path(temp),True)
  audit['files']=[dict(file='primary_batches/'+Path(x['file']).name,sha256=x['sha256'])for x in audit['files']]
 S={}
 for r in records(HERE/'rank16_symplectic_input.jsonl.gz'):
  if r['scope_index']>=end:break
  assert r['scope_index']==len(S)
  S[r['state']]=r
 assert len(S)==end and set(primary)==set(S);validate_records(primary,S)
 scopes=selected_scopes(S,primary);dest=args.output;dest.mkdir(parents=True,exist_ok=True);hashes={}
 for mode,ids in scopes.items():
  path=dest/(mode+'_selected_state_ids.json');path.write_text(json.dumps(sorted(ids),separators=(',',':'))+'\n');hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
 report=dict(status='PASS_AUTHENTICATED_BOUNDED_PRIMARY_PREFIX_SELECTION',scope_start=0,scope_stop=end,full_source_count=67041,primary=audit,selected_scope_counts={k:len(v)for k,v in scopes.items()},selected_file_sha256=hashes,proof_sha256=source_digest(),source_input_sha256=hashlib.sha256((HERE/'rank16_symplectic_input.jsonl.gz').read_bytes()).hexdigest(),limitation='Bounded selection only. The final complete scope must still be derived from all67041 primary results and checked by finish_reduction16.py.')
 (dest/'prefix_scope_audit.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items()if k not in('primary','selected_file_sha256')},indent=2))

if __name__=='__main__':main()
