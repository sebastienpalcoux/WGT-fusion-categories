#!/usr/bin/env python3
"""Bounded subprocess batches with producer/replayer checkpoints.

Each child imports fresh caches. A completed batch is reused only after
its report and exact proof/input/certificate digests are authenticated.
This driver keeps one computational child active at a time.
"""
from pathlib import Path
import argparse,json,subprocess,sys,hashlib,time
HERE=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(cmd,log):
 print('RUN',' '.join(str(x)for x in cmd),flush=True)
 with log.open('w')as out:subprocess.run([str(x)for x in cmd],cwd=HERE,stdout=out,stderr=subprocess.STDOUT,check=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',required=True,choices=('primary','E','small_pairs','tensor','higher_tensor','f8'));p.add_argument('--source',type=Path,required=True);p.add_argument('--count',type=int,required=True);p.add_argument('--batch-size',type=int,default=500);p.add_argument('--range-start',type=int,default=0);p.add_argument('--range-stop',type=int);p.add_argument('--worker',type=int,default=0);p.add_argument('--workers',type=int,default=1);p.add_argument('--output',type=Path,required=True);p.add_argument('--kernel',choices=('original','fast'),default='original');p.add_argument('--selected',type=Path);p.add_argument('--produce-only',action='store_true');p.add_argument('--refinement-runner',action='store_true');p.add_argument('--refinement-cache',action='store_true');p.add_argument('--max-dimension',type=int,default=30);args=p.parse_args()
 assert not args.refinement_cache or args.refinement_runner
 args.source=args.source.resolve();args.output=args.output.resolve();args.output.mkdir(parents=True,exist_ok=True)
 if args.selected:args.selected=args.selected.resolve()
 started=time.monotonic();done=[]
 end=args.count if args.range_stop is None else min(args.count,args.range_stop)
 assert 0<=args.range_start<end<=args.count
 for j,start in enumerate(range(args.range_start,end,args.batch_size)):
  if j%args.workers!=args.worker:continue
  stop=min(start+args.batch_size,end);stem=f'{args.mode}_{start}_{stop}';cert=args.output/(stem+'.jsonl');prod=cert.with_suffix('.report.json');ledger=args.output/(stem+'_ledger.jsonl');rep=args.output/(stem+'_replay.json')
  if not prod.exists():
   script='run_refinement_cached16.py'if args.refinement_cache else'run_refinement16.py'if args.refinement_runner else'run_rows16.py'
   cmd=[sys.executable,HERE/script,'--source',args.source,'--output',cert,'--start',start,'--stop',stop,'--mode',args.mode,'--max-dimension',args.max_dimension]
   if args.selected:cmd+=['--selected',args.selected]
   if cert.exists():cmd+=['--resume']
   run(cmd,args.output/(stem+'_producer.log'))
  r=json.loads(prod.read_text());assert r['status']=='COMPLETE_SELECTED_SOURCE_ROW_PRODUCER'and r['start']==start and r['stop']==stop
  if not args.produce_only:
   if not rep.exists():
    cmd=[sys.executable,HERE/'verify_rows16.py','--source',args.source,'--certificates',cert,'--output',rep,'--ledger',ledger,'--start',start,'--stop',stop,'--kernel',args.kernel]
    if ledger.exists():cmd+=['--resume']
    run(cmd,args.output/(stem+'_replay.log'))
   rr=json.loads(rep.read_text());assert rr['status']=='PASS_COMPLETE_SELECTED_ROW_EXCLUSION_REPLAY'and rr['certificates_sha256']==sha(cert)and rr['ledger_sha256']==sha(ledger)
  done.append(dict(start=start,stop=stop,certificates=cert.name,records=r['records'],histogram=r['histogram'],producer=prod.name,replay=None if args.produce_only else rep.name))
  report=dict(status='COMPLETE_BOUNDED_WORKER_PREFIX',mode=args.mode,worker=args.worker,workers=args.workers,batch_size=args.batch_size,count=args.count,batches=done,seconds=time.monotonic()-started)
  (args.output/f'{args.mode}_{args.range_start}_{end}_worker{args.worker}_checkpoint.json').write_text(json.dumps(report,indent=2)+'\n')
  print('DONE',stem,r['histogram'],'seconds',round(time.monotonic()-started,2),flush=True)
 print('WORKER_COMPLETE',args.mode,args.worker,'batches',len(done),flush=True)
if __name__=='__main__':main()
