#!/usr/bin/env python3
"""Complete finite categorical-minimum refinements on primary-OPEN scopes.

This producer only proposes certificates. The preserved original row
checker independently replays every negative. Known matrix (s,t) values
are imposed before the optimized join; equality with manual restriction of
the original rows is separately audited. OPEN can stop once a profile's
mass bound uses only categories whose exact minima were already found.
Further searches cannot improve that particular bound above5399.
"""
from collections import Counter
from math import isqrt
from pathlib import Path
import argparse,hashlib,json,resource,time
from run_rows16 import records,canonical_digest,source_digest
from row_engine16 import Engine,categories,pure_profiles,pure_mass,f8_perron_mass,f8_pair_mass,f8_three_mass
HERE=Path(__file__).resolve().parent

def mass_witness(k,b,lower,perron=False):
 """An exact minimizing pattern for the existing lower-bound relaxation."""
 INF=10**18;best=INF;chosen=None;s=15-2*b
 if perron:
  assert k==2
  L=lower[True,1,0];Z=lower[True,0,0]
  for p in pure_profiles(2,b):
   base=sum(2*lower[False,0,g]**2 for g in p)
   if s>=3:
    cost=(s-3)*Z*Z+f8_three_mass(L)+base
    if cost<best:
     best=cost;chosen=Counter({(True,1,0):3});chosen.update({(True,0,0):s-3});chosen.update((False,0,g)for g in p)
   if s>=1:
    for j,g in enumerate(p):
     cost=(s-1)*Z*Z+f8_pair_mass(L,lower[False,1,g])+base-2*lower[False,0,g]**2
     if cost<best:
      best=cost;chosen=Counter({(True,1,0):1,(True,0,0):s-1,(False,1,g):1});chosen.update((False,0,gg)for i,gg in enumerate(p)if i!=j)
 else:
  budget=2*k-1
  for p in pure_profiles(k,b):
   dp={0:(0,())}
   for sd,g in [(True,0)]*s+[(False,g)for g in p]:
    weight=1 if sd else 2;new={}
    for h in range(isqrt(min(budget//weight,2*k-1-g))+1):
     cat=sd,h,g;cost=weight*lower[cat]**2;used=weight*h*h
     for old,(mass,pattern)in dp.items():
      if old+used<=budget and mass+cost<new.get(old+used,(INF,()))[0]:new[old+used]=(mass+cost,pattern+(cat,))
    dp=new
   mass,pattern=dp.get(budget,(INF,()))
   if mass<best:best=mass;chosen=Counter(pattern)
 return best,None if chosen is None else Counter({cat:n for cat,n in chosen.items()if n})

def compress_certificate(k,b,lower,perron=False):
 """Lower asserted bounds when the same exact contradiction still follows."""
 def mass(bounds):return f8_perron_mass(b,bounds)if perron else pure_mass(k,b,bounds)
 lower=dict(lower)
 for cat in sorted(lower,key=lambda x:(-lower[x],x)):
  hi=lower[cat];lo=3
  while lo<hi:
   middle=(lo+hi)//2;lower[cat]=middle
   if mass(lower)>5399:hi=middle
   else:lo=middle+1
  lower[cat]=lo
 assert mass(lower)>5399
 return lower,mass(lower)

def refine(e,perron=False,max_dimension=72):
 f=e.ctx[1];k=f//4;b=e.assignment['q']+3;cats=categories(k,b);lower={cat:3 for cat in cats};found=set();last=2
 while True:
  minimum,witness=mass_witness(k,b,lower,perron)
  if minimum>5399:
   lower,minimum=compress_certificate(k,b,lower,perron)
   cert=dict(kind='symplectic_f8_perron_mass'if perron else'symplectic_pure_pattern_dimension_minimum',source_pairs=b,lower_bounds=[dict(category=list(cat),minimum=low)for cat,low in sorted(lower.items())],mass_lower_bound=minimum)
   if not perron:cert['formal_codegree']=f
   return cert,dict(last_dimension=last,categories=len(cats),exact_minima_found=len(found),stop_reason='mass_contradiction')
  assert witness is not None
  unresolved=[cat for cat in witness if cat not in found]
  if not unresolved:
   return None,dict(last_dimension=last,categories=len(cats),exact_minima_found=len(found),stop_reason='found_category_mass_bound_stable',stable_mass_bound=minimum)
  # Resolve the least-advanced category occurring in the current minimizer.
  cat=min(unresolved,key=lambda x:(lower[x],-witness[x]*(1 if x[0]else 2),x));sd,h,g=cat;d=lower[cat];cap=72 if sd else 51
  if d>cap:
   lower[cat]=73;continue
  if d>max_dimension:
   return None,dict(last_dimension=last,categories=len(cats),exact_minima_found=len(found),stop_reason='explicit_bounded_prefix')
  last=max(last,d);t=2*(h*h+g);pairs=tuple(sorted({(-2*h,t),(2*h,t)}));e.queries+=1
  yes=next(e.rows(d,sd,tuple(sorted({-2*h,2*h})),pairs),None)
  if yes is None:lower[cat]=d+1
  else:found.add(cat)

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,required=True);p.add_argument('--mode',required=True,choices=('small_pairs','tensor','higher_tensor','f8'));p.add_argument('--selected',type=Path,required=True);p.add_argument('--max-dimension',type=int,default=72);p.add_argument('--resume',action='store_true');args=p.parse_args()
 selected=set(json.loads(args.selected.read_text()));done=set();counts=Counter();raw=0;start=time.monotonic();proof=source_digest()
 if args.resume and args.output.exists():
  for line in args.output.read_text().splitlines():
   r=json.loads(line);i=r['scope_index'];assert i not in done;done.add(i);counts[r['certificate']['kind']if r['certificate']else'OPEN']+=1;raw+=r['raw_rows']
 with args.output.open('a'if args.resume else'w')as out:
  for rec in records(args.source):
   i=rec['scope_index']
   if i<args.start:continue
   if i>=args.stop:break
   if i in done or rec['state']not in selected:continue
   begin=time.monotonic();e=Engine(rec,rec['assignment'],rec['kind'],'fast');f=e.ctx[1];b=rec['assignment']['q']+3
   assert rec['kind']=='symplectic'
   assert(args.mode=='small_pairs'and b in(3,4))or(args.mode=='tensor'and b in(5,6,7)and f in(36,40,60))or(args.mode=='higher_tensor'and b in(5,6,7)and f in(72,100,108))or(args.mode=='f8'and f==8)
   cert,details=refine(e,args.mode=='f8',args.max_dimension)
   ans={key:rec[key]for key in('state','scope_index','index','double_degree','assignment_index','kind')}
   ans.update(certificate=cert,mode=args.mode,level=e.level,raw_rows=e.raw,queries=e.queries,seconds=round(time.monotonic()-begin,6),input_record_sha256=canonical_digest(rec),refinement_search=details)
   out.write(json.dumps(ans,separators=(',',':'))+'\n');out.flush();done.add(i);counts[cert['kind']if cert else'OPEN']+=1;raw+=e.raw
   if len(done)%25==0:print('mode',args.mode,'done',len(done),'last',i,'hist',dict(counts),'raw',raw,'seconds',round(time.monotonic()-start,2),flush=True)
 report=dict(status='COMPLETE_SELECTED_SOURCE_ROW_PRODUCER',mode=args.mode,start=args.start,stop=args.stop,records=len(done),histogram=dict(counts),raw_rows=raw,kernel='fast',source_proof_sha256=proof,proof_unchanged=proof==source_digest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),maximum_resident_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,max_dimension=args.max_dimension,seconds=time.monotonic()-start)
 assert report['proof_unchanged'];args.output.with_suffix('.report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
