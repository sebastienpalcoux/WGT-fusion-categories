"""Exact fast rational-form signatures with independently checked direct forms.

Positive rational forms are classified by dimension, determinant squareclass
and finite Hasse invariants. All actual field signatures have support 2,3,5.
Orthogonal direct sums use epsilon(A+B)=epsilon(A)epsilon(B)(det A,det B).
"""
from fractions import Fraction as Q
from functools import lru_cache
from math import prod,gcd
import generic_fields as fields
import r32_trace_forms as forms
from trace_rank16 import trace_pass,orthogonal_forms,square_sum_possible

PRIMES=(2,3,5)
SQUARECLASSES=(1,2,3,6,5,10,15,30)
INDEX={v:i for i,v in enumerate(SQUARECLASSES)}
HILBERT=tuple(tuple(sum((forms.hilbert(a,b,p)==-1)<<j for j,p in enumerate(PRIMES))for b in SQUARECLASSES)for a in SQUARECLASSES)

@lru_cache(None)
def signature(diagonal):
 n,d,bad=forms.invariants(diagonal)
 assert d in INDEX and set(bad)<=set(PRIMES),(diagonal,n,d,bad)
 return n,INDEX[d],sum((p in bad)<<j for j,p in enumerate(PRIMES))

@lru_cache(maxsize=65536)
def add(a,b):
 n,d,e=a; nn,dd,ee=b
 return n+nn,d^dd,e^ee^HILBERT[d][dd]

@lru_cache(None)
def decomposition_signatures(f,k):
 return tuple((x,signature(x[1]),signature(x[2]),signature(x[3]))for x in fields.decompositions(f,k))

@lru_cache(None)
def orth_fast(whole,minus,q,f):
 b=q+1;missing=(1,(b%2)^minus[1],0)
 if add(minus,missing)!=signature((Q(2),)*b):return False
 delta=SQUARECLASSES[signature((Q(f,2),))[1]^missing[1]]
 if f%delta or not square_sum_possible(f//delta,b):return False
 return any(add(whole,signature(diag))==(16,0,0)for diag in orthogonal_forms(delta,f))

@lru_cache(None)
def fast(whole,plus,minus,q,q6,f,kind):
 if kind=='orthogonal':
  if q>5 or q+1<2*q6:return False
  if q==q6==1 and(f%2 or f==6):return False
  return orth_fast(whole,minus,q,f)
 if q>4 or q+3<2*q6:return False
 if q==q6:
  if q==2:return False
  if q==0 and f not in(36,100):return False
  if q==1 and f not in(8,72):return False
 b=q+3
 if add(plus,signature((Q(2,f),)))!=signature((Q(1),)*(16-2*b)+(Q(2),)*b):return False
 return any(all(f%p==0 for p in ram) and add(whole,signature(tuple(Q(2*a,f)for a in diag)))==(16,0,0)for ram,diag in(((2,),(1,1,1,1)),((3,),(1,1,3,3)),((5,),(1,2,5,10)),((2,3,5),(1,3,10,30))))

CHECKED={};CHECK_COUNTS={}
def checked(assignment,whole,plus,minus,q,q6,f,kind):
 key=(whole,plus,minus,q,q6,f,kind)
 result=fast(*key)
 if key not in CHECKED:
  rawwhole=(Q(1,5400),)+tuple(a for x in assignment for a in x[1])
  rawplus=(Q(1,5400),)+tuple(a for x in assignment for a in x[2])
  rawminus=tuple(a for x in assignment for a in x[3])
  assert signature(rawwhole)==whole and signature(rawplus)==plus and signature(rawminus)==minus
  expected=trace_pass(rawwhole,rawplus,rawminus,q,q6,f,kind)
  assert result==expected,(key,rawwhole,rawplus,rawminus,result,expected)
  CHECKED[key]=result;CHECK_COUNTS[kind]=CHECK_COUNTS.get(kind,0)+1
 return result
