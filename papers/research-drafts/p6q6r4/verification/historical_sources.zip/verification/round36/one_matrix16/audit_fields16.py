#!/usr/bin/env python3
"""Independent full-conductor field completeness and lattice-witness audit.

An index-e subgroup contains all e-th powers. Enumerate subgroups in the
finite quotient G/G^e; lift to the ORIGINAL conductor, not a reduced one.
Compare the complete set to the producer's listed fields after lifting.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
from math import gcd
import json,time,hashlib
from generic_fields import fields
from field_discriminant_profiles import kronecker
from linear_field_lattice import field_lattice_failure,verify_field_lattice
from r32_trace_forms import phi
HERE=Path(__file__).resolve().parent

@lru_cache(None)
def index_subgroups(c,e):
 units=tuple(a for a in range(c)if gcd(a,c)==1);power=frozenset(pow(a,e,c)for a in units)
 if len(units)%e:return frozenset()
 cosets={};reps=[]
 for a in units:
  if a in cosets:continue
  i=len(reps);reps.append(a)
  for b in power:cosets[a*b%c]=i
 n=len(reps);target=n//e
 if n%e:return frozenset()
 table=tuple(tuple(cosets[a*b%c]for b in reps)for a in reps)
 identity=cosets[1];initial=frozenset((identity,));seen={initial};queue=[initial];answer=set()
 for h in queue:
  if len(h)==target:
   answer.add(frozenset(a for a in units if cosets[a]in h));continue
  if len(h)>target or target%len(h):continue
  for a in range(n):
   if a in h:continue
   gen=set(h);p=a
   while p not in h:
    gen.update(table[p][b]for b in h);p=table[p][a]
   hh=frozenset(gen)
   if len(hh)<=target and target%len(hh)==0 and hh not in seen:seen.add(hh);queue.append(hh)
 return frozenset(answer)

def lift(c,label):
 units=tuple(a for a in range(c)if gcd(a,c)==1)
 if label=='Q':return frozenset(units)
 if label=='Q(sqrt(-3))':label='quadratic_disc=-3'
 if label.startswith('quadratic_disc='):
  D=int(label.split('=')[1]);return frozenset(a for a in units if kronecker(D,a)==1)
 if label=='real_cubic_conductor9':cc=9;h={1,8}
 else:
  x,y=label.split(':H=');cc=int(x[4:]);h=set(map(int,y.split(',')))
 assert c%cc==0,(c,label)
 return frozenset(a for a in units if a%cc in h)

def main():
 start=time.monotonic();inventory=json.loads((HERE/'raw_field_inventory16.json').read_text());checked=0;records=[];failures={};degrees=set()
 for block in inventory:
  f,k=block['f'],block['k'];c=gcd(2*f,f*f);source=fields(f,k)
  actual={lift(c,x[0])for x in source};assert len(actual)==len(source)
  if f==6:
   assert{x[0]for x in source}=={'Q','Q(sqrt(-3))'}
  else:
   expected=set()
   for e in range(1,k+1):
    if e==1 and f==540:continue
    expected.update(index_subgroups(c,e))
   assert actual==expected,(f,k,len(actual),len(expected),actual-expected,expected-actual)
   checked+=1
  for x in source:
   label=x[0];degrees.add(len(x[1]));cert=field_lattice_failure(f,label)
   if cert:
    assert verify_field_lattice({'fields':[{'formal_codegree':f,'fields':[label]}]},cert)
    failures[f,label]=cert
  records.append(dict(f=f,k=k,conductor=c,fields=len(source),full_conductor_quotient_checked=f!=6))
 report=dict(status='PASS_COMPLETE_FULL_CONDUCTOR_FIELDS_AND_COLUMN_WITNESSES',inventory_blocks=len(inventory),full_conductor_blocks_checked=checked,field_degrees=sorted(degrees),column_failure_witnesses=[failures[key]for key in sorted(failures)],field_blocks=records,seconds=time.monotonic()-start)
 (HERE/'complete_field_catalogue_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in('field_blocks','column_failure_witnesses')},indent=2),flush=True)
if __name__=='__main__':main()
