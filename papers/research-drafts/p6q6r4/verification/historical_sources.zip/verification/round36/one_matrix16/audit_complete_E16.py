#!/usr/bin/env python3
"""Independent streamed coverage audit of the complete rank-sixteen E replay.

This does not replace the mathematical negative-row checker. It binds every
actual input to its 25-parameter certificate and completed original-kernel
ledger, and checks the full disjoint batch partition without importing any
producer, row engine, or final-union implementation.
"""
from collections import Counter
from hashlib import sha256
from math import isqrt
from pathlib import Path
import ast
import gzip
import json
import re

HERE = Path(__file__).resolve().parent
COUNT = 59761


def digest(path):
    h = sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return sha256(json.dumps(value,sort_keys=True,
                            separators=(',',':')).encode()).hexdigest()


def proof_binding():
    tree = ast.parse((HERE/'run_rows16.py').read_text())
    assignments = [node for node in tree.body if isinstance(node,ast.Assign)
                   and any(isinstance(t,ast.Name) and t.id=='PROOF_FILES'
                           for t in node.targets)]
    assert len(assignments)==1
    names = ast.literal_eval(assignments[0].value)
    assert isinstance(names,tuple) and len(names)==len(set(names))
    h = sha256()
    for name in sorted(names):
        assert isinstance(name,str) and Path(name).name==name
        h.update(name.encode()+b'\0'+(HERE/name).read_bytes()+b'\0')
    h.update((HERE/'symplectic_profiles.json').read_bytes())
    return h.hexdigest(),list(names)


def main():
    proof,names = proof_binding()
    parameters = [(tau,p) for tau in (-1,1)
                  for p in range(3,isqrt(5400)+1)
                  if 1+(2*p-tau)**2+(4*p-tau)**2+4*p*p+9*9<=5400]
    assert len(parameters)==25
    source = HERE/'rank16_orthogonal_E_input.jsonl.gz'
    expected = []
    source_hash = sha256()
    pair_counts = Counter()
    previous_state = -1
    metadata = ('state','scope_index','index','double_degree',
                'assignment_index','kind')
    with gzip.open(source,'rb') as stream:
        for line in stream:
            source_hash.update(line)
            record = json.loads(line)
            assert record['scope_index']==len(expected)
            assert record['state']>previous_state
            assert record['kind']=='orthogonal' and record['double_degree']==900
            assignment = record['assignment']
            assert assignment['orthogonal_delta']==3
            b = assignment['q']+1
            assert 2<=b<=6
            pair_counts[b]+=1
            expected.append((canonical(record),
                             {key:record[key] for key in metadata}))
            previous_state = record['state']
    assert len(expected)==COUNT
    derived = json.loads((HERE/'derived_input_coverage_audit.json').read_text())
    assert derived['orthogonal_E_states']==COUNT
    assert derived['uncompressed_sha256']['E']==source_hash.hexdigest()

    folder = HERE/'E_batches'
    pattern = re.compile(r'E_(\d+)_(\d+)\.jsonl$')
    found = {}
    for path in folder.glob('E_*.jsonl'):
        match = pattern.fullmatch(path.name)
        if match:
            interval = tuple(map(int,match.groups()))
            assert interval not in found
            found[interval] = path
    intervals = [(0,500)]+[(start,min(start+2000,COUNT))
                           for start in range(500,COUNT,2000)]
    assert set(found)==set(intervals)
    assert len(intervals)==31
    total = raw = producer_raw = 0
    missing_types = Counter()
    parameter_types = Counter()
    batches = []
    previous_stop = 0
    for begin,end in intervals:
        assert begin==previous_stop
        previous_stop=end
        path = found[begin,end]
        records = {}
        for line in path.read_text().splitlines():
            record = json.loads(line)
            i = record['scope_index']
            assert begin<=i<end and i not in records
            actual_hash,actual_metadata = expected[i]
            assert record['input_record_sha256']==actual_hash
            assert all(record[key]==actual_metadata[key] for key in metadata)
            assert record['mode']=='E' and record['level']==1
            cert = record['certificate']
            assert cert is not None and cert['kind']=='orthogonal_six_E_forced_rows'
            witnesses = cert['parameter_witnesses']
            assert [(x['tau'],x['p']) for x in witnesses]==parameters
            for witness in witnesses:
                tau,p=witness['tau'],witness['p']
                row=tuple(witness['missing_row'])
                assert type(row[0]) is bool and all(type(x) is int for x in row[1:])
                forced=((False,p,-tau,4,0),
                        (True,2*p-tau,2*tau,4,0),
                        (True,4*p-tau,0,2,-1))
                assert row in forced
                index=forced.index(row)
                missing_types[index]+=1
                parameter_types[tau,p,index]+=1
            records[i]=record
            producer_raw+=record['raw_rows']
        assert set(records)==set(range(begin,end))
        producer=path.with_suffix('.report.json')
        ledger=path.with_name(path.stem+'_ledger.jsonl')
        replay=path.with_name(path.stem+'_replay.json')
        pr=json.loads(producer.read_text())
        rr=json.loads(replay.read_text())
        histogram={'orthogonal_six_E_forced_rows':end-begin}
        assert pr['status']=='COMPLETE_SELECTED_SOURCE_ROW_PRODUCER'
        assert (pr['mode'],pr['start'],pr['stop'],pr['records'])==('E',begin,end,end-begin)
        assert pr['source_proof_sha256']==proof and pr['proof_unchanged']
        assert pr['histogram']==histogram
        assert pr['raw_rows']==sum(r['raw_rows'] for r in records.values())
        assert rr['status']=='PASS_COMPLETE_SELECTED_ROW_EXCLUSION_REPLAY'
        assert rr['kernel']=='original' and rr['proof_sha256']==proof
        assert (rr['scope_start'],rr['scope_stop'],rr['certificate_records'])==(begin,end,end-begin)
        assert rr['replayed_exclusions']==end-begin and rr['histogram']==histogram
        assert rr['certificates_sha256']==digest(path)
        assert rr['ledger_sha256']==digest(ledger)
        seen=set()
        local_raw=0
        for line in ledger.read_text().splitlines():
            entry=json.loads(line)
            i=entry['scope_index']
            assert i in records and i not in seen
            record=records[i]
            assert entry['status']=='PASS' and entry['kernel']=='original'
            assert entry['state']==record['state'] and entry['proof_sha256']==proof
            assert entry['certificate_sha256']==canonical(record)
            assert entry['input_record_sha256']==expected[i][0]
            assert type(entry['raw_rows_examined']) is int and entry['raw_rows_examined']>=0
            seen.add(i)
            local_raw+=entry['raw_rows_examined']
        assert seen==set(records) and local_raw==rr['raw_rows_examined']
        total+=len(seen)
        raw+=local_raw
        batches.append(dict(start=begin,stop=end,records=len(seen),
                            original_raw_rows=local_raw,
                            files=[dict(file=p.relative_to(HERE).as_posix(),sha256=digest(p))
                                   for p in (path,producer,ledger,replay)]))
    assert previous_stop==total==COUNT
    assert sum(missing_types.values())==25*COUNT
    assert proof==proof_binding()[0]
    result=dict(
        status='PASS_COMPLETE_ORTHOGONAL_E_INPUT_AND_LEDGER_COVERAGE',
        scope='All actual rank-sixteen split-orthogonal f=6 E inputs and their complete 25-parameter signed-row certificates; authentication of completed original-kernel mathematical replays.',
        input_records=COUNT,certificate_records=total,replayed_exclusions=total,
        OPEN_records=0,disjoint_complete_batches=len(batches),
        signed_parameters_per_record=25,parameter_witnesses=25*COUNT,
        proof_sha256=proof,proof_files=names,
        input_gzip_sha256=digest(source),
        input_uncompressed_sha256=source_hash.hexdigest(),
        source_pair_histogram=dict(sorted(pair_counts.items())),
        required_row_witness_histogram={name:missing_types[i] for i,name in enumerate(
            ('common_pair','selfdual_trace_2tau','selfdual_trace_zero'))},
        witnesses_by_parameter_and_row=[dict(tau=tau,p=p,row_index=i,count=n)
            for (tau,p,i),n in sorted(parameter_types.items())],
        producer_raw_rows=producer_raw,original_replay_raw_rows=raw,batches=batches,
        audit_source_sha256=digest(Path(__file__).resolve()),
        derived_input_audit_sha256=digest(HERE/'derived_input_coverage_audit.json'),
        formal_proof_assistant_verification=False)
    output=HERE/'complete_E_coverage_audit.json'
    temporary=output.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    temporary.replace(output)
    print(json.dumps({key:result[key] for key in (
        'status','input_records','replayed_exclusions','OPEN_records',
        'disjoint_complete_batches','parameter_witnesses',
        'producer_raw_rows','original_replay_raw_rows')},indent=2))


if __name__=='__main__':
    main()
