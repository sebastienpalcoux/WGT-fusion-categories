#!/usr/bin/env python3
"""Deterministic exact controls for the producer-only minimum witness.

This audit does not replace negative row replay. It checks that the
producer's minimizing witness agrees with the frozen checker formulas,
and that certificate compression preserves a strict mass contradiction.
"""
from collections import Counter
from pathlib import Path
from random import Random
import argparse,gzip,hashlib,json,time
from row_engine16 import categories,pure_mass,f8_perron_mass
from run_refinement16 import mass_witness,compress_certificate
HERE=Path(__file__).resolve().parent

def audit():
 start=time.monotonic();pairs=set()
 with gzip.open(HERE/'rank16_symplectic_input.jsonl.gz','rt')as inp:
  for line in inp:
   rec=json.loads(line);f=5400//rec['double_degree'];b=rec['assignment']['q']+3
   if b in(3,4)or f in(36,40,60,72,100,108):pairs.add((f//4,b))
 rng=Random(36016);checks=Counter();compression=[]
 for k,b in sorted(pairs):
  cats=categories(k,b)
  vectors=[{c:d for c in cats}for d in(3,4,10,19,30,51,52,72,73)]
  vectors +=[{c:rng.randrange(3,74)for c in cats}for _ in range(8)]
  for lower in vectors:
   mass,witness=mass_witness(k,b,lower)
   assert mass==pure_mass(k,b,lower),(k,b,mass)
   if witness is not None:
    assert set(witness)<=set(cats)
    assert sum(n for(c,h,g),n in witness.items()if c)==15-2*b
    assert sum(n for(c,h,g),n in witness.items()if not c)==b
    assert sum(n*(1 if sd else 2)*h*h for(sd,h,g),n in witness.items())==2*k-1
    assert sum(n*(1 if sd else 2)*lower[c]**2 for c,n in witness.items()for sd in(c[0],))==mass
   checks['pure_minimum_controls']+=1
 for b in range(3,8):
  cats=categories(2,b)
  vectors=[{c:d for c in cats}for d in(3,4,10,19,30,51,52,72,73)]
  vectors +=[{c:rng.randrange(3,74)for c in cats}for _ in range(32)]
  for lower in vectors:
   mass,witness=mass_witness(2,b,lower,True)
   assert mass==f8_perron_mass(b,lower),(b,mass)
   if witness is not None:
    assert sum(n for(sd,h,g),n in witness.items()if sd)==15-2*b
    assert sum(n for(sd,h,g),n in witness.items()if not sd)==b
    assert sum(n*(1 if sd else 2)*h*h for(sd,h,g),n in witness.items())==3
    assert sum(n*(1 if c[0]else 2)*lower[c]**2 for c,n in witness.items())<=mass
   checks['perron_minimum_controls']+=1
 for k,b,perron in((2,4,False),(3,4,False),(9,3,False),(9,5,False),(18,5,False),(27,7,False),(2,4,True),(2,7,True)):
  cats=categories(k,b);lower={c:40 for c in cats}
  old=mass_witness(k,b,lower,perron)[0];assert old>5399
  reduced,mass=compress_certificate(k,b,lower,perron)
  assert all(3<=reduced[c]<=lower[c]for c in cats)
  assert mass==mass_witness(k,b,reduced,perron)[0]>5399
  for cat,low in reduced.items():
   if low==3:continue
   trial=dict(reduced);trial[cat]-=1
   assert mass_witness(k,b,trial,perron)[0]<=5399
  compression.append(dict(k=k,b=b,perron=perron,initial_mass=old,compressed_mass=mass))
  checks['coordinatewise_minimal_compressions']+=1
 return dict(status='PASS_EXACT_REFINEMENT_PRODUCER_CONTROLS',counts=dict(checks),scopes=[list(x)for x in sorted(pairs)],compression_controls=compression,source_sha256={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest()for n in('audit_refinement16.py','run_refinement16.py','row_engine16.py','symplectic_profiles.json')},seconds=time.monotonic()-start,limitation='Producer controls only. Every claimed negative requires the separate complete original row-kernel replay; OPEN is a necessary relaxation, not a realization.')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'refinement_producer_audit.json');a=p.parse_args()
 result=audit();a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
