#!/usr/bin/env python3
from pathlib import Path
from itertools import product
import json,time
from row_engine16 import f8_pair_mass,f8_three_mass,f8_perron_mass,pure_profiles
HERE=Path(__file__).resolve().parent

def main():
 start=time.monotonic();pair_controls=triple_controls=0
 for L in range(2,73):
  # In an optimum, two terms can be taken equal to their lower bound;
  # brute-force all lower entries up to 2L+1 and both resulting signs.
  brute=min(a*a+b*b+c*c for a in range(L,2*L+2)for b in range(L,2*L+2)for c in(a+b-1,a+b+1)if c>=L)
  assert f8_three_mass(L)==brute;triple_controls+=1
  for P in range(2,53):
   brute=min(2*p*p+r*r for p in range(P,max(P,L)+3)for r in(2*p-1,2*p+1)if r>=L)
   assert f8_pair_mass(L,P)==brute;pair_controls+=1
 # Independent enumeration of the two possible trace supports, with
 # categorical minima varying independently over nonzero and zero traces.
 profile_controls=0
 for b in range(4,8):
  s=15-2*b
  local_controls=0
  for L,Z,P,Q,R in product(range(3,7),repeat=5):
   if local_controls>=350:break
   lower={(True,1,0):L,(True,0,0):Z}
   for g in range(3):lower[False,1,g]=P+g;lower[False,0,g]=Q+(g==2)*(R-3)
   answer=10**18
   for profile in pure_profiles(2,b):
    base=sum(2*lower[False,0,g]**2 for g in profile)
    if s>=3:
     brute=min(x*x+y*y+z*z for x in range(L,2*L+2)for y in range(L,2*L+2)for z in(x+y-1,x+y+1)if z>=L)
     answer=min(answer,(s-3)*Z*Z+base+brute)
    for j,g in enumerate(profile):
     PP=lower[False,1,g]
     brute=min(2*p*p+r*r for p in range(PP,max(PP,L)+3)for r in(2*p-1,2*p+1)if r>=L)
     answer=min(answer,(s-1)*Z*Z+base-2*lower[False,0,g]**2+brute)
   assert answer==f8_perron_mass(b,lower);profile_controls+=1;local_controls+=1
 report=dict(status='PASS_EXACT_F8_PERRON_MASS_FORMULAS',pair_lower_bound_controls=pair_controls,three_selfdual_controls=triple_controls,profile_controls=profile_controls,seconds=time.monotonic()-start)
 assert pair_controls==3621 and profile_controls==1400
 (HERE/'f8_perron_mass_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
