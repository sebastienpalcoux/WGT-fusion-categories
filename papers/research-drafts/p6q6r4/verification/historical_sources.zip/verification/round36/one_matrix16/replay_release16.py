#!/usr/bin/env python3
"""Portable complete or selected replay of the frozen rank16 proof package.

All fresh outputs are written under --output. Frozen payloads are only read.
The original recursive row kernel is the default. No numerical solver or
third-party Python dependency is used.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,shutil,subprocess,sys,re,time
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def gunzip_sha(p):
 h=hashlib.sha256()
 with gzip.open(p,'rb')as inp:
  for block in iter(lambda:inp.read(1<<20),b''):h.update(block)
 return h.hexdigest()

def run(cmd,log,cwd):
 print('RUN',Path(cmd[1]).name,flush=True)
 with log.open('w')as out:subprocess.run([str(x)for x in cmd],cwd=cwd,stdout=out,stderr=subprocess.STDOUT,check=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--part',choices=('all','coverage','trace','rows','audits'),default='all');ap.add_argument('--output',type=Path,required=True);ap.add_argument('--kernel',choices=('original','fast'),default='original');ap.add_argument('--scope-start',type=int);ap.add_argument('--scope-stop',type=int);args=ap.parse_args()
 started=time.monotonic();dest=args.output.resolve();dest.mkdir(parents=True,exist_ok=True)
 manifest=json.loads((HERE/'RELEASE_MANIFEST.json').read_text());before={}
 for item in manifest['files']:
  p=HERE/item['file'];assert p.is_file()and sha(p)==item['sha256'],item['file'];before[item['file']]=item['sha256']
 for item in manifest.get('external_bindings',[]):assert sha(HERE/item['file'])==item['sha256'],item['file']
 assert json.loads((HERE/'symplectic_profiles.json').read_text())['profiles']==json.loads((HERE/'../structural/symplectic_profiles.json').read_text())['profiles']
 workroot=dest/'runtime'
 assert not HERE.resolve().is_relative_to(workroot.resolve()),'Replay output must not contain the frozen source as its runtime.'
 for name in('one_matrix16','structural','cubic_structure'):
  old=workroot/name
  if old.is_symlink():old.unlink()
  elif old.exists():shutil.rmtree(old)
 runtime=workroot/'one_matrix16';runtime.mkdir(parents=True,exist_ok=True)
 for name in before:
  src=HERE/name;target=runtime/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
 for item in manifest.get('external_bindings',[]):
  src=HERE/item['file'];target=runtime/item['file'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
 python=sys.executable;completed=[]
 def audit_original_E():
  kernels={json.loads(p.read_text())['kernel']for p in(runtime/'E_batches').glob('*_replay.json')}
  if kernels!={'original'}:
   assert kernels=={'fast'}
   return
  run([python,runtime/'audit_complete_E16.py'],dest/'complete_E_coverage_audit.log',runtime)
  fresh=json.loads((runtime/'complete_E_coverage_audit.json').read_text());saved=json.loads((HERE/'complete_E_coverage_audit.json').read_text())
  keys=('status','input_records','certificate_records','replayed_exclusions','OPEN_records','disjoint_complete_batches','signed_parameters_per_record','parameter_witnesses','proof_sha256','input_gzip_sha256','input_uncompressed_sha256','source_pair_histogram','required_row_witness_histogram','witnesses_by_parameter_and_row','producer_raw_rows','original_replay_raw_rows')
  assert all(fresh[k]==saved[k]for k in keys)
  completed.append('independent complete original E input and ledger coverage')
 if args.part in('all','audits'):
  for script in('generate_input16.py','audit_fields16.py','audit_row_kernel16.py','audit_f8_perron16.py','audit_refinement16.py','audit_refinement_mass_cache16.py'):
   run([python,runtime/script],dest/(script+'.log'),runtime);completed.append(script)
  assert sha(runtime/'profiles16.json')==sha(HERE/'profiles16.json')
  # Parent structural catalogues are separately bound, then freshly audited.
  for relative in('../structural/verify_symplectic_profiles.py','../cubic_structure/audit_orthogonal_six.py','../cubic_structure/audit_orthogonal_six_refinement.py'):
   if (runtime/relative).is_file():
    run([python,runtime/relative],dest/(Path(relative).stem+'.log'),(runtime/relative).parent);completed.append(relative)
  if args.part=='audits':audit_original_E()
 if args.part in('all','trace'):
  lo=0 if args.scope_start is None else args.scope_start
  hi=470747 if args.scope_stop is None else args.scope_stop
  assert 0<=lo<hi<=470747
  shards=[]
  for begin in range(lo,hi,100000):
   end=min(begin+100000,hi);report=dest/f'trace_replay_{begin}_{end}.json'
   cmd=[python,runtime/'verify_trace16.py','--source',runtime/'rank16_trace_complete.jsonl.gz','--start',begin,'--stop',end,'--output',report]
   run(cmd,dest/f'trace_replay_{begin}_{end}.log',runtime);shards.append(report)
  if lo==0 and hi==470747:
   run([python,runtime/'merge_trace_replay16.py',*shards,'--output',dest/'complete_trace_fresh_verification.json'],dest/'trace_merge.log',runtime)
  completed.append('complete trace replay'if lo==0 and hi==470747 else'bounded trace replay')
 if args.part in('all','rows'):
  pattern=re.compile(r'(primary|E|small_pairs|tensor|higher_tensor|f8)_(\d+)_(\d+)\.jsonl$')
  for mode in('E','primary','small_pairs','tensor','higher_tensor','f8'):
   source='rank16_orthogonal_E_input.jsonl.gz'if mode=='E'else'rank16_symplectic_input.jsonl.gz'
   for cert in sorted((runtime/(mode+'_batches')).glob(mode+'_*.jsonl')):
    match=pattern.fullmatch(cert.name)
    if not match:continue
    begin,end=map(int,match.groups()[1:]);lo=begin if args.scope_start is None else max(begin,args.scope_start);hi=end if args.scope_stop is None else min(end,args.scope_stop)
    if lo>=hi:continue
    # Full replays replace only runtime copies of the ledger/report.
    report=cert.with_name(cert.stem+'_replay.json');ledger=cert.with_name(cert.stem+'_ledger.jsonl')
    cmd=[python,runtime/'verify_rows16.py','--source',runtime/source,'--certificates',cert,'--start',lo,'--stop',hi,'--kernel',args.kernel,'--output',report,'--ledger',ledger]
    run(cmd,dest/(cert.stem+'_replay.log'),runtime)
  completed.append('all negative row certificates'if args.scope_start is None and args.scope_stop is None else'bounded negative row certificates')
 if args.part in('all','coverage'):
  assert args.scope_start is None and args.scope_stop is None,'A bounded replay cannot claim complete coverage.'
  derived=dest/'derived';run([python,runtime/'derive_inputs16.py','--sources',runtime/'rank16_trace_complete.jsonl.gz','--output',derived],dest/'derived_coverage.log',runtime)
  r=json.loads((derived/'derived_input_coverage_audit.json').read_text());saved=json.loads((HERE/'derived_input_coverage_audit.json').read_text())
  assert r['uncompressed_sha256']==saved['uncompressed_sha256']and r['field_duality_states']==saved['field_duality_states']
  bindings={'trace':'rank16_trace_complete.jsonl.gz','S':'rank16_symplectic_input.jsonl.gz','E':'rank16_orthogonal_E_input.jsonl.gz','structural':'rank16_f6_structural_exclusions.jsonl.gz'}
  for key,name in bindings.items():
   assert gunzip_sha(HERE/name)==saved['uncompressed_sha256'][key]==gunzip_sha(derived/name),(key,name)
  run([python,runtime/'finish_reduction16.py','--output',dest/'coverage'],dest/'final_coverage.log',runtime)
  new=json.loads((dest/'coverage'/'rank16_reduction_summary.json').read_text());old=json.loads((HERE/'rank16_reduction_summary.json').read_text());assert new==old
  audit_original_E()
  completed+=['complete derived-input coverage','complete exclusion union and OPEN scope']
 for name,h in before.items():assert sha(HERE/name)==h,('Frozen payload changed',name)
 report=dict(status='PASS_COMPLETE_RANK16_RELEASE_REPLAY'if args.part=='all'and args.scope_start is None and args.scope_stop is None else'PASS_REQUESTED_RANK16_REPLAY_SCOPE',part=args.part,kernel=args.kernel,scope_start=args.scope_start,scope_stop=args.scope_stop,authenticated_payloads=len(before),completed=completed,frozen_payloads_unchanged=True,seconds=time.monotonic()-started)
 (dest/'replay_result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
