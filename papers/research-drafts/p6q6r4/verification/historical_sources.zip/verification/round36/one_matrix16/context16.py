"""Exact matrix contexts, preserving nonsplit rational quaternion algebras."""
from functools import lru_cache
from fractions import Fraction as Q
from math import prod
import trace_signature16 as sig
from trace_rank16 import orthogonal_forms,skew_diagonal_values
from matrix_spectral_filter import degree,ramification,context as direct_context
import generic_fields as fields

@lru_cache(None)
def field_label_signature(f,label,k):
 r=next(r for r in fields.fields(f,k)if r[0]==label)
 return sig.signature(tuple(a/f for a in r[1])),sig.signature(tuple(a/f for a in r[3]))

def form_data(assignment):
 whole=sig.signature((Q(1,5400),));minus=(0,0,0)
 for block in assignment['fields']:
  f=block['formal_codegree'];labels=block['fields'];k=sum(degree(x)for x in labels)
  for label in labels:
   a,b=field_label_signature(f,label,k);whole=sig.add(whole,a);minus=sig.add(minus,b)
 return whole,minus

@lru_cache(None)
def context_from_signatures(whole,minus,q,f,kind):
 if kind=='orthogonal':
  b=q+1;delta=sig.SQUARECLASSES[sig.signature((Q(f,2),))[1]^(b%2)^minus[1]]
  allowed={ramification(-delta,int(diag[2]*f/2))for diag in orthogonal_forms(delta,f)if sig.add(whole,sig.signature(diag))==(16,0,0)}
  assert allowed
  return kind,f,delta,tuple(sorted(allowed)),skew_diagonal_values(delta,f,b)
 assert kind=='symplectic'and f%4==0
 allowed={ram for ram,diag in(((2,),(1,1,1,1)),((3,),(1,1,3,3)),((5,),(1,2,5,10)),((2,3,5),(1,3,10,30)))if all(f%p==0 for p in ram)and sig.add(whole,sig.signature(tuple(Q(2*a,f)for a in diag)))==(16,0,0)}
 assert allowed
 return kind,f,None,tuple(sorted(allowed)),()

CHECKED=set()
def context(assignment,matrix_degree,kind,audit=False):
 w,m=form_data(assignment);q=assignment['q'];f=5400//matrix_degree;key=(w,m,q,f,kind)
 result=context_from_signatures(*key)
 if kind=='orthogonal':
  assert result[2]==assignment['orthogonal_delta']
  assert list(result[4])==assignment['orthogonal_skew_diagonals']
 if audit and key not in CHECKED:
  assert result==direct_context(assignment,matrix_degree,kind),(result,assignment)
  CHECKED.add(key)
 return result
