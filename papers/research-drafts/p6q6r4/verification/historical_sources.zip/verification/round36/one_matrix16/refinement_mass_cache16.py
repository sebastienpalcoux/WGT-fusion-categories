"""Bounded memoization of independent exact pure-profile mass minima.

The immutable key contains every category bound used by the profile.
This module is producer-only: no cache result certifies a missing row.
Every negative certificate is replayed by the preserved original checker.
"""
from collections import Counter
from functools import lru_cache
from math import isqrt
from row_engine16 import pure_profiles

@lru_cache(maxsize=16384)
def profile_minimum(k,b,profile,bounds):
 budget=2*k-1;INF=10**18;lookup={(sd,g):values for sd,g,values in bounds}
 dp={0:(0,())}
 for sd,g in [(True,0)]*(15-2*b)+[(False,g)for g in profile]:
  weight=1 if sd else 2;new={}
  for h,low in enumerate(lookup[sd,g]):
   cost=weight*low*low;used=weight*h*h;cat=sd,h,g
   for old,(mass,pattern)in dp.items():
    if old+used<=budget and mass+cost<new.get(old+used,(INF,()))[0]:
     new[old+used]=(mass+cost,pattern+(cat,))
  dp=new
 return dp.get(budget,(INF,()))

def mass_witness(k,b,lower,perron=False):
 assert not perron,'This cache covers pure profiles; the small Perron formula is evaluated directly.'
 budget=2*k-1;best=10**18;chosen=None
 for profile in pure_profiles(k,b):
  blocks={(True,0)}if 15-2*b else set();blocks.update((False,g)for g in profile)
  bounds=tuple((sd,g,tuple(lower[sd,h,g]for h in range(isqrt(min(budget//(1 if sd else 2),2*k-1-g))+1)))for sd,g in sorted(blocks))
  mass,pattern=profile_minimum(k,b,profile,bounds)
  if mass<best:best=mass;chosen=Counter(pattern)
 return best,chosen
