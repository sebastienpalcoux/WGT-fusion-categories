#!/usr/bin/env python3
"""Complete residue-join controls and direct original/optimized row equality."""
from collections import Counter
from pathlib import Path
from itertools import product
import argparse,gzip,json,time,hashlib
from endpoint_core import DEGREES
import fixed_field_rows as fast
import fixed_field_rows_original as old
from context16 import context
HERE=Path(__file__).resolve().parent

def join_audit():
 controls=0;weight_pairs=0
 for dimension in(2,3):
  if dimension==2:
   first=tuple((s,t)for t in range(5)for s in range(-min(t,2),min(t,2)+1))
   second=tuple((s,t)for t in range(5)for s in range(-min(t,2),min(t,2)+1))
  else:
   first=tuple((s,t,w)for t in range(4)for s in range(-min(t,2),min(t,2)+1)for w in range(0,2*t+1,2))
   second=tuple((s,t,w)for t in range(3)for s in range(-min(t,1),min(t,1)+1)for w in range(0,2*t+1,2))
  for a,b in product(DEGREES,repeat=2):
   data=fast.residue_buckets(a,first,b,second);expected={}
   for x,y in product(first,second):
    target=tuple(a*u+b*v for u,v in zip(x,y));expected.setdefault(target,set()).add((x,y));controls+=1
   for target,answer in expected.items():assert set(fast.residue_completions(data,target))==answer,(a,b,target)
   # Include nonlattice and negative-norm boundary targets.
   for target in ((1,)*dimension,(0,-1)+(0,)*(dimension-2),(-1,0)+(0,)*(dimension-2)):
    assert set(fast.residue_completions(data,target))==expected.get(target,set())
   weight_pairs+=1
 return weight_pairs,controls

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=HERE/'rank16_symplectic_input.jsonl.gz');args=ap.parse_args();start=time.monotonic()
 pairs,controls=join_audit();chosen={};targets=(8,12,20,24,36,40,60,72)
 with gzip.open(args.source,'rt')as inp:
  for line in inp:
   rec=json.loads(line);f=5400//rec['double_degree']
   if f in targets and len(chosen.get(f,()))<2:chosen.setdefault(f,[]).append(rec)
   if all(len(chosen.get(f,()))==2 for f in targets):break
 assert all(len(chosen.get(f,()))==2 for f in targets)
 dimensions=(3,4,7,10,18,25,51,52,72);checks=rows=filters=value_filters=0
 for f in targets:
  for rec in chosen[f]:
   a=rec['assignment'];p,mi=fast.fixed_blocks(a,rec['double_degree']);ctx=context(a,rec['double_degree'],rec['kind'],audit=True)
   for d in dimensions:
    kwargs=dict(context=ctx,dimensions=(d,))
    x=list(old.fixed_rows(p,mi,a['q6'],a['q'],rec['kind'],**kwargs));y=list(fast.fixed_rows(p,mi,a['q6'],a['q'],rec['kind'],**kwargs))
    assert Counter(x)==Counter(y),(rec['state'],d,len(x),len(y))
    traces=(0,2,-2)
    z=list(fast.fixed_rows(p,mi,a['q6'],a['q'],rec['kind'],matrix_traces=traces,**kwargs))
    assert Counter(z)==Counter(r for r in x if r[2][mi][0]in traces)
    vv=((0,0),(2,2),(-2,2))
    z=list(fast.fixed_rows(p,mi,a['q6'],a['q'],rec['kind'],matrix_values=vv,**kwargs))
    assert Counter(z)==Counter(r for r in x if r[2][mi]in vv)
    checks+=1;rows+=len(x);filters+=1;value_filters+=1
   print('actual control',f,rec['state'],'checks',checks,'seconds',round(time.monotonic()-start,2),flush=True)
 report=dict(status='PASS_EXACT_ORIGINAL_OPTIMIZED_ROW_EQUIVALENCE_CONTROLS',ordered_weight_coordinate_pairs=pairs,cartesian_pair_controls=controls,actual_states=16,dimension_list=dimensions,actual_row_comparisons=checks,raw_rows=rows,matrix_trace_filter_comparisons=filters,matrix_value_filter_comparisons=value_filters,source_hashes={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest()for n in('fixed_field_rows.py','fixed_field_rows_original.py')},seconds=time.monotonic()-start)
 (HERE/'row_kernel_equivalence_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
