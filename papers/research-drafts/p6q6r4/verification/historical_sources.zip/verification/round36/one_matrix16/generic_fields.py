"""Exact full character fields for thirteen nonunit weighted canonical entries.

For quartic fields the conductor reduces to gcd(c,240): every quotient of
order4 kills wild3/5-inertia and the 2-primary characters of conductor>16.
Cubic fields have conductor9. Sextic fields also arise at conductors36 and72;
a real cyclic quintic arises at conductor25;
full degree-eight fields arise at conductors15,20 and24.
"""
from functools import lru_cache
from itertools import combinations,product
from collections import Counter
from fractions import Fraction as Q
from math import gcd,prod
import r32_trace_forms as forms

@lru_cache(None)
def cyclotomic_polynomial(n):
    p=[-1]+[0]*(n-1)+[1]
    for d in range(1,n):
        if n%d:continue
        q=cyclotomic_polynomial(d);out=[0]*(len(p)-len(q)+1)
        for k in range(len(p)-len(q),-1,-1):
            value=p[k+len(q)-1];out[k]=value
            if value:
                for j,a in enumerate(q):p[k+j]-=value*a
        assert not any(p)
        p=out
    assert p[-1]==1 and len(p)-1==forms.phi(n)
    return tuple(p)

EXTRA_POLY={c:list(cyclotomic_polynomial(c))
            for c in (3,5,9,12,15,16,20,24,25,36,40,48,60,72,80,120,240)}
forms.POLY.update(EXTRA_POLY)

@lru_cache(None)
def subgroups(c):
    """Generate subgroups by adjoining one group element, never by large subsets."""
    units=tuple(a for a in range(c) if gcd(a,c)==1)
    seen={frozenset((1,))};queue=[frozenset((1,))]
    for h in queue:
        for a in units:
            if a in h:continue
            generated=set(h);power=a
            while power not in h:
                generated.update(power*b%c for b in h)
                power=power*a%c
            hh=frozenset(generated)
            if hh not in seen:seen.add(hh);queue.append(hh)
    return tuple(sorted((tuple(sorted(h)) for h in seen),key=lambda h:(len(h),h)))

@lru_cache(None)
def index_two_subgroups(c,group):
    # H/H^2 is elementary abelian. Build binary coordinates on its cosets,
    # then take kernels of every nonzero binary linear functional.
    group=tuple(group);squares={a*a%c for a in group}
    coordinates={a:0 for a in squares};rank=0
    for generator in group:
        if generator in coordinates:continue
        bit=1<<rank;rank+=1
        old=list(coordinates.items())
        for a,mask in old:coordinates[a*generator%c]=mask|bit
    assert set(coordinates)==set(group)
    return tuple(tuple(a for a in group if (coordinates[a]&mask).bit_count()%2==0)
                 for mask in range(1,1<<rank))

@lru_cache(None)
def index_four_subgroups(c):
    units=tuple(a for a in range(c) if gcd(a,c)==1)
    return tuple(sorted({h for middle in index_two_subgroups(c,units)
                         for h in index_two_subgroups(c,middle)}))

@lru_cache(None)
def fields(f,k):
    c=gcd(2*f,f*f)
    if f==6:return (forms.field_record('Q',[1],[1],[]),forms.field_record('Q(sqrt(-3))',[2,6],[2],[6],1))
    records=[] if f==540 else [forms.field_record('Q',[1],[1],[])]
    if k>=2:
        for delta in forms.quadratic_discriminants(c):
            d=abs(delta if delta%4==1 else delta//4);diagonal=[2,2*d]
            plus,minus=(diagonal,[]) if delta>0 else([2],[2*d])
            records.append(forms.field_record(f'quadratic_disc={delta}',diagonal,plus,minus))
    if k>=3 and c%9==0:
        records.append(forms.field_record('real_cubic_conductor9',[3,6,Q(9,2)],[3,6,Q(9,2)],[]))
    if k>=4:
        ambient=gcd(c,240);units=[a for a in range(ambient) if gcd(a,ambient)==1]
        if len(units)%4==0:
            size=len(units)//4
            for h in index_four_subgroups(ambient):
                assert len(h)==size
                data=forms.fixed_forms(ambient,h)
                records.append(forms.field_record(f'zeta{ambient}:H='+','.join(map(str,h)),*data))
    if k>=5 and forms.phi(c)%5==0:
        assert c%25==0,(f,k,c)
        h=(1,7,18,24)
        records.append(forms.field_record('zeta25:H=1,7,18,24',*forms.fixed_forms(25,h)))
    if k>=6 and forms.phi(c)%6==0:
        # Complete actual high-multiplicity conductor list at rank16.
        c=gcd(c,360)
        assert c in (9,36,72),(f,k,c)
        units=[a for a in range(c) if gcd(a,c)==1]
        size=len(units)//6
        for tail in combinations(units[1:],size-1):
            h={1,*tail}
            if any(a*b%c not in h for a in h for b in h):continue
            records.append(forms.field_record(f'zeta{c}:H='+','.join(map(str,sorted(h))),*forms.fixed_forms(c,tuple(sorted(h)))))
    if k>=8 and forms.phi(c)%8==0:
        assert c in (15,20,24),(f,k,c)
        records.append(forms.field_record(f'zeta{c}:H=1',*forms.fixed_forms(c,(1,))))
    assert k<=9,(f,k)
    return tuple(records)

@lru_cache(None)
def decompositions(f,k):
    options=fields(f,k);out=[]
    def rec(left,start,indices):
        if left==0:
            labels=tuple(options[i][0] for i in indices)
            whole=tuple(a/f for i in indices for a in options[i][1])
            plus=tuple(a/f for i in indices for a in options[i][2])
            minus=tuple(a/f for i in indices for a in options[i][3])
            out.append((labels,whole,plus,minus,sum(options[i][4] for i in indices)))
            return
        for i in range(start,len(options)):
            e=len(options[i][1])
            if e<=left:rec(left-e,i,indices+[i])
    rec(k,0,[]);return tuple(out)

def commutative_assignments(profile,rank=13):
    blocks=[(5400//a,k) for a,k in Counter(profile).items()]
    alternatives=[decompositions(f,k) for f,k in blocks]
    total=0;tested=0;kept=[]
    for assignment in product(*alternatives):
        total+=1;q6=sum(a[4] for a in assignment);q=sum(len(a[3]) for a in assignment)
        if q6>2 or q<2*q6 or q>(rank-2)//2:continue
        whole=(Q(1,5400),)+tuple(a for block in assignment for a in block[1])
        plus=(Q(1,5400),)+tuple(a for block in assignment for a in block[2])
        minus=tuple(a for block in assignment for a in block[3])
        if forms.squareclass(prod(whole))!=1:continue
        tested+=1
        if not forms.isometric(whole,[1]*rank):continue
        if not forms.isometric(minus,[2]*q):continue
        if not forms.isometric(plus,[1]*(rank-2*q)+[2]*q):continue
        kept.append({'fields':[{'formal_codegree':f,'fields':list(a[0])} for (f,k),a in zip(blocks,assignment)],'q6':q6,'q':q,'duality_types':['commutative']})
    return {'total_assignments':total,'tested_assignments':tested,'surviving_assignments':kept,'excluded':not kept}
