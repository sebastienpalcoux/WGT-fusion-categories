"""Standard-library exact row queries and finite rank-sixteen mass gates."""
from collections import Counter
from functools import lru_cache
from math import isqrt
import importlib.util
from pathlib import Path
from fixed_field_rows import fixed_blocks
import fixed_field_rows as fast_rows
import fixed_field_rows_original as original_rows
from context16 import context
from bounded_remainder import row_allowed,parity_index,canonical_requirements,reachable
from norm_word_filter import determinant_options

HERE=Path(__file__).resolve().parent

def load_sibling(filename,module_name):
 spec=importlib.util.spec_from_file_location(module_name,HERE/filename)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

@lru_cache(None)
def pure_profiles(k,b):
 assert 3<=b<=7
 if b==3:
  z=isqrt(k)
  return ((k,k,k),)if z*z==k else()
 if b==4:
  answer=set()
  def visit(left,start,squares):
   if len(squares)==4:
    if left==0:answer.add(tuple(sorted(k-x for x in squares)))
    return
   for z in range(start,isqrt(left)+1):visit(left-z*z,z,squares+(z*z,))
  visit(k,0,());return tuple(sorted(answer))
 import json
 data=json.loads((HERE/'symplectic_profiles.json').read_text())
 return tuple(tuple([0]*(b-len(p))+p)for p in data['profiles'][str(k)]if len(p)<=b)

@lru_cache(None)
def categories(k,b):
 s=15-2*b;budget=2*k-1;answer=set()
 if s:
  answer.update((True,h,0)for h in range(isqrt(budget)+1))
 for p in pure_profiles(k,b):
  for g in p:
   answer.update((False,h,g)for h in range(isqrt(min(budget//2,2*k-1-g))+1))
 return tuple(sorted(answer))

def category(row,mi):
 sd,d,values=row;s,t=values[mi]
 assert s%2==t%2==0
 h=abs(s)//2;g=t//2-h*h
 assert g>=0 and(not sd or g==0)
 return(sd,h,g)

def pure_mass(k,b,lower):
 """Minimum squared source mass using all pure profiles and the trace norm."""
 s=15-2*b;budget=2*k-1;INF=10**18;best=INF
 for p in pure_profiles(k,b):
  dp={0:0}
  for sd,g in [(True,0)]*s+[(False,g)for g in p]:
   weight=1 if sd else 2;nextdp={}
   for h in range(isqrt(min(budget//weight,2*k-1-g))+1):
    key=sd,h,g;d=lower.get(key,3);cost=weight*d*d;used=weight*h*h
    for old,mass in dp.items():
     if old+used<=budget:nextdp[old+used]=min(nextdp.get(old+used,INF),mass+cost)
   dp=nextdp
  best=min(best,dp.get(budget,INF))
 return best

class Engine:
 def __init__(self,case,assignment,kind,kernel='fast',level=1,audit_context=False):
  self.case=case;self.assignment=assignment;self.kind=kind;self.level=level
  self.pieces,self.mi=fixed_blocks(assignment,case['double_degree'])
  self.ctx=context(assignment,case['double_degree'],kind,audit_context)
  self.parity=parity_index(assignment,self.pieces,kind)
  self.kernel=fast_rows if kernel=='fast'else original_rows
  self.orth_categories=None
  if kind=='orthogonal'and self.ctx[1]==6 and self.ctx[2]==3 and self.ctx[3]==((),):
   from orthogonal_six_catalogue import profiles as six_profiles
   self.orth_categories={cat for profile in six_profiles(assignment['q']+1,self.ctx[2],self.ctx[3])for cat in profile}
  self.cache={};self.raw=0;self.queries=0
 def rows(self,d,sd,traces=None,matrix_values=None):
  kwargs=dict(context=self.ctx,dimensions=(d,),source_dualities=(sd,))
  if traces is not None and self.kernel is fast_rows:kwargs['matrix_traces']=traces
  if matrix_values is not None and self.kernel is fast_rows:kwargs['matrix_values']=matrix_values
  for row in self.kernel.fixed_rows(self.pieces,self.mi,self.assignment['q6'],self.assignment['q'],self.kind,**kwargs):
   self.raw+=1
   if matrix_values is not None and row[2][self.mi]not in matrix_values:continue
   if traces is not None and row[2][self.mi][0]not in traces:continue
   ss,tt=row[2][self.mi]
   if self.kind=='symplectic':
    if ss%2 or tt%2:continue
    hh=ss//2;gg=tt//2-hh*hh;kk=self.ctx[1]//4
    if not 0<=gg<=kk or(not sd and hh*hh>=kk):continue
   if self.orth_categories is not None:
    nn=determinant_options(self.pieces,d,row[2],sd,self.kind,self.ctx)[1]
    if not any((sd,abs(ss),tt,n)in self.orth_categories for n in nn):continue
   if row_allowed(self.pieces,self.mi,self.assignment,self.kind,self.ctx,self.parity,row,self.level):yield row
 def exists(self,d,sd,m=0,central=None,cat=None):
  if d<3 or d>(72 if sd else 51):return False
  key=d,sd,m,central,cat
  if key in self.cache:return self.cache[key]
  self.queries+=1;traces=None
  if cat is not None:
   assert cat[0]==sd
   traces=tuple({2*cat[1],-2*cat[1]})if self.kind=='symplectic'else tuple({cat[1],-cat[1]})
  for row in self.rows(d,sd,traces):
   values=row[2];regular=d+sum((2 if i==self.mi else 1)*s for i,(s,t)in enumerate(values))
   if regular<m:continue
   if cat is not None:
    if self.kind=='symplectic':
     if category(row,self.mi)!=cat:continue
    else:
     s,t=values[self.mi]
     if abs(s)!=cat[1]or t!=cat[2]or cat[3]not in determinant_options(self.pieces,d,values,sd,self.kind,self.ctx)[1]:continue
   s,t=values[self.mi]
   if central=='single'and(s%2 or 2*t!=s*s):continue
   if central=='pair_sum'and(t%2 or t//2 not in determinant_options(self.pieces,d,values,sd,self.kind,self.ctx)[1]):continue
   self.cache[key]=True
   for mm in range(min(regular,2)+1):self.cache[d,sd,mm,central,cat]=True
   return True
  self.cache[key]=False
  for mm in range(m,3):self.cache[d,sd,mm,central,cat]=False
  return False
 def coin(self,c,selfdual,m,central=False):
  if self.exists(c,True,m,'single'if central else None):return True
  if selfdual:return c%2==0 and self.exists(c//2,False,m,'pair_sum'if central else None)
  return self.exists(c,False,m,'single'if central else None)
 def bounded(self):
  remainders=sorted({r for r,a,m,sd in canonical_requirements(self.assignment,self.case['double_degree'])})
  eligible=[];tested=set()
  for R in remainders:
   if reachable(R,eligible):continue
   for d in range(3,min(R,72)+1):
    if d in tested:continue
    tested.add(d)
    if self.exists(d,True)or self.exists(d,False):eligible.append(d)
    if d==18 and not eligible:
     return dict(kind='source_dimension_density',dimension_bound=18,eligible_dimensions=[],nonunit_count=15,minimum_forced_dimension=19)
    if reachable(R,eligible):break
   if not reachable(R,eligible):
    assert tested==set(range(3,min(R,72)+1))
    return dict(kind='bounded_canonical_remainder',remainder=R,dimension_bound=min(R,72),eligible_dimensions=eligible)
  return None
 def canonical(self):
  for R,a,m,sd in canonical_requirements(self.assignment,self.case['double_degree']):
   eligible=[];bound=min(R,102 if sd else 72)
   for c in range(3,bound+1):
    if self.coin(c,sd,m):eligible.append(c)
    if reachable(R,eligible):break
   cert=dict(canonical_degree=a,multiplicity=m,canonical_selfdual=sd,remainder=R,contribution_bound=bound,regular_trace_minimum=m,eligible_contributions=eligible)
   if not reachable(R,eligible):return dict(cert,kind='canonical_remainder_with_duality')
   if R<2*min(eligible)and not self.coin(R,sd,m,True):return dict(cert,kind='central_canonical_atom',minimum_contribution=min(eligible))
  return None
 def pure(self,max_dimension=30):
  assert self.kind=='symplectic';f=self.ctx[1];k=f//4;b=self.assignment['q']+3
  cats=categories(k,b);lower={cat:3 for cat in cats};found=set()
  for d in range(3,max_dimension+1):
   for cat in cats:
    if cat in found:continue
    if self.exists(d,cat[0],cat=cat):found.add(cat)
    else:lower[cat]=d+1
   mass=pure_mass(k,b,lower)
   if mass>5399:
    return dict(kind='symplectic_pure_pattern_dimension_minimum',formal_codegree=f,source_pairs=b,lower_bounds=[dict(category=list(cat),minimum=low)for cat,low in sorted(lower.items())],mass_lower_bound=mass)
   if len(found)==len(cats):break
  return None
 def orth_profile(self,profiles,max_dimension=30):
  cats=tuple(sorted({cat for p in profiles for cat in p}));lower={cat:3 for cat in cats};found=set()
  for d in range(3,max_dimension+1):
   for cat in cats:
    if cat in found:continue
    if self.exists(d,cat[0],cat=cat):found.add(cat)
    else:lower[cat]=d+1
   mass=min((sum(n*(1 if cat[0]else 2)*lower[cat]**2 for cat,n in p.items())for p in profiles),default=10**18)
   if mass>5399:return dict(kind='orthogonal_six_pattern_dimension_minimum',source_pairs=self.assignment['q']+1,lower_bounds=[dict(category=list(cat),minimum=low)for cat,low in sorted(lower.items())],mass_lower_bound=mass)
   if len(found)==len(cats):break
  return None

 def exact_matrix_row(self,d,sd,s,t,n):
  key=('signed',d,sd,s,t,n)
  if key in self.cache:return self.cache[key]
  self.queries+=1
  for row in self.rows(d,sd,(s,),((s,t),)):
   if row[2][self.mi]!=(s,t):continue
   if n not in determinant_options(self.pieces,d,row[2],sd,self.kind,self.ctx)[1]:continue
   self.cache[key]=True;return True
  self.cache[key]=False;return False
 def E_coupled(self):
  assert self.kind=='orthogonal'and self.ctx[1:4]==(6,3,((),))
  witnesses=[]
  for tau,p in E_parameters():
   forced=((False,p,-tau,4,0),(True,2*p-tau,2*tau,4,0),(True,4*p-tau,0,2,-1))
   missing=next((row for row in forced if not self.exact_matrix_row(row[1],row[0],row[2],row[3],row[4])),None)
   if missing is None:return None
   witnesses.append(dict(tau=tau,p=p,missing_row=list(missing)))
  return dict(kind='orthogonal_six_E_forced_rows',parameter_witnesses=witnesses)

 def primary(self):
  certificate=self.bounded()
  if certificate is None:certificate=self.canonical()
  if certificate is None and self.kind=='symplectic'and self.ctx[1]in(8,12,20,24):certificate=self.pure()
  return certificate

def f8_three_mass(L):return 2*L*L+(2*L-1)**2

def f8_pair_mass(L,P):
 return min((2*p+delta)**2+2*p*p for delta in(-1,1)for p in(max(P,(L-delta+1)//2),))

def f8_perron_mass(b,lower):
 s=15-2*b;INF=10**18;best=INF;L=lower.get((True,1,0),3);Z=lower.get((True,0,0),3)
 for p in pure_profiles(2,b):
  zero_pair=sum(2*lower.get((False,0,g),3)**2 for g in p)
  if s>=3:best=min(best,(s-3)*Z*Z+f8_three_mass(L)+zero_pair)
  if s>=1:
   for j,g in enumerate(p):
    P=lower.get((False,1,g),3)
    best=min(best,(s-1)*Z*Z+f8_pair_mass(L,P)+zero_pair-2*lower.get((False,0,g),3)**2)
 return best

def f8_perron(engine,max_dimension=45):
 assert engine.kind=='symplectic'and engine.ctx[1]==8
 b=engine.assignment['q']+3;cats=categories(2,b);lower={cat:3 for cat in cats};found=set()
 for d in range(3,max_dimension+1):
  for cat in cats:
   if cat in found:continue
   if engine.exists(d,cat[0],cat=cat):found.add(cat)
   else:lower[cat]=d+1
  mass=f8_perron_mass(b,lower)
  if mass>5399:return dict(kind='symplectic_f8_perron_mass',source_pairs=b,lower_bounds=[dict(category=list(cat),minimum=low)for cat,low in sorted(lower.items())],mass_lower_bound=mass)
  if len(found)==len(cats):break
 return None


def E_parameters():
 return tuple((tau,p)for tau in(-1,1)for p in range(3,52)
              if 24*p*p-12*tau*p+2+9*9<=5399)
