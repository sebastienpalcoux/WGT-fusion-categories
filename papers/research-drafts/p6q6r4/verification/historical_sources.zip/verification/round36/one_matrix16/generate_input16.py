#!/usr/bin/env python3
from collections import Counter
from pathlib import Path
from math import prod
import json,time,hashlib
from endpoint_core import degree_profiles,DEGREES
import generic_fields as fields
HERE=Path(__file__).resolve().parent

def main():
 start=time.monotonic(); profiles=list(degree_profiles(left=13)); assert len(profiles)==470747
 dp=[[0]*5400 for _ in range(14)]; dp[0][0]=1
 for a in DEGREES:
  for k in range(1,14):
   cur=dp[k];old=dp[k-1]
   for n in range(a,5400):cur[n]+=old[n-a]
 assert dp[13][5399]==len(profiles)
 inv=Counter(); placements=Counter()
 for p in profiles:
  c=Counter(p)
  for a,k in c.items():
   if k<2:continue
   placements[a]+=1
   inv.update((5400//aa,kk-2*(a==aa))for aa,kk in c.items()if kk-2*(a==aa))
 assert sum(placements.values())==1224166
 for a,n in placements.items():assert n==dp[11][5399-2*a]
 data=json.dumps(profiles,separators=(',',':'))+'\n';(HERE/'profiles16.json').write_text(data)
 (HERE/'raw_field_inventory16.json').write_text(json.dumps([dict(f=f,k=k,occurrences=n)for(f,k),n in sorted(inv.items())],indent=2)+'\n')
 records=[]
 for f,k in sorted(inv):
  ff=fields.fields(f,k)
  records.append(dict(f=f,k=k,occurrences=inv[f,k],field_labels=[x[0]for x in ff],field_degrees=[len(x[1])for x in ff],decompositions=len(fields.decompositions(f,k))))
 data=json.dumps(profiles,separators=(',',':'))+'\n';(HERE/'profiles16.json').write_text(data)
 report=dict(status='PASS_COMPLETE_CANONICAL_INPUT_INVENTORY',profiles=len(profiles),placements=sum(placements.values()),palette=DEGREES,field_inventory=records,profiles_sha256=hashlib.sha256(data.encode()).hexdigest(),seconds=time.monotonic()-start)
 (HERE/'input_inventory16.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='field_inventory'},indent=2),flush=True)
if __name__=='__main__':main()
