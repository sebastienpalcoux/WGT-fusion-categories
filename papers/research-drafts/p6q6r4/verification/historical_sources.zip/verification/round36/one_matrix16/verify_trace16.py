#!/usr/bin/env python3
"""Fresh complete producer-independent file replay of rank16 trace inputs.

For every selected canonical profile all placements and full assignments
are regenerated, then compared exactly to the saved trace record. Each
new fast form signature is separately checked against rational diagonals.
"""
from pathlib import Path
from collections import Counter
import argparse,gzip,json,hashlib,time
from run_trace16 import analyze
from post_trace_columns16 import finalize_case
import trace_signature16 as sig
HERE=Path(__file__).resolve().parent
TRACE_FILES=('verify_trace16.py','run_trace16.py','trace_signature16.py','trace_rank16.py','generic_fields.py','r32_trace_forms.py','post_trace_columns16.py','quadratic_character_gate.py','imaginary_quadratic_gate.py','linear_field_lattice.py','fixed_lattice.py','fixed_field_rows.py','orbit_pairs.py','field_discriminant_profiles.py','coupled_rows.py','refined_rows.py','endpoint_core.py')

def proof_digest():
 h=hashlib.sha256()
 for name in sorted(TRACE_FILES):h.update(name.encode()+b'\0'+(HERE/name).read_bytes()+b'\0')
 return h.hexdigest()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=HERE/'rank16_trace_complete.jsonl.gz');ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=470747);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 started=time.monotonic();proof=proof_digest();profiles=json.loads((HERE/'profiles16.json').read_text());expected=iter((i,a)for i,p in enumerate(profiles)for a,n in Counter(p).items()if n>=2);counts=Counter();duality=Counter();digest=hashlib.sha256()
 with gzip.open(args.source,'rt')as inp:
  for line in inp:
   digest.update(line.encode());case=json.loads(line);i,a=next(expected)
   assert(case['index'],case['double_degree'])==(i,a)and case['profile']==profiles[i]
   counts['covered_placements']+=1
   if not args.start<=i<args.stop:continue
   ans=analyze(tuple(profiles[i]),a,True);ans.update(index=i,profile=profiles[i],double_degree=a);ans=finalize_case(ans)
   assert ans==case,(i,a)
   counts['replayed_placements']+=1
   for key in('total_assignments','column_assignments','determinant_assignments','removed_nonfour_symplectic'):counts[key]+=ans[key]
   counts['post_trace_column_exclusions']+=len(ans.get('post_trace_column_exclusions',()))
   counts['surviving_assignments']+=len(ans['surviving_assignments']);counts['surviving_placements']+=not ans['excluded']
   for assignment in ans['surviving_assignments']:
    for kind in assignment['duality_types']:duality[kind]+=1
   if counts['replayed_placements']%50000==0:print('replayed',counts['replayed_placements'],'profile',i,'seconds',round(time.monotonic()-started,2),flush=True)
 assert next(expected,None)is None and counts['covered_placements']==1224166
 assert proof==proof_digest()
 report=dict(status='PASS_COMPLETE_FIELD_TRACE_REPLAY_SHARD',profile_start=args.start,profile_stop=args.stop,counts=dict(counts),duality_counts=dict(duality),direct_rational_form_checks=sig.CHECK_COUNTS,proof_sha256=proof,input_uncompressed_sha256=digest.hexdigest(),seconds=time.monotonic()-started)
 args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
