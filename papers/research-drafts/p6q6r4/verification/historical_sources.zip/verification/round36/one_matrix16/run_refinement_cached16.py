#!/usr/bin/env python3
"""The reviewed refinement producer with bounded pure-profile memoization.

The underlying producer, original row checker, and mathematical formulas
remain unchanged. The small Perron formula is evaluated directly. This
entrypoint records both the core producer and the cache extension hashes.
"""
from pathlib import Path
import argparse,hashlib,json
import run_refinement16 as producer
from refinement_mass_cache16 import mass_witness as cached_witness,profile_minimum

HERE=Path(__file__).resolve().parent
original_witness=producer.mass_witness

def dispatch(k,b,lower,perron=False):
 return original_witness(k,b,lower,True)if perron else cached_witness(k,b,lower)

def main():
 p=argparse.ArgumentParser(add_help=False);p.add_argument('--output',type=Path,required=True)
 args,unused=p.parse_known_args()
 sources={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest()for n in('run_refinement_cached16.py','refinement_mass_cache16.py','run_refinement16.py')}
 producer.mass_witness=dispatch
 try:producer.main()
 finally:producer.mass_witness=original_witness
 path=args.output.with_suffix('.report.json');report=json.loads(path.read_text())
 assert report['producer_sha256']==sources['run_refinement16.py']
 assert all(hashlib.sha256((HERE/n).read_bytes()).hexdigest()==h for n,h in sources.items())
 report.update(producer_entrypoint='run_refinement_cached16.py',core_producer_sha256=report['producer_sha256'],producer_sha256=sources['run_refinement_cached16.py'],producer_extension_sha256=sources,mass_profile_cache=profile_minimum.cache_info()._asdict())
 path.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(dict(status='PASS_BOUND_PRODUCER_CACHE_EXTENSION',source_sha256=sources,cache=report['mass_profile_cache']),indent=2),flush=True)

if __name__=='__main__':main()
