#!/usr/bin/env python3
"""Select the current proof closure and authoritative data, omitting probes."""
import ast,hashlib,importlib.util,json,re
from pathlib import Path
from run_rows16 import PROOF_FILES
from verify_trace16 import TRACE_FILES
HERE=Path(__file__).resolve().parent

ENTRY=('prepare_refinement_prefix16.py','batch_refinement_prefix16.py','audit_complete_E16.py','run_refinement_cached16.py','audit_refinement_mass_cache16.py','run_refinement16.py','write_final_docs16.py','replay_release16.py','build_release_manifest16.py','generate_input16.py','audit_fields16.py','run_trace16.py','derive_inputs16.py','verify_trace16.py','merge_trace_replay16.py','run_rows16.py','verify_rows16.py','finish_reduction16.py','batch_rows16.py','audit_row_kernel16.py','audit_f8_perron16.py','audit_refinement16.py','repair_interrupted_batches16.py','post_trace_columns16.py')
DATA=('profiles16.json','raw_field_inventory16.json','input_inventory16.json','complete_field_catalogue_audit.json','symplectic_profiles.json','rank16_trace_complete.jsonl.gz','rank16_symplectic_input.jsonl.gz','rank16_orthogonal_E_input.jsonl.gz','rank16_f6_structural_exclusions.jsonl.gz','derived_input_coverage_audit.json','complete_trace_fresh_verification.json','complete_trace_replay_0_100000.json','complete_trace_replay_100000_200000.json','complete_trace_replay_200000_300000.json','complete_trace_replay_300000_400000.json','complete_trace_replay_400000_470747.json','row_kernel_equivalence_audit.json','f8_perron_mass_audit.json','refinement_producer_audit.json','refinement_mass_cache_audit.json','primary_completion_and_refinement_scopes.json','cubic_support_replay16.json','rank16_reduction_summary.json','rank16_completion_coverage_replay.json','rank16_open_state_ids.jsonl.gz','remaining_input_inventory16.json','orthogonal_six_E_completion.json','orthogonal_six_E_0_59761_replay.json','complete_E_coverage_audit.json','README_one_matrix16.md','EXTERNAL_DEPENDENCIES.txt')
EXTERNAL=('../structural/symplectic_profiles.py','../structural/symplectic_profiles.json','../structural/verify_symplectic_profiles.py','../structural/symplectic_profile_verification.json','../structural/r36_symplectic_structure.tex','../cubic_structure/orthogonal_six_catalogue.py','../cubic_structure/orthogonal_six_catalogue.json','../cubic_structure/audit_orthogonal_six.py','../cubic_structure/orthogonal_six_independent_audit.json','../cubic_structure/audit_orthogonal_six_refinement.py','../cubic_structure/orthogonal_six_refinement_audit.json','../cubic_structure/r36_orthogonal_six_catalogue.tex','../cubic_structure/r36_orthogonal_six_refinement.tex')

def main():
 assert json.loads((HERE/'symplectic_profiles.json').read_text())['profiles']==json.loads((HERE/'../structural/symplectic_profiles.json').read_text())['profiles']
 from orthogonal_six_catalogue import profiles as local_profiles
 spec=importlib.util.spec_from_file_location('r36_verified_parent_six',HERE/'../cubic_structure/orthogonal_six_catalogue.py');parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
 for b in range(1,8):
  for delta in(1,2,3,6):
   for classes in(((),),((2,3),),((),(2,3))):
    assert [sorted(x.items())for x in local_profiles(b,delta,classes)]==[sorted(x.items())for x in parent.profiles(b,delta,classes)]
 files=set(ENTRY)|set(PROOF_FILES)|set(TRACE_FILES);todo=list(files)
 while todo:
  name=todo.pop();path=HERE/name;assert path.exists(),name
  for node in ast.walk(ast.parse(path.read_text())):
   if isinstance(node,ast.Import):modules=[x.name for x in node.names]
   elif isinstance(node,ast.ImportFrom):modules=[node.module or'']
   else:continue
   for module in modules:
    local=module.split('.')[0]+'.py'
    if (HERE/local).exists()and local not in files:files.add(local);todo.append(local)
 for name in DATA:assert(HERE/name).is_file(),name;files.add(name)
 files.update(p.name for p in HERE.glob('r36_one_matrix16_*.tex'))
 for mode in('primary','E','small_pairs','tensor','higher_tensor','f8'):
  pattern=re.compile(rf'{mode}_\d+_\d+(?:_ledger\.jsonl|_replay\.json|\.jsonl|\.report\.json)$')
  directory=HERE/(mode+'_batches');assert directory.is_dir()
  files.update(str(p.relative_to(HERE))for p in directory.iterdir()if pattern.fullmatch(p.name))
  for producer_report in directory.glob(mode+'_*.report.json'):
   record=json.loads(producer_report.read_text())
   for filename,digest in record.get('producer_extension_sha256',{}).items():
    assert filename in files and hashlib.sha256((HERE/filename).read_bytes()).hexdigest()==digest,(producer_report.name,filename)
  if mode not in('primary','E'):files.add(mode+'_selected_state_ids.json')
 assert all((HERE/n).is_file()for n in files)
 (HERE/'RELEASE_FILES.txt').write_text('\n'.join(sorted(files))+'\n')
 files.add('RELEASE_FILES.txt')
 report=dict(schema='r36-rank16-proof-release-v1',scope='Complete field-duality input and all explicitly selected negative-certificate scopes; residual OPEN states are preserved.',files=[dict(file=n,bytes=(HERE/n).stat().st_size,sha256=hashlib.sha256((HERE/n).read_bytes()).hexdigest())for n in sorted(files)],external_bindings=[dict(file=n,sha256=hashlib.sha256((HERE/n).read_bytes()).hexdigest())for n in EXTERNAL])
 (HERE/'RELEASE_MANIFEST.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status='PASS_COMPLETE_SELECTED_RELEASE_MANIFEST',files=len(files),bytes=sum(x['bytes']for x in report['files']),external_bindings=len(EXTERNAL)),indent=2))
if __name__=='__main__':main()
