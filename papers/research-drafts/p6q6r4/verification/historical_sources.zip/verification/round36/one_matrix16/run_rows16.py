#!/usr/bin/env python3
"""Resumable bounded exact row-certificate production; OPEN is explicit."""
from collections import Counter
from pathlib import Path
import resource
import argparse,gzip,json,time,hashlib,sys
from row_engine16 import Engine,f8_perron
from orthogonal_six_catalogue import profiles as orth_profiles
HERE=Path(__file__).resolve().parent

def records(path):
 with gzip.open(path,'rt')as inp:
  for line in inp:yield json.loads(line)

def canonical_digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

PROOF_FILES=('run_rows16.py','verify_rows16.py','row_engine16.py','context16.py','trace_signature16.py','trace_rank16.py',
 'orthogonal_six_catalogue.py','fixed_field_rows.py','fixed_field_rows_original.py',
 'matrix_spectral_filter.py','bounded_remainder.py','norm_word_filter.py',
 'gap_filter.py','power_trace_filter.py','mixed_trace_filter.py','field_power_polynomials.py',
 'generic_fields.py','r32_trace_forms.py','fixed_lattice.py','orbit_pairs.py',
 'coupled_rows.py','refined_rows.py','field_discriminant_profiles.py',
 'linear_field_gate.py','linear_field_lattice.py','quadratic_character_gate.py',
 'imaginary_quadratic_gate.py','trace_rank15.py')

def source_digest():
 h=hashlib.sha256()
 for name in sorted(PROOF_FILES):h.update(name.encode()+b'\0'+(HERE/name).read_bytes()+b'\0')
 h.update((HERE/'symplectic_profiles.json').read_bytes())
 return h.hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,required=True);p.add_argument('--mode',choices=('primary','E','small_pairs','tensor','higher_tensor','f8'),default='primary');p.add_argument('--selected',type=Path);p.add_argument('--max-dimension',type=int,default=30);p.add_argument('--kernel',choices=('fast','original'),default='fast');p.add_argument('--resume',action='store_true');args=p.parse_args()
 selected=None if args.selected is None else set(json.loads(args.selected.read_text()))
 done=set();counts=Counter();raw=0;start=time.monotonic();proof=source_digest()
 if args.resume and args.output.exists():
  for line in args.output.read_text().splitlines():
   r=json.loads(line);assert r['scope_index']not in done;done.add(r['scope_index']);counts[r['certificate']['kind']if r['certificate']else'OPEN']+=1;raw+=r['raw_rows']
 with args.output.open('a'if args.resume else'w')as out:
  for rec in records(args.source):
   i=rec['scope_index']
   if i<args.start:continue
   if i>=args.stop:break
   if i in done or(selected is not None and rec['state']not in selected):continue
   begin=time.monotonic();eng=Engine(rec,rec['assignment'],rec['kind'],args.kernel)
   if args.mode=='primary':cert=eng.primary()
   elif args.mode=='E':
    pp=list(orth_profiles(rec['assignment']['q']+1,eng.ctx[2],eng.ctx[3]));assert pp and eng.ctx[2]==3 and eng.ctx[3]==((),)
    cert=eng.E_coupled()
   elif args.mode=='f8':cert=f8_perron(eng,args.max_dimension)
   else:
    f=eng.ctx[1];b=rec['assignment']['q']+3
    assert(args.mode=='small_pairs'and b in(3,4))or(args.mode=='tensor'and b in(5,6,7)and f in(36,40,60))or(args.mode=='higher_tensor'and b in(5,6,7)and f in(72,100,108))
    cert=eng.pure(args.max_dimension)
   ans={key:rec[key]for key in('state','scope_index','index','double_degree','assignment_index','kind')}
   ans.update(certificate=cert,mode=args.mode,level=eng.level,raw_rows=eng.raw,queries=eng.queries,seconds=round(time.monotonic()-begin,6),input_record_sha256=canonical_digest(rec))
   out.write(json.dumps(ans,separators=(',',':'))+'\n');out.flush();counts[cert['kind']if cert else'OPEN']+=1;raw+=eng.raw;done.add(i)
   if len(done)%100==0:print('scope',args.mode,'done',len(done),'last',i,'hist',dict(counts),'raw',raw,'seconds',round(time.monotonic()-start,2),flush=True)
 report=dict(status='COMPLETE_SELECTED_SOURCE_ROW_PRODUCER',mode=args.mode,start=args.start,stop=args.stop,records=len(done),histogram=dict(counts),raw_rows=raw,kernel=args.kernel,source_proof_sha256=proof,proof_unchanged=proof==source_digest(),maximum_resident_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,seconds=time.monotonic()-start)
 assert report['proof_unchanged']
 args.output.with_suffix('.report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
