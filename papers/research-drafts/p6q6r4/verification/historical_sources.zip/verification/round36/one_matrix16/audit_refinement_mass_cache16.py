#!/usr/bin/env python3
"""Exact cache-key controls and actual refinement-query trace benchmarks."""
from collections import Counter
from pathlib import Path
from random import Random
import argparse,gzip,hashlib,json,time
import run_refinement16 as reference
from row_engine16 import Engine,categories
from refinement_mass_cache16 import mass_witness,profile_minimum
from run_rows16 import canonical_digest
HERE=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'refinement_mass_cache_audit.json');args=p.parse_args()
 start=time.monotonic();rng=Random(360163);controls=0;records={};pairs=set()
 with gzip.open(HERE/'rank16_symplectic_input.jsonl.gz','rt')as inp:
  for line in inp:
   r=json.loads(line);f=5400//r['double_degree'];b=r['assignment']['q']+3
   if b in(3,4)or f in(36,40,60,72,100,108):pairs.add((f//4,b))
   if r['scope_index']in(232,462):records[r['scope_index']]=r
 original=reference.mass_witness
 for k,b in sorted(pairs):
  cats=categories(k,b)
  for iteration in range(8):
   lower={c:(3 if iteration==0 else 73 if iteration==1 else rng.randrange(3,74))for c in cats}
   assert mass_witness(k,b,lower)==original(k,b,lower)
   # Change just one bound, so an omitted cache-key dependency is exposed.
   for cat in rng.sample(list(cats),min(3,len(cats))):
    lower=dict(lower);lower[cat]=3+(lower[cat]-2)%71
    assert mass_witness(k,b,lower)==original(k,b,lower)
   controls+=1+min(3,len(cats))
 benchmarks=[]
 for index,r in sorted(records.items()):
  trace=[];reference_cpu=0.0
  def recording(k,b,lower,perron=False):
   nonlocal reference_cpu
   begin=time.process_time();ans=original(k,b,lower,perron);reference_cpu+=time.process_time()-begin
   trace.append((k,b,dict(lower),ans));return ans
  reference.mass_witness=recording
  try:
   engine=Engine(r,r['assignment'],r['kind'],'fast');cert,details=reference.refine(engine,False,72)
  finally:reference.mass_witness=original
  profile_minimum.cache_clear();begin=time.process_time()
  for k,b,lower,expected in trace:assert mass_witness(k,b,lower)==expected
  cached_cpu=time.process_time()-begin;info=profile_minimum.cache_info()
  benchmarks.append(dict(scope_index=index,input_record_sha256=canonical_digest(r),query_trace_length=len(trace),reference_mass_cpu_seconds=reference_cpu,cached_mass_cpu_seconds=cached_cpu,cache_hits=info.hits,cache_misses=info.misses,cache_maxsize=info.maxsize,cache_currsize=info.currsize,reference_certificate_sha256=canonical_digest(cert),reference_search=details,reference_raw_rows=engine.raw))
  print('BENCHMARK',index,'queries',len(trace),'CPU',round(reference_cpu,3),'cached',round(cached_cpu,3),flush=True)
 report=dict(status='PASS_EXACT_BOUNDED_PROFILE_CACHE_CONTROLS',perturbed_bound_controls=controls,actual_query_trace_controls=sum(x['query_trace_length']for x in benchmarks),benchmarks=benchmarks,source_sha256={n:hashlib.sha256((HERE/n).read_bytes()).hexdigest()for n in('audit_refinement_mass_cache16.py','refinement_mass_cache16.py','run_refinement16.py','row_engine16.py','symplectic_profiles.json')},seconds=time.monotonic()-start,scope='Producer-only bounded memoization; no missing row is accepted from this cache, and every negative still requires the preserved original checker.')
 args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
