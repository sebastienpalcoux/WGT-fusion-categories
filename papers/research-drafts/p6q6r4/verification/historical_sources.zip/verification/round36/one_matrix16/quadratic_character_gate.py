#!/usr/bin/env python3
"""Exact integral difference-column gates for full quadratic linear fields."""
from imaginary_quadratic_gate import full_discriminant,obstruction as imaginary_obstruction

def real_obstruction(assignment,kind):
    norm_two=[]
    for block in assignment['fields']:
        f=block['formal_codegree']
        for label in block['fields']:
            D=full_discriminant(label)
            if D is None or D<0:continue
            assert 2*f%D==0
            if D==2*f:
                return {'kind':'real_quadratic_difference_norm_one',
                        'formal_codegree':f,'field':label,'discriminant':D}
            if D==f:norm_two.append({'formal_codegree':f,'field':label,'discriminant':D})
    b=assignment['q']+(3 if kind=='symplectic'else 1);s=15-2*b
    if norm_two and 2*len(norm_two)>=s:
        return {'kind':'real_quadratic_norm_two_supports','source_pairs':b,
                'selfdual_nonunits':s,'orbit_count':len(norm_two),'orbits':norm_two}
    return None

def obstruction(assignment,kind):
    return imaginary_obstruction(assignment,kind)or real_obstruction(assignment,kind)

def main():
    from bounded_remainder import states,HERE
    from collections import Counter
    import json,time
    t0=time.monotonic();hist=Counter();duality=Counter();n=0
    with(HERE/'quadratic_character_exclusions.jsonl').open('w')as out:
        for ordinal,case,ai,a,kind in states(HERE/'rank15_trace_final.jsonl'):
            cert=obstruction(a,kind)
            if cert is None:continue
            r={'state':ordinal,'index':case['index'],'double_degree':case['double_degree'],
               'assignment_index':ai,'kind':kind,'level':0,'phase':'integral_quadratic_columns',
               'certificate':cert}
            out.write(json.dumps(r,separators=(',',':'))+'\n')
            n+=1;hist[cert['kind']]+=1;duality[kind]+=1
    report={'status':'COMPLETE_EXACT_STRUCTURAL_GATE','universe_states':125545,
            'excluded_states':n,'remaining_states':125545-n,
            'certificate_histogram':dict(hist),'duality_types':dict(duality),
            'seconds':time.monotonic()-t0}
    (HERE/'quadratic_character_gate_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
