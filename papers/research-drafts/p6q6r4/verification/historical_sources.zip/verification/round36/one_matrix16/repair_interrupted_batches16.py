#!/usr/bin/env python3
"""Preserve valid append-only prefixes after an intentional job interruption.

Only a malformed FINAL unterminated JSONL record may be removed. Its exact
bytes are retained beside the file. Malformed terminated/interior records
raise. A half-written final JSON report is renamed, never accepted as PASS.
Run only when all controllers writing this directory have stopped.
"""
from pathlib import Path
import argparse,hashlib,json,time

def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('directory',type=Path);args=p.parse_args();directory=args.directory.resolve();changes=[]
 for path in sorted(directory.glob('*.jsonl')):
  data=path.read_bytes();lines=data.splitlines(keepends=True);valid=0
  for i,line in enumerate(lines):
   try:json.loads(line)
   except(json.JSONDecodeError,UnicodeDecodeError):
    assert i==len(lines)-1 and not line.endswith(b'\n'),('Unexpected interior/terminated malformed record',path,i)
    tail=path.with_name(path.name+'.interrupted_tail');assert not tail.exists()
    tail.write_bytes(line);prefix=b''.join(lines[:i]);path.write_bytes(prefix)
    changes.append(dict(file=path.name,operation='removed_only_final_unterminated_record',original_sha256=sha(data),retained_prefix_sha256=sha(prefix),retained_records=i,saved_tail=tail.name))
   else:valid+=1
 for path in sorted(directory.glob('*.report.json'))+sorted(directory.glob('*_replay.json')):
  try:json.loads(path.read_bytes())
  except(json.JSONDecodeError,UnicodeDecodeError):
   renamed=path.with_name(path.name+'.interrupted');assert not renamed.exists();path.rename(renamed);changes.append(dict(file=path.name,operation='renamed_incomplete_final_report',saved_file=renamed.name))
 out=dict(status='PASS_VALIDATED_INTERRUPTED_JSON_PREFIXES',directory=str(directory),changes=changes,warning='This validates syntax and preserves prefixes; mathematical credit still requires certificate/replay coverage checks.')
 target=directory/f'interruption_repair_{int(time.time())}.json';target.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
