from pathlib import Path
from collections import Counter
import argparse,json,hashlib
HERE=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser();ap.add_argument('sources',type=Path,nargs='+');ap.add_argument('--output',type=Path,default=HERE/'complete_trace_fresh_verification.json');args=ap.parse_args();reports=[json.loads(p.read_text())for p in args.sources];reports.sort(key=lambda x:x['profile_start']);last=0;counts=Counter();duality=Counter();checks=Counter()
 for r in reports:
  assert r['status']=='PASS_COMPLETE_FIELD_TRACE_REPLAY_SHARD'and r['profile_start']==last;last=r['profile_stop'];counts.update({k:v for k,v in r['counts'].items()if k!='covered_placements'});duality.update(r['duality_counts']);checks.update(r['direct_rational_form_checks'])
 assert last==470747 and counts['replayed_placements']==1224166
 assert len({r['proof_sha256']for r in reports})==len({r['input_uncompressed_sha256']for r in reports})==1
 out=dict(status='PASS_COMPLETE_FIELD_TRACE_REPLAY',profiles=470747,counts=dict(counts),duality_counts=dict(duality),direct_rational_form_checks_per_shard_sum=dict(checks),proof_sha256=reports[0]['proof_sha256'],input_uncompressed_sha256=reports[0]['input_uncompressed_sha256'],shards=[dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in args.sources])
 args.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
