#!/usr/bin/env python3
"""Independent exact audit of the rank-independent split E obstruction.

No producer routine is imported. This audit uses the opposite rational
coordinate normalization, H=diag(1,3), and derives the cones by row reduction.
It checks finite arithmetic and identities; the TeX supplies the general
based-ring proof, including reciprocity and the character norm decomposition.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import hashlib
import json

HERE = Path(__file__).resolve().parent
I = ((1, 0), (0, 1))
ZERO = ((0, 0), (0, 0))


def scale(c, a):
    return tuple(tuple(c * x for x in row) for row in a)


def add(a, b):
    return tuple(tuple(a[i][j] + b[i][j] for j in range(2)) for i in range(2))


def mul(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(2))
                       for j in range(2)) for i in range(2))


def star(a):
    h = (1, 3)
    return tuple(tuple(F(a[j][i]) * h[j] / h[i] for j in range(2))
                 for i in range(2))


def trace(a):
    return a[0][0] + a[1][1]


def flat(a):
    return [a[i][j] for i in range(2) for j in range(2)]


def rref(rows, variables):
    rows = [[F(x) for x in row] for row in rows]
    row = 0
    pivots = []
    for col in range(variables):
        choice = next((i for i in range(row, len(rows)) if rows[i][col]), None)
        if choice is None:
            continue
        rows[row], rows[choice] = rows[choice], rows[row]
        divisor = rows[row][col]
        rows[row] = [x / divisor for x in rows[row]]
        for other in range(len(rows)):
            if other == row or not rows[other][col]:
                continue
            coefficient = rows[other][col]
            rows[other] = [x - coefficient * y for x, y in zip(rows[other], rows[row])]
        pivots.append(col)
        row += 1
        if row == len(rows):
            break
    assert all(not any(x[:-1]) and not x[-1] for x in rows[row:])
    return rows[:row], pivots


def cone_equations(matrices, target, selfdual=False):
    columns = list(map(flat, matrices))
    rhs = flat(target)
    rows = [[columns[j][i] for j in range(6)] + [rhs[i]] for i in range(4)]
    if selfdual:
        rows += [[0, 0, 1, -1, 0, 0, 0], [0, 0, 0, 0, 1, -1, 0]]
    return rref(rows, 6)


def main():
    matrix_records = []
    for tau in (-1, 1):
        pmat = scale(tau, ((2, 0), (0, 0)))
        qmat = scale(tau, ((-1, 0), (0, 1)))
        u = scale(-tau, ((0, 0), (1, 1)))
        v = scale(-tau, ((0, -3), (0, 1)))
        matrices = (pmat, qmat, u, star(u), v, star(v))
        assert star(pmat) == pmat and star(qmat) == qmat
        assert all(star(star(a)) == a for a in matrices)
        for a in matrices:
            for b in matrices:
                assert star(mul(a, b)) == mul(star(b), star(a))
        assert trace(mul(u, star(u))) == 4
        assert mul(u, star(u)) == ((0, 0), (0, 4))
        assert mul(u, u) == scale(-tau, u)
        difference = trace(mul(mul(u, star(u)), mul(u, star(u)))) - trace(
            mul(mul(u, u), star(mul(u, u))))
        assert difference == 12 and F(difference, 6) == 2

        zero_rows, pivots = cone_equations(matrices, ZERO)
        expected = [[1, 0, 0, 0, -1, -1, 0],
                    [0, 1, 0, 0, -2, -2, 0],
                    [0, 0, 1, 0, 0, -1, 0],
                    [0, 0, 0, 1, -1, 0, 0]]
        assert pivots == [0, 1, 2, 3] and zero_rows == expected
        u_rows, u_pivots = cone_equations(matrices, u)
        expected_u = [row[:] for row in expected]
        expected_u[2][-1] = 1
        assert u_pivots == pivots and u_rows == expected_u
        square_rows, square_pivots = cone_equations(
            matrices, add(mul(u, star(u)), scale(-1, I)), selfdual=True)
        expected_square = [[1, 0, 0, 0, 0, -2, tau],
                           [0, 1, 0, 0, 0, -4, 3*tau],
                           [0, 0, 1, 0, 0, -1, 0],
                           [0, 0, 0, 1, 0, -1, 0],
                           [0, 0, 0, 0, 1, -1, 0]]
        assert square_pivots == [0, 1, 2, 3, 4] and square_rows == expected_square
        matrix_records.append(dict(tau=tau, zero_cone_rref=expected,
                                   image_U_cone_rref=expected_u,
                                   selfdual_square_rref=expected_square,
                                   matrix_norm_difference=12,
                                   based_ring_norm_difference=2))

    records = []
    # Four distinct pair labels of dimension p already give 4p^2 <=5400.
    # The explicit bound36 therefore covers every integral p, independently
    # of any rank-sixteen input generator.
    for tau in (1, -1):
        for p in range(3, 37):
            dP, dQ = 2*p-tau, 4*p-tau
            core = 1 + dP*dP + dQ*dQ + 4*p*p
            if core > 5400:
                continue
            M = 5400-core
            L = dP + 2*dQ + 2*p
            assert L == 12*p-3*tau
            base = 1+dP+3*dQ if tau == 1 else 1+dP+dQ+4*p
            assert base == (14*p-3 if tau == 1 else 10*p+3)
            r = p*p-base
            item = dict(tau=tau, p=p, core_mass=core, zero_image_mass=M,
                        kernel_generator_dimension=L, minimal_active_dimension=base,
                        remainder_dimension=r)
            if r < 0:
                item['exclusion'] = 'active_dimension'
                records.append(item)
                continue
            assert r < 2*L, 'Another active allocation would need separate treatment.'
            cap = (p*r)//L
            item.update(remainder_norm_cap=cap, remainder_Cauchy_gap=r*r-M*cap)
            if r*r > M*cap:
                item['exclusion'] = 'remainder_Cauchy'
                records.append(item)
                continue
            assert tau == -1 and p in (12, 13)
            assert p*p < p+L
            active_square_norm = 1+1+1+4
            T_cap = active_square_norm + cap - 1 - 2
            assert T_cap == 4+cap
            T_dimension = p*p-p
            assert T_dimension*T_dimension > M*T_cap
            item.update(exclusion='square_norm_Cauchy', square_remainder_dimension=T_dimension,
                        square_remainder_norm_cap=T_cap,
                        square_Cauchy_left=T_dimension*T_dimension,
                        square_Cauchy_right=M*T_cap)
            records.append(item)
    assert len(records) == 25
    counts = Counter(r['exclusion'] for r in records)
    assert counts == {'active_dimension': 19, 'remainder_Cauchy': 4, 'square_norm_Cauchy': 2}
    producer = json.loads((HERE / 'orthogonal_E_cone_exclusion_audit.json').read_text())
    assert producer['status'] == 'PASS_EXACT_ORTHOGONAL_E_CONE_EXCLUSION_AUDIT'
    other = {(r['tau'], r['p']): r for r in producer['parameters']}
    assert len(other) == 25 and set(other) == {(r['tau'], r['p']) for r in records}
    names = {'active_dimension': 'UUstar_active_dimension',
             'remainder_Cauchy': 'zero_image_remainder_Cauchy',
             'square_norm_Cauchy': 'U_square_norm_Cauchy'}
    for row in records:
        saved = other[row['tau'], row['p']]
        assert saved['active_squared_mass'] == row['core_mass']
        assert saved['zero_image_squared_mass'] == row['zero_image_mass']
        assert saved['positive_kernel_mass'] == row['kernel_generator_dimension']
        assert saved['least_UUstar_dimension'] == row['minimal_active_dimension']
        assert saved['exclusion'] == names[row['exclusion']]
        if row['exclusion'] != 'active_dimension':
            assert saved['remainder_dimension'] == row['remainder_dimension']
            assert saved['remainder_norm_cap'] == row['remainder_norm_cap']
    bound = ('r36_orthogonal_E_cone_exclusion.tex', 'verify_orthogonal_E_cone.py',
             'orthogonal_E_cone_exclusion_audit.json', 'audit_orthogonal_E_mass.py')
    report = dict(status='PASS_INDEPENDENT_SPLIT_E_DIMENSION_AUDIT',
                  method='Independent H=diag(1,3) rational matrices; literal coefficient equations and exact RREF; complete dimension range from the four pair labels; integer Cauchy checks.',
                  rank_bound_used=False, full_linear_field_assignment_used=False,
                  matrix_checks=matrix_records, parameters=records, exclusions=dict(counts),
                  source_sha256={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in bound},
                  formal_proof_assistant_verification=False)
    (HERE / 'orthogonal_E_mass_independent_audit.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(status=report['status'], parameters=25, exclusions=dict(counts)), indent=2))


if __name__ == '__main__':
    main()
