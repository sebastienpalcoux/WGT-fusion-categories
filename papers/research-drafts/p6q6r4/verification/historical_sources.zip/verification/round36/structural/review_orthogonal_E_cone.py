#!/usr/bin/env python3
"""Independent, source-bound review of the rank-independent split E proof.

No mathematical producer or verifier is imported.  The small exact check
compares every previously audited signed E support with the displayed
normal form and independently reproduces the two norm/mass contradictions.
The accompanying findings record the mathematical necessity review.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from itertools import permutations,product
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
ROUND=HERE.parent

def mul(a,b):
    return (a[0]*b[0]+a[1]*b[2],a[0]*b[1]+a[1]*b[3],
            a[2]*b[0]+a[3]*b[2],a[2]*b[1]+a[3]*b[3])

def star(a):return(a[0],a[2]/3,3*a[1],a[3])
def tr(a):return a[0]+a[3]
def norm(a):return tr(mul(a,star(a)))

def matrices(tau):
    P=tuple(map(F,(2*tau,0,0,0)))
    Q=tuple(map(F,(-tau,0,0,tau)))
    U=tuple(map(F,(0,0,-3*tau,-tau)))
    V=tuple(map(F,(0,tau,0,-tau)))
    return(P,Q,U,star(U),V,star(V))

def determinant(rows):
    n=len(rows)
    return sum((-1)**sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))
               *product_entries(rows,p) for p in permutations(range(n)))

def product_entries(rows,p):
    value=F(1)
    for i,j in enumerate(p):value*=rows[i][j]
    return value

def signed_support_check():
    catalogue=json.loads((ROUND/'cubic_structure/orthogonal_six_catalogue.json').read_bytes())
    counts=Counter();witnesses=[]
    for index,state in enumerate(catalogue['states']):
        if state['family']!='E' or not state['positive']:continue
        counts['positive_E_states']+=1
        d=state['duality'];t=state['traces'];g=state['gram']
        P=next(i for i in range(6) if abs(t[i])==2)
        Q=next(i for i in range(6) if t[i]==0);tau=t[P]//2
        pairs=[(i,j) for i,j in enumerate(d) if i<j]
        assert d[P]==P and d[Q]==Q and len(pairs)==2
        pair_traces={t[i] for pair in pairs for i in pair}
        assert len(pair_traces)==1
        pair_trace=next(iter(pair_traces));assert pair_trace in (-tau,tau)
        if pair_trace==tau:
            # Unit/Perron orthogonality becomes 1+tau*(dP+p1+p2)=0.
            # All three dimensions are at least one, so neither sign works.
            counts['excluded_by_unit_positive_dimension_relation']+=1
            continue
        images=matrices(tau)
        target=[[2*tr(mul(a,star(b)))-tr(a)*tr(b) for b in images] for a in images]
        matches=[]
        for order in permutations(pairs):
            for flips in product((0,1),repeat=2):
                perm=[P,Q]+[i for pair,flip in zip(order,flips)
                            for i in pair[::(-1 if flip else 1)]]
                if all(g[perm[i]][perm[j]]==target[i][j] for i in range(6) for j in range(6)):
                    matches.append(perm)
        assert matches,(index,state)
        counts['normal_form_matches']+=1
        witnesses.append({'catalogue_state_index':index,'tau':tau,
                          'target_label_order_P_Q_U_Ustar_V_Vstar':matches[0]})
    assert dict(counts)=={'positive_E_states':144,
        'excluded_by_unit_positive_dimension_relation':96,'normal_form_matches':48}
    return dict(counts),witnesses

def elementary_checks():
    for tau in (-1,1):
        P,Q,U,Us,V,Vs=images=matrices(tau)
        assert star(P)==P and star(Q)==Q
        assert all(star(star(a))==a for a in images)
        assert determinant(tuple(zip(P,Q,U,Us)))!=0
        # Four independent image columns and two independent kernel vectors
        # establish the full two-dimensional coefficient kernel.
        for coeff in ((1,2,0,1,1,0),(1,2,1,0,0,1)):
            assert all(sum(c*a[j] for c,a in zip(coeff,images))==0 for j in range(4))
        assert mul(U,Us)==(0,0,0,4)
        assert mul(U,U)==tuple(-tau*x for x in U)
        assert (norm(mul(U,Us))-norm(mul(U,U)))/6==2
    values=[];histogram=Counter()
    for tau in (-1,1):
        for p in range(3,74):
            dP,dQ=2*p-tau,4*p-tau
            S=1+dP*dP+dQ*dQ+4*p*p
            if S>5400:continue
            M=5400-S;L=dP+2*dQ+2*p
            n=0 if tau==1 else 1
            a,b=2*n+tau,4*n+3*tau
            B=1+a*dP+b*dQ+4*n*p
            rec={'tau':tau,'p':p,'S':S,'M':M,'L':L,'B':B}
            if B>p*p:stage='active_dimension'
            else:
                r=p*p-B;assert r<2*L;cap=p*r//L
                rec.update(r=r,R_squared_norm_cap=cap,first_gap=r*r-M*cap)
                if r*r>M*cap:stage='first_Cauchy'
                else:
                    assert tau==-1 and p in (12,13) and p*p<p+L
                    left=(p*p-p)**2;right=M*(4+cap)
                    assert left>right
                    rec.update(second_lhs=left,second_rhs=right)
                    stage='second_Cauchy'
            rec['exclusion']=stage;histogram[stage]+=1;values.append(rec)
    assert len(values)==25 and dict(histogram)=={
        'active_dimension':19,'first_Cauchy':4,'second_Cauchy':2}
    return values,dict(histogram)

def main():
    counts,witnesses=signed_support_check();parameters,histogram=elementary_checks()
    names=('structural/review_orthogonal_E_cone.py',
        'structural/r36_orthogonal_E_cone_exclusion.tex',
        'structural/verify_orthogonal_E_cone.py',
        'structural/orthogonal_E_cone_exclusion_audit.json',
        'cubic_structure/r36_orthogonal_six_catalogue.tex',
        'cubic_structure/r36_orthogonal_six_refinement.tex',
        'cubic_structure/orthogonal_six_catalogue.json',
        'cubic_structure/orthogonal_six_independent_audit.json',
        'cubic_structure/orthogonal_six_refinement_audit.json')
    findings=[
      'Normal-form completeness was derived independently. In a real orthonormal model write A=diag(1,-1) and B=[[0,1],[1,0]]. Diagonalizing P gives P0=tau*A. The trace relation gives U0+V0=P0. Their equal squared pure norms force U0=(tau/2)*A+(sqrt(3)/2)*B and V0=(tau/2)*A-(sqrt(3)/2)*B, up to exchanging pair names or reflecting the coordinate. The fixed-frame identity gives Q0=+/-P0, and the positive dimension relation forces Q0=-P0. Each skew part is independently +/-sqrt(3)/2 times the standard alternating matrix. Choosing each pair representative and rescaling the first coordinate by sqrt(3) produces exactly the displayed H=diag(3,1) matrices. Thus every allowed signed E support is covered, without an assumption about linear fields.',
      'The complete previously independently audited catalogue has 144 positive normalized E states. The unit/Perron relation excludes 96 same-trace-sign states. Every one of the remaining 48 states matches the displayed Gram and trace data after a pair permutation and independent pair-representative choices; explicit matching orders are recorded. This finite comparison supplements the algebraic normal-form argument and does not replace it.',
      'The coefficient kernel is exactly generated by (1,2,0,1,1,0) and (1,2,1,0,0,1) in the order P,Q,U,U*,V,V*. The P,Q,U,U* matrix columns are linearly independent. The two free coordinates are the nonnegative coefficients of V,V*, so every positive zero-image object without a unit has exactly the asserted nonnegative kernel-cone active part. The analogous image-U cone is U plus that same cone.',
      'UU* is selfdual and has unit coefficient one. Its full active part must therefore have equal coefficients on each dual pair. Comparing entries yields nprime=n, a=2n+tau, b=4n+3tau. Positivity gives nmin=0 for tau=1 and nmin=1 for tau=-1. Dimension increments are exactly 2L. The residual bound r<2L forces the least active part in all six dimension-surviving parameters.',
      'For every zero-image simple D, including a nonselfdual one, Frobenius reciprocity gives N_(D,U)^U=N_(U,U*)^D=m_D. No replacement of D by D* is needed. Also [DU:1]=0 because D differs from U*, whose matrix image is nonzero. Hence DU lies in the no-unit positive zero-image cone and its coefficient of U forces active dimension at least m_D*L. This proves p*d_D>=m_D*L for each individual D.',
      'The remainder R is supported on individually zero-image labels after the complete active part is removed. Summing m_D times the preceding inequality gives ||R||^2<=p*r/L, and the integer norm permits the floor. M=5400-S is the squared dimension mass of every zero-image simple, whether or not it occurs in R and with both members of each nonselfdual pair counted separately. Thus r^2<=(sum_all_zero d_D^2)*(sum_all_zero m_D^2)=M*||R||^2 is valid; enlarging to all zero labels only weakens the bound.',
      'For tau=-1 and p=12 or13, E(U^2)=E(U). Since U is nonselfdual, U^2 has no unit. The complete image-U cone and p^2<p+L force U^2=U+T with T supported on individually zero-image labels and d_T=p^2-p.',
      'The coefficient trace decomposes as sum_E Tr(E(a))/f_E. The unique nonlinear block has formal codegree6 and contributes exactly (Tr((E(U)E(U)*)^2)-Tr(E(U)^2(E(U)*)^2))/6=(16-4)/6=2. Every linear component cancels separately because both terms equal |chi(U)|^4, including nonreal linear characters; no rationality assumption is used. Thus ||UU*||^2-||U^2||^2=2 exactly.',
      'The least tau=-1 active part has seven distinct simple terms of coefficient one. Orthogonality of the basis and disjoint active/zero-image supports give (7+||R||^2)-(1+||T||^2)=2, hence ||T||^2=4+||R||^2. T need not be selfdual. Applying Cauchy to its coefficient vector on the same complete zero-image basis gives (p^2-p)^2<=M*(4+floor(p*r/L)). Both remaining parameters violate this inequality.',
      'The parameter universe uses only integrality, minimum nonunit dimension three and total dimension5400. No source rank restriction, center assumption, linear-field assignment, or numerical optimizer is used. After E is excluded, the nonsplit B_(2,3) conclusion follows from the complete orthogonal catalogue A,B,D,E.']
    report={'status':'PASS','review_kind':'Independent mathematical and exact small-control review of the rank-independent split-E exclusion',
      'formal_proof_assistant_verification':False,'source_sha256':{name:sha256((ROUND/name).read_bytes()).hexdigest() for name in names},
      'normal_form_coverage_counts':counts,'normal_form_matching_witnesses':witnesses,
      'independently_checked_parameters':parameters,'exclusion_histogram':histogram,
      'necessity_findings':findings,
      'scope':'Integral source dimension5400, minimum nonunit simple dimension3, unique nonlinear component M2(C) of formal codegree6 with orthogonal positive involution. Pattern E is excluded at every source rank. Other orthogonal patterns are not excluded by this theorem.'}
    output=HERE/'orthogonal_E_cone_independent_review.json'
    output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':report['status'],'normal_form_coverage':counts,'parameter_count':len(parameters),'exclusions':histogram},indent=2))

if __name__=='__main__':main()
