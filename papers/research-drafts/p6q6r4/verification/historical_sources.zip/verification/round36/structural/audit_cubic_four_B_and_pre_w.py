#!/usr/bin/env python3
"""Independent exact audit of both B enumerations, before and after W40.

This does not import either producer. The matrix kernel is parametrized by
the pair multiplicity and the second selfdual coefficient, and residual
dimension/trace possibilities are sets, rather than the producer bitsets.
"""
from pathlib import Path
from itertools import product
from math import isqrt
from collections import Counter
import hashlib,json,time
HERE=Path(__file__).resolve().parent
CUBIC=HERE.parent/'cubic_structure'

def tails(n,m,minimum=5):
    if n==0:
        return [()]if m==0 else[]
    out=[]
    for d in range(minimum,isqrt(max(0,m//n))+1):
        for t in tails(n-1,m-d*d,d):out.append((d,)+t)
    return out

def inputs(pre):
    answer=set()
    for p in range(5,34):
        for z in range(59):
            if (z+p)%2:continue
            u=10+z;v=20-u
            x=((u+p)//2,(u-p)//2,(v+p)//2,(v-p)//2)
            if any(abs(q)<5 for q in x):continue
            if z>=p+20:mu=z+10
            elif p>=z+20:mu=3*p+10
            else:
                assert z==p
                mu=p+10
            if mu>(37 if pre else 97):continue
            if pre:
                for d in range(7,21):
                    e=40-d
                    for n in range(3):
                        for extra in tails(n,4986-z*z-3*p*p-d*d-e*e):answer.add((14+n,p,z,x,(d,e)+extra))
            else:
                for n in range(4):
                    for extra in tails(n,3386-z*z-3*p*p):answer.add((13+n,p,z,x,extra))
    return answer

def zero_coefficients(mass,dims):
    # Enumerate a Cartesian coefficient box with the final coordinate forced.
    if not dims:
        if mass==0:yield()
        return
    for q in product(*(range(mass//d+1)for d in dims[:-1])):
        remaining=mass-sum(a*b for a,b in zip(q,dims[:-1]))
        if remaining>=0 and remaining%dims[-1]==0:yield q+(remaining//dims[-1],)

def matrix_rows(x,p,zeros,mass,rho):
    if mass<0:return
    dims=tuple(abs(t)for t in x);s=tuple(1 if t>0 else -1 for t in x)
    for k in range(mass//(2*p)+1):
        for n2 in range(mass//dims[1]+1):
            f2=s[1]*n2;f1=f2+k
            n=(s[0]*f1,n2,s[2]*(rho-f2),s[3]*(rho-f1))
            if min(n)<0:continue
            # Literal matrix trace and two independent fixed-plane equations.
            f=tuple(a*b for a,b in zip(n,s))
            assert sum(f)==2*rho and f[0]-f[1]==k and f[2]-f[3]==k
            rem=mass-sum(a*b for a,b in zip(n,dims))-2*p*k
            if rem<0:continue
            for q in zero_coefficients(rem,zeros):yield n+(k,k)+q

def trace_possible(x,p,zeros,mass,trace):
    if mass<0:return False
    generators={(abs(q),1 if q>0 else -1)for q in x}|{(2*p,0)}|{(d,0)for d in zeros}
    states=[set()for _ in range(mass+1)];states[0].add(0)
    for m in range(mass+1):
        for d,s in generators:
            if m+d<=mass:states[m+d].update(t+s for t in states[m])
    return trace in states[mass]

def audit_records(pre):
    path=HERE/'cubic_four_pre_w_certificates.json' if pre else CUBIC/'cubic_four_e11_B_certificates.json'
    data=json.loads(path.read_text());records=data['B_certificates']if pre else data['certificates'];seen=set();replayed=Counter()
    for rec in records:
        c=rec['input'];cert=rec['certificate'];x=tuple(c['x']if pre else c['signed_dimensions']);p=c['p'];z=c['z']
        original_zero=tuple(c['zeros']if pre else c['extras']);seen.add((c['rank'],p,z,x,original_zero))
        assert cert['excluded']
        zeros=original_zero if pre else(40,)+original_zero
        if pre and cert['stage']=='P74_scalar_cone':
            assert not list(matrix_rows(x,p,zeros,74,2)),c
            replayed['no_scalar_P74']+=1;continue
        if pre:
            assert list(matrix_rows(x,p,zeros,74,2)),c
            test=cert['tested'][-1];j=test['index'];massdim=test['dimension'];v=int(test['in_V'])
            t=3 if j<4 else 4 if j==4 else 0
        else:
            old=cert['missing_index'];massdim=cert['missing_dimension'];v=0
            # Producer order is [W,A1..A4,M,M*,extras]. Audit order puts W
            # with the other zero images, after [A1..A4,M,M*].
            j=old-1 if 1<=old<=6 else old
            t=3 if 1<=old<=4 else 4 if old==5 else 0
        rows=eligible=0
        for row in matrix_rows(x,p,zeros,4*massdim-23*v,v):
            rows+=1;cdiag=row[j]
            if cdiag>3:continue
            a=2*v*v+sum(n*n for n in row)-1-cdiag
            rem=massdim*massdim-13-23*a-12*cdiag
            if a<0 or rem<0:continue
            eligible+=1
            assert not trace_possible(x,p,zeros,rem,t-2+2*a),(pre,rec,row,rem)
        replayed['missing_product']+=1;replayed['coefficient_rows']+=rows;replayed['norm_eligible_rows']+=eligible
    assert seen==inputs(pre),(pre,len(seen),len(inputs(pre)))
    return dict(inputs=len(seen),counts=dict(replayed),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def main():
    started=time.monotonic();result={'status':'PASS','A_pre_W40':audit_A(),'pre_W40':audit_records(True),'W40_simple':audit_records(False),
                                   'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    result['seconds']=time.monotonic()-started
    (HERE/'cubic_four_B_and_pre_w_independent_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

def audit_A():
    data=json.loads((HERE/'cubic_four_pre_w_certificates.json').read_text())
    seen=set(); passing=[];three=set()
    for a in range(5,73):
        for p in range(5,52):
            for q in range(5,p+1):
                same=(p+q==10)
                if not same and p-q!=10:continue
                if 4*p>74:continue
                for d in range(7,21):
                    e=40-d;rem=5086-3*a*a-2*p*p-2*q*q-d*d-e*e
                    for n in (0,1):
                        for extra in tails(n,rem):
                            zeros=(d,e)+extra;seen.add((a,p,q,zeros))
                            for u in range(74//(2*p)+1):
                                v=(2-u)if same else(u-2)
                                if v<0:continue
                                for active in range(74//(3*a)+1):
                                    rest=74-2*p*u-2*q*v-3*a*active
                                    if rest<0:continue
                                    for coeff in zero_coefficients(rest,zeros):passing.append((a,p,q,zeros,(active,u,v)+coeff))
        for d in range(7,27):
            for e in range(d,27):
                g=40-d-e
                if g<e:continue
                if 3*a*a+d*d+e*e+g*g==4986:three.add((a,(d,e,g)))
    expected={(c['a'],c['p'],c['q'],tuple(c['zeros']))for c in data['A2_inputs']}
    assert seen==expected and len(seen)==27
    assert passing==[(35,16,6,(19,21,5),(0,2,0,0,0,2))]
    assert three=={(38,(7,11,22))}
    assert list(zero_coefficients(20,(19,21,5)))==[(0,0,4)]
    # Both pair coefficients must agree for zero image; their first possible
    # mass is 2(16+6)=44. The active selfdual triple costs105.
    assert 2*(16+6)>20 and 3*35>20
    assert 4*7-(11+12)==5<2*5
    return {'two_summand_descriptions':27,'scalar_P74_remaining':1,'three_summand_descriptions':1,'all_excluded':True}

if __name__=='__main__':main()
