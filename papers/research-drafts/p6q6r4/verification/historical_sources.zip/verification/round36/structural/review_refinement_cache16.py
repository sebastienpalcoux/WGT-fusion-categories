#!/usr/bin/env python3
"""Independent source-bound review of the producer cache and prefix pipeline.

Only small exact cache-key/mutation controls run here.  No source row search
or missing-row certificate is produced.  The frozen original checker is
still the authority for every actual negative certificate.
"""
from pathlib import Path
from hashlib import sha256
from math import isqrt
import json,sys

HERE=Path(__file__).resolve().parent
ROUND=HERE.parent
MODULE=ROUND/'one_matrix16'
sys.path.insert(0,str(MODULE))
import run_refinement16 as core
import refinement_mass_cache16 as cache
import run_refinement_cached16 as wrapper
from row_engine16 import categories,pure_profiles
from run_rows16 import source_digest

def profile_bounds(k,b,profile,lower):
    groups={(True,0)} if 15-2*b else set()
    groups.update((False,g) for g in profile)
    return tuple((sd,g,tuple(lower[sd,h,g]
                   for h in range(isqrt(min((2*k-1)//(1 if sd else 2),2*k-1-g))+1)))
                 for sd,g in sorted(groups))

def controls():
    counts={'mass_and_witness_equalities':0,'caller_mutation_controls':0,
            'changed_key_controls':0,'irrelevant_bound_reuse_controls':0,
            'perron_bypass_controls':0}
    assert cache.profile_minimum.cache_parameters()=={'maxsize':16384,'typed':False}
    assert core.mass_witness is wrapper.original_witness
    for k,b in ((2,4),(9,3),(9,5),(18,5)):
        cats=categories(k,b)
        for offset in (0,1,14):
            lower={cat:3+offset+(sum(map(int,cat))%4) for cat in cats}
            expected=core.mass_witness(k,b,lower)
            actual=cache.mass_witness(k,b,lower)
            assert actual==expected
            counts['mass_and_witness_equalities']+=1
            if actual[1] is not None:
                # A caller receives a fresh Counter, not the cached tuple.
                actual[1].clear()
                assert cache.mass_witness(k,b,lower)==expected
                counts['caller_mutation_controls']+=1
    k,b=9,5
    profile=pure_profiles(k,b)[0]
    assert isinstance(profile,tuple) and all(type(g)is int for g in profile)
    lower={cat:3 for cat in categories(k,b)}
    bounds=profile_bounds(k,b,profile,lower)
    assert all(isinstance(values,tuple) for sd,g,values in bounds)
    cache.profile_minimum.cache_clear()
    original=cache.profile_minimum(k,b,profile,bounds)
    assert isinstance(original,tuple) and isinstance(original[1],tuple)
    assert all(isinstance(cat,tuple) for cat in original[1])
    assert cache.profile_minimum(k,b,profile,bounds)==original
    assert cache.profile_minimum.cache_info().hits==1
    sd,g,values=bounds[0];changed=list(bounds)
    changed[0]=(sd,g,(values[0]+1,)+values[1:])
    cache.profile_minimum(k,b,profile,tuple(changed))
    assert cache.profile_minimum.cache_info().misses==2
    counts['changed_key_controls']+=1
    used={(sd,h,g) for sd,g,values in bounds for h in range(len(values))}
    unused=set(lower)-used
    assert unused
    modified=dict(lower);modified[next(iter(unused))]=73
    same_bounds=profile_bounds(k,b,profile,modified)
    assert same_bounds==bounds
    assert cache.profile_minimum(k,b,profile,same_bounds)==original
    assert cache.profile_minimum.cache_info().hits==2
    counts['irrelevant_bound_reuse_controls']+=1
    for b in (4,7):
        lower={cat:3 for cat in categories(2,b)}
        before=cache.profile_minimum.cache_info()
        assert wrapper.dispatch(2,b,lower,True)==core.mass_witness(2,b,lower,True)
        assert cache.profile_minimum.cache_info()==before
        counts['perron_bypass_controls']+=1
    assert core.mass_witness is wrapper.original_witness
    cache.profile_minimum.cache_clear()
    return counts

def main():
    names=('structural/review_refinement_cache16.py',
        'one_matrix16/refinement_mass_cache16.py',
        'one_matrix16/run_refinement_cached16.py',
        'one_matrix16/prepare_refinement_prefix16.py',
        'one_matrix16/batch_refinement_prefix16.py',
        'one_matrix16/batch_rows16.py',
        'one_matrix16/run_refinement16.py',
        'one_matrix16/finish_reduction16.py',
        'one_matrix16/row_engine16.py',
        'one_matrix16/run_rows16.py',
        'one_matrix16/verify_rows16.py',
        'one_matrix16/symplectic_profiles.json',
        'one_matrix16/audit_refinement_mass_cache16.py',
        'one_matrix16/refinement_mass_cache_audit.json',
        'one_matrix16/build_release_manifest16.py')
    hashes={name:sha256((ROUND/name).read_bytes()).hexdigest() for name in names}
    proof=source_digest()
    assert hashes['one_matrix16/run_refinement16.py']=='57fdfe815549cb8cff1c5f00d632fec054ae944f0cf473baf2fef886290be3c3'
    assert hashes['one_matrix16/finish_reduction16.py']=='281c3972a8b5f6f92fd8f2cc0d5ef0fe5aeb230c36d628c7ff16466a9c14f11c'
    checked=controls()
    audit=json.loads((MODULE/'refinement_mass_cache_audit.json').read_bytes())
    assert audit['status']=='PASS_EXACT_BOUNDED_PROFILE_CACHE_CONTROLS'
    assert audit['perturbed_bound_controls']==1088 and audit['actual_query_trace_controls']==3551
    for filename,expected in audit['source_sha256'].items():
        assert sha256((MODULE/filename).read_bytes()).hexdigest()==expected
    findings=[
      'The cached quantity is purely an arithmetic minimum for one fixed pure profile. Its entire dependence is included in the immutable key: k, b, the full ordered tuple of pair slice norms including repeated entries and zero padding, and the tuple of all categorical lower bounds used in that profile. Scalar-field and source-state information enters this calculation only through those lower bounds, so reuse across different states with the same key is valid.',
      'pure_profiles returns tuples of integer tuples in every branch. For a given profile, every h permitted by the original DP has its lower bound in the key; the h bound is isqrt(min((2k-1)/weight,2k-1-g)). Bounds for categories absent from the profile can be omitted because no term of that profile depends on them. The cache-key mutation controls confirm a changed relevant bound causes a distinct key and a changed irrelevant bound safely reuses the original key.',
      'The cached per-profile DP preserves the original slot order, h iteration order, dictionary insertion order, strict less-than tie update, trace budget2k-1, and weights1/2. The outer profile iteration and strict comparison also match. Consequently it returns the same minimizing witness as well as the same mass, including ties and empty-profile cases. The return value is an immutable integer/tuple pair; a new Counter is constructed for each caller, so mutation of a returned Counter cannot corrupt cached data.',
      'The LRU bound is16384 entries. Eviction only causes recomputation of the same exact minimum. It cannot change a mathematical result or turn a missing row into a claimed fact. This cache is outside the frozen negative proof closure.',
      'The thin wrapper dispatches only the pure-profile mass query to the cache. Every f8 Perron query goes to the saved original formula, and the exact compression formulas remain unchanged. The producer mass_witness global is restored in a finally block; merely importing the wrapper does not replace the core function. Both core source and extension source hashes are checked before and after the producer and recorded in its completed report.',
      'The optional batch flag selects the wrapper only when refinement-runner is enabled. With that flag absent, the historical primary/E and uncached secondary paths retain their original entrypoints. The fixed core producer and finish_reduction16 hashes remain exactly those of the preceding independent review; the frozen negative proof digest is unchanged.',
      'The prefix preparer accepts only a contiguous chain of completed primary batch spans starting at0. A gap or overlap stops extension, and an explicitly requested stop must be reached exactly. The prefix endpoint must be a500 boundary or the final source count67041. Temporary hard links are used only to read completed batches through the already reviewed load_mode authentication; the original batch files are not modified.',
      'Every primary prefix certificate/report/negative ledger is authenticated by load_mode. The preparer then reads exactly the source records with scope indices0..end-1, checks contiguous indices and equality of complete state sets, and validates full input hashes and identities. selected_scopes therefore receives exactly the already completed primary outcomes in the prefix. Its output files are hash-bound in an explicitly bounded prefix record, which makes no global completion claim.',
      'The prefix driver accepts either those prepared selections or the final complete selected scopes. It checks that every selected state occurs in the frozen input, preserves input order for binary interval counts, and assigns500-sized intervals by j modulo worker_count. Within each interval it processes the four modes sequentially with an inner single-worker batch. The caller must use the same start/stop/worker_count for workers of one prefix and disjoint start/stop ranges for successive prefixes; the intended recorded workflow does so.',
      'Every launched secondary batch explicitly passes max-dimension72 and kernel original. Empty selected intervals are skipped, while a completed nonempty interval must report exactly its selected count. A cached call changes only the producer entrypoint. Every actual negative is still replayed by the unchanged original checker. Bounded checkpoints are explicitly labeled as such.',
      'Prefix selection is stable under later extension: a primary result already completed within the prefix cannot be changed by adding later source IDs. The full final finish_reduction16 pass remains mandatory and independently reconstructs all selected scopes from all67041 primary records. It rejects missing, extra or duplicate mode states and validates every negative ledger, so a prefix result is never promoted to complete coverage.',
      'The release manifest builder follows the wrapper imports to include the cache module and includes both prefix helpers. For every completed producer report it authenticates every producer_extension_sha256 entry against a selected current source file. Thus cached production is inspectable and bound separately from the unchanged negative proof sources.']
    assert hashes=={name:sha256((ROUND/name).read_bytes()).hexdigest() for name in names}
    assert proof==source_digest()
    report={'status':'PASS','review_kind':'Independent source-bound review of producer-only bounded cache and authenticated prefix orchestration',
        'formal_proof_assistant_verification':False,'frozen_negative_proof_sha256':proof,
        'source_sha256':hashes,'independent_lightweight_controls':checked,
        'existing_source_bound_cache_audit':{
            'perturbed_bound_controls':audit['perturbed_bound_controls'],
            'actual_query_trace_controls':audit['actual_query_trace_controls'],
            'exact_minimizing_witness_equality':True},
        'necessity_and_orchestration_findings':findings,
        'scope_limitations':[
            'This is a producer/pipeline review, not a completed numerical scope reduction. The final complete original-kernel negative ledgers and global coverage audit remain mandatory.',
            'The large existing cache audit was authenticated, not rerun here. Only the listed lightweight exact mutation, witness and dispatch controls were newly run.',
            'The prefix driver relies on the authenticated preparer or complete final selected-scope files; its bounded checkpoints are not a substitute for final full-scope equality.',
            'Necessary OPEN mass patterns are not common character tables, fusion rings or categories.']}
    output=HERE/'refinement_cache_independent_review.json'
    output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','controls':checked,'proof_sha256':proof,
        'cache_sha256':hashes['one_matrix16/refinement_mass_cache16.py'],
        'wrapper_sha256':hashes['one_matrix16/run_refinement_cached16.py']},indent=2))

if __name__=='__main__':main()
