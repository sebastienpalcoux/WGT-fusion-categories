#!/usr/bin/env python3
"""Close the t=2,3 alternatives before treating V40 as a simple object.

This independently regenerates all bounded dimension descriptions, rather than
assuming the later W40-simple branch. Exact integer kernels and signed trace
semigroups provide necessary obstructions only.
"""
from pathlib import Path
from math import isqrt
from collections import Counter
import hashlib,itertools,json
HERE=Path(__file__).resolve().parent

def square_tails(mass,n,lower=5):
    if n==0:
        if mass==0:yield ()
        return
    if mass<n*lower*lower:return
    for d in range(lower,isqrt(mass//n)+1):
        for tail in square_tails(mass-d*d,n-1,d):yield(d,)+tail

def coin_rows(mass,dims):
    if not dims:
        if mass==0:yield()
        return
    for n in range(mass//dims[0]+1):
        for rest in coin_rows(mass-n*dims[0],dims[1:]):yield(n,)+rest

def b_descriptions():
    for p in range(5,28):
        for z in range(28):
            if (z-p)%2:continue
            x=((z+10+p)//2,(z+10-p)//2,(10-z+p)//2,(10-z-p)//2)
            if min(map(abs,x))<5:continue
            mu=z+10 if z>=p+20 else 3*p+10 if p>=z+20 else p+10
            if mu>37:continue
            for d in range(7,21):
                e=40-d
                for count in range(3):
                    for extra in square_tails(4986-z*z-3*p*p-d*d-e*e,count):
                        yield dict(rank=14+count,p=p,z=z,x=x,zeros=(d,e)+extra,mu=mu)

def b_scalar_rows(case,mass,rho):
    x=case['x'];dims=tuple(map(abs,x));sgn=tuple(1 if t>0 else -1 for t in x);p=case['p']
    # Each row is the actual coefficient vector on A1..A4,M,M*,zeros.
    for n1 in range(mass//dims[0]+1):
        for n2 in range(mass//dims[1]+1):
            f1=sgn[0]*n1;f2=sgn[1]*n2;k=f1-f2
            n3=sgn[2]*(rho-f2);n4=sgn[3]*(rho-f1)
            if min(k,n3,n4)<0:continue
            active=(n1,n2,n3,n4)
            cost=sum(a*b for a,b in zip(active,dims))+2*p*k
            if cost>mass:continue
            for zeros in coin_rows(mass-cost,case['zeros']):yield active+(k,k)+zeros

def trace_rows(case,limit):
    gens={(abs(x),1 if x>0 else -1)for x in case['x']}
    gens|={(2*case['p'],0)}|{(d,0)for d in case['zeros']}
    offset=limit//5;mask=(1<<(2*offset+1))-1;bits=[0]*(limit+1);bits[0]=1<<offset
    for m in range(1,limit+1):
        for d,s in gens:
            if d<=m:
                bits[m]|=(bits[m-d]<<s if s>=0 else bits[m-d]>>(-s))
        bits[m]&=mask
    return bits,offset

def b_check(case):
    # Y^2=1+2(Y+Z)+P74 and E(P)=2I are checked first.
    prem=list(b_scalar_rows(case,74,2))
    if not prem:return dict(excluded=True,stage='P74_scalar_cone',rows=0)
    dims=tuple(map(abs,case['x']))+(case['p'],case['p'])+tuple(case['zeros'])
    index=sorted(list(range(4))+[4]+list(range(6,len(dims))),key=lambda j:(dims[j],j))
    bits,offset=trace_rows(case,max(d*d for d in dims));tested=[]
    for j in index:
        d=dims[j];v=1 if j in (6,7) else 0;t=3 if j<4 else 4 if j==4 else 0
        counts=Counter();found=False
        for row in b_scalar_rows(case,4*d-23*v,v):
            counts['rows']+=1;c=row[j]
            if c>3:continue
            norm=2*v*v+sum(n*n for n in row);a=norm-1-c
            rem=d*d-13-23*a-12*c
            if a<0 or rem<0:continue
            counts['norm_eligible']+=1;tr=t-2+2*a;hit=offset+tr
            if hit>=0 and (bits[rem]>>hit)&1:
                found=True;break
        tested.append(dict(index=j,dimension=d,in_V=bool(v),found=found,counts=dict(counts)))
        if not found:return dict(excluded=True,stage='individual_product',P74_rows=len(prem),tested=tested)
    return dict(excluded=False,P74_rows=len(prem),tested=tested)

def a_descriptions(t):
    if t==2:
        for p,q in [(5,5)]+[(q+10,q)for q in range(5,9)]:
            for a in range(5,42):
                for d in range(7,21):
                    e=40-d;mass=5086-3*a*a-2*p*p-2*q*q-d*d-e*e
                    for count in (0,1):
                        for extra in square_tails(mass,count):yield dict(a=a,p=p,q=q,zeros=(d,e)+extra,rank=15+count)
    if t==3:
        for a in range(5,42):
            for d in range(7,14):
                for e in range(d,(40-d)//2+1):
                    g=40-d-e
                    if 3*a*a+d*d+e*e+g*g==4986:yield dict(a=a,p=5,q=5,zeros=(d,e,g),rank=16)

def a_p74(case):
    a,p,q=case['a'],case['p'],case['q'];out=[]
    for n in range(75//(3*a)+1):
        for u in range(75//(2*p)+1):
            for v in range(75//(2*q)+1):
                if (u+v if p==q else u-v)!=2:continue
                mass=3*a*n+2*p*u+2*q*v
                if mass<=74:
                    for z in coin_rows(74-mass,case['zeros']):out.append((n,u,v)+z)
    return out

def main():
    A2=list(a_descriptions(2));A3=list(a_descriptions(3));A2_passing=[]
    for c in A2:
        rows=a_p74(c)
        if rows:A2_passing.append(dict(input=c,P74_rows=rows))
    assert len(A2)==27 and len(A3)==1
    assert A2_passing==[dict(input=dict(a=35,p=16,q=6,zeros=(19,21,5),rank=16),P74_rows=[(0,2,0,0,0,2)])]
    assert A3==[dict(a=38,p=5,q=5,zeros=(7,11,22),rank=16)]
    # The remaining A2 row must be X D5=4D5 (forbidden diagonal four).
    # The remaining A3 row leaves a selfdual positive remainder of mass five,
    # but the only dimension-five labels are the two active nonselfdual pairs.
    B=[];counts=Counter();stages=Counter()
    for c in b_descriptions():
        cert=b_check(c);B.append(dict(input=c,certificate=cert));counts[c['rank']]+=1;stages[cert.get('stage','OPEN')]+=1
    result=dict(status='PASS' if all(r['certificate']['excluded']for r in B)else'OPEN',
                A2_inputs=A2,A2_P74_remaining=A2_passing,A3_inputs=A3,
                B_rank_counts=dict(counts),B_stages=dict(stages),B_certificates=B,
                proof_scope='t=2 and t=3 alternatives before W40 is declared simple; all source ranks at most16',
                producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (HERE/'cubic_four_pre_w_certificates.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in('A2_inputs','B_certificates')},indent=2))
if __name__=='__main__':main()
