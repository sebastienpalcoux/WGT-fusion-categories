#!/usr/bin/env python3
"""Exact cone and arithmetic audit of the rank-independent split-E exclusion.

All coefficient relations are recovered by rational row reduction from the
displayed matrices. No row engine, field assignment or numerical package is
used. This audit is separate from the complete rank-sixteen E row replay.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from math import isqrt
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
ZERO = (F(0),) * 4
UNIT = (F(1), F(0), F(0), F(1))


def add(*matrices):
    return tuple(sum(entries) for entries in zip(*matrices))


def scale(c, matrix):
    return tuple(c * x for x in matrix)


def product(a, b):
    return (a[0]*b[0] + a[1]*b[2], a[0]*b[1] + a[1]*b[3],
            a[2]*b[0] + a[3]*b[2], a[2]*b[1] + a[3]*b[3])


def adjoint(a):
    # H^{-1} A^T H for H=diag(3,1).
    return a[0], a[2]/3, 3*a[1], a[3]


def trace(a):
    return a[0] + a[3]


def norm(a):
    return trace(product(a, adjoint(a)))


def determinant(a):
    return a[0]*a[3] - a[1]*a[2]


def rref(columns, target):
    rows = [[F(c[j]) for c in columns] + [F(target[j])]
            for j in range(4)]
    lead = 0
    for column in range(len(columns)):
        pivot = next((j for j in range(lead, 4) if rows[j][column]), None)
        if pivot is None:
            continue
        rows[lead], rows[pivot] = rows[pivot], rows[lead]
        pivot_value = rows[lead][column]
        rows[lead] = [v/pivot_value for v in rows[lead]]
        for j in range(4):
            if j != lead:
                factor = rows[j][column]
                rows[j] = [x-factor*y for x, y in zip(rows[j], rows[lead])]
        lead += 1
        if lead == 4:
            break
    return tuple(tuple(row) for row in rows)


def integer_rows(rows):
    assert all(x.denominator == 1 for row in rows for x in row)
    return [[int(x) for x in row] for row in rows]


def matrices(tau):
    P = scale(F(tau), (2, 0, 0, 0))
    Q = scale(F(tau), (-1, 0, 0, 1))
    U = scale(F(-tau), (0, 0, 3, 1))
    V = scale(F(-tau), (0, -1, 0, 1))
    return P, Q, U, adjoint(U), V, adjoint(V)


def audit_cones():
    result = []
    for tau in (-1, 1):
        P, Q, U, Us, V, Vs = images = matrices(tau)
        assert adjoint(P) == P and adjoint(Q) == Q
        assert all(adjoint(adjoint(A)) == A for A in images)
        assert [(trace(A), norm(A), determinant(A)) for A in (P,Q,U,V)] == [
            (2*tau, 4, 0), (0, 2, -1), (-tau, 4, 0), (-tau, 4, 0)]
        UU = product(U, Us)
        U2 = product(U, U)
        assert UU == (0, 0, 0, 4) and U2 == scale(-tau, U)
        assert (norm(UU)-norm(U2))/6 == 2
        selfdual = rref((P, Q, add(U, Us), add(V, Vs)),
                       add(UU, scale(-1, UNIT)))
        expected_sd = ((1,0,0,-2,tau), (0,1,0,-4,3*tau),
                       (0,0,1,-1,0), (0,0,0,0,0))
        assert selfdual == expected_sd
        zero = rref(images, ZERO)
        expected_zero = ((1,0,0,0,-1,-1,0), (0,1,0,0,-2,-2,0),
                         (0,0,1,0,0,-1,0), (0,0,0,1,-1,0,0))
        assert zero == expected_zero
        same_U = rref(images, U)
        expected_U = ((1,0,0,0,-1,-1,0), (0,1,0,0,-2,-2,0),
                      (0,0,1,0,0,-1,1), (0,0,0,1,-1,0,0))
        assert same_U == expected_U
        # Directly check both nonnegative kernel generators.
        assert add(P, scale(2,Q), Us, V) == ZERO
        assert add(P, scale(2,Q), U, Vs) == ZERO
        n = 0 if tau == 1 else 1
        active_coefficients = (2*n+tau, 4*n+3*tau, n, n, n, n)
        assert min(active_coefficients) >= 0
        assert add(UNIT, *(scale(c,A) for c,A in zip(active_coefficients,images))) == UU
        result.append(dict(tau=tau,
                           UUstar_selfdual_augmented_rref=integer_rows(selfdual),
                           zero_image_augmented_rref=integer_rows(zero),
                           image_U_augmented_rref=integer_rows(same_U),
                           least_UUstar_active_coefficients=list(active_coefficients),
                           matrix_norm_difference=2))
    return result


def audit_parameters():
    records = []
    for tau in (-1, 1):
        for p in range(3, isqrt(5400)+1):
            dP, dQ = 2*p-tau, 4*p-tau
            S = 1+dP*dP+dQ*dQ+4*p*p
            assert S == 24*p*p-12*tau*p+3
            if S > 5400:
                continue
            M = 5400-S
            L = dP+2*dQ+2*p
            assert L == 12*p-3*tau
            n = 0 if tau == 1 else 1
            a,b = 2*n+tau,4*n+3*tau
            B = 1+a*dP+b*dQ+4*n*p
            assert B == (14*p-3 if tau == 1 else 10*p+3)
            rec = dict(tau=tau,p=p,active_squared_mass=S,
                       zero_image_squared_mass=M,positive_kernel_mass=L,
                       least_UUstar_dimension=B)
            if B > p*p:
                rec['exclusion'] = 'UUstar_active_dimension'
            else:
                r = p*p-B
                assert r < 2*L
                norm_cap = p*r//L
                rec.update(remainder_dimension=r,remainder_norm_cap=norm_cap,
                           first_cauchy_lhs=r*r,first_cauchy_rhs=M*norm_cap)
                if r*r > M*norm_cap:
                    rec['exclusion'] = 'zero_image_remainder_Cauchy'
                else:
                    assert tau == -1 and p in (12,13)
                    assert p*p < p+L
                    assert 1+a*a+b*b+4*n*n == 7
                    t = p*p-p
                    cap = 4+norm_cap
                    assert t*t > M*cap
                    rec.update(exclusion='U_square_norm_Cauchy',
                               square_remainder_dimension=t,
                               square_remainder_norm_cap=cap,
                               second_cauchy_lhs=t*t,second_cauchy_rhs=M*cap)
            records.append(rec)
    assert len(records) == 25
    assert Counter(r['exclusion'] for r in records) == {
        'UUstar_active_dimension':19,
        'zero_image_remainder_Cauchy':4,
        'U_square_norm_Cauchy':2}
    return records


def main():
    cones = audit_cones()
    parameters = audit_parameters()
    sources = ('verify_orthogonal_E_cone.py', 'r36_orthogonal_E_cone_exclusion.tex')
    report = dict(status='PASS_EXACT_ORTHOGONAL_E_CONE_EXCLUSION_AUDIT',
                  scope='All twenty-five positive integral E parameters at dimension 5400 and minimum nonunit dimension three; no source rank or linear-field assignment used.',
                  source_sha256={name:sha256((HERE/name).read_bytes()).hexdigest()
                                 for name in sources},
                  cone_audits=cones,parameters=parameters,
                  exclusion_histogram=dict(Counter(r['exclusion'] for r in parameters)),
                  formal_proof_assistant_verification=False)
    output = HERE/'orthogonal_E_cone_exclusion_audit.json'
    output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(status=report['status'],parameters=len(parameters),
                         histogram=report['exclusion_histogram']),indent=2))


if __name__ == '__main__':
    main()
