#!/usr/bin/env python3
"""Exact positive and negative controls for the individual symplectic theorem."""
from itertools import product,combinations
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent

def dic(n):
    basis=list(product(range(2*n),range(2)))
    def mul(x,y):
        i,e=x;j,f=y
        return ((i+(-1)**e*j+n*e*f)%(2*n),(e+f)%2)
    return basis,mul

def group_ring(n,cyclic=()):
    b,m=dic(n);basis=list(product(b,*(range(k)for k in cyclic)))
    def mul(x,y):return (m(x[0],y[0]),)+tuple((x[i+1]+y[i+1])%k for i,k in enumerate(cyclic))
    identity=((0,0),)+tuple(0 for k in cyclic);where={x:i for i,x in enumerate(basis)}
    table=[[{where[mul(x,y)]:1}for y in basis]for x in basis]
    dual=[next(where[y]for y in basis if mul(x,y)==identity)for x in basis]
    return basis,table,dual

def fibonacci_tensor(ring):
    b,t,d=ring;basis=list(product(range(len(b)),(0,1)));where={x:i for i,x in enumerate(basis)}
    table=[]
    for g,a in basis:
        line=[]
        for h,e in basis:
            fib=(0,1)if a==e==1 else(a+e,)
            line.append({where[(k,f)]:v for k,v in t[g][h].items()for f in fib})
        table.append(line)
    return basis,table,[where[(d[g],a)]for g,a in basis]

def mm(A,B):
    return [[sum(a*b for a,b in zip(row,col))for col in zip(*B)]for row in A]

def charpoly(A):
    n=len(A);power=[[int(i==j)for j in range(n)]for i in range(n)];traces=[0]
    for k in range(1,n+1):
        power=mm(power,A);traces.append(sum(power[i][i]for i in range(n)))
    coeff=[1]
    for k in range(1,n+1):
        s=sum(coeff[k-j]*traces[j]for j in range(1,k+1));assert s%k==0;coeff.append(-s//k)
    return coeff

def poly_mul(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return out

def check(name,ring,expected=None):
    basis,N,star=ring;n=len(basis)
    def c(i,j,k):return N[i][j].get(star[k],0)-N[j][i].get(star[k],0)
    violation=next(((i,j,k,c(star[i],j,k),c(i,j,k))for i,j,k in product(range(n),repeat=3)if c(star[i],j,k)!=-c(i,j,k)),None)
    if expected is None:
        assert violation is not None
        return {'name':name,'basis_size':n,'sign_identity':False,'witness':violation}
    assert violation is None
    pairs=[(i,star[i])for i in range(n)if i<star[i]];rep=[i for i,j in pairs];b=len(rep)
    H=[[sum(c(rep[i],rep[u],rep[v])*c(rep[j],rep[u],rep[v])for u,v in combinations(range(b),2))for j in range(b)]for i in range(b)]
    assert charpoly(H)==expected
    index={};
    for k,(i,j)in enumerate(pairs):index[i]=(k,1);index[j]=(k,-1)
    for i,j in product(range(n),repeat=2):
        g=sum(c(i,a,v)*c(j,a,v)for a,v in combinations(range(n),2))
        if i in index and j in index:
            u,s=index[i];v,t=index[j];assert g==4*s*t*H[u][v]
        else:assert g==0
    return {'name':name,'basis_size':n,'source_pairs':b,'sign_identity':True,
            'reduced_gram':H,'characteristic_polynomial':expected,
            'full_tensor_squared_norm':sum(c(i,j,k)**2 for i,j,k in combinations(range(n),3))}

def main():
    p=[1]
    for _ in range(12):p=poly_mul(p,[1,-4])
    fib=[1]
    for _ in range(3):fib=poly_mul(fib,[1,-5,5])
    records=[check('Z[Q8]',group_ring(2),[1,-3,3,-1]),
             check('Z[Q8 x C2 x C2]',group_ring(2,(2,2)),p),
             check('Z[Q8] tensor Fibonacci',fibonacci_tensor(group_ring(2)),fib),
             check('Z[Dic3]: mixed symplectic and orthogonal',group_ring(3)),
             check('Z[Q8 x C3]: two nonlinear components exchanged by duality',group_ring(2,(3,)))]
    # Direct indicator control for the two degree-two characters of Dic3.
    basis,mul=dic(3);indicators=[]
    for first in (1,-1):
        trace=[2,first]
        for _ in range(2,6):trace.append(first*trace[-1]-trace[-2])
        s=sum(trace[mul(g,g)[0]] if mul(g,g)[1]==0 else 0 for g in basis)
        assert s%12==0;indicators.append(s//12)
    assert indicators==[-1,1]
    # The degree-five complement hypothesis needs nonunit dimensions >=3.
    # In Z[C6], W=sum_g g has rank1, all diagonal entries1, and all d_g=1.
    W=[[1]*6 for _ in range(6)];assert mm(W,W)==[[6]*6 for _ in range(6)]
    report={'status':'PASS','scope':'Exact controls for the general spectral theorem; these are not dimension5400 source candidates.',
            'controls':records,'Dic3_indicators':indicators,
            'degree_five_invertible_negative_control':{'rank':6,'q':5,'all_dimensions':1,'hypothesis_fails':True},
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'proof_sha256':hashlib.sha256((HERE/'r36_symplectic_structure.tex').read_bytes()).hexdigest()}
    (HERE/'symplectic_spectrum_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='controls'},indent=2))
if __name__=='__main__':main()
