#!/usr/bin/env python3
"""Source-bound independent review of the adaptive rank16 refinement.

The tiny synthetic controls exercise stopping and domain endpoints; they
are not actual row certificates. Every actual negative still requires its
separate complete replay with the preserved original mathematical kernel.
"""
from pathlib import Path
from hashlib import sha256
import json,sys

HERE=Path(__file__).resolve().parent
ROUND=HERE.parent
MODULE=ROUND/'one_matrix16'
sys.path.insert(0,str(MODULE))
from run_refinement16 import refine
from row_engine16 import categories,pure_mass,f8_perron_mass
from run_rows16 import source_digest

class SyntheticRows:
    def __init__(self,k,b,minima):
        self.ctx=('symplectic',4*k)
        self.assignment={'q':b-3}
        self.queries=0
        self.minima=minima
        self.searched=[]
    def rows(self,d,sd,traces,pairs):
        s,t=pairs[0];h=abs(s)//2;g=t//2-h*h;cat=sd,h,g
        assert all((abs(ss)//2,tt//2-(ss//2)**2)==(h,g) for ss,tt in pairs)
        assert 3<=d<=(72 if sd else 51)
        self.searched.append((cat,d))
        if self.minima[cat]==d:
            yield 'synthetic eligible row for stopping-control only'

def boundary_controls():
    results=[]
    definitions=(
        ('stable_pure',2,4,False,None),
        ('stable_perron',2,4,True,None),
        ('selfdual_endpoint_72',2,7,False,(True,1,0)),
        ('nonselfdual_endpoint_51',2,4,False,(False,0,1)),
        ('explicit_prefix_retained_OPEN',2,4,False,None))
    for name,k,b,perron,absent in definitions:
        prefix=name=='explicit_prefix_retained_OPEN'
        minima={cat:(4 if prefix else 3) for cat in categories(k,b)}
        if absent is not None:minima[absent]=None
        e=SyntheticRows(k,b,minima)
        cert,details=refine(e,perron,max_dimension=3 if prefix else 72)
        exact={c:73 if v is None else v for c,v in minima.items()}
        mass=f8_perron_mass(b,exact) if perron else pure_mass(k,b,exact)
        if cert:
            lower={tuple(x['category']):x['minimum'] for x in cert['lower_bounds']}
            assert all(lower[c]<=exact[c] for c in lower)
            asserted=f8_perron_mass(b,lower) if perron else pure_mass(k,b,lower)
            assert cert['mass_lower_bound']==asserted>5399
            for c,low in lower.items():
                assert all(minima[c]!=d for d in range(3,min(low,73 if c[0] else 52)))
        elif details['stop_reason']=='found_category_mass_bound_stable':
            assert mass==details['stable_mass_bound']<=5399
        else:
            assert prefix and details['stop_reason']=='explicit_bounded_prefix'
        last=max(d for cat,d in e.searched)
        if name=='selfdual_endpoint_72':assert last==72 and cert
        if name=='nonselfdual_endpoint_51':assert last==51 and cert
        results.append({'name':name,'synthetic_queries':len(e.searched),
            'last_dimension':last,'certificate_kind':None if cert is None else cert['kind'],
            'completed_relaxation_mass':mass,'producer_stopping_record':details})
    return results

def main():
    names=('structural/review_refinement16.py',
        'one_matrix16/run_refinement16.py','one_matrix16/finish_reduction16.py',
        'one_matrix16/batch_rows16.py','one_matrix16/run_rows16.py',
        'one_matrix16/verify_rows16.py','one_matrix16/row_engine16.py',
        'one_matrix16/bounded_remainder.py','one_matrix16/context16.py',
        'one_matrix16/fixed_field_rows.py','one_matrix16/fixed_field_rows_original.py',
        'one_matrix16/audit_refinement16.py','one_matrix16/refinement_producer_audit.json',
        'one_matrix16/row_kernel_equivalence_audit.json',
        'one_matrix16/f8_perron_mass_audit.json','one_matrix16/symplectic_profiles.json',
        'one_matrix16/derive_inputs16.py','one_matrix16/derived_input_coverage_audit.json',
        'one_matrix16/replay_release16.py',
        'one_matrix16/r36_one_matrix16_row_constraints.tex',
        'structural/r36_symplectic_structure.tex')
    hashes={name:sha256((ROUND/name).read_bytes()).hexdigest() for name in names}
    proof=source_digest()
    controls=boundary_controls()
    old_audit=json.loads((MODULE/'refinement_producer_audit.json').read_bytes())
    assert old_audit['status']=='PASS_EXACT_REFINEMENT_PRODUCER_CONTROLS'
    for name,digest in old_audit['source_sha256'].items():
        assert sha256((MODULE/name).read_bytes()).hexdigest()==digest
    row_audit=json.loads((MODULE/'row_kernel_equivalence_audit.json').read_bytes())
    for name,digest in row_audit['source_hashes'].items():
        assert sha256((MODULE/name).read_bytes()).hexdigest()==digest
    findings=[
      'The category (sd,h,g) is imposed exactly by matrix traces +/-2h and t=2(h^2+g). For h=0 the duplicate sign is removed. Early matrix-value restriction intersects the complete option set before the join; it does not change any scalar-field option or select one sign. The original checker restricts the resulting complete original rows manually, and the existing source-bound row-equivalence controls include the fixed-(s,t) restriction.',
      'For every category, lower starts at3 and is incremented only after a complete row query at that dimension has no eligible row. The first eligible row therefore establishes the exact minimum of this necessary row relaxation. row_allowed already enforces nonnegative regular trace, so the direct producer rows query is compatible with Engine.exists at threshold zero. This does not establish an actual fusion-ring realization.',
      'The full eligible dimensions are3..72 for a selfdual label and3..51 for a nonselfdual label. At rank16, d^2+14*9<=5399 gives the former cap, while 2d^2+13*9<=5399 gives the latter. The producer queries these endpoints inclusively. After a category is absent throughout its finite domain, the sentinel73 is a valid impossible-category lower bound; the original checker also rejects dimensions beyond each duality cap.',
      'For b source pairs there are s=15-2b selfdual nonunit labels. Each DP profile has exactly s selfdual slots and b pair slots. Squared dimensions and trace-square contributions carry weight1 for a selfdual slot and2 for a pair slot. The required nonunit trace budget is2k-1. Repeated profile entries are repeated slots, and Counter merges only their category multiplicities. No source simple or dual pair is counted an extra time.',
      'The pure mass witness records an actual minimizing category pattern of the same finite DP used by the frozen mass checker. The f8 witness records exactly the lower-bound categories used by the chosen three-selfdual or one-selfdual-plus-one-pair formula. In the pair formula the selected zero-trace pair contribution is subtracted before the nonzero-trace pair contribution is inserted, and the witness removes that same one slot. Zero-multiplicity categories are discarded, so they cannot prevent stable stopping.',
      'Early OPEN is sound: once every category in one minimizing pattern has its exact eligible-row minimum fixed, that pattern retains the same cost under every future increase of the other lower bounds. Monotonicity prevents the global relaxed minimum from decreasing, while the unchanged pattern prevents it from increasing. Thus the relaxed mass bound remains at the observed value<=5399. The pattern need not be jointly realizable; OPEN makes no such claim.',
      'The f8 Perron formulas use all allowed trace supports, including a scalar nonselfdual pair. For three selfdual nonzero traces the minimum is2L^2+(2L-1)^2. For a nonzero-trace pair of dimension p and selfdual dimension e, e=2p+/-1, with p>=P and e>=L; choosing the least permitted p for each sign gives the exact stated minimum. The witness depends on L and P even if the minimizing coupled dimensions exceed these individual minima, which is a valid necessary relaxation.',
      'Certificate compression only lowers asserted categorical bounds, never raises them. Both mass functions are coordinatewise nondecreasing. Binary search therefore preserves a strict mass contradiction while reducing the absence prefixes that the original checker must exhaust. INF=10^18 represents an empty finite pattern set and safely exceeds every finite mass in the permitted bounds.',
      'The negative certificate schema is unchanged. The frozen verify_rows16.replay function requires the exact category set, integer bounds3..73, source pair count, formal codegree when relevant, and exact mass>5399. It exhausts every d from3 through lower-1 using the selected original kernel and independently recomputes the mass formula. The producer optimization is not part of this negative trust boundary.',
      'The default producer maximum is72, but batch_rows16 has a historical default30 and forwards it. This orchestration risk was identified during review. The owner confirmed explicit --refinement-runner --max-dimension72 for every secondary production launch, and the final finish_reduction16.load_mode now requires max_dimension==72 for all four secondary modes. Thus an accidentally truncated secondary producer report cannot pass final coverage. A deliberately bounded prefix otherwise returns OPEN only.',
      'Secondary scopes are reconstructed from all primary-OPEN symplectic identifiers: small_pairs has b in{3,4} at every codegree; tensor has b in{5,6,7} and f in{36,40,60}; higher_tensor has b in{5,6,7} and f in{72,100,108}; f8 contains every primary-OPEN f8 state. The f8/small_pairs overlap is intentional. Final coverage requires exact equality between each recorded mode set and its recomputed selected set.',
      'The final orchestrator requires the complete67041 primary symplectic records and59761 public E records, validates every full input-record digest and identity, and requires every E record to have a negative certificate. It rejects duplicate state identifiers, duplicate scope indices, range/mode mismatches and missing or extra selected records.',
      'For every batch, final coverage checks the producer proof digest, range, mode, histogram and record count; replay range, count and histogram; the certificate and ledger hashes; every PASS entry proof digest, record hash, input hash and kernel; exact equality of ledger indices to the negative certificate indices; and exact summed replay row totals. The CLI has no no-replay escape path. The optional internal diagnostic path is explicitly labeled DIAGNOSTIC_CERTIFICATE_RECORDS_ONLY and is not used by the final main routine.',
      'The exclusion union is built with global state identifier sets. Each stage counts additional=ids-closed before taking the union. Overlaps between secondary scopes, primary, structural exclusions and the27 cubic-support exclusions are therefore not double-counted. The OPEN export reuses the same trace/assignment/duality iteration order as derive_inputs16 and asserts total states1325156 and OPEN+closed=total.',
      'Both original and audited fast replay kernels are accepted by the orchestrator, but the actual kernel is checked entry by entry and reported explicitly. The release and batch defaults are original, and the root integration wrapper explicitly requests original. A claim that every negative used the original kernel must be supported by the completed mode kernel counts; the current code review does not substitute for those completed ledgers.']
    assert hashes=={name:sha256((ROUND/name).read_bytes()).hexdigest() for name in names}
    assert proof==source_digest()
    report={'status':'PASS','review_kind':'Independent review of frozen adaptive producer and exact selected-scope orchestration',
        'formal_proof_assistant_verification':False,'frozen_negative_proof_sha256':proof,
        'source_sha256':hashes,'synthetic_stopping_and_domain_controls':controls,
        'existing_source_bound_minimum_control_counts':old_audit['counts'],
        'necessity_and_coverage_findings':findings,
        'scope_limitations':[
            'This reviews the exact sources bound above. A later producer cache or wrapper is not automatically included; its source and any equivalence evidence must be bound separately.',
            'The synthetic controls test stopping logic and inclusive finite domains only; they are not actual category row certificates.',
            'Actual production and replay batches were still running at review time. This is not a declaration of completed selected-scope coverage or final OPEN counts.',
            'Every actual negative still requires the separate complete exact row replay. OPEN states are necessary field-duality data, not rings or categories.']}
    output=HERE/'refinement_producer_independent_review.json'
    output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','synthetic_controls':len(controls),
        'proof_sha256':proof,'run_refinement16_sha256':hashes['one_matrix16/run_refinement16.py'],
        'finish_reduction16_sha256':hashes['one_matrix16/finish_reduction16.py']},indent=2))

if __name__=='__main__':main()
