"""Dependency-free exhaustive verification of integral source dual-pair choices."""
from itertools import combinations_with_replacement
from math import comb
from exact_certificate_checks import verify_certificate

def nonnegative_indices(target):
    n=next(n for n in range(1,20) if 3+3*n+n*(n-1)//2==len(target))
    return (0,1,2)+tuple(3+3*i+j for i in range(n) for j in (0,2))

def pair_choices(vectors,target):
    positions=[i for i,v in enumerate(vectors) if v[1]]
    positive=nonnegative_indices(target)
    for choice in combinations_with_replacement(positions,target[1]):
        residual=tuple(t-sum(vectors[i][j] for i in choice) for j,t in enumerate(target))
        if any(residual[j]<0 for j in positive):continue
        yield choice,residual

def verify_pair_branches(vectors,target,record):
    selfdual=[v for v in vectors if v[0]]
    paired=[v for v in vectors if v[1]]
    for v in vectors:assert (v[0],v[1]) in ((1,0),(0,1))
    total=comb(len(paired)+target[1]-1,target[1])
    assert total==record['unpruned_integer_pair_choices']
    stored={tuple(b['pair_indices']):b['certificate'] for b in record['branches']}
    assert len(stored)==len(record['branches'])==record['branch_count']
    used=set()
    for choice,residual in pair_choices(vectors,target):
        assert choice in stored
        assert stored[choice]['kind']=='integer_separator'
        assert verify_certificate(selfdual,residual,stored[choice])
        used.add(choice)
    assert used==set(stored)
    return {'unpruned_pair_choices':total,'positive_budget_pruned':total-len(used),
            'certified_pair_choices':len(used),'selfdual_atoms':len(selfdual),
            'pair_atoms':len(paired),'integer_separators':len(used),
            'atom_evaluations':len(used)*len(selfdual)}
