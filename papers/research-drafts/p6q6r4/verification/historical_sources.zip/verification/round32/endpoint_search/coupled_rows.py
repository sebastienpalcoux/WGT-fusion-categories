"""Exact rows coupling the f=6 field/support type to source duality.

Relaxes all global full-field assignments except the f=6 rational/Eisenstein
split and total conjugate-pair count. No row or feasibility claim is a ring.
"""
from collections import Counter
from functools import lru_cache
from math import gcd,isqrt
from itertools import combinations
from orbit_pairs import allowed_pairs
from refined_rows import odd_orbit_possible,moment_target,row_moment_vector
DIM=5400

def coupled_blocks(profile,double_degree,q6):
    pieces=[]
    for a,count in Counter(profile).items():
        if a==double_degree:
            assert count>=2
            pieces.append((a,2,'matrix'));count-=2
        if a==900:
            assert count>=2*q6
            if count>2*q6:pieces.append((a,count-2*q6,'rational6'))
            if q6:pieces.append((a,2*q6,'complex6'))
            continue
        if count and count%2 and not odd_orbit_possible(DIM//a,count):
            pieces.append((a,1,'linear'));count-=1
        if count:pieces.append((a,count,'linear'))
    pieces.sort(key=lambda x:(x[1]>1,-x[0],x[2]))
    double=next((i for i,x in enumerate(pieces) if x[2]=='matrix'),None)
    assert sum(k for a,k,t in pieces)==10
    return pieces,double

@lru_cache(None)
def rational_pairs(k,bound):
    states={(0,0)}
    for _ in range(k):
        states={(s+x,t+x*x) for s,t in states for x in range(-bound,bound+1) if t+x*x<6}
    return states

def block_options(piece,d,is_selfdual,matrix_kind,real_other,q6):
    a,k,kind=piece;f=DIM//a
    cap=min((DIM-d*d)//a,k*d*d-1,f-1)
    if kind=='rational6':
        return [(s,t) for s,t in rational_pairs(k,2 if is_selfdual else 1)
                if t<=cap and abs(s)<k*d]
    if kind=='complex6':
        if is_selfdual:
            options=[(0,0),(-2,2),(2,2)] if q6==1 else [(0,0),(0,4)]
        else:options=[(0,0),(-1,2),(1,2)]
        return [(s,t) for s,t in options if t<=cap]
    if kind=='matrix':
        options=[]
        for t in range(cap+1):
            for s in range(-min(2*d-1,isqrt(2*t)),min(2*d-1,isqrt(2*t))+1):
                if matrix_kind=='symplectic':
                    if t%2:continue
                    if is_selfdual and (s%2 or t!=s*s//2):continue
                if is_selfdual:
                    if (s*s-t)%2:continue
                    if t>=2*d*d-2*d*abs(s)+s*s:continue
                options.append((s,t))
        return options
    return [(s,t) for s,t in allowed_pairs(f,k,d,is_selfdual or real_other)
            if t<=cap and abs(s)<k*d]

def coupled_rows(pieces,double,q6,q,matrix_kind):
    real_other=(q==q6)
    blocks=[(a,k) for a,k,t in pieces]
    for is_selfdual in [True,False]:
      for d in range(3,73):
        choices=[sorted(block_options(p,d,is_selfdual,matrix_kind,real_other,q6),key=lambda x:(x[1],x[0])) for p in pieces]
        if any(not opt for opt in choices):continue
        order=sorted(range(len(blocks)),key=lambda i:len(choices[i]))
        lookup=[set(opt) for opt in choices];selected=[None]*len(blocks)
        suffix_s=[0]*(len(blocks)+1);suffix_t=[0]*(len(blocks)+1)
        suffix_mass=[0]*(len(blocks)+1);suffix_factor=[1]*(len(blocks)+1)
        suffix_gcd=[[0]*4 for _ in range(len(blocks)+1)]
        for h in reversed(range(len(blocks))):
            i=order[h];a,k=blocks[i]
            suffix_s[h]=suffix_s[h+1]+a*max(abs(s) for s,t in choices[i])
            suffix_t[h]=suffix_t[h+1]+a*max(t for s,t in choices[i])
            suffix_mass[h]=suffix_mass[h+1]+a*k
            suffix_factor[h]=max(suffix_factor[h+1],2 if i==double else 1)
            gg=suffix_gcd[h+1].copy()
            for s,t in choices[i]:
                for j,v in enumerate((a*s,a*t,a*(t-s),a*(t+s))):gg[j]=gcd(gg[j],v)
            suffix_gcd[h]=gg
        def rec(h,linear,square):
            if square<0 or square>suffix_t[h] or abs(linear)>suffix_s[h]:return
            if abs(linear)>suffix_factor[h]*square:return
            if linear*linear>suffix_mass[h]*square:return
            for value,g in zip((linear,square,square-linear,square+linear),suffix_gcd[h]):
                if (g and value%g) or (not g and value):return
            i=order[h];a,k=blocks[i]
            if h==len(blocks)-1:
                if linear%a or square%a:return
                pair=(linear//a,square//a)
                if pair in lookup[i]:
                    selected[i]=pair
                    yield is_selfdual,d,tuple(selected)
                return
            for s,t in choices[i]:
                if a*t>square:break
                selected[i]=(s,t)
                yield from rec(h+1,linear-a*s,square-a*t)
        yield from rec(0,-d,DIM-d*d)

def coupled_moments(pieces,double,rows,q,matrix_kind):
    blocks=[(a,k) for a,k,t in pieces]
    base=moment_target(blocks,double)
    b=q+(0 if double is None else 3 if matrix_kind=='symplectic' else 1)
    rank=11 if double is None else 13
    target=(rank-1-2*b,b)+base
    vectors=set()
    for sd,d,values in rows:
        v=row_moment_vector(d,values)
        vectors.add(((1,0)+v) if sd else ((0,1)+tuple(2*x for x in v)))
    return target,sorted(vectors)
