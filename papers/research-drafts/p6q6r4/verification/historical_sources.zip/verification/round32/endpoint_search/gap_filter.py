"""Exact minimal-polynomial gap-divisibility row filter for commutative rings."""
from functools import lru_cache
from itertools import product
from math import isqrt

@lru_cache(None)
def rational_factor_options(k,s,t):
    """Possible DISTINCT monic linear factors, represented low-to-high."""
    out=set();limit=isqrt(t)
    def visit(left,lo,total,norm,chosen):
        if left==0:
            if total==norm==0:out.add(tuple(sorted({(-x,1) for x in chosen})))
            return
        if norm<0 or total*total>left*norm:return
        for x in range(lo,limit+1):
            if x*x>norm:continue
            visit(left-1,x,total-x,norm-x*x,chosen+[x])
    visit(k,-limit,s,t,[])
    return frozenset(out)

def quadratic_factors(s,t,real):
    n=(s*s-t)//2 if real else t//2
    assert (s*s-t)%2==0 if real else t%2==0
    disc=s*s-4*n
    if disc==0:
        assert s%2==0
        return ((-s//2,1),)
    return ((n,-s,1),)

def piece_factors(piece,value):
    a,k,label=piece;s,t=value
    if label in ('Q','rational6','rational_group'):
        return rational_factor_options(k,s,t)
    if label=='complex6':
        if k==2:
            return frozenset([quadratic_factors(s,t,False)])
        assert k==4
        if (s,t)==(0,0):return frozenset([((0,1),)])
        if (s,t)==(0,4):return frozenset([((-1,1),(1,1))])
        assert t==2 and abs(s)==1
        return frozenset([((0,1),(1,-s,1))])
    if label.startswith('quadratic_disc='):
        delta=int(label.split('=')[1]);return frozenset([quadratic_factors(s,t,delta>0)])
    if label.startswith('zeta'):
        from orbit_pairs import phi,quadratic_discriminants
        from field_discriminant_profiles import kronecker
        cstr,hstr=label.split(':H=');c=int(cstr[4:]);h=tuple(map(int,hstr.split(',')));e=phi(c)//len(h)
        if e==1:return rational_factor_options(1,s,t)
        if e==2:
            deltas=[delta for delta in quadratic_discriminants(c) if all(kronecker(delta,a)==1 for a in h)]
            assert len(deltas)==1,(label,deltas)
            return frozenset([quadratic_factors(s,t,deltas[0]>0)])
    # These higher-field cases have no claimed exclusion here.
    return None

def gap_possible(pieces,d,values):
    choices=[piece_factors(p,v) for p,v in zip(pieces,values)]
    if any(x is None for x in choices):return True
    for selected in product(*choices):
        factors=set(factor for block in selected for factor in block)
        residue=1
        for polynomial in factors:
            value=0
            for c in reversed(polynomial):value=value*d+c
            residue=residue*value%5400
        if residue==0:return True
    return False

def matrix_factor_options(s,t,sd,kind,known_dets=None):
    """Safe characteristic-polynomial factors, including a repeated root.

    The unique degree-two character is rational. Its determinant is an
    integer and |det|<=t/2. Selfdual matrices have determinant(s²-t)/2;
    a symplectic positive involution has determinantt/2.
    """
    if known_dets is not None:dets=known_dets
    elif sd:
        if (s*s-t)%2:return []
        dets=[(s*s-t)//2]
    elif kind=='symplectic':
        if t%2:return []
        dets=[t//2]
    else:dets=range(-(t//2),t//2+1)
    out=[]
    for determinant in dets:
        if 2*abs(determinant)>t:continue
        if kind=='orthogonal' and 2*determinant<s*s-t:continue
        discriminant=s*s-4*determinant
        r=isqrt(discriminant) if discriminant>=0 else -1
        if r>=0 and r*r==discriminant:
            if (s-r)%2:continue
            first,second=(s-r)//2,(s+r)//2
            if first==second and sd:
                # Self-adjoint matrices are diagonalizable.
                out.append(((-first,1),))
            else:out.append(((-first,1),(-second,1)))
        else:out.append(((determinant,-s,1),))
    return out

def noncommutative_gap_possible(pieces,d,values,sd,kind):
    from collections import Counter
    matrix=next(i for i,p in enumerate(pieces) if p[2]=='matrix')
    choices=[piece_factors(p,v) for i,(p,v) in enumerate(zip(pieces,values)) if i!=matrix]
    if any(x is None for x in choices):return True
    matrix_options=matrix_factor_options(*values[matrix],sd,kind,row_determinants(pieces,d,values,sd,kind))
    for selected in product(*choices):
        linear_factors=set(factor for block in selected for factor in block)
        for factors in matrix_options:
            multiplicities=Counter(factors)
            for factor in linear_factors:multiplicities[factor]=max(multiplicities[factor],1)
            residue=1;has_dimension_root=False
            for polynomial,multiplicity in multiplicities.items():
                value=0
                for c in reversed(polynomial):value=value*d+c
                if value==0:has_dimension_root=True;break
                residue=residue*pow(value,multiplicity,5400)%5400
            if not has_dimension_root and residue==0:return True
    return False

def linear_square_trace(piece,value,sd):
    """Trace of X^2 on a fixed linear-character block, if determined."""
    a,k,label=piece;s,t=value
    if label in ('Q','rational6','rational_group','real_cubic_conductor9'):return t
    if label=='complex6':
        if sd:return t
        assert (s,t) in ((0,0),(-1,2),(1,2))
        return s*s-t
    if label.startswith('quadratic_disc='):
        return t if int(label.split('=')[1])>0 else s*s-t
    if label.startswith('zeta'):
        from orbit_pairs import phi,quadratic_discriminants
        from field_discriminant_profiles import kronecker
        cstr,hstr=label.split(':H=');c=int(cstr[4:]);h=tuple(map(int,hstr.split(',')));e=phi(c)//len(h)
        if c-1 in h:return t
        if e==2:return s*s-t
    return None

def row_determinants(pieces,d,values,sd,kind):
    """Apply tau(X^2)=delta_(X,X*) to the unique matrix component.

    None means that a higher complex field leaves its square trace unknown;
    an empty tuple proves the row impossible; otherwise the determinant is
    uniquely determined as an integer.
    """
    matrix=next((i for i,p in enumerate(pieces) if p[2]=='matrix'),None)
    squares=[linear_square_trace(p,v,sd) for i,(p,v) in enumerate(zip(pieces,values)) if i!=matrix]
    if any(x is None for x in squares):return None
    linear=[p for i,p in enumerate(pieces) if i!=matrix]
    rhs=5400*sd-d*d-sum(p[0]*u for p,u in zip(linear,squares))
    if matrix is None:return (0,) if rhs==0 else ()
    a,k,label=pieces[matrix];s,t=values[matrix]
    if rhs%a:return ()
    u=rhs//a
    if (s*s-u)%2:return ()
    det=(s*s-u)//2
    if 2*abs(det)>t:return ()
    if kind=='orthogonal' and 2*det<s*s-t:return ()
    if kind=='symplectic' and 2*det!=t:return ()
    if sd and 2*det!=s*s-t:return ()
    return (det,)
