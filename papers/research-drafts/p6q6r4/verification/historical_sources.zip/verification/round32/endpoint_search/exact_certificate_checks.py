"""Dependency-free checking of necessary finite moment exclusions."""

def upper_bounds(vectors,target):
    nblocks=next((n for n in range(1,20) if 3+3*n+n*(n-1)//2==len(target)),None)
    assert nblocks is not None
    positive=(0,1,2)+tuple(3+3*i+j for i in range(nblocks) for j in (0,2))
    return [min(target[j]//row[j] for j in positive if row[j]>0) for row in vectors]

def dot(a,b):
    assert len(a)==len(b)
    return sum(x*y for x,y in zip(a,b))

def verify_certificate(vectors,target,certificate):
    if certificate is None:return False
    kind=certificate['kind']
    if kind=='empty':
        assert not vectors;return True
    if kind=='bounded_empty':
        assert not any(upper_bounds(vectors,target));return True
    z=certificate['coefficients'];assert all(type(x)is int for x in z)
    goal=dot(z,target)
    if kind=='integer_separator':
        values=[dot(z,row) for row in vectors]
        assert values and min(values)>=0 and goal<0
        assert goal==certificate['target_value']
        assert min(values)==certificate['minimum_row_value']
    elif kind=='integer_box_separator':
        upper=upper_bounds(vectors,target)
        lower=sum(u*min(0,dot(z,row)) for row,u in zip(vectors,upper))
        assert goal<lower
        assert goal==certificate['target_value'] and lower==certificate['lower_bound']
    elif kind=='modular_separator':
        upper=upper_bounds(vectors,target);modulus=certificate['modulus']
        assert modulus>=2
        assert all(dot(z,row)%modulus==0 for row,u in zip(vectors,upper) if u)
        assert goal%modulus==certificate['target_residue']!=0
    else:raise AssertionError(kind)
    return True
