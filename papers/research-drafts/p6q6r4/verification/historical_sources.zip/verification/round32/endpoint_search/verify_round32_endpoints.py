#!/usr/bin/env python3
"""Regenerate all full-field cases and verify every R32 endpoint certificate.

Python standard library only. R31's 59/79 surviving inputs are frozen here;
R31's independent complete verifier remains in the preceding archive.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,time
from endpoint_core import degree_profiles
from field_discriminant_profiles import profile_states,placement_states
from fixed_field_rows import fixed_blocks,fixed_rows
from coupled_rows import coupled_moments
from gap_filter import gap_possible,noncommutative_gap_possible
from exact_certificate_checks import verify_certificate
from exact_pair_branches import verify_pair_branches
HERE=Path(__file__).resolve().parent

def signature(index,doubled,fields,kind):return index,doubled,json.dumps(fields,sort_keys=True),kind

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--trace-code',type=Path,default=HERE.parent/'trace_forms/exact_trace_forms.py');ap.add_argument('--output',type=Path,default=HERE/'endpoint32_verification.json');args=ap.parse_args()
    start=time.monotonic();spec=importlib.util.spec_from_file_location('r32_trace_forms',args.trace_code);trace=importlib.util.module_from_spec(spec);spec.loader.exec_module(trace)
    source=json.loads((HERE/'r31_endpoint_input.json').read_text());stored=json.loads((HERE/'endpoint32_certificates.json').read_text())
    certificates={signature(r['index'],r['double_degree'],r['fields'],r['kind']):r for r in stored['records']}
    assert len(certificates)==len(stored['records'])
    paired=json.loads((HERE/'endpoint32_pair_certificates.json').read_text())
    pair_records={signature(r['index'],r['double_degree'],r['fields'],r['kind']):r for r in paired['records']}
    assert len(pair_records)==len(paired['records'])
    pair_used=set();pair_summaries=[]
    profiles=list(degree_profiles());assert len(profiles)==497
    cases=source['commutative_cases']+source['noncommutative_cases'];assert len(cases)==138
    used=set();verified=0;checked_rows=0;results=[]
    for index,doubled in cases:
        profile=profiles[index]
        states=(profile_states(profile) if doubled is None else placement_states(profile,doubled))[1]
        field_result=trace.analyze(profile,doubled,states)
        unresolved=[];case_records=[]
        for assignment in field_result['surviving_assignments']:
          for kind in assignment['duality_types']:
            kind=None if kind=='commutative' else kind
            key=signature(index,doubled,assignment['fields'],kind);assert key in certificates,(index,doubled,assignment,kind)
            record=certificates[key];used.add(key)
            q6,q=assignment['q6'],assignment['q'];assert (q6,q)==(record['q6'],record['q'])
            pieces,double=fixed_blocks(assignment,doubled)
            assert pieces==[tuple(x) for x in record['pieces']] and double==record['double']
            rows=list(fixed_rows(pieces,double,q6,q,kind));before=len(rows)
            if record['method']=='annihilator':
                if doubled is None:rows=[r for r in rows if gap_possible(pieces,r[1],r[2])]
                else:rows=[r for r in rows if noncommutative_gap_possible(pieces,r[1],r[2],r[0],kind)]
            else:assert record['method']=='fixed_fields'
            target,vectors=coupled_moments(pieces,double,rows,q,kind)
            assert (len(rows),len(vectors))==(record['rows'],record['vectors']),(index,doubled,kind,len(rows),len(vectors),record['rows'],record['vectors'])
            passed=verify_certificate(vectors,target,record['certificate'])
            if passed:verified+=1;checked_rows+=len(rows)
            elif key in pair_records:
                branch_record=pair_records[key]
                assert (branch_record['q6'],branch_record['q'])==(q6,q)
                assert [tuple(x) for x in branch_record['pieces']]==pieces and branch_record['double']==double
                branch_summary=verify_pair_branches(vectors,target,branch_record)
                branch_summary.update(index=index,double_degree=doubled,q6=q6,q=q,kind=kind)
                pair_summaries.append(branch_summary);pair_used.add(key)
                verified+=branch_summary['integer_separators'];checked_rows+=branch_summary['atom_evaluations'];passed=True
            else:unresolved.append({'fields':assignment['fields'],'q6':q6,'q':q,'kind':kind,'rows':len(rows),'vectors':len(vectors)})
            case_records.append({'fields':assignment['fields'],'q6':q6,'q':q,'kind':kind,'method':record['method'],'before_rows':before,'rows':len(rows),'excluded':passed})
        results.append({'index':index,'double_degree':doubled,'profile':profile,'trace_form_excluded':field_result['excluded'],'trace_form_assignments':len(field_result['surviving_assignments']),'excluded':not unresolved,'unresolved_assignments':unresolved,'row_tests':case_records})
        print('PASS',index,doubled,'EXCLUDED' if not unresolved else 'UNRESOLVED',len(case_records),flush=True)
    assert used==set(certificates),(len(used),len(certificates))
    assert pair_used==set(pair_records)
    comm=[r for r in results if r['double_degree'] is None];noncomm=[r for r in results if r['double_degree'] is not None]
    output={'status':'PASS','input_cases':{'commutative_rank11':len(comm),'noncommutative_rank13':len(noncomm)},'full_field_duality_records':len(used),'verified_certificate_count':verified,'exact_rows_checked':checked_rows,'commutative_excluded':sum(r['excluded'] for r in comm),'noncommutative_excluded':sum(r['excluded'] for r in noncomm),'unresolved_commutative':[r['index'] for r in comm if not r['excluded']],'unresolved_noncommutative':[[r['index'],r['double_degree']] for r in noncomm if not r['excluded']],'pair_branch_summaries':pair_summaries,'records':results,'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),args.trace_code,HERE/'endpoint32_certificates.json',HERE/'endpoint32_pair_certificates.json',HERE/'exact_pair_branches.py',HERE/'r31_endpoint_input.json',HERE/'fixed_field_rows.py',HERE/'coupled_rows.py',HERE/'gap_filter.py',HERE/'exact_certificate_checks.py',HERE/'orbit_pairs.py',HERE/'refined_rows.py',HERE/'field_discriminant_profiles.py',HERE/'endpoint_core.py']},'elapsed_seconds':time.monotonic()-start,'scope':'Exclusions only. Unresolved assignments need not be integral moment models or rings.'}
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:output[k] for k in ['status','full_field_duality_records','verified_certificate_count','exact_rows_checked','commutative_excluded','noncommutative_excluded','unresolved_commutative','unresolved_noncommutative','elapsed_seconds']}),flush=True)
if __name__=='__main__':main()
