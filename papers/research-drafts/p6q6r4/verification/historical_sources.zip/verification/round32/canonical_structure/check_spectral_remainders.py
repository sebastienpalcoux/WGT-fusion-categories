"""Exact arithmetic checks for R32 spectral and remainder statements.
No category/ring existence is asserted. Standard library only.
"""
from itertools import combinations
from math import factorial,prod,gcd
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent

def valuation(n,p):
    r=0
    while n and n%p==0:n//=p;r+=1
    return r

def squarefree(n):
    q=2
    while q*q<=n:
        if n%(q*q)==0:return False
        q+=1
    return True

def fundamental(delta):
    if delta==1 or not delta:return False
    if delta%4==1:return squarefree(abs(delta))
    if delta%4:return False
    d=delta//4
    return d%4 in (2,3) and squarefree(abs(d))

def minimum_gap_sets(d,n):
    # Exhaustive sizes only up through the first attainable one.
    for k in range(1,2*d):
        found=[xs for xs in combinations(range(1,2*d),k) if prod(xs)%n==0]
        if found:return k,found
    return None,[]

def main():
    n=5400
    k6,g6=minimum_gap_sets(6,n)
    assert k6==5
    # All admissible subsets, including nonminimal ones, have the claimed values.
    count=0
    for k in range(1,12):
        for gaps in combinations(range(1,12),k):
            if prod(gaps)%n:continue
            count+=1
            vals={6-x for x in gaps}
            assert {1,-4,-3}<=vals and ({0,3}&vals)
    # Four forced5-divisible gaps atd12. Testall three additionalgaps.
    forced=(5,10,15,20)
    others=[x for x in range(1,24) if x not in forced]
    g12=[tuple(sorted(forced+extra)) for extra in combinations(others,3)
         if prod(forced+extra)%(n*n)==0]
    assert g12==[(5,9,10,12,15,18,20)]
    assert prod(g12[0])==n*n
    # No two furthergaps can supplythe five missing powersof3.
    assert max(sum(valuation(x,3) for x in extra) for extra in combinations(others,2))<5
    discs=[D for D in range(-1080,1081) if D and 1080%abs(D)==0 and fundamental(D)]
    odd=[D for D in discs if D%2]
    assert odd==[-15,-3,5]
    degree_lists={m:[e for e in range(2,289,2) if 288%e==0 and 1+e*m*m<=490]
                  for m in (5,6,7)}
    assert degree_lists=={5:[2,4,6,8,12,16,18],6:[2,4,6,8,12],7:[2,4,6,8]}
    for r in (3,4,5):
        assert valuation(factorial(2*r-1),5)<2
    assert not [mu for mu in range(-9,10) if (10+24*mu)%25==0]
    out={'degree12_matrix_residue_exclusion':{'r':10,'modulus':25,'coefficient':24,'admissible_integers':[]},'n5400_dimension6_minimum_nonperron_values':k6,
         'n5400_dimension6_minimal_gap_sets':g6,
         'n5400_dimension6_all_admissible_subsets_checked':count,
         'n5400_squared_dimension12_minimum_nonperron_values':7,
         'n5400_squared_dimension12_unique_minimal_gap_set':g12[0],
         'quadratic_fundamental_discriminants_dividing1080':discs,
         'retained_odd_quadratic_discriminants':odd,
         'high_multiplicity_even_field_degrees':degree_lists,
         'status':'all exact arithmetic assertions passed; no existence claim'}
    (HERE/'spectral_remainders_check.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
