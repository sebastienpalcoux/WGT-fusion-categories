"""Independent R32 rational trace-form arithmetic and field-coverage audit.
Uses squarefree integer Hilbert symbols, fixed spaces from exact nullspaces,
and cyclotomic multiplication traces instead of orbit sums/Ramanujan formulas.
Replays all138 baseline cases after replacing the producer's invariant engine.
"""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from math import prod,gcd
import json,sys,hashlib
HERE=Path(__file__).resolve().parent
TF=HERE.parent/'trace_forms'
sys.path.insert(0,str(TF))
import exact_trace_forms as T
sys.path.insert(1,str(T.DEFAULT_BASE))
from endpoint_core import degree_profiles
from field_discriminant_profiles import profile_states,placement_states

def sq(a):
    a=F(a);n=a.numerator*a.denominator
    sign=-1 if n<0 else 1;n=abs(n);z=1;p=2
    while p*p<=n:
        parity=0
        while n%p==0:n//=p;parity^=1
        if parity:z*=p
        p+=1
    return sign*z*n

def factors(n):
    n=abs(n);ans=set();p=2
    while p*p<=n:
        if n%p==0:
            ans.add(p)
            while n%p==0:n//=p
        p+=1
    if n>1:ans.add(n)
    return ans

@lru_cache(None)
def symbol(a,b,p):
    a,b=sq(a),sq(b)
    av=int(a%p==0);bv=int(b%p==0)
    u=a//p if av else a;v=b//p if bv else b
    if p==2:
        exponent=int(u%4==3)*int(v%4==3)+av*int(v%8 in (3,5))+bv*int(u%8 in (3,5))
    else:
        residues={x*x%p for x in range(1,p)}
        exponent=av*bv*((p-1)//2)+bv*int(u%p not in residues)+av*int(v%p not in residues)
    return -1 if exponent%2 else 1

def own_invariants(diag):
    ds=[F(a) for a in diag]
    assert all(a>0 for a in ds)
    primes={2}
    for a in ds:primes|=factors(sq(a))
    bad=[]
    for p in sorted(primes):
        if prod(symbol(a,b,p) for a,b in combinations(ds,2))<0:bad.append(p)
    assert len(bad)%2==0
    return len(ds),sq(prod(ds)),tuple(bad)

def own_isometry(a,b):return own_invariants(a)==own_invariants(b)

def own_local_square(a,p):
    a=sq(a)
    if a%p==0:return False
    if p==2:return a%8==1
    return a%p in {x*x%p for x in range(1,p)}

def nullspace(matrix,n):
    rows=[[F(x) for x in row] for row in matrix if any(row)]
    pivots=[];r=0
    for c in range(n):
        j=next((j for j in range(r,len(rows)) if rows[j][c]),None)
        if j is None:continue
        rows[r],rows[j]=rows[j],rows[r]
        scale=rows[r][c];rows[r]=[x/scale for x in rows[r]]
        for j in range(len(rows)):
            if j!=r and rows[j][c]:
                scale=rows[j][c];rows[j]=[x-scale*y for x,y in zip(rows[j],rows[r])]
        pivots.append(c);r+=1
    basis=[]
    for c in range(n):
        if c in pivots:continue
        v=[F(0)]*n;v[c]=1
        for j,p in enumerate(pivots):v[p]=-rows[j][c]
        basis.append(v)
    return basis

def diagonal_form(gram):
    n=len(gram);basis=[];diagonal=[]
    def pairing(v,w):return sum(v[i]*gram[i][j]*w[j] for i in range(n) for j in range(n))
    for i in range(n):
        v=[F(int(i==j)) for j in range(n)]
        for w,d in zip(basis,diagonal):
            a=pairing(v,w)/d;v=[x-a*y for x,y in zip(v,w)]
        d=pairing(v,v);assert d>0
        basis.append(v);diagonal.append(d)
    return tuple(diagonal)

@lru_cache(None)
def independent_powers(c):
    polynomial=T.POLY[c];n=len(polynomial)-1
    out=[]
    for exponent in range(c):
        coefficients=[0]*(max(n,exponent+1));coefficients[exponent]=1
        for j in range(len(coefficients)-1,n-1,-1):
            coeff=coefficients[j]
            for k in range(n+1):coefficients[j-n+k]-=coeff*polynomial[k]
        out.append(tuple(coefficients[:n]))
    return tuple(out)

@lru_cache(None)
def independently_fixed_forms(c,h):
    pp=independent_powers(c);n=len(pp[0])
    # Trace of multiplication byzeta^j, computedon1,zeta,...,zeta^(n-1).
    traces=[sum(pp[(j+k)%c][k] for k in range(n)) for j in range(c)]
    automorphism=lambda a:[[pp[(a*j)%c][i] for j in range(n)] for i in range(n)]
    equations=[]
    for a in h:
        M=automorphism(a)
        equations.extend([[M[i][j]-int(i==j) for j in range(n)] for i in range(n)])
    conjugation=automorphism(c-1)
    answer=[]
    for sign in (None,1,-1):
        rows=list(equations)
        if sign is not None:
            rows += [[conjugation[i][j]-sign*int(i==j) for j in range(n)] for i in range(n)]
        basis=nullspace(rows,n)
        gram=[[sum(v[i]*w[j]*traces[(i-j)%c] for i in range(n) for j in range(n))/len(h) for w in basis] for v in basis]
        answer.append(diagonal_form(gram))
    return tuple(answer)

def generated_subgroups(c):
    units={a for a in range(c) if gcd(a,c)==1}
    seen={frozenset([1])};todo=list(seen)
    while todo:
        h=todo.pop()
        for a in units-h:
            k=set(h)|{a}
            while True:
                new=k|{x*y%c for x in k for y in k}
                if new==k:break
                k=new
            k=frozenset(k)
            if k not in seen:seen.add(k);todo.append(k)
    return seen

def independent_fundamental_discriminants(c):
    ans=[]
    for D in range(-c,c+1):
        if not D or D==1 or c%abs(D):continue
        if D%4==1:
            rad=D
        elif D%4==0 and (D//4)%4 in (2,3):rad=D//4
        else:continue
        if abs(sq(rad))==abs(rad):ans.append(D)
    return sorted(ans)

def main():
    baseline=json.loads((T.DEFAULT_BASE/'endpoint_verification.json').read_text())
    profiles=list(degree_profiles())
    requests=baseline['field_and_certificate_summary']['11']['unresolved_cases']+baseline['field_and_certificate_summary']['13']['unresolved_cases']
    block_pairs=set()
    for index,double in requests:
        from collections import Counter
        counts=Counter(profiles[index])
        if double is not None:counts[double]-=2
        block_pairs|={(5400//a,k) for a,k in counts.items() if k}
    fields_checked=0;subgroup_options_checked=0
    for f,k in sorted(block_pairs):
        c=gcd(2*f,f*f);opts=T.field_options(f,k)
        if f==6:
            assert {x[0] for x in opts}=={'Q','Q(sqrt(-3))'}
        elif k>=4:
            expected={tuple(sorted(h)) for h in generated_subgroups(c) if T.phi(c)//len(h)<=k}
            actual={tuple(map(int,o[0].split(':H=')[1].split(','))) for o in opts}
            assert actual==expected,(f,k)
            for o in opts:
                h=tuple(map(int,o[0].split(':H=')[1].split(',')))
                own=independently_fixed_forms(c,h)
                assert all(own_isometry(x,y) for x,y in zip(own,o[1:4])),(f,k,h,own,o)
                subgroup_options_checked+=1
        else:
            expected=set() if f==540 else {'Q'}
            if k>=2:expected|={f'quadratic_disc={D}' for D in independent_fundamental_discriminants(c)}
            if k>=3 and c%9==0:
                assert c%27!=0
                expected.add('real_cubic_conductor9')
            assert {o[0] for o in opts}==expected,(f,k,expected,opts)
        for o in opts:
            for diag in o[1:4]:assert own_invariants(diag)==T.invariants(diag)
        fields_checked+=len(opts)
    # Independently derive the realcubicGramfromalpha^3=3alpha-1.
    cubic_gram=[[F(3),F(0),F(6)],[F(0),F(6),F(-3)],[F(6),F(-3),F(18)]]
    assert own_isometry(diagonal_form(cubic_gram),(F(3),F(6),F(9,2)))
    # Compare Hilbert formulas on signed rationals, including negative valuations.
    tests=0
    samples=[F(s*a,b) for s in (-1,1) for a in range(1,16) for b in (1,2,3,5,6,8)]
    for a in samples:
        for b in samples[::11]:
            for p in (2,3,5,7,11,13):
                assert T.hilbert(a,b,p)==symbol(a,b,p),(a,b,p)
                tests+=1
    # Replace only arithmetic/form-construction functions; replayallassignments.
    T.hilbert=symbol;T.invariants=own_invariants;T.isometric=own_isometry
    T.locally_square=own_local_square
    T.fixed_forms=independently_fixed_forms
    T.field_options.cache_clear();T.block_decompositions.cache_clear()
    stored=json.loads((TF/'trace_form_results.json').read_text())
    previous={(r['index'],r['double_degree']):r for r in stored['records']}
    all_records=[]
    for index,double in requests:
        profile=profiles[index]
        _,states=profile_states(profile) if double is None else placement_states(profile,double)
        own=T.analyze(profile,double,states);old=previous[index,double]
        for key in ('tested_assignments','duality_tests','surviving_duality_tests','excluded'):
            assert own[key]==old[key],(index,double,key,own[key],old[key])
        a={(json.dumps(s['fields'],sort_keys=True),s['q6'],s['q'],tuple(s['duality_types'])) for s in own['surviving_assignments']}
        b={(json.dumps(s['fields'],sort_keys=True),s['q6'],s['q'],tuple(s['duality_types'])) for s in old['surviving_assignments']}
        assert a==b,(index,double)
        all_records.append(own)
    result={'status':'PASS','baseline_cases':len(requests),'tested_assignments':sum(r['tested_assignments'] for r in all_records),'surviving_assignments':sum(len(r['surviving_assignments']) for r in all_records),'formal_codegree_block_pairs':len(block_pairs),'field_options_checked_including_repeats':fields_checked,'cyclotomic_subgroup_field_options_checked':subgroup_options_checked,'independent_hilbert_comparisons':tests,'producer_sha256':hashlib.sha256((TF/'exact_trace_forms.py').read_bytes()).hexdigest(),'results_sha256':hashlib.sha256((TF/'trace_form_results.json').read_bytes()).hexdigest(),'method':'Independent squarefreeHilbertsymbols,generatedsubgroups,fixedspacesbynullspace,andmultiplicationtraces; replayofall304assignments. Existinganalyzeassignmentassemblyisretainedandreviewedseparately.'}
    (HERE/'trace_forms_independent_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
