"""Independent determinant, gap-filter and certificate audit for R32 rank13.
The pre-filter universe is imported from fixed_rows; all later arithmetic
is independently implemented here. Standard library only.
"""
from pathlib import Path
from collections import Counter
from itertools import combinations,product
from math import isqrt
import json,hashlib
from audit_gap_filter import independent_piece,EP,HERE
from fixed_field_rows import fixed_rows
from gap_filter import noncommutative_gap_possible,row_determinants

def normalized(p):
    a,k,label=p
    if label=='zeta16:H=1,3,5,7,9,11,13,15':return (a,k,'Q')
    if label=='zeta16:H=1,5,9,13':return (a,k,'quadratic_disc=-4')
    return p

def det_for_row(pieces,d,vals,sd,kind):
    num=5400 if sd else 0
    num-=d*d
    for p,v in zip(pieces,vals):
        a,k,label=normalized(p);s,t=v
        if label=='matrix':matrix=(a,s,t);continue
        if label in ('Q','rational6','rational_group'):u=t
        elif label=='complex6':u=t if sd else s*s-t
        elif label.startswith('quadratic_disc='):u=t if int(label.split('=')[1])>0 else s*s-t
        else:raise AssertionError(label)
        num-=a*u
    a,s,t=matrix
    if num%a:return ()
    trace_square=num//a
    if (s*s-trace_square)%2:return ()
    det=(s*s-trace_square)//2
    if 2*abs(det)>t:return ()
    if kind=='orthogonal' and t-s*s+2*det<0:return ()
    if kind=='symplectic' and 2*det!=t:return ()
    if sd and trace_square!=t:return ()
    return (det,)

def independent_filter(pieces,d,vals,sd,kind):
    ds=det_for_row(pieces,d,vals,sd,kind)
    if not ds:return False
    assert len(ds)==1
    det=ds[0]
    choices=[]
    for p,v in zip(pieces,vals):
        p=normalized(p)
        if p[2]=='matrix':s,t=v;continue
        choices.append(independent_piece(p,v))
    disc=s*s-4*det
    k=isqrt(disc) if disc>=0 else -1
    if k>=0 and k*k==disc:
        if (s-k)%2:return False
        roots=((s-k)//2,(s+k)//2)
        matrix_factors=Counter((-v,1) for v in roots)
        if sd:matrix_factors=Counter({f:1 for f in matrix_factors})
    else:matrix_factors=Counter({(det,-s,1):1})
    for option in product(*choices):
        fs=matrix_factors.copy()
        for f in set(f for block in option for f in block):fs[f]=max(fs[f],1)
        z=1
        for f,power in fs.items():z*=sum(c*d**j for j,c in enumerate(f))**power
        if z and z%5400==0:return True
    return False

def independent_moments(pieces,rows,q,kind):
    b=q+(3 if kind=='symplectic' else 1)
    target=[12-2*b,b,5399]
    for a,k,label in pieces:
        f=5400//a
        target += [(k+2*(label=='matrix'))*f-k,-k,k*f-k*k]
    target += [-pieces[i][1]*pieces[j][1] for i,j in combinations(range(len(pieces)),2)]
    vectors=set()
    for sd,d,vals in rows:
        v=[d*d]
        for s,t in vals:v += [t,d*s,s*s]
        v += [vals[i][0]*vals[j][0] for i,j in combinations(range(len(vals)),2)]
        vectors.add(tuple([1,0]+v) if sd else tuple([0,1]+[2*x for x in v]))
    return target,vectors

def main():
    data=(EP/'gap_noncomm_results.jsonl').read_bytes()
    recs=[json.loads(x) for x in data.splitlines()]
    out=[];pre=post=certs=0
    for rec in recs:
        pieces=[tuple(x) for x in rec['pieces']]
        rows=list(fixed_rows(pieces,rec['double'],rec['q6'],rec['q'],rec['kind']))
        kept=[]
        for sd,d,vals in rows:
            own_d=det_for_row(pieces,d,vals,sd,rec['kind'])
            their_d=row_determinants(pieces,d,vals,sd,rec['kind'])
            assert own_d==their_d,(rec['index'],pieces,d,vals,own_d,their_d)
            own=independent_filter(pieces,d,vals,sd,rec['kind'])
            assert own==noncommutative_gap_possible(pieces,d,vals,sd,rec['kind'])
            if own:kept.append((sd,d,vals))
        assert len(rows)==rec['rows_before_gap']
        assert len(kept)==rec['rows']
        target,vectors=independent_moments(pieces,kept,rec['q'],rec['kind'])
        assert len(vectors)==rec['vectors']
        if (certificate:=rec['certificate']):
            coeff=certificate['coefficients'];assert len(coeff)==len(target)
            tv=sum(x*y for x,y in zip(coeff,target))
            rv=[sum(x*y for x,y in zip(coeff,v)) for v in vectors]
            assert tv<0 and min(rv)>=0
            assert tv==certificate['target_value'] and min(rv)==certificate['minimum_row_value']
            certs+=1
        pre+=len(rows);post+=len(kept)
        out.append({'index':rec['index'],'double_degree':rec['double_degree'],'assignment_index':rec['assignment_index'],'kind':rec['kind'],'rows_before':len(rows),'rows_after':len(kept),'certificate_verified':bool(certificate)})
    result={'records':len(recs),'certificates_independently_verified':certs,'pre_filter_rows':pre,'retained_rows':post,'input_sha256':hashlib.sha256(data).hexdigest(),'results':out,'scope':'Independently reconstructed determinant restrictions, safe annihilator powers, integer moments, and exact certificate signs. Pre-filter rows use fixed_rows.'}
    (HERE/'noncommutative_gap_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))
if __name__=='__main__':main()
