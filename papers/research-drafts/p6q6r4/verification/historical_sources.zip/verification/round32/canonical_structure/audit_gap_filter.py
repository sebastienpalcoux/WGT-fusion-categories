"""Independent finite check of the commutative R32 gap filter and certificates.
Uses endpoint fixed_rows only for the pre-filter row universe; reconstructs
factor choices, retained rows, moment vectors, targets and certificate signs.
"""
from pathlib import Path
import sys,json,itertools,math
from functools import lru_cache
HERE=Path(__file__).resolve().parent
EP=HERE.parent/'endpoint_search'
sys.path.insert(0,str(EP))
sys.path.insert(1,str(HERE.parent.parent/'round31/deliverable/p6q6r4_Round31/verification/round31/endpoints'))
from fixed_field_rows import fixed_rows
from gap_filter import gap_possible, rational_factor_options, piece_factors

@lru_cache(None)
def independent_rational(k,s,t):
    r=math.isqrt(t)
    found=set()
    for xs in itertools.combinations_with_replacement(range(-r,r+1),k):
        if sum(xs)==s and sum(x*x for x in xs)==t:
            found.add(tuple(sorted(set((-x,1) for x in xs))))
    return frozenset(found)

def independent_piece(piece,v):
    a,k,label=piece;s,t=v
    if label in ('Q','rational6','rational_group'):
        return independent_rational(k,s,t)
    if label=='complex6':
        if k==4:
            if v==(0,0):return frozenset([((0,1),)])
            if v==(0,4):return frozenset([((-1,1),(1,1))])
            assert t==2 and s in (-1,1)
            return frozenset([((0,1),(1,-s,1))])
        assert k==2
        delta=-3
    else:
        assert label.startswith('quadratic_disc=')
        delta=int(label.split('=')[1])
    # Recover the coordinate b from t=(s^2+abs(delta)b^2)/2;
    # then construct the actual conjugate-entry minimal polynomial.
    b2=(2*t-s*s)
    assert b2%abs(delta)==0
    b2//=abs(delta)
    b=math.isqrt(b2);assert b*b==b2
    if not b:
        assert s%2==0
        return frozenset([((-s//2,1),)])
    assert (s*s-delta*b*b)%4==0
    norm=(s*s-delta*b*b)//4
    return frozenset([((norm,-s,1),)])

def independent_gap(pieces,d,values):
    choices=[independent_piece(p,v) for p,v in zip(pieces,values)]
    for option in itertools.product(*choices):
        fs=set(f for group in option for f in group)
        z=1
        for f in fs:z*=sum(c*d**i for i,c in enumerate(f))
        if z%5400==0:return True
    return False

def moments(pieces,rows,q):
    target=[10-2*q,q,5399]
    for a,k,label in pieces:
        f=5400//a
        target += [k*(f-1),-k,k*(f-k)]
    target += [-pieces[i][1]*pieces[j][1] for i,j in itertools.combinations(range(len(pieces)),2)]
    vectors=set()
    for sd,d,vals in rows:
        v=[d*d]
        for s,t in vals:v += [t,d*s,s*s]
        v += [vals[i][0]*vals[j][0] for i,j in itertools.combinations(range(len(vals)),2)]
        vectors.add(tuple([1,0]+v) if sd else tuple([0,1]+[2*x for x in v]))
    return tuple(target),vectors

def main():
    results=[];count_before=count_after=0
    for line in (EP/'gap_results.jsonl').read_text().splitlines():
        rec=json.loads(line);assert rec['double_degree'] is None
        pieces=[tuple(x) for x in rec['pieces']]
        allrows=list(fixed_rows(pieces,None,rec['q6'],rec['q'],None))
        kept=[]
        for sd,d,vals in allrows:
            for p,v in zip(pieces,vals):
                own=independent_piece(p,v);their=piece_factors(p,v)
                assert own==their,(p,v,own,their)
            own=independent_gap(pieces,d,vals)
            assert own==gap_possible(pieces,d,vals)
            if own:kept.append((sd,d,vals))
        assert len(allrows)==rec['rows_before_gap']
        assert len(kept)==rec['rows']
        target,vectors=moments(pieces,kept,rec['q'])
        assert len(vectors)==rec['vectors']
        coeff=rec['certificate']['coefficients']
        assert len(coeff)==len(target)
        tv=sum(x*y for x,y in zip(coeff,target))
        rv=[sum(x*y for x,y in zip(coeff,row)) for row in vectors]
        assert tv<0 and min(rv)>=0
        assert tv==rec['certificate']['target_value']
        assert min(rv)==rec['certificate']['minimum_row_value']
        count_before+=len(allrows);count_after+=len(kept)
        results.append({'index':rec['index'],'assignment_index':rec['assignment_index'],'rows_before':len(allrows),'rows_after':len(kept),'certificate_verified':True})
    out={'assignments':len(results),'profiles':len({r['index'] for r in results}),'pre_filter_rows':count_before,'retained_rows':count_after,'results':results,'scope':'Independent gap-factor construction and moment/certificate signs; pre-filter universe is regenerated using fixed_rows and reviewed separately.'}
    (HERE/'gap_filter_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
