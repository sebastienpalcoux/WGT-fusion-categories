#!/usr/bin/env python3
"""Independent structural sanity checks for exact rational trace forms."""
from fractions import Fraction as F
from pathlib import Path
import json
import random
from exact_trace_forms import (diagonalize, fixed_forms, hilbert, invariants,
                               isometric, field_options, phi)


def transformed_gram(d, p):
    return [[sum(d[k]*p[k][i]*p[k][j] for k in range(len(d)))
             for j in range(len(d))] for i in range(len(d))]


def main():
    rng = random.Random(3205400)
    congruences = 0
    for n in range(2,9):
        for _ in range(30):
            d = [F(rng.randint(1,15),rng.randint(1,15)) for _ in range(n)]
            p = [[F(i==j) for j in range(n)] for i in range(n)]
            for _ in range(3*n):
                a,b = rng.sample(range(n),2)
                q = F(rng.choice([-3,-2,-1,1,2,3]),rng.choice([1,2,3]))
                for row in p:
                    row[a] += q*row[b]
            out = diagonalize(transformed_gram(d,p))
            assert invariants(d) == invariants(out)
            congruences += 1
    # Known positive trace forms from independently specified small groups.
    group_forms = {
        'Rep(S3)': [F(1,6),F(1,2),F(1,3)],
        'Rep(A5)': [F(1,60),F(1,4),F(1,3),F(2,5),F(2)],
        'Vec(S3)': [F(1,6)]*2+[F(2,3),F(2),F(2,3),F(2)],
        'Vec(Q8)': [F(1,8)]*4+[F(1,2)]*4,
        'Vec(C3)': [F(1,3),F(2,3),F(2)],
    }
    for name,diagonal in group_forms.items():
        assert isometric(diagonal,[1]*len(diagonal)),name
    whole,plus,minus = fixed_forms(20,(1,11))  # Q(zeta_5)
    assert isometric((F(1,5),)+tuple(a/5 for a in whole),[1]*5)
    assert isometric((F(1,5),)+tuple(a/5 for a in plus),[1,2,2])
    assert isometric(tuple(a/5 for a in minus),[2,2])
    # Direct symbol identities and examples; no isometry enumeration involved.
    assert hilbert(-1,-1,2) == -1
    assert hilbert(-3,-1,3) == -1 and hilbert(-3,-1,2) == 1
    assert hilbert(-6,2,2) == hilbert(-6,2,3) == -1
    assert hilbert(-2,1,2) == hilbert(-2,1,3) == 1
    for p in (2,3,5,7,11):
        for a in (-30,-15,-6,-3,-2,-1,1,2,3,5,6,15,30):
            for b in (1,2,3,5,6,10,15,30):
                assert hilbert(a,b,p) == hilbert(b,a,p)
                assert hilbert(a,-a,p) == 1
                assert hilbert(a,9*b,p) == hilbert(a,b,p)
                assert hilbert(a,F(b,4),p) == hilbert(a,b,p)
    # Recheck every cyclotomic fixed field that can enter a large block.
    field_count = 0
    for f,c in [(9,9),(6,12),(8,16),(10,20),(12,24)]:
        if f == 6:
            continue  # The codegree-six field theorem is stronger.
        for label,whole,plus,minus,q6 in field_options(f,phi(c)):
            assert len(whole) == len(plus)+len(minus)
            assert isometric(whole,plus+minus)
            field_count += 1
    out = {'status':'PASS','exact_congruences':congruences,
           'known_group_trace_forms':list(group_forms)+['Vec(C5) with duality'],
           'cyclotomic_fields_checked':field_count,
           'scope':'Exact arithmetic and trace normalization checks; endpoint coverage is checked by the endpoint verifier.'}
    (Path(__file__).resolve().parent/'trace_form_validation.json').write_text(
        json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()
