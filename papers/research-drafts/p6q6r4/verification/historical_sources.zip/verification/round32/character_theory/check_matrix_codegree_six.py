#!/usr/bin/env python3
"""Exact auxiliary checks for the Round 32 matrix-codegree-six proofs.

Uses only Python's standard library. These calculations check finite
arithmetic and support assertions; the accompanying TeX contains the
categorical, order-theoretic, and projection proofs.
"""
from fractions import Fraction as F
from itertools import product, combinations, combinations_with_replacement
from math import isqrt
import json
from pathlib import Path


def square(n):
    return n >= 0 and isqrt(n)**2 == n


def matmul(a,b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]


def rank(a):
    a=[[F(x) for x in row] for row in a]
    r=0
    for j in range(len(a[0])):
        pivot=next((i for i in range(r,len(a)) if a[i][j]),None)
        if pivot is None:continue
        a[r],a[pivot]=a[pivot],a[r]
        scale=a[r][j];a[r]=[x/scale for x in a[r]]
        for i in range(len(a)):
            if i!=r and a[i][j]:
                z=a[i][j];a[i]=[x-z*y for x,y in zip(a[i],a[r])]
        r+=1
    return r


def valuation_unit(x,p):
    x=F(x);a=0
    n,d=x.numerator,x.denominator
    while n%p==0:n//=p;a+=1
    while d%p==0:d//=p;a-=1
    return a,F(n,d)


def unit_mod(u,m):
    return (u.numerator*pow(u.denominator,-1,m))%m


def hilbert(a,b,p):
    a,b=F(a),F(b)
    if p=='infinity':return -1 if a<0 and b<0 else 1
    aa,u=valuation_unit(a,p);bb,v=valuation_unit(b,p)
    if p==2:
        uu,vv=unit_mod(u,8),unit_mod(v,8)
        e=((uu-1)//2)*((vv-1)//2)+aa*((vv*vv-1)//8)+bb*((uu*uu-1)//8)
        return -1 if e%2 else 1
    def leg(u):
        z=pow(unit_mod(u,p),(p-1)//2,p)
        return -1 if z==p-1 else z
    return ((-1)**((aa*bb*((p-1)//2))%2))*leg(u)**(bb%2)*leg(v)**(aa%2)


def dot(x,y):
    weights=(1,1,1,2,2,2,2,2)
    return sum(w*a*b for w,a,b in zip(weights,x,y))


def main():
    out={}
    skew=[]
    for length in range(1,6):
        for v in combinations_with_replacement(range(1,7),length):
            if sum(v)==6 and all(square(x*y) for x in v for y in v):skew.append(v)
    assert set(skew)=={(6,),(3,3),(2,2,2),(1,1,4)}
    out['orthogonal_skew_norm_multisets']=[list(v) for v in skew]

    norm6=[]
    for s,t in product(range(-2,3),range(6)):
        if (6-t+s*s)%2==0 and 2*t-s*s>=6:norm6.append((s,t))
    assert norm6==[(-1,5),(0,4),(1,5)]
    out['norm_six_pair_trace_norm_options']=[list(v) for v in norm6]

    diag=sorted({2*t-s*s for t,s in product((0,2,4),range(-2,3)) if 0<=2*t-s*s<=6})
    assert diag==[0,3,4]
    symp=[]
    for b in range(3,6):
        symp.extend(v for v in combinations_with_replacement(diag,b) if sum(v)==18)
    assert symp==[(3,3,4,4,4)]
    out['symplectic_diagonal_multisets']=[list(v) for v in symp]

    # Exact rank-two minor squareclasses used in the structural proof.
    small={4-z*z for z in range(-1,2)}
    mixed={6-z*z for z in range(-2,3)}
    assert small=={3,4} and mixed=={2,5,6}
    assert all(not square(x*y) for x in small for y in mixed)
    L=[[3,3,0,0,0],[3,3,0,0,0],[0,0,2,2,2],[0,0,2,2,2],[0,0,2,2,2]]
    K=[[6*int(i==j)-L[i][j] for j in range(5)] for i in range(5)]
    assert matmul(K,K)==[[6*x for x in row] for row in K]
    assert rank(K)==3 and rank(L)==2
    out['canonical_skew_gram']=K

    # All rational f6 characters after the unique impossible extra-R sign
    # is removed. Every orthogonal triple has an impossible dimension sum.
    rational=[]
    triple_count=0
    bad_count=0
    for eta,s1,s2 in product((-1,1),repeat=3):
        E=(2,2*eta,0,s1,s2,0,0,0)
        rows=[]
        bad=[]
        for tail in product(range(-2,3),range(-2,3),*([range(-1,2)]*5)):
            h=(1,)+tail
            if dot(h,h)!=6 or dot(E,h):continue
            if h[1]==eta and h[2]==0:
                assert tuple(x+y for x,y in zip(h,E))==(3,3*eta,0,0,0,0,0,0)
                bad.append(h)
            else:rows.append(h)
        triples=[]
        for a,b,c in combinations(rows,3):
            if dot(a,b)==dot(a,c)==dot(b,c)==0:
                summed=tuple(x+y+z for x,y,z in zip(a,b,c))
                assert summed==(3,-3*eta,0,0,0,0,0,0)
                triples.append((a,b,c))
        assert len(rows)==40 and len(bad)==1 and len(triples)==8
        rational.append({'signs':[eta,s1,s2],'retained_rows':len(rows),'bad_rows':len(bad),'orthogonal_triples':len(triples),'triple_sum':[3,-3*eta,0,0,0,0,0,0]})
        triple_count+=len(triples);bad_count+=len(bad)
    out['rational_support_checks']=rational
    out['checked_orthogonal_triples']=triple_count
    out['excluded_single_rows']=bad_count

    ramification={}
    for a,b,expected in [(-1,6,[2,3]),(-3,2,[2,3]),(-6,2,[2,3]),(-6,3,[2,3]),(-1,3,[2,3]),(-3,-1,[3,'infinity'])]:
        places=[p for p in (2,3,5,7,11,13,'infinity') if hilbert(a,b,p)==-1]
        assert places==expected,(a,b,places)
        ramification[f'({a},{b})']=places
    out['quaternion_ramification_checks']=ramification
    assert F(6)*F(1,3)**2==F(2,3)

    D=[[0,-1,1,0],[-1,1,0,1],[1,0,1,1],[0,1,1,0]]
    assert matmul(D,D)==[[D[i][j]+2*int(i==j) for j in range(4)] for i in range(4)]
    # Verify the polynomial dimension identity as constant and linear parts.
    for vec in ([1,0,2,1],[0,1,1,1]):
        assert [sum(a*b for a,b in zip(row,vec)) for row in D]==[2*x for x in vec]
    out['quadratic_difference_component']=D
    out['status']='PASS'
    dest=Path(__file__).with_name('matrix_codegree_six_verification.json')
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':'PASS','orthogonal_norm_multisets':len(skew),'rational_support_sign_cases':len(rational),'orthogonal_triples_checked':triple_count,'quaternion_presentations_checked':len(ramification),'output':dest.name}))

if __name__=='__main__':main()
