#!/usr/bin/env python3
"""Run disjoint standard-library verification shards and check their coverage."""
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
from pathlib import Path
import argparse
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
RANGES = ((0, 1000), (1000, 2200), (2200, 3200), (3200, 4500),
          (4500, 5200), (5200, 5800), (5800, 6547))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--use-replay-ledger', action='store_true')
    args = parser.parse_args()
    assert args.workers >= 1
    records = [json.loads(line) for line in
               (HERE / 'rank14_final_certificates.jsonl').read_text().splitlines()]
    sizes = {r: sum(r[0] <= item['index'] < r[1] for item in records) for r in RANGES}

    def run(bounds):
        a, b = bounds
        output = HERE / f'verification14_{a}_{b}.json'
        command = [sys.executable, str(HERE / 'verify_rank14.py'),
                   '--start', str(a), '--stop', str(b), '--output', str(output)]
        if args.use_replay_ledger:
            command.append('--use-replay-ledger')
        with (HERE / f'verification14_{a}_{b}_console.txt').open('w') as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
        result = json.loads(output.read_text())
        assert result['status'] == 'PASS'
        assert result['checked_row_states'] == sizes[bounds]
        print('PASS', bounds, 'states', sizes[bounds], flush=True)
        return result

    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        results = list(executor.map(run, sorted(RANGES, key=sizes.get, reverse=True)))
    assert len({r['proof_sha256'] for r in results}) == 1
    assert all(r['enumeration'] == results[0]['enumeration'] for r in results)
    counts = Counter()
    for result in results:
        counts.update(result['certificate_kinds_in_range'])
    combined = {'status': 'PASS', 'workers': args.workers,
                'used_exact_replay_ledger': args.use_replay_ledger,
                'proof_sha256': results[0]['proof_sha256'],
                'enumeration': results[0]['enumeration'],
                'checked_row_states': sum(r['checked_row_states'] for r in results),
                'retained_rows_checked': sum(r['retained_rows_checked'] for r in results),
                'moment_vectors_checked': sum(r['moment_vectors_checked'] for r in results),
                'certificate_kinds': dict(counts),
                'ranges': [list(r) for r in RANGES]}
    assert combined['checked_row_states'] == len(records)
    (HERE / 'rank14_full_verification.json').write_text(
        json.dumps(combined, indent=2) + '\n')
    print(json.dumps(combined, indent=2), flush=True)


if __name__ == '__main__':
    main()
