#!/usr/bin/env python3
"""Exact independent checks of the new degree-two word recurrences.

This checks the formulas against direct matrix and cyclotomic arithmetic.
It is not an existence test for a fusion ring.
"""
from fractions import Fraction as Q
from itertools import product
from collections import Counter
from pathlib import Path
import json

from mixed_trace_filter import matrix_mixed
from power_trace_filter import quadratic_powers
from field_power_polynomials import multiply
from fixed_lattice import fixed_lattice
from orbit_pairs import phi, powers, ramanujan
from generic_fields import fields
import r32_trace_forms as forms

HERE = Path(__file__).resolve().parent


def mm(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(2))
                       for j in range(2)) for i in range(2))


def tr(a):
    return a[0][0] + a[1][1]


def matrix_checks():
    count = comparisons = 0
    identity = ((1, 0), (0, 1))
    bound = 6
    for entries in product(range(-2, 3), repeat=4):
        a = (entries[:2], entries[2:])
        # The nontrivial positive involutions also check that no orthonormal
        # rational basis for the positive plane was silently assumed.
        for delta in (1, 2, 3):
            star = ((a[0][0], Q(a[1][0], delta)),
                    (delta * a[0][1], a[1][1]))
            s = tr(a)
            n = a[0][0] * a[1][1] - a[0][1] * a[1][0]
            t = tr(mm(a, star))
            aa = [identity]
            bb = [identity]
            yy = [identity]
            y = mm(a, star)
            for _ in range(bound):
                aa.append(mm(aa[-1], a))
                bb.append(mm(bb[-1], star))
                yy.append(mm(yy[-1], y))
            expected = matrix_mixed(s, t, n, bound)
            actual = tuple(tr(mm(aa[i], bb[j]))
                           for i in range(bound + 1) for j in range(i + 1))
            assert actual == expected
            assert tuple(map(tr, aa)) == quadratic_powers(s, n, bound)
            assert tuple(map(tr, yy)) == quadratic_powers(t, n * n, bound)
            difference = tr(yy[2]) - tr(mm(aa[2], bb[2]))
            assert difference == (t - 2 * n) * (t + 2 * n - s * s)
            assert difference >= 0
            count += 1
            comparisons += len(actual) + 2 * (bound + 1) + 2
    return {"matrices_with_involution": count,
            "exact_matrix_comparisons": comparisons, "power_cutoff": bound}


def quartic_checks():
    profiles = json.loads((HERE / 'profiles.json').read_text())
    blocks = {(5400 // a, k) for p in profiles for a, k in Counter(p).items()}
    quartics = set()
    for f, k in blocks:
        for label, whole, plus, minus, q6 in fields(f, k):
            if len(whole) != 4 or not minus:
                continue
            cstr, hstr = label.split(':H=')
            quartics.add((int(cstr[4:]), tuple(map(int, hstr.split(',')))))
    count = 0
    for c, h in sorted(quartics):
        n = phi(c)
        basis, _, _ = fixed_lattice(c, h, False)
        pp = powers(c)
        trace = lambda x: sum(a * ramanujan(c, j) for j, a in enumerate(x)) // len(h)
        identity = (1,) + (0,) * (n - 1)
        for coordinates in product(range(-1, 2), repeat=4):
            alpha = tuple(sum(z * b[j] for z, b in zip(coordinates, basis))
                          for j in range(n))
            if any(z.denominator != 1 for z in alpha):
                continue
            alpha = tuple(map(int, alpha))
            conjugate = tuple(sum(alpha[j] * pp[-j % c][i] for j in range(n))
                              for i in range(n))
            beta = multiply(c, alpha, conjugate)
            apower = bpower = identity
            alpha_traces = [4]
            beta_traces = [4]
            for j in range(1, 9):
                apower = multiply(c, apower, alpha)
                bpower = multiply(c, bpower, beta)
                alpha_traces.append(trace(apower))
                beta_traces.append(trace(bpower))
            coefficients = [1]
            for j in range(1, 5):
                numerator = -sum(coefficients[j-i] * alpha_traces[i]
                                 for i in range(1, j+1))
                assert numerator % j == 0
                coefficients.append(numerator // j)
            assert beta_traces[1] % 2 == 0
            predicted = tuple(2 * z for z in quadratic_powers(
                beta_traces[1] // 2, coefficients[-1], 8))
            assert tuple(beta_traces) == predicted
            count += 1
    return {"CM_quartic_fields": len(quartics),
            "CM_quartic_entries": count, "norm_power_cutoff": 8}


def quaternion_checks():
    tests = [(1, 1, (2,)), (1, 3, (3,)),
             (2, 5, (5,)), (3, 10, (2, 3, 5))]
    for a, b, expected in tests:
        places = sorted({2} | forms.prime_factors(a) | forms.prime_factors(b))
        actual = tuple(p for p in places if forms.hilbert(-a, -b, p) == -1)
        assert actual == expected
    return {"definite_quaternion_presentations": len(tests)}


def main():
    result = {"matrix_words": matrix_checks(),
              "CM_norm_words": quartic_checks(),
              "quaternion_forms": quaternion_checks(), "status": "PASS"}
    (HERE / 'trace_recursion_verification.json').write_text(
        json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
