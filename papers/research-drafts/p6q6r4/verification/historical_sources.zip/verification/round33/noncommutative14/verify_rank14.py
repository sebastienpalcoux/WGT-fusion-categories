#!/usr/bin/env python3
"""Reproduce rank-fourteen exclusions using exact standard-library arithmetic.

The certificate generators use scipy only to propose separators.  This verifier
never imports those generators and checks every separator with integer sums.
The --start/--stop options split the row replay by canonical profile index.
The --coverage-only option checks all enumeration and coverage data but omits
the potentially longer row replay.  No unknown row is treated as excluded.
"""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import time

from endpoint_core import degree_profiles
from trace_rank14 import analyze as trace_analyze
from cheap_rank14 import analyze as cheap_analyze
from fixed_field_rows import fixed_blocks, fixed_rows
from coupled_rows import coupled_moments
from gap_filter import row_determinants, noncommutative_gap_possible
from power_trace_filter import power_trace_possible
from mixed_trace_filter import mixed_trace_possible
from norm_word_filter import norm_word_possible
from exact_certificate_checks import verify_certificate

HERE = Path(__file__).resolve().parent
PROOF_FILES = (
    'verify_rank14.py', 'endpoint_core.py', 'trace_rank14.py',
    'generic_fields.py', 'r32_trace_forms.py', 'cheap_rank14.py',
    'fixed_field_rows.py', 'fixed_lattice.py', 'coupled_rows.py',
    'refined_rows.py', 'orbit_pairs.py', 'field_discriminant_profiles.py',
    'gap_filter.py', 'power_trace_filter.py', 'field_power_polynomials.py',
    'mixed_trace_filter.py', 'norm_word_filter.py', 'exact_certificate_checks.py',
)


def record_digest(record):
    return hashlib.sha256(json.dumps(record, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def proof_digest():
    digest = hashlib.sha256()
    for name in sorted(PROOF_FILES):
        digest.update(name.encode() + b'\0' + (HERE / name).read_bytes() + b'\0')
    return digest.hexdigest()


def key(record):
    return (record['index'], record['double_degree'],
            record['assignment_index'], record['kind'])


def read_records(name):
    path = HERE / name
    return [json.loads(line) for line in path.read_text().splitlines()]


def parity_case(assignment, pieces, kind):
    if kind != 'orthogonal' or assignment['q6'] != 1:
        return None
    if assignment['q'] == 1:
        pass
    elif assignment['q'] == 2:
        if not any(block['formal_codegree'] == 8 and
                   'quadratic_disc=-8' in block['fields']
                   for block in assignment['fields']):
            return None
    else:
        return None
    return next(i for i, piece in enumerate(pieces) if piece[2] == 'complex6')


def verify_small_certificate(profile, doubled, rows, q, kind, certificate):
    category = certificate['kind']
    if category == 'canonical_remainder':
        dimensions = sorted({d for sd, d, values in rows})
        assert dimensions == certificate['eligible_dimensions']
        counts = Counter(profile)
        required = {a - 1 for a, n in counts.items()
                    if n - 2 * (a == doubled) > 0} | {doubled - 2}
        # Independently build reachable remainders by forward additions.
        reachable = {0}
        for value in range(max(profile) + 1):
            if value not in reachable:
                continue
            reachable.update(value + d for d in dimensions
                             if value + d <= max(profile))
        missing = sorted(required - reachable)
        assert missing and missing == certificate['missing_remainders']
        return True
    if category == 'duality_dimension_squares':
        selfdual = sorted({d for sd, d, values in rows if sd})
        paired = sorted({d for sd, d, values in rows if not sd})
        assert selfdual == certificate['eligible_selfdual']
        assert paired == certificate['eligible_pair']
        pairs = q + (3 if kind == 'symplectic' else 1)
        reachable = {0}
        for count, choices, weight in ((13 - 2 * pairs, selfdual, 1),
                                       (pairs, paired, 2)):
            assert count >= 0
            for _ in range(count):
                reachable = {value + weight * d * d
                             for value in reachable for d in choices
                             if value + weight * d * d <= 5399}
        assert 5399 not in reachable
        return True
    return False


def replay_record(record, assignment):
    pieces, matrix = fixed_blocks(assignment, record['double_degree'])
    assert [list(piece) for piece in pieces] == record['pieces']
    assert matrix == record['double']
    q6, q, kind = record['q6'], record['q'], record['kind']
    assert (q6, q) == (assignment['q6'], assignment['q'])
    rows = list(fixed_rows(pieces, matrix, q6, q, kind))
    assert len(rows) == record['rows_before']
    parity = parity_case(assignment, pieces, kind)
    assert parity == record['parity']
    if parity is not None:
        rows = [row for row in rows
                if (row[2][matrix][0] - row[2][parity][0]) % 2 == 0]
    method = record['method']
    if method != 'fixed_fields':
        assert method in ('mixed_power_traces', 'higher_power_norm_words')
        rows = [row for row in rows
                if row_determinants(pieces, row[1], row[2], row[0], kind) != ()
                and noncommutative_gap_possible(
                    pieces, row[1], row[2], row[0], kind)]
        if method == 'higher_power_norm_words':
            assert len(rows) == record['rows_gap']
        rows = [row for row in rows if power_trace_possible(
            pieces, row[1], row[2], row[0], kind, max_power=14,
            higher_fields=(method == 'higher_power_norm_words'))]
        if method == 'higher_power_norm_words':
            assert len(rows) == record['rows_power']
        rows = [row for row in rows if mixed_trace_possible(
            pieces, row[1], row[2], row[0], kind, bound=11)]
        if method == 'higher_power_norm_words':
            rows = [row for row in rows if norm_word_possible(
                pieces, row[1], row[2], row[0], kind, bound=14)]
    assert len(rows) == record['rows']
    target, vectors = coupled_moments(pieces, matrix, rows, q, kind)
    assert len(vectors) == record['vectors']
    certificate = record['certificate']
    assert certificate is not None
    if not verify_small_certificate(record['profile'], record['double_degree'],
                                    rows, q, kind, certificate):
        assert verify_certificate(vectors, target, certificate)
    return len(rows), len(vectors)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--start', type=int, default=0)
    parser.add_argument('--stop', type=int, default=6547)
    parser.add_argument('--coverage-only', action='store_true')
    parser.add_argument('--skip-trace-replay', action='store_true')
    parser.add_argument('--use-replay-ledger', action='store_true',
                        help='use already completed exact row replays, verifying all hashes')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    start = time.monotonic()
    profiles = list(degree_profiles(left=11))
    assert len(profiles) == 6547
    assert [list(p) for p in profiles] == json.loads((HERE / 'profiles.json').read_text())
    expected_placements = {(i, a) for i, p in enumerate(profiles)
                           for a, count in Counter(p).items() if count >= 2}
    assert len(expected_placements) == 12921
    trace_records = read_records('rank14_trace_final.jsonl')
    trace = {(r['index'], r['double_degree']): r for r in trace_records}
    assert len(trace_records) == len(trace) and set(trace) == expected_placements
    cheap = {(r['index'], r['double_degree']): r
             for r in read_records('cheap14_final.jsonl')}
    assert all(not trace[k]['excluded'] and r['excluded'] for k, r in cheap.items())
    # The frozen final file contains exactly one proved record per required
    # field/duality state. No first-pass open certificate is silently accepted.
    final_records = read_records('rank14_final_certificates.jsonl')
    final = {key(r): r for r in final_records}
    assert len(final) == len(final_records)
    required = {}
    counts = Counter()
    for placement, record in trace.items():
        index, doubled = placement
        assert record['profile'] == list(profiles[index])
        if args.start <= index < args.stop and not args.skip_trace_replay:
            regenerated = trace_analyze(profiles[index], doubled)
            assert all(record[k] == value for k, value in regenerated.items())
        counts['placements'] += 1
        if record['excluded']:
            counts['trace_excluded_placements'] += 1
            continue
        counts['trace_surviving_assignments'] += len(record['surviving_assignments'])
        counts['trace_surviving_states'] += sum(len(a['duality_types'])
                                                for a in record['surviving_assignments'])
        if placement in cheap:
            if args.start <= index < args.stop:
                regenerated = cheap_analyze(profiles[index], doubled)
                assert all(cheap[placement][k] == value
                           for k, value in regenerated.items())
                assert regenerated['excluded']
            counts['cheap_excluded_placements'] += 1
            continue
        for ai, assignment in enumerate(record['surviving_assignments']):
            for kind in assignment['duality_types']:
                state = index, doubled, ai, kind
                required[state] = assignment
    assert set(final) == set(required), (len(final), len(required),
                                       set(required) - set(final), set(final) - set(required))
    counts['required_row_states'] = len(required)
    checked = row_count = vector_count = 0
    certificates = Counter()
    ledger = {}
    current_proof = proof_digest()
    if args.use_replay_ledger:
        for path in sorted(HERE.glob('row_replay14_*.jsonl')):
            for line in path.read_text().splitlines():
                entry = json.loads(line)
                state = tuple(entry['state'])
                assert state not in ledger
                assert entry['status'] == 'PASS'
                assert entry['proof_sha256'] == current_proof
                ledger[state] = entry
    for state, assignment in required.items():
        record = final[state]
        assert record['certificate'] is not None
        assert record['fields'] == assignment['fields']
        assert record['profile'] == list(profiles[record['index']])
        if not args.start <= state[0] < args.stop:
            continue
        certificates[record['certificate']['kind']] += 1
        if not args.coverage_only:
            if args.use_replay_ledger:
                assert state in ledger, state
                entry = ledger[state]
                assert entry['record_sha256'] == record_digest(record)
                rows, vectors = entry['rows'], entry['vectors']
            else:
                rows, vectors = replay_record(record, assignment)
            row_count += rows
            vector_count += vectors
            checked += 1
            if checked % 100 == 0:
                print('checked', checked, 'last', state, 'seconds',
                      round(time.monotonic() - start, 2), flush=True)
    result = {'status': 'PASS', 'range': [args.start, args.stop],
              'coverage_only': args.coverage_only,
              'trace_replayed': not args.skip_trace_replay,
              'used_exact_replay_ledger': args.use_replay_ledger,
              'proof_sha256': current_proof,
              'enumeration': dict(counts),
              'checked_row_states': checked, 'retained_rows_checked': row_count,
              'moment_vectors_checked': vector_count,
              'certificate_kinds_in_range': dict(certificates),
              'seconds': time.monotonic() - start}
    output = args.output or HERE / f'verification14_{args.start}_{args.stop}.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
