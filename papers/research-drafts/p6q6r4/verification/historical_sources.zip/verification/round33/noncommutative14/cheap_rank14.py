#!/usr/bin/env python3
"""Exact preliminary source-degree/remainder/type screen for rank14."""
from collections import Counter
from functools import lru_cache
from math import gcd,isqrt
from pathlib import Path
import json,time,argparse
DIM=5400;HERE=Path(__file__).resolve().parent

@lru_cache(None)
def options(a,k,matrix,d):
    cap=min(DIM//a-1,k*d*d-1,(DIM-d*d)//a)
    if k==1:
        r=min(d-1,isqrt(cap));return tuple((a*s,a*s*s)for s in range(-r,r+1))
    return tuple((a*s,a*t)for t in range(cap+1)for s in range(-min(k*d-1,isqrt(k*t),t),min(k*d-1,isqrt(k*t),t)+1)if matrix or t!=1 or abs(s)==1)

def eligible(blocks,d):
    choices=[options(a,k,m,d)for a,k,m in blocks]
    order=sorted(range(len(blocks)),key=lambda i:len(choices[i]));choices=[sorted(choices[i],key=lambda z:z[1])for i in order];blocks=[blocks[i]for i in order]
    if any(not x for x in choices):return False
    n=len(choices);ss=[0]*(n+1);st=[0]*(n+1);sm=[0]*(n+1);sg=[(0,0,0,0)]*(n+1)
    for h in reversed(range(n)):
        a,k,m=blocks[h];ss[h]=ss[h+1]+max(abs(s)for s,t in choices[h]);st[h]=st[h+1]+max(t for s,t in choices[h]);sm[h]=sm[h+1]+a*k
        g=list(sg[h+1])
        for s,t in choices[h]:
            for j,x in enumerate((s,t,t-s,t+s)):g[j]=gcd(g[j],x)
        sg[h]=tuple(g)
    lookup=set(choices[-1])
    @lru_cache(None)
    def rec(h,s,t):
        if t<0 or t>st[h]or abs(s)>ss[h]or abs(s)>t or s*s>sm[h]*t:return False
        if any((g and x%g)or(not g and x)for x,g in zip((s,t,t-s,t+s),sg[h])):return False
        if h==n-1:return(s,t)in lookup
        for u,v in choices[h]:
            if v>t:break
            if rec(h+1,s-u,t-v):return True
        return False
    return rec(0,-d,DIM-d*d)

def semigroup(maximum,ds):
    bits=[False]*(maximum+1);bits[0]=True
    for i in range(1,maximum+1):bits[i]=any(i>=d and bits[i-d]for d in ds)
    return bits

def square_possible(ds,count=13):
    bits=1;mask=(1<<DIM)-1
    for _ in range(count):
        result=0
        for d in ds:result|=bits<<(d*d)
        bits=result&mask
    return bool(bits>>(DIM-1)&1)

def analyze(profile,double):
    counts=Counter(profile);blocks=[(a,k,a==double)for a,k in counts.items()]
    ds=[d for d in range(3,73)if eligible(blocks,d)];reachable=semigroup(max(profile),ds)
    remainders=[a-1 for a,k in counts.items()if k-2*(a==double)>0]+[double-2]
    bad=[r for r in remainders if not reachable[r]]
    square=not bad and square_possible(ds)
    return{'eligible':ds,'remainder_obstructions':bad,'square_possible':square,'excluded':not square}

def main():
    p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=0);p.add_argument('--stop',type=int,default=6547);p.add_argument('--output',type=Path,default=HERE/'rank14_cheap.jsonl');a=p.parse_args();start=time.time();n=ex=0
    records=[r for l in(HERE/'rank14_trace.jsonl').read_text().splitlines()if not(r:=json.loads(l))['excluded']and a.start<=r['index']<a.stop]
    with a.output.open('w')as out:
        for row in records:
            r=analyze(tuple(row['profile']),row['double_degree']);r.update({k:row[k]for k in('index','profile','double_degree')});out.write(json.dumps(r)+'\n');out.flush();n+=1;ex+=r['excluded']
            if n%50==0:print(n,'excluded',ex,'index',row['index'],'sec',round(time.time()-start,2),flush=True)
    print('FINAL',n,'excluded',ex,'seconds',round(time.time()-start,2),flush=True)
if __name__=='__main__':main()
