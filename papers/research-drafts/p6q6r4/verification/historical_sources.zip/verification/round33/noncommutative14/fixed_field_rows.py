"""Exact moment rows for one global assignment of full character fields."""
from collections import Counter
from functools import lru_cache
from math import gcd,isqrt
from orbit_pairs import lattice_vectors,ramanujan,powers,phi,full_orbits
from coupled_rows import block_options,coupled_moments
from generic_fields import EXTRA_POLY
import orbit_pairs
orbit_pairs.POLY.update(EXTRA_POLY)
from fixed_lattice import fixed_pairs

@lru_cache(None)
def fixed_orbit_pairs(f,label,d,sd):
    cap=f-1
    if label=='Q':
        limit=min(isqrt(cap),d-1)
        if not sd:limit=min(limit,isqrt(cap//2))
        return frozenset((x,x*x) for x in range(-limit,limit+1))
    if label=='Q(sqrt(-3))':
        return frozenset([(0,0),(-2,2),(2,2)] if sd else [(0,0),(-1,2),(1,2)])
    if label.startswith('quadratic_disc='):
        delta=int(label.split('=')[1]);out=set()
        for b in range(isqrt(2*cap//abs(delta))+1):
            if sd and delta<0 and b:continue
            for s in range(-isqrt(2*cap),isqrt(2*cap)+1):
                if delta%4==1:
                    if (s-b)%2:continue
                elif s%2:continue
                numerator=s*s+abs(delta)*b*b
                if numerator%2 or numerator//2>cap:continue
                if delta>0:
                    if 2*d<=abs(s) or delta*b*b>=(2*d-abs(s))**2:continue
                elif numerator>=4*d*d:continue
                out.add((s,numerator//2))
        return frozenset(out)
    if label=='real_cubic_conductor9':
        return frozenset((s,t) for s,t in fixed_pairs(f,9,(1,8),sd) if t<3*d*d)
    assert label.startswith('zeta'),label
    cstr,hstr=label.split(':H=');c=int(cstr[4:]);h=tuple(map(int,hstr.split(',')))
    return frozenset((s,t) for s,t in fixed_pairs(f,c,h,sd)
                     if t<(phi(c)//len(h))*d*d)

@lru_cache(None)
def subgroup_pairs(f,c,h,sd):
    n=phi(c);e=n//len(h);cap=f-1
    gram=[[ramanujan(c,i-j) for j in range(n)] for i in range(n)]
    pp=powers(c);required=h+((c-1,) if sd and c-1 not in h else ())
    autos=[tuple(pp[(a*j)%c] for j in range(n)) for a in required]
    traces=[ramanujan(c,j) for j in range(n)];out=set()
    for x,q in lattice_vectors(gram,len(h)*cap):
        if any(tuple(sum(x[j]*auto[j][i] for j in range(n)) for i in range(n))!=x for auto in autos):continue
        tr=sum(a*b for a,b in zip(x,traces));assert tr%len(h)==q%len(h)==0
        s,t=tr//len(h),q//len(h)
        if not sd and 2*t>e*f-e:continue
        out.add((s,t))
    return frozenset(out)

def fixed_blocks(assignment,double_degree):
    pieces=[]
    if double_degree is not None:pieces.append((double_degree,2,'matrix'))
    for block in assignment['fields']:
        f=block['formal_codegree'];labels=block['fields'];a=5400//f
        rational=sum(label=='Q' for label in labels)
        complex6=sum(label=='Q(sqrt(-3))' for label in labels) if f==6 else 0
        if rational:
            # Keep one rational character separately. Remaining rational
            # columns may be merged, which is still a necessary relaxation.
            pieces.append((a,1,'rational6' if f==6 else 'Q'))
            if rational>1:pieces.append((a,rational-1,'rational6' if f==6 else 'rational_group'))
        if complex6:pieces.append((a,2*complex6,'complex6'))
        for label in labels:
            if label=='Q' or (f==6 and label=='Q(sqrt(-3))'):continue
            if label.startswith('quadratic'):e=2
            elif label=='real_cubic_conductor9':e=3
            else:
                cstr,hstr=label.split(':H=');e=phi(int(cstr[4:]))//len(hstr.split(','))
            pieces.append((a,e,label))
    pieces.sort(key=lambda x:(x[1]>1,-x[0],x[2]))
    double=next((i for i,p in enumerate(pieces) if p[2]=='matrix'),None)
    assert sum(p[1] for p in pieces)==11,(pieces,assignment)
    return pieces,double

@lru_cache(None)
def rational_group_pairs(f,k,d,sd):
    options=fixed_orbit_pairs(f,'Q',d,sd);states={(0,0)}
    for _ in range(k):states={(s+u,t+v) for s,t in states for u,v in options if t+v<f}
    return frozenset(states)

def fixed_options(piece,d,sd,kind,q6):
    a,k,label=piece;f=5400//a;cap=min((5400-d*d)//a,k*d*d-1,f-1)
    if label in ('matrix','rational6','complex6'):
        if label=='matrix' and f==6 and kind=='symplectic':
            # R32 codegree-six matrix support theorem (q=2 handled outside).
            return [(s,t) for s,t in ((-2,2),(0,0),(2,2)) if t<=cap] if sd else [(s,t) for s,t in ((0,0),(-1,2),(0,2),(1,2)) if t<=cap]
        return block_options(piece,d,sd,kind,False,q6)
    options=(rational_group_pairs(f,k,d,sd) if label=='rational_group' else fixed_orbit_pairs(f,label,d,sd))
    return [(s,t) for s,t in options if t<=cap and abs(s)<k*d]

def fixed_rows(pieces,double,q6,q,kind):
    if double is not None and pieces[double][0]==900 and kind=='symplectic' and q not in (2,3):return
    blocks=[(a,k) for a,k,label in pieces]
    for sd in [True,False]:
      for d in range(3,73):
        choices=[sorted(fixed_options(p,d,sd,kind,q6),key=lambda x:(x[1],x[0])) for p in pieces]
        if any(not opt for opt in choices):continue
        order=sorted(range(len(blocks)),key=lambda i:len(choices[i]));lookup=[set(opt) for opt in choices]
        selected=[None]*len(blocks);length=len(blocks)
        ss=[0]*(length+1);st=[0]*(length+1);sm=[0]*(length+1);sf=[1]*(length+1);sg=[[0]*4 for _ in range(length+1)]
        for h in reversed(range(length)):
            i=order[h];a,k=blocks[i]
            ss[h]=ss[h+1]+a*max(abs(s) for s,t in choices[i]);st[h]=st[h+1]+a*max(t for s,t in choices[i]);sm[h]=sm[h+1]+a*k
            sf[h]=max(sf[h+1],2 if i==double else 1);gg=sg[h+1].copy()
            for s,t in choices[i]:
                for j,v in enumerate((a*s,a*t,a*(t-s),a*(t+s))):gg[j]=gcd(gg[j],v)
            sg[h]=gg
        def visit(h,linear,square):
            if square<0 or square>st[h] or abs(linear)>ss[h] or abs(linear)>sf[h]*square or linear*linear>sm[h]*square:return
            for v,g in zip((linear,square,square-linear,square+linear),sg[h]):
                if (g and v%g) or (not g and v):return
            i=order[h];a,k=blocks[i]
            if h==length-1:
                if linear%a or square%a:return
                pair=(linear//a,square//a)
                if pair in lookup[i]:
                    selected[i]=pair;yield sd,d,tuple(selected)
                return
            for s,t in choices[i]:
                if a*t>square:break
                selected[i]=(s,t);yield from visit(h+1,linear-a*s,square-a*t)
        yield from visit(0,-d,5400-d*d)
