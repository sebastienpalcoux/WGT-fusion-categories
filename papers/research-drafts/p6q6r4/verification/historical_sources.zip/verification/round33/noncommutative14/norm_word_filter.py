"""Exact necessary coefficient traces of (X X*)^k and a commutator congruence."""
from functools import lru_cache
from itertools import product
from power_trace_filter import scalar_power_options,quadratic_powers
from gap_filter import row_determinants
from mixed_trace_filter import field_reality

@lru_cache(None)
def scalar_norm_options(piece,value,sd,d,bound):
    a,k,label=piece;s,t=value
    if label in('Q','rational6','rational_group')or sd:
        pp=scalar_power_options(piece,value,2*bound,sd,d,True)
        if pp is None:return None
        return tuple(tuple(v[2*j]for j in range(bound+1))for v in pp)
    if label=='complex6':return ((k,)+(t,)*bound,)
    reality=field_reality(piece)
    if reality is True:
        pp=scalar_power_options(piece,value,2*bound,sd,d,True)
        return tuple(tuple(v[2*j]for j in range(bound+1))for v in pp)
    if reality is False:
        assert k==2
        if t%2:return ()
        return(tuple(2*(t//2)**j for j in range(bound+1)),)
    # Higher real or CM fields are identified exactly by their subgroup.
    if label=='real_cubic_conductor9':
        pp=scalar_power_options(piece,value,2*bound,sd,d,True)
        return tuple(tuple(v[2*j]for j in range(bound+1))for v in pp)
    if not label.startswith('zeta'):return None
    cc,hh=label.split(':H=');c=int(cc[4:]);h=tuple(map(int,hh.split(',')))
    if c-1 in h:
        pp=scalar_power_options(piece,value,2*bound,sd,d,True)
        return tuple(tuple(v[2*j]for j in range(bound+1))for v in pp)
    if k==4:
        if t%2:return ()
        from field_power_polynomials import polynomial_map
        out=set()
        for coefficients in polynomial_map(5400//a,c,h,sd).get((s,t),()):
            n=coefficients[-1]
            out.add(tuple(2*x for x in quadratic_powers(t//2,n,bound)))
        return tuple(sorted(out))
    if k==6 and c==9:
        # The exact fixed lattice has only t=0 or t=6 at f=9.
        # At t=e>0, AM--GM and the nonzero integral norm force all
        # conjugate absolute values to equal1.
        assert 5400//a==9 and t in(0,6)
        return((6,)+(t,)*bound,)
    return None

def determinant_options(pieces,d,values,sd,kind):
    mi=next(i for i,p in enumerate(pieces)if p[2]=='matrix');s,t=values[mi]
    ns=row_determinants(pieces,d,values,sd,kind)
    if ns is None:
        if sd:
            if(s*s-t)%2:return mi,()
            ns=((s*s-t)//2,)
        elif kind=='symplectic':
            if t%2:return mi,()
            ns=(t//2,)
        else:ns=range(-(t//2),t//2+1)
    f=5400//pieces[mi][0];out=[]
    for n in ns:
        if 2*abs(n)>t or(kind=='orthogonal'and 2*n<s*s-t):continue
        F=(t-2*n)*(t+2*n-s*s)
        if F<0 or F%f:continue
        out.append(n)
    return mi,tuple(out)

def norm_word_possible(pieces,d,values,sd,kind,bound=14):
    mi,ns=determinant_options(pieces,d,values,sd,kind)
    if not ns:return False
    choices=[];weights=[]
    for i,(p,v)in enumerate(zip(pieces,values)):
        if i==mi:continue
        opts=scalar_norm_options(tuple(p),tuple(v),sd,d,bound)
        if opts is None:return True
        if not opts:return False
        choices.append(opts);weights.append(p[0])
    s,t=values[mi]
    choices.append(tuple(quadratic_powers(t,n*n,bound)for n in ns));weights.append(pieces[mi][0])
    base=[d**(2*k)for k in range(bound+1)]
    for selected in product(*choices):
        if all((z:=base[k]+sum(a*v[k]for a,v in zip(weights,selected)))>=0 and z%5400==0 for k in range(bound+1)):
            return True
    return False
