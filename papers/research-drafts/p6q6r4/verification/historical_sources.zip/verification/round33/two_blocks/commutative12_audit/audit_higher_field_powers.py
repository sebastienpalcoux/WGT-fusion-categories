#!/usr/bin/env python3
"""Independent exact audit of the three higher fields needed at rank twelve.

The producer uses rational fixed nullspaces and an LDL lattice walk.  This
audit instead enumerates the ENTIRE ambient integral-coordinate box, whose
bounds follow from the inverse trace Gram matrix, and tests automorphisms
directly. Cyclotomic polynomials, multiplication, traces and inverse matrices
are reimplemented independently here. Only the final answer comparison
imports the producer.
"""
from collections import defaultdict
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from math import gcd, isqrt, prod
from pathlib import Path
import argparse, json, sys

HERE=Path(__file__).resolve().parent

def trim(p):
    p=list(p)
    while len(p)>1 and not p[-1]:p.pop()
    return p

def divide_exact(p,q):
    p=trim(p);q=trim(q);out=[0]*(len(p)-len(q)+1)
    assert q[-1]==1
    for i in range(len(out)-1,-1,-1):
        out[i]=p[i+len(q)-1]
        for j,x in enumerate(q):p[i+j]-=out[i]*x
    assert not any(p)
    return tuple(trim(out))

@lru_cache(None)
def cyclotomic(c):
    p=(-1,)+(0,)*(c-1)+(1,)
    for d in range(1,c):
        if c%d==0:p=divide_exact(p,cyclotomic(d))
    return p

def multiply(c,x,y):
    p=cyclotomic(c);n=len(p)-1;z=[0]*(2*n-1)
    for i,a in enumerate(x):
        for j,b in enumerate(y):z[i+j]+=a*b
    for i in range(2*n-2,n-1,-1):
        v=z[i]
        for j,a in enumerate(p):z[i-n+j]-=v*a
    assert not any(z[n:])
    return tuple(z[:n])

@lru_cache(None)
def root_powers(c):
    n=len(cyclotomic(c))-1;one=(1,)+(0,)*(n-1)
    z=(0,1)+(0,)*(n-2);powers=[one]
    for _ in range(c):powers.append(multiply(c,powers[-1],z))
    assert powers[-1]==one
    return tuple(powers[:-1])

def automorphism(c,x,a):
    powers=root_powers(c);n=len(x)
    return tuple(sum(x[j]*powers[(a*j)%c][i] for j in range(n))for i in range(n))

def trace(c,x):
    n=len(x);answer=0
    for i in range(n):
        basis=tuple(int(i==j)for j in range(n))
        answer+=multiply(c,x,basis)[i]
    return answer

def inverse(g):
    n=len(g);a=[[Q(x)for x in r]+[Q(i==j)for j in range(n)]for i,r in enumerate(g)]
    for j in range(n):
        k=next(k for k in range(j,n)if a[k][j]);a[j],a[k]=a[k],a[j]
        pivot=a[j][j];a[j]=[x/pivot for x in a[j]]
        for k in range(n):
            if k==j:continue
            q=a[k][j];a[k]=[x-q*y for x,y in zip(a[k],a[j])]
    assert all(a[i][j]==(i==j)for i in range(n)for j in range(n))
    return tuple(tuple(r[n:])for r in a)

def characteristic_from_traces(traces):
    # Independent Newton form using coefficient indices reversed from the
    # producer's implementation. Every polynomial is also evaluated below.
    e=traces[0];a=[1]
    for k in range(1,e+1):
        value=sum(a[j]*traces[k-j]for j in range(k))
        assert value%k==0;a.append(-value//k)
    return tuple(a)

def evaluate(c,coefficients,x):
    n=len(x);one=(1,)+(0,)*(n-1);value=(0,)*n
    for a in coefficients:
        value=multiply(c,value,x)
        value=tuple(y+a*z for y,z in zip(value,one))
    return value

def direct_field_data(f,c,h,sd):
    n=len(cyclotomic(c))-1;e=n//len(h);bound=len(h)*(f-1)
    assert n%len(h)==0
    powers=root_powers(c)
    gram=[[trace(c,powers[(i-j)%c])for j in range(n)]for i in range(n)]
    ig=inverse(gram)
    radii=[isqrt((bound*ig[i][i]).numerator//(bound*ig[i][i]).denominator)for i in range(n)]
    result=defaultdict(set);trace_data={};integral_points=0;norm_points=0
    for x in product(*(range(-r,r+1)for r in radii)):
        norm=sum(x[i]*gram[i][j]*x[j]for i in range(n)for j in range(n))
        if norm>bound:continue
        norm_points+=1
        if any(automorphism(c,x,a)!=x for a in h):continue
        if sd and automorphism(c,x,c-1)!=x:continue
        integral_points+=1
        power=(1,)+(0,)*(n-1);traces=[e]
        for k in range(1,13):
            power=multiply(c,power,x);v=trace(c,power)
            assert v%len(h)==0;traces.append(v//len(h))
        coeff=characteristic_from_traces(traces)
        assert not any(evaluate(c,coeff,x))
        assert norm%len(h)==0
        result[traces[1],norm//len(h)].add(coeff)
        if coeff in trace_data:assert trace_data[coeff]==tuple(traces)
        trace_data[coeff]=tuple(traces)
    return ({k:tuple(sorted(v))for k,v in result.items()},trace_data,
            {'formal_codegree':f,'conductor':c,'fixed_subgroup':h,'self_dual':sd,
             'ambient_dimension':n,'field_degree':e,'norm_bound':bound,
             'coordinate_radii':radii,'box_points':prod(2*r+1 for r in radii),
             'points_within_norm':norm_points,'fixed_integral_points':integral_points,
             'trace_norm_pairs':len(result),'distinct_polynomials':len(trace_data)})

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--producer',type=Path,default=HERE.parents[1]/'commutative12')
    parser.add_argument('--output',type=Path,default=HERE/'higher_field_power_audit.json')
    args=parser.parse_args();sys.path.insert(0,str(args.producer))
    from field_power_polynomials import polynomial_map,powers_of_polynomial
    from fixed_lattice import fixed_pairs
    checks=[]
    for f,c,h in [(9,9,(1,8)),(10,20,(1,11)),(10,20,(1,19))]:
        for sd in (False,True):
            expected,traces,record=direct_field_data(f,c,h,sd)
            actual=polynomial_map(f,c,h,sd)
            assert actual==expected,(f,c,h,sd,expected,actual)
            assert set(fixed_pairs(f,c,h,sd))==set(expected)
            for coeff,t in traces.items():assert powers_of_polynomial(coeff,12)==t
            record['exact_polynomial_map_matches']=True
            record['all_twelve_power_traces_match']=True
            checks.append(record)
    result={'status':'PASS','checks':checks,
            'scope':'All three higher fields used by the nine final rank12 commutative assignments, both self-dual statuses; complete ambient integral-box enumeration.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
