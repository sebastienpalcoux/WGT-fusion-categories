#!/usr/bin/env python3
"""Certified preliminary canonical reduction for rank15,C^7+2M2.

Standard library only. Enumerates all weighted profiles and unordered
nonlinear-degree placements. Uses only proved rational-degree10, positive
trace determinant, 24/200 pattern and rational canonical residue tests.
No source row, unknown Schur index, matrix involution, or multiplication
ansatz is used. Equal-degree matrix characters may form a quadratic orbit.
"""
from collections import Counter
from functools import lru_cache
from itertools import combinations_with_replacement,product
from math import gcd,prod,isqrt
from pathlib import Path
import argparse,json

N=5400
PALETTE=tuple(a for a in range(10,901)if N%a==0 and sum(a%p==0 for p in(2,3,5))>=2)
HERE=Path(__file__).resolve().parent

def profiles(slots,total,cap=900):
    if not slots:
        if total==0:yield ()
        return
    if total<10*slots:return
    for a in reversed(PALETTE):
        if a>cap:continue
        if a*slots<total:break
        if total-a<10*(slots-1):continue
        for p in profiles(slots-1,total-a,a):yield(a,)+p

def sf(n):
    n=abs(n);out=1;p=2
    while p*p<=n:
        e=0
        while n%p==0:n//=p;e^=1
        if e:out*=p
        p+=1
    return out*n

def fundamental_discriminants(c):
    # All squarefree radicands supported on the conductor primes2,3,5.
    answer=[]
    for exps in product((0,1),repeat=3):
        a=2**exps[0]*3**exps[1]*5**exps[2]
        for sign in(-1,1):
            d=sign*a
            if d==1:continue
            D=d if d%4==1 else 4*d
            if c%abs(D)==0:answer.append(D)
    return tuple(sorted(answer))

def kronecker(D,n):
    result=1
    while n%2==0:
        n//=2
        if D%8 in(3,5):result=-result
    D%=n
    while D:
        while D%2==0:
            D//=2
            if n%8 in(3,5):result=-result
        D,n=n,D
        if D%4==n%4==3:result=-result
        D%=n
    assert n==1
    return result

def sign_of_permutation(p):
    # Independent inversion-parity formula (rather than cycle counting).
    return -1 if sum(p[i]>p[j]for i in range(len(p))for j in range(i+1,len(p)))%2 else 1

def quartic16():
    units=tuple(a for a in range(16)if gcd(a,16)==1);answer=[]
    for a in units:
        if a==1 or a*a%16!=1:continue
        h=(1,a);cosets=sorted({tuple(sorted(z*b%16 for b in h))for z in units})
        assert len(cosets)==4;where={C:i for i,C in enumerate(cosets)}
        signs={z:sign_of_permutation([where[tuple(sorted(z*b%16 for b in C))]for C in cosets])for z in units}
        if all(s==1 for s in signs.values()):D=1
        else:
            ds=[D for D in fundamental_discriminants(16)if all(kronecker(D,z)==s for z,s in signs.items())]
            assert len(ds)==1;D=ds[0]
        answer.append((4,sf(abs(D)),f'zeta16:H=1,{a}'))
    assert len(answer)==3
    return tuple(answer)

@lru_cache(None)
def field_orbits(a,k):
    f=N//a;c=gcd(2*f,f*f)
    if f==6:
        return ((1,1,'Q'),)+( ((2,3,'Q(sqrt(-3))'),)if k>=2 else ())
    answer=[] if a==10 else [(1,1,'Q')]
    if k>=2:answer.extend((2,sf(abs(D)),f'quadratic_disc={D}')for D in fundamental_discriminants(c))
    if k>=3 and c%9==0:answer.append((3,1,'real_cubic_conductor9'))
    if k>=4:
        # Verified below for every placement; this is the only remaining
        # larger linear block after the f6 support theorem is applied.
        assert f==8 and k<=5,(a,k,c)
        answer.extend(quartic16())
    return tuple(answer)

@lru_cache(None)
def field_classes(a,k):
    orbits=field_orbits(a,k);states=[set()for _ in range(k+1)];states[0]={1}
    for used in range(k):
        for old in states[used]:
            for e,D,label in orbits:
                if used+e<=k:states[used+e].add(sf(old*D))
    return tuple(sorted(states[k]))

def rational_residue_failures(types):
    failures=[]
    for i,(a,m,k)in enumerate(types):
        if k!=1:continue
        other=[aa*mm for j,(aa,mm,kk)in enumerate(types)if j!=i]
        g=0
        for w in other:g=gcd(g,w)
        assert g
        remainder=a-m;weight=a*m
        # Direct full interval enumeration, independent of the exploratory
        # modular-inverse solution of the same congruence.
        if not any((remainder+weight*u)%g==0 for u in range(-remainder+1,remainder)):
            failures.append({'degree':a,'multiplicity':m,'other_weight_gcd':g,
                             'remainder':remainder,'integer_interval':[-remainder+1,remainder-1]})
    return failures

def coefficient_table():
    table=[[0]*N for _ in range(11)];table[0][0]=1
    for a in PALETTE:
        for k in range(1,11):
            for n in range(a,N):table[k][n]+=table[k-1][n-a]
    return table

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'rank15_two_blocks_preliminary.json')
    args=parser.parse_args();ps=tuple(profiles(10,N-1));assert len(ps)==497
    records=[];placement_counts=Counter();linear_blocks=set()
    for index,p in enumerate(ps):
        c=Counter(p);eligible=sorted((a for a,k in c.items()if k>=2),reverse=True)
        for a,b in combinations_with_replacement(eligible,2):
            if a==b and c[a]<4:continue
            nonlinear=Counter((a,b));linear={x:k-2*nonlinear[x]for x,k in c.items()if k>2*nonlinear[x]}
            assert sum(linear.values())==6
            types=sorted([(x,1,k)for x,k in linear.items()]+[(x,2,k)for x,k in nonlinear.items()],reverse=True)
            bad10=any(x==10 and k==1 for x,m,k in types)
            base=sf(N*prod(x**k for x,k in linear.items()))
            assert base==sf(N*prod(p))
            choices={1}
            for x,k in linear.items():
                linear_blocks.add((x,k))
                choices={sf(u*v)for u in choices for v in field_classes(x,k)}
            det=not bad10 and base in choices
            pattern=c[24]==c[200]==1 and all(x in(24,200)or x%225==0 for x in c)
            residues=rational_residue_failures(types)if det and not pattern else []
            if a==b:
                f=N//a;conductor=gcd(2*f,f*f)
                matrix_fields={'type':'two rational characters or one quadratic orbit',
                               'quadratic_discriminants':fundamental_discriminants(conductor)}
            else:matrix_fields={'type':'two individually rational characters'}
            records.append({'profile_index':index,'profile':p,'nonlinear_degrees':[a,b],
                            'linear_counts':sorted(linear.items(),reverse=True),
                            'types':types,'nonlinear_field_options':matrix_fields,
                            'excluded_by_rational_degree10':bad10,
                            'baseline_squareclass':base,'possible_linear_field_squareclasses':sorted(choices),
                            'determinant_pass':det,'forbidden_24_200':pattern,
                            'rational_residue_failures':residues,
                            'retained':det and not pattern and not residues})
            placement_counts[tuple(sorted((a,b)))]+=1
    assert len(records)==747
    coefficients=coefficient_table();assert coefficients[10][5399]==497
    for a,b in combinations_with_replacement(PALETTE,2):
        n=5399-2*a-2*b
        assert placement_counts[a,b]==(coefficients[6][n]if n>=0 else 0)
    after10=[r for r in records if not r['excluded_by_rational_degree10']]
    afterdet=[r for r in after10 if r['determinant_pass']]
    afterpattern=[r for r in afterdet if not r['forbidden_24_200']]
    kept=[r for r in afterpattern if not r['rational_residue_failures']]
    assert tuple(map(len,(records,after10,afterdet,afterpattern,kept)))==(747,727,176,161,153)
    assert all(f['degree']==12 and f['multiplicity']==2 and f['other_weight_gcd']==25
               for r in afterpattern for f in r['rational_residue_failures'])
    stages=[]
    for name,rr in [('raw_placements',records),('rational_degree10',after10),('linear_field_determinant',afterdet),
                    ('forbidden_24_200',afterpattern),('rational_canonical_residues',kept)]:
        stages.append({'stage':name,'placements':len(rr),'profiles':len({r['profile_index']for r in rr})})
    result={'status':'PASS','dimension':5400,'source_rank':15,'complex_algebra':'C^7+M2+M2',
            'canonical_length':11,'weighted_profiles':497,'raw_placements':747,'retained_placements':153,
            'retained_profiles':104,'stages':stages,
            'retained_equal_nonlinear_degree':sum(r['nonlinear_degrees'][0]==r['nonlinear_degrees'][1]for r in kept),
            'complete_linear_field_orbits':[
                {'canonical_degree':a,'linear_count':k,'orbits':field_orbits(a,k),'possible_products':field_classes(a,k)}
                for a,k in sorted(linear_blocks,reverse=True)],
            'records':records,
            'scope':'Certified preliminary necessary restriction to153 placements on104 profiles; no complete field assignment, source row, fusion multiplication, or existence assertion.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in('records','complete_linear_field_orbits')},indent=2))

if __name__=='__main__':main()
