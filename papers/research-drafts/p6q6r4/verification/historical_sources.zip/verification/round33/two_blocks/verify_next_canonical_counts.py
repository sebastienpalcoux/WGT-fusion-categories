#!/usr/bin/env python3
"""Independent initial canonical counts at commutative13/noncommutative15.

Counts each weighted profile and each choice of doubled canonical degrees.
A direct nonincreasing-entry recursion is cross-checked against coefficients
of product_a (1-u*v^a)^(-1), using removal of the prescribed doubled entries.
Only the established central palette and canonical mass are used. These are
initial necessary inputs, before field, residue, trace-form or row tests.
"""
from collections import Counter
from itertools import combinations_with_replacement
from pathlib import Path
import argparse,json

N=5400
PALETTE=tuple(a for a in range(10,901)if N%a==0 and sum(a%p==0 for p in (2,3,5))>=2)
HERE=Path(__file__).resolve().parent

def entry_profiles(slots,total,cap=900):
    if not slots:
        if total==0:yield ()
        return
    if total<10*slots:return
    for a in reversed(PALETTE):
        if a>cap:continue
        if a*slots<total:break
        if total-a<10*(slots-1):continue
        for tail in entry_profiles(slots-1,total-a,a):yield (a,)+tail

def generating_coefficients(max_slots,total):
    # Coefficient table for the product of geometric series, updated one
    # palette degree at a time. This uses no profile recursion.
    dp=[[0]*(total+1)for _ in range(max_slots+1)];dp[0][0]=1
    for a in PALETTE:
        for k in range(1,max_slots+1):
            row,previous=dp[k],dp[k-1]
            for t in range(a,total+1):row[t]+=previous[t-a]
    return dp

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'next_canonical_counts.json')
    args=parser.parse_args();dp=generating_coefficients(12,N-1)
    profiles12=0;single_profiles=0;single_by_degree=Counter();ten_counts12=Counter()
    first12=last12=None
    for p in entry_profiles(12,N-1):
        profiles12+=1;c=Counter(p);ten_counts12[c[10]]+=1
        if first12 is None:first12=p
        last12=p;double=[a for a,k in c.items()if k>=2]
        single_profiles+=bool(double);single_by_degree.update(double)
    assert profiles12==dp[12][N-1]
    for a in PALETTE:assert single_by_degree[a]==dp[10][N-1-2*a]
    profiles10=0;two_profiles=0;two_by_degrees=Counter();ten_counts10=Counter()
    first10=last10=None
    for p in entry_profiles(10,N-1):
        profiles10+=1;c=Counter(p);ten_counts10[c[10]]+=1
        if first10 is None:first10=p
        last10=p;double=sorted(a for a,k in c.items()if k>=2)
        placed=[]
        for a,b in combinations_with_replacement(double,2):
            if a==b and c[a]<4:continue
            placed.append((a,b));two_by_degrees[a,b]+=1
        two_profiles+=bool(placed)
    assert profiles10==dp[10][N-1]==497
    for a,b in combinations_with_replacement(PALETTE,2):
        rest=N-1-2*a-2*b
        expected=dp[6][rest]if rest>=0 else 0
        assert two_by_degrees[a,b]==expected,(a,b)
    result={'status':'PASS','dimension':N,'central_palette':PALETTE,
            'rank15_shape_argument':'L>=11 andr-L=sum m(m-1) even imply the only noncommutative rank15 shapes areC^11+M2(L13) andC^7+2M2(L11).',
            'commutative_rank13':{'algebra':'C^13','canonical_length':13,'nonunit_weighted_entries':12,
                                  'weighted_profiles':profiles12,'first_profile':first12,'last_profile':last12,
                                  'number_of_degree10_entries_distribution':dict(sorted(ten_counts12.items()))},
            'rank15_one_degree2':{'algebra':'C^11+M2','canonical_length':13,'nonunit_weighted_entries':12,
                                 'weighted_profiles':profiles12,'profiles_admitting_placement':single_profiles,
                                 'placements':sum(single_by_degree.values()),
                                 'placements_by_nonlinear_degree':dict(sorted(single_by_degree.items(),reverse=True))},
            'rank15_two_degree2':{'algebra':'C^7+M2+M2','canonical_length':11,'nonunit_weighted_entries':10,
                                 'weighted_profiles':profiles10,'profiles_admitting_placement':two_profiles,
                                 'placements':sum(two_by_degrees.values()),'first_profile':first10,'last_profile':last10,
                                 'number_of_degree10_entries_distribution':dict(sorted(ten_counts10.items())),
                                 'placements_by_unordered_nonlinear_degrees':[
                                     {'degrees':[a,b],'count':count}for(a,b),count in sorted(two_by_degrees.items(),reverse=True)]},
            'independent_cross_check':'Every profile count and every per-degree placement count agrees with generating-function coefficients after removing the doubled entries.',
            'scope':'Initial necessary canonical inputs only; no full-field, rational-degree10, determinant, residue, source-row, or categorification claim is applied.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    summary={k:v for k,v in result.items()if k not in('central_palette',)}
    for label in('rank15_one_degree2','rank15_two_degree2'):
        summary[label]={k:v for k,v in summary[label].items()if not k.startswith('placements_by_')}
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
