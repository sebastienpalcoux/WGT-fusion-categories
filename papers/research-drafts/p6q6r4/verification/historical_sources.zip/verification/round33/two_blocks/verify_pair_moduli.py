#!/usr/bin/env python3
"""Exact local check of the two-rational-canonical-character modulus.

Checks every residue a,b,u for each prime power dividing5400, subject to
1+a+b=0. The gcd of all possible t=d-h residues equals the proved modulus.
The exploratory length11 application is optional and does not change the
certified length10 certificate.
"""
from math import gcd
from pathlib import Path
import argparse,json
HERE=Path(__file__).resolve().parent

def valuation(a,p):
    assert a>0
    e=0
    while a%p==0:a//=p;e+=1
    return e

def factor(n):
    out=[];p=2
    while p*p<=n:
        if n%p==0:
            e=0
            while n%p==0:n//=p;e+=1
            out.append((p,e))
        p+=1
    if n>1:out.append((n,1))
    return out

def forced_modulus(a,b,M):
    Q=1
    for p,k in factor(M):
        alpha,beta=valuation(a,p),valuation(b,p)
        Q*=p**min(k,beta+(max(0,k-alpha-beta)+1)//2)
    return Q

def pattern_failure(types):
    # Types are(a,m,c): c representations of dimensionm at canonical degreea.
    # A unique linear representation at its (a,m) type is Galois fixed.
    rational=[i for i,(a,m,c)in enumerate(types)if m==c==1]
    for i in rational:
        for j in rational:
            if i==j:continue
            a,b=types[i][0],types[j][0];M=5400
            for z,(aa,mm,cc)in enumerate(types):
                if z not in (i,j):M=gcd(M,aa)
            assert (1+a+b)%M==0
            Q=forced_modulus(a,b,M)
            if Q>=2*(a-1):return {'a':a,'b':b,'modulus':M,'forced_difference_modulus':Q}
    return None

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--length11',type=Path)
    parser.add_argument('--output',type=Path,default=HERE/'pair_moduli_verification.json')
    args=parser.parse_args();checks=[]
    for p,e in factor(5400):
        for k in range(1,e+1):
            M=p**k;count=0
            for aa in range(M):
                bb=(-1-aa)%M
                # The positive representative M has valuation >=k and gives
                # exactly the same local congruences as the zero residue.
                a=aa or M;b=bb or M;g=M
                for u in range(M):
                    t=(-b*u)%M
                    if (t*t+b*u*u)%M==0:
                        assert a*b*u*u%M==0
                        g=gcd(g,t);count+=1
                assert g==forced_modulus(a,b,M),(p,k,a,b,g)
            checks.append({'prime':p,'exponent':k,'modulus':M,'allowed_residue_pairs':count})
    assert forced_modulus(24,200,225)==75
    result={'status':'PASS','prime_power_checks':checks,
            'example_24_200_225':75,
            'scope':'Every local residue case at every prime power dividing5400; verifies the exact largest forced divisor ofd-h.'}
    if args.length11:
        data=json.loads(args.length11.read_text());old=[r for r in data['records']if r['retained']]
        rejected=[];remaining=[]
        for r in old:
            fail=pattern_failure(r['types'])
            if fail:rejected.append({'index':r['index'],'rank':r['rank'],'multiplicities':r['multiplicities'],'obstruction':fail})
            else:remaining.append(r)
        result['exploratory_length11']={'initial':len(old),'excluded':len(rejected),'remaining':len(remaining),
                                      'rank15_remaining':sum(r['rank']==15 for r in remaining),
                                      'exclusions':rejected}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
