#!/usr/bin/env python3
"""Independent exact power-filter decisions on the complete pre-power rows.

The existing fixed-field row generator supplies the universe. Decisions use
independent rational combinations, binomial quadratic power formulas, and
the separately audited ambient-box higher-field calculations. No producer
power recurrence is used in the decision being compared.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import combinations_with_replacement,product
from math import comb,isqrt
from pathlib import Path
import argparse,json,sys,time
from audit_higher_field_powers import direct_field_data

HERE=Path(__file__).resolve().parent

def quadratic_binomial(s,n):
    delta=s*s-4*n;out=[2]
    for j in range(1,13):
        numerator=2*sum(comb(j,k)*s**(j-k)*delta**(k//2)for k in range(0,j+1,2))
        assert numerator%(2**j)==0
        out.append(numerator//(2**j))
    return tuple(out)

@lru_cache(None)
def direct_higher(f,label,sd):
    if label=='real_cubic_conductor9':c,h=9,(1,8)
    else:
        a,b=label.split(':H=');c=int(a[4:]);h=tuple(map(int,b.split(',')))
    polys,traces,_=direct_field_data(f,c,h,sd)
    return {st:tuple(traces[p]for p in choices)for st,choices in polys.items()}

@lru_cache(None)
def options(piece,value,sd,d,higher):
    a,k,label=piece;s,t=value;f=5400//a
    if label in ('Q','rational6','rational_group'):
        bound=min(d-1,isqrt((f-1)//(1 if sd else 2)),isqrt(t))
        answer=[]
        for xs in combinations_with_replacement(range(-bound,bound+1),k):
            if sum(xs)!=s or sum(x*x for x in xs)!=t:continue
            answer.append(tuple(sum(x**j for x in xs)for j in range(13)))
        return tuple(answer)
    if label.startswith('quadratic_disc='):
        delta=int(label.split('=')[1]);n=(s*s-t)//2 if delta>0 else t//2
        return (quadratic_binomial(s,n),)
    if label=='complex6':
        if k==2:return (quadratic_binomial(s,t//2),)
        assert k==4
        if t==0:xs=(0,0,0,0);return (tuple(sum(x**j for x in xs)for j in range(13)),)
        if sd:
            assert (s,t)==(0,4);xs=(1,1,-1,-1)
            return (tuple(sum(x**j for x in xs)for j in range(13)),)
        assert t==2 and abs(s)==1
        return ((4,)+quadratic_binomial(s,1)[1:],)
    assert label.startswith('zeta')or label=='real_cubic_conductor9',label
    if not higher:return None
    return direct_higher(f,label,sd).get((s,t),())

def possible(pieces,d,values,sd,higher):
    choices=[]
    for p,v in zip(pieces,values):
        choice=options(tuple(p),tuple(v),sd,d,higher)
        if choice is None:return True
        if not choice:return False
        choices.append(choice)
    for selection in product(*choices):
        positive=False;ok=True
        for j in range(13):
            numerator=d**j+sum(p[0]*v[j]for p,v in zip(pieces,selection))
            if numerator<0 or numerator%5400:
                ok=False;break
            if j==0 and numerator!=5400:ok=False;break
            if j==1 and numerator!=0:ok=False;break
            if j==2 and numerator!=5400*sd:ok=False;break
            if j and numerator:positive=True
        if ok and positive:return True
    return False

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--producer',type=Path,default=HERE.parents[1]/'commutative12')
    parser.add_argument('--output',type=Path,default=HERE/'power_row_audit.json')
    parser.add_argument('--start',type=int,default=0)
    parser.add_argument('--stop',type=int,default=6547)
    args=parser.parse_args();sys.path.insert(0,str(args.producer))
    from fixed_field_rows import fixed_rows
    from gap_filter import gap_possible,row_determinants
    from power_trace_filter import power_trace_possible
    records=[json.loads(s)for f in sorted(args.producer.glob('powers_*.jsonl'))for s in f.read_text().splitlines()]
    records=[r for r in records if args.start<=r['index']<args.stop]
    final={}
    path=args.producer/'higher_power_results.jsonl'
    if path.exists():final={(r['index'],r['assignment_index']):r for r in map(json.loads,path.read_text().splitlines())}
    start=time.monotonic();checks=[];decisions=0
    for record in records:
        p=record['pieces'];assert record['double']is None
        before=[row for row in fixed_rows(p,None,record['q6'],record['q'],None)
                if row_determinants(p,row[1],row[2],row[0],None)!=()and gap_possible(p,row[1],row[2])]
        assert len(before)==record['rows_before']
        kept=[]
        for sd,d,values in before:
            expected=possible(p,d,values,sd,False)
            actual=power_trace_possible(p,d,values,sd)
            assert expected==actual,(record['index'],record['assignment_index'],sd,d,values)
            decisions+=1
            if expected:kept.append((sd,d,values))
        assert len(kept)==record['rows']
        check={'profile_index':record['index'],'assignment_index':record['assignment_index'],
               'before':len(before),'after_basic_powers':len(kept)}
        if not record['certificate']:
            higher=[]
            for sd,d,values in before:
                expected=possible(p,d,values,sd,True)
                actual=power_trace_possible(p,d,values,sd,higher_fields=True)
                assert expected==actual
                decisions+=1
                if expected:higher.append((sd,d,values))
            key=record['index'],record['assignment_index']
            if key in final:assert len(higher)==final[key]['rows']
            check['after_higher_powers']=len(higher)
        checks.append(check)
        print(record['index'],record['assignment_index'],len(before),'->',len(kept),'PASS',round(time.monotonic()-start,2),flush=True)
    result={'status':'PASS','record_count':len(checks),'row_decisions_compared':decisions,
            'pre_power_rows':sum(r['before']for r in checks),
            'after_basic_power_rows':sum(r['after_basic_powers']for r in checks),
            'higher_field_records':sum('after_higher_powers'in r for r in checks),
            'records':checks,'seconds':time.monotonic()-start,
            'scope':'Independent scalar-value and power-trace decisions on all supplied pre-power rows; row generation and final certificate coverage are separate audits.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='records'},indent=2))

if __name__=='__main__':main()
