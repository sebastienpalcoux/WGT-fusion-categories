#!/usr/bin/env python3
"""Safe aggregate-row extension of the frozen rank15 two-M2 checkpoint.

Every row is a Galois-stable degree-block aggregate.  No nonlinear character
is assumed rational, split, orthogonal, or symplectic. Two independent exact
feasibility algorithms are compared on every tested source degree.
"""
from collections import Counter
from functools import lru_cache
from math import gcd,isqrt,prod
from pathlib import Path
import argparse,hashlib,json,time

N=5400
HERE=Path(__file__).resolve().parent

@lru_cache(None)
def options(a,k,d):
    # At(a,k,j), sum m^2=k+2j. The extra global bound
    # (k+2j)f-k >= f-1 is redundant for k>=1, so all placements on a
    # weighted profile share this intentionally weak aggregate row universe.
    cap=min(N//a-1,k*d*d,(N-d*d)//a)
    if k==1:
        limit=min(d-1,isqrt(cap))
        return tuple((a*s,a*s*s)for s in range(-limit,limit+1))
    return tuple((a*s,a*t)for t in range(cap+1)
                 for s in range(-min(k*d-1,isqrt(k*t)),min(k*d-1,isqrt(k*t))+1))

def feasible_mitm(blocks,d):
    choices=[options(a,k,d)for a,k in blocks];target=(-d,N-d*d)
    masks=range(1,1<<(len(choices)-1))
    mask=min(masks,key=lambda m:max(prod(len(v)for i,v in enumerate(choices)if m>>i&1),
                                   prod(len(v)for i,v in enumerate(choices)if not(m>>i&1))))
    def sums(vectors):
        result={(0,0)}
        for v in vectors:
            result={(x+a,y+b)for x,y in result for a,b in v if y+b<=target[1]}
        return result
    left=sums([v for i,v in enumerate(choices)if mask>>i&1])
    right=sums([v for i,v in enumerate(choices)if not(mask>>i&1)])
    return any((target[0]-s,target[1]-t)in right for s,t in left)

def feasible_norm_first(blocks,d):
    # Independent arrangement: enumerate the norm equation first, then
    # solve the signed integer trace equation for each resulting norm tuple.
    blocks=tuple(sorted(blocks,reverse=True));caps=[];norm_options=[]
    for a,k in blocks:
        cap=min(N//a-1,k*d*d,(N-d*d)//a);caps.append(cap)
        norm_options.append(tuple(s*s for s in range(min(d-1,isqrt(cap))+1))if k==1 else range(cap+1))
    length=len(blocks);suffix_max=[0]*(length+1);suffix_gcd=[0]*(length+1)
    for i in reversed(range(length)):
        suffix_max[i]=suffix_max[i+1]+blocks[i][0]*caps[i]
        suffix_gcd[i]=gcd(suffix_gcd[i+1],blocks[i][0])
    def trace(ts):
        reachable={0}
        for(a,k),t in zip(blocks,ts):
            if k==1:
                q=isqrt(t);ss={q,-q}
            else:
                q=min(k*d-1,isqrt(k*t));ss=range(-q,q+1)
            reachable={x+a*s for x in reachable for s in ss}
        return -d in reachable
    def norms(i,remaining,ts):
        if i==length:return remaining==0 and trace(ts)
        if remaining<0 or remaining>suffix_max[i]or remaining%suffix_gcd[i]:return False
        a,k=blocks[i]
        if i==length-1:
            if remaining%a:return False
            t=remaining//a
            if t>caps[i]:return False
            if k==1 and(isqrt(t)**2!=t or isqrt(t)>=d):return False
            return trace(ts+(t,))
        return any(norms(i+1,remaining-a*t,ts+(t,))for t in norm_options[i]if a*t<=remaining)
    return norms(0,N-d*d,())

def remainder_semigroup(ds,maximum):
    possible=[False]*(maximum+1);possible[0]=True
    for n in range(1,maximum+1):possible[n]=any(n>=d and possible[n-d]for d in ds)
    return possible

def fourteen_squares(ds):
    # The bit at s records a sum of exactly i squares, with repetitions.
    possible=1;mask=(1<<N)-1
    for _ in range(14):
        following=0
        for d in ds:following|=possible<<(d*d)
        possible=following&mask
    return bool(possible>>(N-1)&1)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--checkpoint',type=Path,default=HERE.parent/'rank15_two_blocks_preliminary.json')
    parser.add_argument('--output',type=Path,default=HERE/'aggregate_results.json')
    args=parser.parse_args();checkpoint=json.loads(args.checkpoint.read_text())
    assert checkpoint['status']=='PASS'and checkpoint['retained_placements']==153
    candidates=[r for r in checkpoint['records']if r['retained']];assert len(candidates)==153
    grouped={r['profile_index']:tuple(r['profile'])for r in candidates};assert len(grouped)==104
    start=time.monotonic();profile_data={};degree_tests=0
    for index,p in sorted(grouped.items()):
        blocks=tuple(sorted(Counter(p).items()));ds=[]
        for d in range(3,73):
            expected=feasible_mitm(blocks,d);actual=feasible_norm_first(blocks,d)
            assert expected==actual,(index,d);degree_tests+=1
            if expected:ds.append(d)
        semigroup=remainder_semigroup(ds,max(p)-1)
        profile_data[index]=(ds,semigroup,fourteen_squares(ds))
        print(index,len(ds),'eligible; independent audit PASS',round(time.monotonic()-start,3),flush=True)
    records=[]
    for r in candidates:
        ds,semigroup,squares=profile_data[r['profile_index']]
        required=sorted({a-m for a,m,k in r['types']})
        missing=[v for v in required if not semigroup[v]]
        records.append({'profile_index':r['profile_index'],'profile':r['profile'],
                        'nonlinear_degrees':r['nonlinear_degrees'],'types':r['types'],
                        'eligible_dimensions':ds,'required_remainders':required,
                        'missing_remainders':missing,'fourteen_square_equation':squares,
                        'retained':not missing and squares})
    after_remainder=[r for r in records if not r['missing_remainders']]
    kept=[r for r in records if r['retained']]
    summary={'initial_placements':len(records),'initial_profiles':len(grouped),
             'after_all_constituent_remainders':len(after_remainder),
             'profiles_after_remainders':len({r['profile_index']for r in after_remainder}),
             'after_fourteen_squares':len(kept),'retained_profiles':len({r['profile_index']for r in kept}),
             'independently_compared_source_degree_tests':degree_tests,
             'retained_equal_nonlinear_degree':sum(r['nonlinear_degrees'][0]==r['nonlinear_degrees'][1]for r in kept)}
    result={'status':'PASS','dimension':N,'source_rank':15,'complex_algebra':'C^7+M2+M2',
            'summary':summary,'records':records,
            'checkpoint_sha256':hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
            'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'seconds':time.monotonic()-start,
            'scope':'Necessary aggregate source-row, all actual canonical-remainder and rank15 source-square tests; nonlinear quadratic orbits remain allowed, and no source ring is constructed.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','summary':summary,'seconds':result['seconds']},indent=2))

if __name__=='__main__':main()
