#!/usr/bin/env python3
"""Independent full-field catalogue audit for all rank12 canonical profiles.

Independent count-vector profile enumeration and full subgroup closure for
all blocks admitting degree >=4. For blocks of size <=3, quadratic kernels
come from every fundamental discriminant dividing the conductor; the only
cubic quotient of a conductor supported on 2,3,5 is the unique conductor9
quotient, when9 divides the conductor. This classification is also checked
against full subgroup closure for all size>=4 conductors.
"""
from collections import Counter
from functools import lru_cache
from math import gcd
from pathlib import Path
import argparse,json,sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from verify_two_blocks import PALETTE,quadratic_discriminants
from verify_length10 import generated_subgroups,kronecker

@lru_cache(None)
def profiles_from_counts(i,slots,total):
    if slots==0:return ((),)if total==0 else ()
    if i==len(PALETTE)or total<10*slots or total>PALETTE[i]*slots:return ()
    a=PALETTE[i];out=[]
    for k in range(min(slots,total//a)+1):
        out.extend((a,)*k+p for p in profiles_from_counts(i+1,slots-k,total-k*a))
    return tuple(out)

def kernel_of_label(label,c):
    units=tuple(a for a in range(c)if gcd(a,c)==1)
    if label=='Q':return frozenset(units)
    if label=='Q(sqrt(-3))':label='quadratic_disc=-3'
    if label.startswith('quadratic_disc='):
        D=int(label.split('=')[1]);assert D in quadratic_discriminants(c)
        return frozenset(a for a in units if kronecker(D,a)==1)
    if label=='real_cubic_conductor9':
        assert c%9==0
        return frozenset(a for a in units if a%9 in (1,8))
    cstr,hstr=label.split(':H=');ambient=int(cstr[4:]);h=set(map(int,hstr.split(',')))
    assert c%ambient==0
    return frozenset(a for a in units if a%ambient in h)

def small_kernels(c,k):
    units=frozenset(a for a in range(c)if gcd(a,c)==1);out={units}
    if k>=2:
        out|={frozenset(a for a in units if kronecker(D,a)==1)for D in quadratic_discriminants(c)}
    if k>=3 and c%9==0:out.add(frozenset(a for a in units if a%9 in (1,8)))
    return out

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--producer',type=Path,default=HERE.parents[1]/'commutative12')
    parser.add_argument('--output',type=Path,default=HERE/'rank12_field_catalogue_audit.json')
    args=parser.parse_args();sys.path.insert(0,str(args.producer))
    from generic_fields import fields
    expected=tuple(sorted(profiles_from_counts(0,11,5399),reverse=True))
    actual=tuple(tuple(p)for p in json.loads((args.producer/'profiles_rank12.json').read_text()))
    assert expected==actual and len(expected)==6547
    blocks=sorted({(5400//a,k)for p in expected for a,k in Counter(p).items()})
    checked=[]
    for f,k in blocks:
        c=gcd(2*f,f*f);units={a for a in range(c)if gcd(a,c)==1}
        if k>=4:
            all_groups=generated_subgroups(c)
            theoretical={frozenset(h)for h in all_groups if len(units)//len(h)<=k}
            # Independently verify the small-degree classification in every
            # conductor for which every subgroup has just been constructed.
            assert {h for h in theoretical if len(units)//len(h)<=3}==small_kernels(c,3)
        else:theoretical=small_kernels(c,k)
        if f==540:theoretical.discard(frozenset(units))
        if f==6:theoretical&={kernel_of_label('Q',c),kernel_of_label('Q(sqrt(-3))',c)}
        listed=[r for r in fields(f,k)if len(r[1])<=k]
        mapped={kernel_of_label(r[0],c)for r in listed}
        assert len(mapped)==len(listed),(f,k,'duplicate labels')
        assert mapped==theoretical,(f,k,theoretical-mapped,mapped-theoretical)
        for r in listed:
            h=kernel_of_label(r[0],c);e=len(units)//len(h)
            assert len(r[1])==e
            minus=0 if c-1 in h else e//2
            assert len(r[3])==minus and len(r[2])==e-minus
        checked.append({'formal_codegree':f,'weighted_multiplicity':k,
                        'conductor':c,'field_count':len(mapped),
                        'full_subgroup_enumeration':k>=4})
    result={'status':'PASS','independently_reconstructed_profiles':len(expected),
            'all_blocks_checked':len(blocks),
            'large_blocks_checked':sum(k>=4 for f,k in blocks),
            'records':checked,
            'scope':'Complete permitted full fields for all6547 rank12 commutative weighted profiles, including real/CM dimensions and every higher-degree orbit.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='records'},indent=2))

if __name__=='__main__':main()
