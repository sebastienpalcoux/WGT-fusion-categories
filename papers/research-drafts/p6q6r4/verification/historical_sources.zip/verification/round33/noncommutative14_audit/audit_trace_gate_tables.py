#!/usr/bin/env python3
"""Independent exact arithmetic audit of the rank-14 quaternion form tables.

The finite field catalogue is audited separately. This script implements its
own local symbols and checks all eight possible skew squareclasses and all
codegrees in the canonical palette. Only the production table generator is
imported for comparison; its local-symbol functions are not used as oracles.
"""
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from pathlib import Path
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'noncommutative14'
sys.path.insert(0, str(SOURCE))
import trace_rank14 as subject


def prime_factors(n):
    n = abs(int(n))
    out = set()
    p = 2
    while p * p <= n:
        while n % p == 0:
            out.add(p)
            n //= p
        p += 1
    if n > 1:
        out.add(n)
    return out


def valuation_and_unit(x, p):
    x = Q(x)
    a, b, value = x.numerator, x.denominator, 0
    assert a
    while a % p == 0:
        a //= p
        value += 1
    while b % p == 0:
        b //= p
        value -= 1
    return value, a, b


def hilbert(a, b, p):
    va, an, ad = valuation_and_unit(a, p)
    vb, bn, bd = valuation_and_unit(b, p)
    modulus = 8 if p == 2 else p
    u = (an * pow(ad, -1, modulus)) % modulus
    v = (bn * pow(bd, -1, modulus)) % modulus
    if p == 2:
        exponent = ((u - 1) // 2) * ((v - 1) // 2)
        exponent += va * ((v * v - 1) // 8)
        exponent += vb * ((u * u - 1) // 8)
        return -1 if exponent % 2 else 1
    sign = -1 if (va * vb * ((p - 1) // 2)) % 2 else 1
    if vb % 2:
        sign *= -1 if pow(u, (p - 1) // 2, p) == p - 1 else 1
    if va % 2:
        sign *= -1 if pow(v, (p - 1) // 2, p) == p - 1 else 1
    return sign


def local_square(a, p):
    value, num, den = valuation_and_unit(a, p)
    if value % 2:
        return False
    if p == 2:
        return (num * pow(den, -1, 8)) % 8 == 1
    return pow((num * pow(den, -1, p)) % p, (p - 1) // 2, p) == 1


def ramification(a, b):
    a, b = Q(a), Q(b)
    primes = {2} | prime_factors(a.numerator) | prime_factors(a.denominator)
    primes |= prime_factors(b.numerator) | prime_factors(b.denominator)
    return tuple(p for p in sorted(primes) if hilbert(a, b, p) == -1)


def squareclass(n):
    answer = 1
    for p in prime_factors(n):
        exponent = 0
        while n % p == 0:
            n //= p
            exponent += 1
        if exponent % 2:
            answer *= p
    return answer


def partitions(n, least=1, slots=5):
    if n == 0:
        yield ()
    elif slots:
        for x in range(least, n + 1):
            for rest in partitions(n - x, x, slots - 1):
                yield (x,) + rest


def main():
    codegrees = sorted({5400 // a for a in range(10, 901)
                        if 5400 % a == 0 and sum(a % p == 0 for p in (2, 3, 5)) >= 2})
    definite = [(1, 1, (2,)), (1, 3, (3,)),
                (2, 5, (5,)), (3, 10, (2, 3, 5))]
    for a, b, expected in definite:
        assert ramification(-a, -b) == expected
        assert len(expected) % 2 == 1  # The real place is also ramified.

    orthogonal_checks = []
    for delta, f in product((1, 2, 3, 5, 6, 10, 15, 30), codegrees):
        targets = {ram for ram in ((), (2, 3), (2, 5), (3, 5))
                   if all(f % p == 0 and not local_square(-delta, p) for p in ram)}
        candidates = subject.orthogonal_forms(delta, f)
        observed = set()
        for diagonal in candidates:
            unscaled = tuple(x * f / 2 for x in diagonal)
            assert unscaled[0] == 1 and unscaled[1] == delta
            c = unscaled[2]
            assert c > 0 and unscaled[3] == delta * c
            ram = ramification(-delta, c)
            assert ram in targets and ram not in observed
            observed.add(ram)
        assert observed == targets
        orthogonal_checks.append({'delta': delta, 'f': f,
                                  'ramification_sets': [list(r) for r in sorted(targets)]})

    norms = {part for part in partitions(6)
             if len({squareclass(x) for x in part}) == 1}
    assert norms == {(6,), (3, 3), (2, 2, 2), (1, 1, 4)}
    possibilities = []
    for s, t, n in product(range(-2, 3), range(6), range(-2, 3)):
        if t - s*s + 2*n == 6 and 2*abs(n) <= t and 2*t - s*s >= 6:
            possibilities.append((s, t, n))
            v_square = 2*t - 6 - s*s
            assert v_square in (2, 3)
            assert ramification(-6, v_square) == (2, 3)
    assert possibilities == [(-1, 5, 1), (0, 4, 1), (1, 5, 1)]
    six_forms = [(6, 2, 1, (2, 3)), (3, 1, 2, ()),
                 (3, 2, 2, (2, 3)), (2, 1, 3, ()),
                 (1, 1, 3, ()), (1, 6, 3, (2, 3))]
    for delta, c, count, expected in six_forms:
        assert ramification(-delta, c) == expected
        assert count in (1, 2, 3)
    assert local_square(-2, 3)

    special = {}
    for q in (0, 1, 2):
        # With q=q6 the matrix skew projection has diagonal f/2 on
        # 2q positions and f on the other 3-q positions.
        possible = []
        for f in codegrees:
            if squareclass(f) != (2 if q % 2 else 1):
                continue
            if q and (f % 2 or (f // 2) % 4 not in (0, 3)):
                continue
            if 3-q and f % 4 not in (0, 3):
                continue
            possible.append(f)
        permitted_by_production = (8, 72) if q == 1 else (36, 100)
        assert set(possible) <= set(permitted_by_production)
        special[q] = possible
    assert special == {0: [36, 100], 1: [8, 72], 2: []}

    result = {'status': 'PASS', 'codegrees': codegrees,
              'definite_quaternion_presentations': len(definite),
              'orthogonal_squareclass_codegree_cases': len(orthogonal_checks),
              'orthogonal_cases': orthogonal_checks,
              'codegree_six_skew_norm_lists': [list(x) for x in sorted(norms)],
              'codegree_six_positive_forms': len(six_forms),
              'independent_symplectic_q_equals_q6_allowed': special,
              'scope': 'Finite quaternion and special skew gates; field catalogue and general trace-form arithmetic are separately audited.',
              'source_sha256': hashlib.sha256((SOURCE/'trace_rank14.py').read_bytes()).hexdigest()}
    (HERE/'trace_gate_tables_audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'orthogonal_cases'}, indent=2))


if __name__ == '__main__':
    main()
