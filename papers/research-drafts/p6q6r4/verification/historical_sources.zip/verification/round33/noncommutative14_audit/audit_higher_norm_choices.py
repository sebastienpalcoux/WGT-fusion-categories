#!/usr/bin/env python3
"""Independent complete-box audit of all quartic norm-power choices.

Cyclotomic polynomials, ring products, traces, fixed spaces, inverse-Gram
coordinate bounds, and power values are implemented independently below.
The production field catalogue is used only to name the fields to audit;
its completeness is checked by a separate catalogue audit.
"""
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from math import gcd, isqrt, lcm
from pathlib import Path
import hashlib
import json
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'noncommutative14'
sys.path.insert(0, str(SOURCE))
from generic_fields import fields as subject_fields
from field_power_polynomials import polynomial_map as subject_polynomials
from norm_word_filter import scalar_norm_options as subject_norms


def divide_monic(a, b):
    a = list(a)
    out = [0] * (len(a) - len(b) + 1)
    for k in range(len(a) - len(b), -1, -1):
        z = a[k + len(b) - 1]
        out[k] = z
        for j, value in enumerate(b):
            a[k+j] -= z * value
    assert not any(a)
    return tuple(out)


@lru_cache(None)
def cyclotomic(n):
    polynomial = (-1,) + (0,) * (n-1) + (1,)
    for d in range(1, n):
        if n % d == 0:
            polynomial = divide_monic(polynomial, cyclotomic(d))
    return polynomial


class Cyclotomic:
    def __init__(self, c):
        self.c = c
        self.polynomial = cyclotomic(c)
        self.n = len(self.polynomial) - 1
        self.one = (1,) + (0,) * (self.n-1)
        self.powers = [self.one]
        for _ in range(1, c):
            previous = self.powers[-1]
            z = [0] + list(previous)
            top = z.pop()
            for j in range(self.n):
                z[j] -= top * self.polynomial[j]
            self.powers.append(tuple(z))
        self.trace_z = tuple(sum(self.powers[(j+i) % c][i]
                                 for i in range(self.n)) for j in range(c))
        self.gram = tuple(tuple(self.trace_z[(i-j) % c] for j in range(self.n))
                          for i in range(self.n))

    def multiply(self, a, b):
        out = [0] * self.n
        for i, x in enumerate(a):
            if not x:
                continue
            for j, y in enumerate(b):
                if not y:
                    continue
                z = x*y
                for k, coefficient in enumerate(self.powers[(i+j) % self.c]):
                    if coefficient:
                        out[k] += z*coefficient
        return tuple(out)

    def conjugate(self, a):
        return tuple(sum(x*self.powers[-j % self.c][i] for j, x in enumerate(a))
                     for i in range(self.n))

    def trace(self, a):
        return sum(x*self.trace_z[j] for j, x in enumerate(a))


def row_reduce(rows, n):
    matrix = [[Q(x) for x in row] for row in rows if any(row)]
    pivots, r = [], 0
    for col in range(n):
        selected = next((i for i in range(r, len(matrix)) if matrix[i][col]), None)
        if selected is None:
            continue
        matrix[r], matrix[selected] = matrix[selected], matrix[r]
        lead = matrix[r][col]
        matrix[r] = [x/lead for x in matrix[r]]
        for i in range(len(matrix)):
            if i == r or not matrix[i][col]:
                continue
            coefficient = matrix[i][col]
            matrix[i] = [x-coefficient*y for x, y in zip(matrix[i], matrix[r])]
        pivots.append(col)
        r += 1
        if r == len(matrix):
            break
    return matrix[:r], pivots


def inverse(matrix):
    n = len(matrix)
    augmented = [list(row) + [Q(i == j) for j in range(n)]
                 for i, row in enumerate(matrix)]
    reduced, pivots = row_reduce(augmented, n)
    assert pivots == list(range(n))
    return [row[n:] for row in reduced]


def fixed_basis(ring, h, sd):
    constraints = set(h)
    if sd:
        constraints.add(ring.c-1)
    equations = []
    for automorphism in sorted(constraints - {1}):
        for i in range(ring.n):
            equations.append([ring.powers[automorphism*j % ring.c][i] - (i == j)
                              for j in range(ring.n)])
    reduced, pivots = row_reduce(equations, ring.n)
    free = [j for j in range(ring.n) if j not in pivots]
    basis = []
    for j in free:
        vector = [Q(0)] * ring.n
        vector[j] = 1
        for row, pivot in zip(reduced, pivots):
            vector[pivot] = -row[j]
        basis.append(tuple(vector))
    gram = [[sum(x[i]*ring.gram[i][j]*y[j]
                 for i in range(ring.n) for j in range(ring.n))
             for y in basis] for x in basis]
    return basis, gram


def enumerate_entries(f, ring, h, sd):
    basis, gram = fixed_basis(ring, h, sd)
    degree = ring.n // len(h)
    assert len(basis) == (degree // 2 if sd and ring.c-1 not in h else degree)
    cap = len(h)*(f-1)
    gram_inverse = inverse(gram)
    bounds = [isqrt((cap*gram_inverse[i][i]).numerator //
                    (cap*gram_inverse[i][i]).denominator) for i in range(len(basis))]
    scale = lcm(*(x.denominator for row in gram for x in row))
    integral_gram = [[int(x*scale) for x in row] for row in gram]
    box_size = 1
    for bound in bounds:
        box_size *= 2*bound+1
    entries = []
    for coordinates in product(*(range(-b, b+1) for b in bounds)):
        norm = sum(coordinates[i]*integral_gram[i][j]*coordinates[j]
                   for i in range(len(basis)) for j in range(len(basis)))
        if norm > cap*scale:
            continue
        vector = tuple(sum(z*b[j] for z, b in zip(coordinates, basis))
                       for j in range(ring.n))
        if any(x.denominator != 1 for x in vector):
            continue
        vector = tuple(map(int, vector))
        assert norm % (scale*len(h)) == 0
        entries.append((vector, norm // (scale*len(h))))
    return entries, bounds, box_size


@lru_cache(None)
def direct_powers(c, vector, bound):
    ring = RINGS[c]
    power, traces = ring.one, [ring.n]
    for _ in range(bound):
        power = ring.multiply(power, vector)
        traces.append(ring.trace(power))
    return tuple(traces)


RINGS = {}


def check_field(f, label, sd, bound=14):
    ctext, htext = label.split(':H=')
    c, h = int(ctext[4:]), tuple(map(int, htext.split(',')))
    ring = RINGS.setdefault(c, Cyclotomic(c))
    entries, coordinate_bounds, box_size = enumerate_entries(f, ring, h, sd)
    expected_polynomials, expected_norms = {}, {}
    degree = ring.n // len(h)
    for alpha, t in entries:
        s0 = ring.trace(alpha)
        assert s0 % len(h) == 0
        s = s0 // len(h)
        traces0 = direct_powers(c, alpha, degree)
        assert all(x % len(h) == 0 for x in traces0)
        traces = [x//len(h) for x in traces0]
        coefficients = [1]
        for k in range(1, degree+1):
            numerator = -sum(coefficients[k-i]*traces[i] for i in range(1, k+1))
            assert numerator % k == 0
            coefficients.append(numerator//k)
        beta = ring.multiply(alpha, ring.conjugate(alpha))
        assert ring.trace(beta) == len(h)*t
        powers0 = direct_powers(c, beta, bound)
        assert all(x % len(h) == 0 for x in powers0)
        powers = tuple(x//len(h) for x in powers0)
        expected_polynomials.setdefault((s, t), set()).add(tuple(coefficients))
        expected_norms.setdefault((s, t), set()).add(powers)
    produced = subject_polynomials(f, c, h, sd)
    assert {key:set(v) for key,v in produced.items()} == expected_polynomials, (f, label, sd)
    for (s, t), expected in expected_norms.items():
        actual = subject_norms((5400//f, degree, label), (s, t), sd, 72, bound)
        assert actual is not None and set(actual) == expected, (f, label, sd, s, t)
    if degree == 6:
        assert f == c == 9 and {t for _,t in entries} == {0, 6}
        assert all(p == ((6,) + (t,)*bound)
                   for (s,t), choices in expected_norms.items() for p in choices)
    return {'f': f, 'field': label, 'selfdual': sd, 'degree': degree,
            'coordinate_bounds': coordinate_bounds, 'complete_box_size': box_size,
            'integral_entries': len(entries), 'trace_norm_pairs': len(expected_norms),
            'distinct_full_polynomials': sum(len(x) for x in expected_polynomials.values()),
            'norm_power_choices': sum(len(x) for x in expected_norms.values())}


def main():
    profiles = json.loads((SOURCE/'profiles.json').read_text())
    blocks = {(5400//a, k) for p in profiles for a,k in Counter(p).items()}
    quartics = set()
    for f,k in blocks:
        for label, whole, plus, minus, q6 in subject_fields(f,k):
            if len(whole) == 4:
                quartics.add((f, label))
    started = time.monotonic()
    records = []
    for f,label in sorted(quartics | {(9, 'zeta9:H=1')}):
        for sd in (False, True):
            record = check_field(f, label, sd)
            records.append(record)
            print(f, label, sd, record['complete_box_size'], record['integral_entries'],
                  'PASS', round(time.monotonic()-started, 3), flush=True)
    result = {'status': 'PASS', 'quartic_codegree_field_pairs': len(quartics),
              'field_duality_cases': len(records),
              'complete_box_points': sum(r['complete_box_size'] for r in records),
              'integral_entries_checked': sum(r['integral_entries'] for r in records),
              'norm_power_choices_checked': sum(r['norm_power_choices'] for r in records),
              'power_bound': 14, 'records': records,
              'source_sha256': {name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()
                                for name in ('norm_word_filter.py','field_power_polynomials.py','fixed_lattice.py')},
              'elapsed_seconds': time.monotonic()-started}
    (HERE/'higher_norm_choices_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2), flush=True)


if __name__ == '__main__':
    main()
