#!/usr/bin/env python3
"""Independent direct-arithmetic tests of rank-14 mixed and norm words."""
from collections import defaultdict
from fractions import Fraction as Q
from itertools import combinations_with_replacement, product
from pathlib import Path
import hashlib
import json
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent/'noncommutative14'
sys.path.insert(0, str(SOURCE))
from mixed_trace_filter import matrix_mixed, scalar_mixed_options
from norm_word_filter import scalar_norm_options
from power_trace_filter import quadratic_powers

I = ((1, 0), (0, 1))


def mm(a, b):
    return tuple(tuple(sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2))
                 for i in range(2))


def transpose(a):
    return ((a[0][0], a[1][0]), (a[0][1], a[1][1]))


def trace(a):
    return a[0][0]+a[1][1]


def determinant(a):
    return a[0][0]*a[1][1]-a[0][1]*a[1][0]


def inverse(a):
    n = determinant(a)
    return ((Q(a[1][1], n), Q(-a[0][1], n)),
            (Q(-a[1][0], n), Q(a[0][0], n)))


def powers(x, multiplication, one, bound):
    out = [one]
    for _ in range(bound):
        out.append(multiplication(out[-1], x))
    return out


def check_matrices():
    bound = 11
    forms = [I, ((2,0),(0,3)), ((2,1),(1,2)),
             ((3,1),(1,1)), ((Q(1),Q(1,2)),(Q(1,2),Q(3,2)))]
    cases = mixed_checks = norm_checks = 0
    for entries in product(range(-1, 2), repeat=4):
        a = (entries[:2], entries[2:])
        for h in forms:
            assert h[0][0] > 0 and determinant(h) > 0
            star = mm(mm(inverse(h), transpose(a)), h)
            s, n = trace(a), determinant(a)
            y = mm(a, star)
            t = trace(y)
            aa, bb = powers(a, mm, I, bound), powers(star, mm, I, bound)
            yy = powers(y, mm, I, 14)
            actual = tuple(trace(mm(aa[i], bb[j]))
                           for i in range(bound+1) for j in range(i+1))
            assert actual == matrix_mixed(s, t, n, bound)
            assert tuple(map(trace, yy)) == quadratic_powers(t, n*n, 14)
            direct_difference = trace(yy[2])-trace(mm(aa[2], bb[2]))
            F = (t-2*n)*(t+2*n-s*s)
            assert direct_difference == F and F >= 0
            assert 2*abs(n) <= t and 2*n >= s*s-t
            cases += 1
            mixed_checks += len(actual)
            norm_checks += len(yy)
    return {'positive_involution_matrices': cases,
            'mixed_word_values': mixed_checks, 'norm_word_values': norm_checks}


def quaternion_multiply(x, y, a, b):
    x0,x1,x2,x3 = x
    y0,y1,y2,y3 = y
    return (x0*y0-a*x1*y1-b*x2*y2-a*b*x3*y3,
            x0*y1+x1*y0+b*(x2*y3-x3*y2),
            x0*y2+x2*y0+a*(x3*y1-x1*y3),
            x0*y3+x3*y0+x1*y2-x2*y1)


def check_quaternion_words():
    one, bound = (1,0,0,0), 11
    cases = comparisons = 0
    for a,b in ((1,1),(1,3),(2,5),(3,10)):
        multiply = lambda x,y: quaternion_multiply(x,y,a,b)
        for x in product(range(-1,2), repeat=4):
            star = (x[0],-x[1],-x[2],-x[3])
            n = x[0]**2+a*x[1]**2+b*x[2]**2+a*b*x[3]**2
            assert multiply(x,star) == (n,0,0,0)
            aa,bb = powers(x,multiply,one,bound),powers(star,multiply,one,bound)
            actual = tuple(2*multiply(aa[i],bb[j])[0]
                           for i in range(bound+1) for j in range(i+1))
            assert actual == matrix_mixed(2*x[0],2*n,n,bound)
            assert quadratic_powers(2*n,n*n,14) == tuple(2*n**k for k in range(15))
            cases += 1
            comparisons += len(actual)+15
    return {'definite_quaternion_elements': cases, 'word_values': comparisons}


def check_rational_groups():
    bound = 11
    cases = choices = 0
    pairs = [(i,j) for i in range(bound+1) for j in range(i+1)]
    for k in range(1,8):
        groups = defaultdict(list)
        for values in combinations_with_replacement(range(-2,3), k):
            groups[(sum(values),sum(x*x for x in values))].append(values)
        for value, alternatives in groups.items():
            expected_mixed = {tuple(sum(x**(i+j) for x in xs) for i,j in pairs)
                              for xs in alternatives}
            expected_norms = {tuple(sum(x**(2*j) for x in xs) for j in range(15))
                              for xs in alternatives}
            for sd in (False,True):
                piece = (50,k,'rational_group')  # f=108, strict d=3 gives |x|<=2.
                assert set(scalar_mixed_options(piece,value,sd,3,bound)) == expected_mixed
                assert set(scalar_norm_options(piece,value,sd,3,14)) == expected_norms
                cases += 1
                choices += len(alternatives)
    return {'rational_trace_norm_duality_cases': cases,
            'rational_multiset_choices': choices}


def quad_multiply(x,y,m):
    return (x[0]*y[0]+m*x[1]*y[1],x[0]*y[1]+x[1]*y[0])


def check_quadratics():
    bound = 11
    pairs = [(i,j) for i in range(bound+1) for j in range(i+1)]
    cases = 0
    for D in (-120,-40,-24,-20,-15,-8,-4,-3,5,8,12,24,40,60):
        m = D if D % 4 == 1 else D//4
        multiply = lambda x,y: quad_multiply(x,y,m)
        for u,v in product(range(-2,3), repeat=2):
            x = (Q(u)+Q(v,2),Q(v,2)) if D%4 == 1 else (Q(u),Q(v))
            star = (x[0],-x[1]) if D < 0 else x
            aa,bb = powers(x,multiply,(1,0),28),powers(star,multiply,(1,0),28)
            s = 2*x[0]
            t = 2*multiply(x,star)[0]
            assert s.denominator == t.denominator == 1
            actual_mixed = tuple(2*multiply(aa[i],bb[j])[0] for i,j in pairs)
            norm_element = multiply(x,star)
            actual_norms = tuple(2*z[0] for z in powers(norm_element,multiply,(1,0),14))
            piece = (50,2,f'quadratic_disc={D}')
            assert scalar_mixed_options(piece,(int(s),int(t)),False,72,bound) == (actual_mixed,)
            assert scalar_norm_options(piece,(int(s),int(t)),False,72,14) == (actual_norms,)
            cases += 1
    return {'quadratic_entries': cases}


def check_complex_six():
    bound = 11
    pairs = [(i,j) for i in range(bound+1) for j in range(i+1)]
    multiply = lambda x,y: quad_multiply(x,y,-3)
    cases = []
    for s in (-1,1):
        x = (Q(s,2),Q(1,2))
        for k in (2,4):
            entries = [x,(x[0],-x[1])] + [(Q(0),Q(0))]*(k-2)
            cases.append((k,False,(s,2),entries))
    cases.extend([(2,False,(0,0),[(Q(0),Q(0))]*2),
                  (4,False,(0,0),[(Q(0),Q(0))]*4),
                  (4,True,(0,0),[(Q(0),Q(0))]*4),
                  (4,True,(0,4),[(Q(1),Q(0))]*2+[(Q(-1),Q(0))]*2)])
    for s in (-2,2):
        cases.append((2,True,(s,2),[(Q(s,2),Q(0))]*2))
    for k,sd,value,entries in cases:
        mixed = [Q(0)]*len(pairs)
        norm = [Q(0)]*15
        for x in entries:
            star = (x[0],-x[1])
            aa,bb = powers(x,multiply,(1,0),bound),powers(star,multiply,(1,0),bound)
            for index,(i,j) in enumerate(pairs):
                mixed[index] += multiply(aa[i],bb[j])[0]
            for index,z in enumerate(powers(multiply(x,star),multiply,(1,0),14)):
                norm[index] += z[0]
        piece = (900,k,'complex6')
        assert scalar_mixed_options(piece,value,sd,72,bound) == (tuple(mixed),)
        assert scalar_norm_options(piece,value,sd,72,14) == (tuple(norm),)
    return {'complex_codegree_six_patterns': len(cases)}


def main():
    start = time.monotonic()
    result = {'matrix_words':check_matrices(),
              'quaternion_words':check_quaternion_words(),
              'rational_groups':check_rational_groups(),
              'quadratic_words':check_quadratics(),
              'codegree_six':check_complex_six(), 'status':'PASS',
              'source_sha256':{name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()
                               for name in ('mixed_trace_filter.py','norm_word_filter.py')},
              'elapsed_seconds':time.monotonic()-start}
    (HERE/'word_formulas_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__ == '__main__':
    main()
