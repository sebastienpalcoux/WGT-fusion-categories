"""LP proposes rational bounded-moment separators, checked as exact integers."""
from fractions import Fraction
from functools import reduce
from math import gcd,lcm
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix,hstack,eye


def upper_bounds(vectors,target):
    # Nonnegative budget coordinates: selfdual/pair counts, dimension square,
    # and per-block norm and trace-square sums.
    nblocks=next((n for n in range(1,20) if 3+3*n+n*(n-1)//2==len(target)),None)
    assert nblocks is not None
    positive=(0,1,2)+tuple(3+3*i+j for i in range(nblocks) for j in (0,2))
    return [min(target[j]//row[j] for j in positive if row[j]>0) for row in vectors]

def bounded_certificate(vectors,target):
    bounds=upper_bounds(vectors,target)
    active=[(r,u) for r,u in zip(vectors,bounds) if u]
    if not active:return {'kind':'bounded_empty'}
    mat=np.array([r for r,u in active],dtype=float);upper=np.array([u for r,u in active],dtype=float)
    scales=np.maximum(np.max(np.abs(mat),axis=0),np.abs(target));scales=np.maximum(scales,1)
    n=len(mat);m=len(target)
    aa=hstack([-csr_matrix(mat/scales),-eye(n,format='csr')],format='csr')
    objective=np.concatenate([np.array(target,dtype=float)/scales,upper])
    result=linprog(objective,A_ub=aa,b_ub=np.zeros(n),bounds=[(-1,1)]*m+[(0,None)]*n,method='highs')
    if not result.success or result.fun>=-1e-8:return None
    for denominator in [100,10000,1000000,1000000000]:
        y=[Fraction(float(v/s)).limit_denominator(denominator) for v,s in zip(result.x[:m],scales)]
        common=lcm(*(q.denominator for q in y));z=[int(q*common) for q in y]
        divisor=reduce(gcd,(abs(v) for v in z));z=[v//divisor for v in z]
        lower=sum(u*min(0,sum(a*b for a,b in zip(z,row))) for row,u in zip(vectors,bounds))
        value=sum(a*b for a,b in zip(z,target))
        if value<lower:
            return {'kind':'integer_box_separator','coefficients':z,'lower_bound':lower,'target_value':value,
                    'rows_positive_bound':len(active),'rows_zero_bound':len(vectors)-len(active)}
    return None
