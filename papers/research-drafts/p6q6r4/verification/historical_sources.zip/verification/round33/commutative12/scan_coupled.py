from endpoint_core import degree_profiles
from field_discriminant_profiles import profile_states,placement_states
from coupled_rows import coupled_blocks,coupled_rows,coupled_moments
from fractions import Fraction
from functools import reduce
from math import gcd,lcm
import numpy as np
from scipy.optimize import linprog
from pathlib import Path
import json,time,argparse
HERE=Path(__file__).resolve().parent
OLD=HERE.parents[1]/'round31/deliverable/p6q6r4_Round31/verification/round31/endpoints'

def certificate(vectors,goal):
    if not vectors:return {'kind':'empty'}
    mat=np.array(vectors,dtype=float)
    scales=np.maximum(np.max(np.abs(mat),axis=0),np.abs(goal));scales=np.maximum(scales,1)
    result=linprog(np.array(goal,dtype=float)/scales,A_ub=-mat/scales,b_ub=np.zeros(len(mat)),bounds=[(-1,1)]*len(goal),method='highs')
    if not result.success or result.fun>=-1e-8:return None
    for denominator in [100,10000,1000000,1000000000]:
        y=[Fraction(float(v/s)).limit_denominator(denominator) for v,s in zip(result.x,scales)]
        # Both atom types have one source-duality orbit, so repair by adding
        # a common constant to BOTH orbit-count coefficients.
        low=min(sum(a*b for a,b in zip(y,row)) for row in vectors)
        if low<0:y[0]-=low;y[1]-=low
        value=sum(a*b for a,b in zip(y,goal))
        if value<0:
            common=lcm(*(q.denominator for q in y));z=[int(q*common) for q in y]
            divisor=reduce(gcd,(abs(v) for v in z));z=[v//divisor for v in z]
            vals=[sum(a*b for a,b in zip(z,row)) for row in vectors];val=sum(a*b for a,b in zip(z,goal))
            assert min(vals)>=0 and val<0
            return {'kind':'integer_separator','coefficients':z,'minimum_row_value':min(vals),'target_value':val}
    return None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=497);args=ap.parse_args()
    old=json.loads((OLD/'endpoint_verification.json').read_text());profiles=list(degree_profiles())
    cases=old['field_and_certificate_summary']['11']['unresolved_cases']+old['field_and_certificate_summary']['13']['unresolved_cases']
    with (HERE/f'coupled_results_{args.start}_{args.stop}.jsonl').open('w') as out:
      for index,doubled in cases:
        if not args.start<=index<args.stop:continue
        p=profiles[index];states=(profile_states(p) if doubled is None else placement_states(p,doubled))[1]
        for state in states:
          _,q6,q=state[:3]
          for kind in ([None] if doubled is None else state[3]):
            start=time.monotonic();pieces,double=coupled_blocks(p,doubled,q6)
            rows=list(coupled_rows(pieces,double,q6,q,kind));target,vectors=coupled_moments(pieces,double,rows,q,kind)
            cert=certificate(vectors,target)
            rec={'index':index,'double_degree':doubled,'q6':q6,'q':q,'kind':kind,'pieces':pieces,'double':double,'rows':len(rows),'vectors':len(vectors),'certificate':cert,'seconds':time.monotonic()-start}
            out.write(json.dumps(rec,separators=(',',':'))+'\n');out.flush()
            print(index,doubled,q6,q,kind,len(rows),'EXCLUDED' if cert else 'open',round(rec['seconds'],3),flush=True)
if __name__=='__main__':main()
