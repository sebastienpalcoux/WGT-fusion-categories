"""Exact necessary dimension eligibility, canonical remainder, and type screens."""
from collections import Counter
from functools import lru_cache
from math import gcd,isqrt
from pathlib import Path
import json,time,argparse
DIM=5400
HERE=Path(__file__).resolve().parent

@lru_cache(None)
def options(a,k,d):
    cap=min(DIM//a-1,k*d*d-1,(DIM-d*d)//a)
    if k==1:
        r=min(d-1,isqrt(cap))
        return tuple((a*s,a*s*s) for s in range(-r,r+1))
    return tuple((a*s,a*t) for t in range(cap+1)
                 for s in range(-min(k*d-1,isqrt(k*t),t),min(k*d-1,isqrt(k*t),t)+1)
                 if t!=1 or abs(s)==1)

def eligible(blocks,d):
    choices=[options(a,k,d) for a,k in blocks]
    order=sorted(range(len(blocks)),key=lambda i:len(choices[i]));choices=[choices[i] for i in order];blocks=[blocks[i] for i in order]
    choices=[sorted(v,key=lambda z:z[1]) for v in choices]
    length=len(choices);ss=[0]*(length+1);st=[0]*(length+1);sm=[0]*(length+1);sg=[(0,0,0,0)]*(length+1)
    for h in reversed(range(length)):
        a,k=blocks[h];ss[h]=ss[h+1]+max(abs(s) for s,t in choices[h]);st[h]=st[h+1]+max(t for s,t in choices[h]);sm[h]=sm[h+1]+a*k
        g=list(sg[h+1])
        for s,t in choices[h]:
            for j,x in enumerate((s,t,t-s,t+s)):g[j]=gcd(g[j],x)
        sg[h]=tuple(g)
    lookup=set(choices[-1])
    @lru_cache(None)
    def rec(h,s,t):
        if t<0 or t>st[h] or abs(s)>ss[h] or abs(s)>t or s*s>sm[h]*t:return False
        if any((g and x%g) or (not g and x) for x,g in zip((s,t,t-s,t+s),sg[h])):return False
        if h==length-1:return (s,t) in lookup
        for u,v in choices[h]:
            if v>t:break
            if rec(h+1,s-u,t-v):return True
        return False
    return rec(0,-d,DIM-d*d)

def residue_fail(profile):
    counts=Counter(profile);out=[]
    for a,k in counts.items():
        if k!=1:continue
        g=0
        for aa,kk in counts.items():
            if aa!=a:g=gcd(g,aa)
        r=a-1
        if not any((r+a*mu)%g==0 for mu in range(-r+1,r)):
            out.append((a,g))
    return out

def semigroup(maximum,ds):
    reached=[False]*(maximum+1);reached[0]=True
    for n in range(1,maximum+1):reached[n]=any(n>=d and reached[n-d] for d in ds)
    return reached

def square_possible(ds,count):
    mask=(1<<DIM)-1;bits=1
    for _ in range(count):
        result=0
        for d in ds:result|=bits<<(d*d)
        bits=result&mask
    return bool(bits>>(DIM-1)&1)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=6547);args=ap.parse_args()
    profiles=json.loads((HERE/'profiles_rank12.json').read_text());start=time.monotonic()
    with (HERE/f'cheap_{args.start}_{args.stop}.jsonl').open('w') as out:
      for index in range(args.start,min(args.stop,len(profiles))):
        p=profiles[index];c=Counter(p);rf=residue_fail(p);record={'index':index,'profile':p,'residue_fail':rf,'rational_ten':c[10]==1}
        if rf or c[10]==1:record['excluded']=True;record['reason']='residue' if rf else 'rational_ten'
        else:
            ds=[d for d in range(3,73) if eligible(list(c.items()),d)]
            reach=semigroup(max(p),ds);part=all(reach[a-1] for a in c)
            squares=part and square_possible(ds,11)
            record.update(eligible=ds,remainder=part,squares=squares,excluded=not squares,reason='remainder' if not part else 'squares' if not squares else None)
        out.write(json.dumps(record,separators=(',',':'))+'\n');out.flush()
        if index%100==0:print(index,'elapsed',round(time.monotonic()-start,2),flush=True)
if __name__=='__main__':main()
