"""Exact full character fields for eleven nonunit canonical entries.

For quartic fields the conductor reduces to gcd(c,240): every quotient of
order4 kills wild3/5-inertia and the 2-primary characters of conductor>16.
Cubic fields have conductor9. The only applicable degree6 field isQ(zeta9).
"""
from functools import lru_cache
from itertools import combinations,product
from collections import Counter
from fractions import Fraction as Q
from math import gcd,prod
import r32_trace_forms as forms

EXTRA_POLY={
 3:[1,1,1],5:[1,1,1,1,1],
 15:[1,-1,0,1,-1,1,0,-1,1],
 40:[1,0,0,0,-1,0,0,0,1,0,0,0,-1,0,0,0,1],
 48:[1,0,0,0,0,0,0,0,-1,0,0,0,0,0,0,0,1],
}
forms.POLY.update(EXTRA_POLY)

@lru_cache(None)
def fields(f,k):
    c=gcd(2*f,f*f)
    if f==6:return (forms.field_record('Q',[1],[1],[]),forms.field_record('Q(sqrt(-3))',[2,6],[2],[6],1))
    records=[] if f==540 else [forms.field_record('Q',[1],[1],[])]
    if k>=2:
        for delta in forms.quadratic_discriminants(c):
            d=abs(delta if delta%4==1 else delta//4);diagonal=[2,2*d]
            plus,minus=(diagonal,[]) if delta>0 else([2],[2*d])
            records.append(forms.field_record(f'quadratic_disc={delta}',diagonal,plus,minus))
    if k>=3 and c%9==0:
        records.append(forms.field_record('real_cubic_conductor9',[3,6,Q(9,2)],[3,6,Q(9,2)],[]))
    if k>=4:
        ambient=gcd(c,240);units=[a for a in range(ambient) if gcd(a,ambient)==1]
        if len(units)%4==0:
            size=len(units)//4
            for tail in combinations(units[1:],size-1):
                h={1,*tail}
                if any(a*b%ambient not in h for a in h for b in h):continue
                data=forms.fixed_forms(ambient,tuple(sorted(h)))
                records.append(forms.field_record(f'zeta{ambient}:H='+','.join(map(str,sorted(h))),*data))
    if k>=6 and c%3==0 and forms.phi(c)%6==0:
        # Check actual profile blocks: onlyf=9,k<=7 invokes this branch.
        assert c==9,(f,k,c)
        records.append(forms.field_record('zeta9:H=1',*forms.fixed_forms(9,(1,))))
    assert k<=7,(f,k)
    return tuple(records)

@lru_cache(None)
def decompositions(f,k):
    options=fields(f,k);out=[]
    def rec(left,start,indices):
        if left==0:
            labels=tuple(options[i][0] for i in indices)
            whole=tuple(a/f for i in indices for a in options[i][1])
            plus=tuple(a/f for i in indices for a in options[i][2])
            minus=tuple(a/f for i in indices for a in options[i][3])
            out.append((labels,whole,plus,minus,sum(options[i][4] for i in indices)))
            return
        for i in range(start,len(options)):
            e=len(options[i][1])
            if e<=left:rec(left-e,i,indices+[i])
    rec(k,0,[]);return tuple(out)

def commutative_assignments(profile,rank=12):
    blocks=[(5400//a,k) for a,k in Counter(profile).items()]
    alternatives=[decompositions(f,k) for f,k in blocks]
    total=0;tested=0;kept=[]
    for assignment in product(*alternatives):
        total+=1;q6=sum(a[4] for a in assignment);q=sum(len(a[3]) for a in assignment)
        if q6>2 or q<2*q6 or q>(rank-2)//2:continue
        whole=(Q(1,5400),)+tuple(a for block in assignment for a in block[1])
        plus=(Q(1,5400),)+tuple(a for block in assignment for a in block[2])
        minus=tuple(a for block in assignment for a in block[3])
        if forms.squareclass(prod(whole))!=1:continue
        tested+=1
        if not forms.isometric(whole,[1]*rank):continue
        if not forms.isometric(minus,[2]*q):continue
        if not forms.isometric(plus,[1]*(rank-2*q)+[2]*q):continue
        kept.append({'fields':[{'formal_codegree':f,'fields':list(a[0])} for (f,k),a in zip(blocks,assignment)],'q6':q6,'q':q,'duality_types':['commutative']})
    return {'total_assignments':total,'tested_assignments':tested,'surviving_assignments':kept,'excluded':not kept}
