#!/usr/bin/env python3
"""Optional numerical certificate proposer; not part of the trusted checker.

Requires NumPy/SciPy. Every accepted numerical proposal is immediately checked
with exact integer arithmetic. An unsuccessful proposal is recorded as
unresolved, never as an exclusion. Existing certificates remain the primary
reproducible proof artifact; this script regenerates candidates from scratch.
"""
from collections import Counter
from pathlib import Path
import argparse
import json
import time

from endpoint_core import degree_profiles
from generic_fields import commutative_assignments
from exact_filters import residue_fail, verify_simple_certificate, dimension_possible
from cheap_screen import semigroup
from fixed_field_rows import fixed_blocks, fixed_rows
from coupled_rows import coupled_moments
from gap_filter import gap_possible, row_determinants
from power_trace_filter import power_trace_possible
from exact_certificate_checks import verify_certificate
from scan_coupled import certificate
from bounded_separator import bounded_certificate


def cheap_row_certificate(profile, rows, q):
    dimensions = sorted({d for sd, d, values in rows})
    reached = semigroup(max(profile), dimensions)
    missing = sorted(a - 1 for a in set(profile) if not reached[a - 1])
    if missing:
        return {'kind': 'canonical_remainder', 'missing_remainders': missing,
                'eligible_dimensions': dimensions}
    if not dimension_possible(rows, q):
        return {'kind': 'duality_dimension_squares',
                'eligible_selfdual': sorted({d for sd, d, values in rows if sd}),
                'eligible_pair': sorted({d for sd, d, values in rows if not sd})}
    return None


def propose(profile, assignment):
    pieces, double = fixed_blocks(assignment, None)
    q6, q = assignment['q6'], assignment['q']
    initial = list(fixed_rows(pieces, double, q6, q, None))
    gap_rows = None
    for stage in ('fixed_fields', 'annihilator', 'powers', 'higher_powers'):
        if stage == 'fixed_fields':
            rows = initial
        elif stage == 'annihilator':
            gap_rows = [
                row for row in initial
                if row_determinants(pieces, row[1], row[2], row[0], None) != ()
                and gap_possible(pieces, row[1], row[2])
            ]
            rows = gap_rows
        else:
            rows = [
                row for row in gap_rows
                if power_trace_possible(
                    pieces, row[1], row[2], row[0],
                    higher_fields=(stage == 'higher_powers')
                )
            ]
        target, vectors = coupled_moments(pieces, double, rows, q, None)
        candidate = cheap_row_certificate(profile, rows, q)
        # The original first stage used only the cheap necessary recurrences.
        if candidate is None and stage != 'fixed_fields':
            candidate = certificate(vectors, target)
            if candidate is None:
                candidate = bounded_certificate(vectors, target)
        if candidate is not None:
            if not verify_simple_certificate(profile, rows, q, candidate):
                assert verify_certificate(vectors, target, candidate)
            return {
                'fields': assignment['fields'], 'q6': q6, 'q': q,
                'pieces': pieces, 'double': double, 'rows': len(rows),
                'vectors': len(vectors), 'stage': stage,
                'certificate': candidate,
            }
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--start', type=int, default=0)
    parser.add_argument('--stop', type=int, default=6547)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Output already exists; use a new candidate file.')
    profiles = list(degree_profiles(left=11))
    assert len(profiles) == 6547
    records, unresolved = [], []
    started = time.monotonic()
    for index in range(args.start, min(args.stop, len(profiles))):
        profile = profiles[index]
        if Counter(profile)[10] == 1 or residue_fail(profile):
            continue
        assignments = commutative_assignments(profile)['surviving_assignments']
        for assignment in assignments:
            record = propose(profile, assignment)
            if record is None:
                unresolved.append({'index': index, 'fields': assignment['fields']})
            else:
                record['index'] = index
                records.append(record)
        if assignments:
            print(index, 'certificates', len(records), 'unresolved', len(unresolved),
                  'seconds', round(time.monotonic() - started, 2), flush=True)
    output = {
        'description': 'Optional regenerated commutative rank12 certificate candidates.',
        'range': [args.start, args.stop], 'records': records,
        'unresolved': unresolved, 'elapsed_seconds': time.monotonic() - started,
    }
    args.output.write_text(json.dumps(output, separators=(',', ':')) + '\n')
    print('Completed with', len(records), 'exact certificates and',
          len(unresolved), 'unresolved assignments.', flush=True)


if __name__ == '__main__':
    main()
