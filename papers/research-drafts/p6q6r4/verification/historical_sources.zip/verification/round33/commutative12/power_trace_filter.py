"""Exact integrality and positivity of coefficient traces of powers of X.

For each compatible scalar-value multiset (and matrix determinant), require
(d^k+sum_i a_i Tr_i(X^k))/5400 to be a nonnegative integer for0<=k<=max_power.
Only a necessary finite positivity test is claimed. Unknown higher field
value data is deliberately retained by this first implementation.
"""
from functools import lru_cache
from itertools import product
from math import isqrt
from gap_filter import row_determinants

@lru_cache(None)
def rational_multisets(k,s,t):
    out=[];limit=isqrt(t)
    def rec(left,lo,total,norm,chosen):
        if left==0:
            if total==norm==0:out.append(tuple(chosen))
            return
        if norm<0 or total*total>left*norm:return
        for x in range(lo,limit+1):
            if x*x<=norm:rec(left-1,x,total-x,norm-x*x,chosen+[x])
    rec(k,-limit,s,t,[]);return tuple(out)

def quadratic_powers(s,n,max_power):
    out=[2,s]
    for _ in range(2,max_power+1):out.append(s*out[-1]-n*out[-2])
    return tuple(out)

@lru_cache(None)
def scalar_power_options(piece,value,max_power,sd,d,higher_fields=False):
    a,k,label=piece;s,t=value;f=5400//a
    if label in('Q','rational6','rational_group'):
        bound=min(d-1,isqrt(f-1 if sd else (f-1)//2))
        return tuple(tuple(sum(x**j for x in xs) for j in range(max_power+1))
                     for xs in rational_multisets(k,s,t) if all(abs(x)<=bound for x in xs))
    if label=='complex6':
        if k==2:return (quadratic_powers(s,t//2,max_power),)
        assert k==4
        if t==0:return ((4,)+(0,)*max_power,)
        if sd:
            assert(s,t)==(0,4)
            return (tuple(4 if j%2==0 else 0 for j in range(max_power+1)),)
        assert abs(s)==1 and t==2
        return ((4,)+quadratic_powers(s,1,max_power)[1:],)
    if label.startswith('quadratic_disc='):
        delta=int(label.split('=')[1]);n=(s*s-t)//2 if delta>0 else t//2
        return (quadratic_powers(s,n,max_power),)
    if label.startswith('zeta'):
        from orbit_pairs import phi,quadratic_discriminants
        from field_discriminant_profiles import kronecker
        cstr,hstr=label.split(':H=');c=int(cstr[4:]);h=tuple(map(int,hstr.split(',')));e=phi(c)//len(h)
        if e==1:return (tuple(s**j for j in range(max_power+1)),)
        if e==2:
            deltas=[delta for delta in quadratic_discriminants(c) if all(kronecker(delta,z)==1 for z in h)]
            assert len(deltas)==1
            n=(s*s-t)//2 if deltas[0]>0 else t//2
            return (quadratic_powers(s,n,max_power),)
    if higher_fields:
        from field_power_polynomials import field_power_options
        return field_power_options(f,label,s,t,sd,max_power)
    return None

def power_trace_possible(pieces,d,values,sd,kind=None,max_power=12,check_cycle=True,higher_fields=False):
    matrix=next((i for i,p in enumerate(pieces) if p[2]=='matrix'),None)
    choices=[];weights=[]
    for i,(p,v) in enumerate(zip(pieces,values)):
        if i==matrix:continue
        opts=scalar_power_options(tuple(p),tuple(v),max_power,sd,d,higher_fields)
        if opts is None:return True
        if not opts:return False
        choices.append(opts);weights.append(p[0])
    if matrix is not None:
        s,t=values[matrix];dets=row_determinants(pieces,d,values,sd,kind)
        if dets is None:
            if sd:
                if(s*s-t)%2:return False
                dets=[(s*s-t)//2]
            elif kind=='symplectic':
                if t%2:return False
                dets=[t//2]
            else:dets=range(-t//2+int(t%2!=0),t//2+1)
        dets=[n for n in dets if 2*abs(n)<=t and(kind!='orthogonal' or 2*n>=s*s-t)]
        choices.append(tuple(quadratic_powers(s,n,max_power)for n in dets));weights.append(pieces[matrix][0])
    base=[d**k for k in range(max_power+1)]
    for selected in product(*choices):
        nums=[base[j]+sum(a*v[j]for a,v in zip(weights,selected))for j in range(max_power+1)]
        if any(n<0 or n%5400 for n in nums):continue
        if nums[0]!=5400 or nums[1]!=0 or nums[2]!=5400*sd:continue
        if check_cycle and not any(nums[1:]):continue
        return True
    return False
