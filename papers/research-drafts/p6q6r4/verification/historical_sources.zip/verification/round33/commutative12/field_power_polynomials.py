"""Exact full-field characteristic polynomials of integral character entries."""
from functools import lru_cache
from fractions import Fraction
from orbit_pairs import phi,ramanujan,lattice_vectors
import orbit_pairs
from generic_fields import EXTRA_POLY
from fixed_lattice import fixed_lattice
orbit_pairs.POLY.update(EXTRA_POLY)

def multiply(c,x,y):
    polynomial=orbit_pairs.POLY[c];n=len(polynomial)-1
    z=[0]*(2*n-1)
    for i,a in enumerate(x):
        if not a:continue
        for j,b in enumerate(y):
            if b:z[i+j]+=a*b
    for degree in range(2*n-2,n-1,-1):
        a=z[degree]
        if a:
            for j,b in enumerate(polynomial):z[degree-n+j]-=a*b
    assert not any(z[n:]);return tuple(z[:n])

@lru_cache(None)
def polynomial_map(f,c,h,sd):
    basis,gram,_=fixed_lattice(c,h,sd);n=phi(c);e=n//len(h);out={}
    ram=[ramanujan(c,j)for j in range(n)]
    for coords,norm in lattice_vectors(gram,len(h)*(f-1)):
        xx=[sum(coords[j]*basis[j][i]for j in range(len(basis)))for i in range(n)]
        if any(x.denominator!=1 for x in xx):continue
        x=tuple(int(a)for a in xx)
        assert norm.denominator==1 and int(norm)%len(h)==0
        t=int(norm)//len(h);power=(1,)+(0,)*(n-1);traces=[e]
        for j in range(1,e+1):
            power=multiply(c,power,x);trace=sum(a*b for a,b in zip(power,ram))
            assert trace%len(h)==0;traces.append(trace//len(h))
        coefficients=[1]
        for j in range(1,e+1):
            value=-sum(coefficients[j-i]*traces[i]for i in range(1,j+1))
            assert value%j==0;coefficients.append(value//j)
        out.setdefault((traces[1],t),set()).add(tuple(coefficients))
    return {key:tuple(sorted(value))for key,value in out.items()}

def powers_of_polynomial(coefficients,max_power):
    e=len(coefficients)-1;out=[e]
    for k in range(1,max_power+1):
        if k<=e:out.append(-sum(coefficients[j]*out[k-j]for j in range(1,k))-k*coefficients[k])
        else:out.append(-sum(coefficients[j]*out[k-j]for j in range(1,e+1)))
    return tuple(out)

@lru_cache(None)
def field_power_options(f,label,s,t,sd,max_power):
    if label=='real_cubic_conductor9':c,h=9,(1,8)
    else:
        cstr,hstr=label.split(':H=');c=int(cstr[4:]);h=tuple(map(int,hstr.split(',')))
    return tuple(powers_of_polynomial(coeff,max_power)for coeff in polynomial_map(f,c,h,sd).get((s,t),()))
