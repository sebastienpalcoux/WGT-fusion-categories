#!/usr/bin/env python3
"""Complete exact commutative rank12 exclusion; Python standard library only."""
from pathlib import Path
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import argparse,hashlib,json,time
from endpoint_core import degree_profiles
from generic_fields import commutative_assignments
from exact_filters import residue_fail,verify_simple_certificate
from fixed_field_rows import fixed_blocks,fixed_rows
from coupled_rows import coupled_moments
from gap_filter import gap_possible,row_determinants
from power_trace_filter import power_trace_possible
from exact_certificate_checks import verify_certificate
HERE=Path(__file__).resolve().parent

def signature(index,fields):return index,json.dumps(fields,sort_keys=True)

def verify_one(task):
    record,profile=task;start=time.monotonic()
    assignment={'fields':record['fields'],'q6':record['q6'],'q':record['q']}
    pieces,double=fixed_blocks(assignment,None)
    assert pieces==[tuple(p)for p in record['pieces']]and double==record['double'] is None
    q6,q=record['q6'],record['q'];rows=list(fixed_rows(pieces,double,q6,q,None));before=len(rows)
    stage=record['stage']
    if stage!='fixed_fields':
        rows=[r for r in rows if row_determinants(pieces,r[1],r[2],r[0],None)!=()and gap_possible(pieces,r[1],r[2])]
    if stage in('powers','higher_powers'):
        rows=[r for r in rows if power_trace_possible(pieces,r[1],r[2],r[0],higher_fields=stage=='higher_powers')]
    assert stage in('fixed_fields','annihilator','powers','higher_powers')
    target,vectors=coupled_moments(pieces,double,rows,q,None)
    assert(len(rows),len(vectors))==(record['rows'],record['vectors']),(record['index'],stage,len(rows),record['rows'])
    certificate=record['certificate']
    if not verify_simple_certificate(profile,rows,q,certificate):assert verify_certificate(vectors,target,certificate)
    return {'index':record['index'],'fields':record['fields'],'q6':q6,'q':q,'stage':stage,'certificate_kind':certificate['kind'],'initial_rows':before,'verified_rows':len(rows),'verified_atoms':len(vectors),'seconds':time.monotonic()-start}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=1);ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=6547);ap.add_argument('--output',type=Path,default=HERE/'rank12_verification.json');args=ap.parse_args()
    started=time.monotonic();profiles=list(degree_profiles(left=11));assert len(profiles)==6547
    declared=json.loads((HERE/'profiles_rank12.json').read_text());assert[tuple(p)for p in declared]==profiles
    stored=json.loads((HERE/'rank12_certificates.json').read_text())['records'];records={signature(r['index'],r['fields']):r for r in stored};assert len(records)==len(stored)==2516
    used=set();tasks=[];cases=[];stage_counts=Counter();field_totals=Counter()
    for index in range(args.start,min(args.stop,len(profiles))):
        p=profiles[index];rf=residue_fail(p);ten=Counter(p)[10]==1
        if rf or ten:
            cases.append({'index':index,'profile':p,'gate':'rational_ten'if ten else'residue','residue_fail':rf,'field_assignments':0,'excluded':True});stage_counts[cases[-1]['gate']]+=1;continue
        result=commutative_assignments(p)
        field_totals['all_assignments']+=result['total_assignments'];field_totals['discriminant_compatible']+=result['tested_assignments'];field_totals['retained_assignments']+=len(result['surviving_assignments'])
        for assignment in result['surviving_assignments']:
            key=signature(index,assignment['fields']);assert key in records
            record=records[key];assert(record['q6'],record['q'])==(assignment['q6'],assignment['q'])
            used.add(key);tasks.append((record,p))
        gate='trace_forms'if result['excluded']else'row_certificates';stage_counts[gate]+=1
        cases.append({'index':index,'profile':p,'gate':gate,'field_assignments':len(result['surviving_assignments']),'excluded':True})
    expected={key for key in records if args.start<=key[0]<args.stop};assert used==expected
    print('FIELDS PASS',len(cases),'profiles',len(tasks),'row records','seconds',time.monotonic()-started,flush=True)
    results=[]
    if args.workers==1:
        iterator=map(verify_one,tasks)
        for result in iterator:
            results.append(result)
            if len(results)%100==0:print('ROWS PASS',len(results),'of',len(tasks),'seconds',time.monotonic()-started,flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers)as pool:
            for result in pool.map(verify_one,tasks,chunksize=5):
                results.append(result)
                if len(results)%100==0:print('ROWS PASS',len(results),'of',len(tasks),'seconds',time.monotonic()-started,flush=True)
    kinds=Counter(r['certificate_kind']for r in results);stages=Counter(r['stage']for r in results)
    trusted=['verify_rank12.py','rank12_certificates.json','profiles_rank12.json','generic_fields.py','r32_trace_forms.py','endpoint_core.py','orbit_pairs.py','refined_rows.py','field_discriminant_profiles.py','coupled_rows.py','fixed_field_rows.py','fixed_lattice.py','gap_filter.py','power_trace_filter.py','field_power_polynomials.py','exact_filters.py','cheap_screen.py','exact_certificate_checks.py']
    output={'status':'PASS','range':[args.start,args.stop],'profiles_checked':len(cases),'profile_gates':dict(stage_counts),'field_totals':dict(field_totals),'full_field_records_checked':len(results),'certificate_kinds':dict(kinds),'record_stages':dict(stages),'initial_rows_regenerated':sum(r['initial_rows']for r in results),'verified_rows':sum(r['verified_rows']for r in results),'verified_atoms':sum(r['verified_atoms']for r in results),'unresolved_cases':[],'cases':cases,'row_records':results,'source_sha256':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()for name in trusted},'elapsed_seconds':time.monotonic()-started,'scope':'Complete exclusion of commutative source rank12 under the center hypothesis; no existence assertion and no exclusion of higher ranks.'}
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:output[k]for k in['status','profiles_checked','profile_gates','field_totals','full_field_records_checked','certificate_kinds','record_stages','initial_rows_regenerated','verified_rows','verified_atoms','unresolved_cases','elapsed_seconds']}),flush=True)
if __name__=='__main__':main()
