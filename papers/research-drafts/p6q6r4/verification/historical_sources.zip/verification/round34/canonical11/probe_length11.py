"""Exploratory necessary determinant/residue screen at canonical length11.
All multiplicity partitions are allowed. Odd nonlinear Galois pairs are
handled separately at(a,m); no rationality is inferred from odd degree alone.
"""
from pathlib import Path
import sys,json
from collections import Counter
from functools import lru_cache
from itertools import product
from math import gcd,prod
HERE=Path(__file__).resolve().parent
from verify_two_blocks import PALETTE,quadratic_discriminants,squarefree_part
from verify_length10 import partitions,subfield_orbits
N=5400

@lru_cache(None)
def profiles_rec(i,slots,total):
    if not slots:return ((),) if total==0 else ()
    if i==len(PALETTE) or total<10*slots or total>PALETTE[i]*slots:return ()
    a=PALETTE[i];out=[]
    for c in range(min(slots,total//a)+1):
        out += [(a,)*c+tail for tail in profiles_rec(i+1,slots-c,total-a*c)]
    return tuple(out)

@lru_cache(None)
def orbit_classes(a,m,k):
    if not k:return (1,)
    f=N//a;c=gcd(2*f,f*f)
    options=set() if a==10 else {(1,1)}
    if k>=2:
        options|={(2,squarefree_part(abs(D))) for D in quadratic_discriminants(c)}
    if k>=3 and c%9==0:options.add((3,1))
    if k>=4:
        assert c in (9,12,16,20,24),(a,m,k,c)
        options|={(e,s) for e,s,D,h in subfield_orbits(c,k) if e>=4}
    states=[set() for _ in range(k+1)];states[0]={1}
    for n in range(k):
        for old in states[n]:
            for e,s in options:
                if n+e<=k:states[n+e].add(squarefree_part(old*s))
    return tuple(sorted(states[k]))

def residue_failure(types):
    for a,m,c in types:
        if c!=1:continue
        g=0
        for aa,mm,cc in types:
            left=cc-int((aa,mm)==(a,m))
            if left:g=gcd(g,aa*mm)
        assert g
        r=a-m;w=a*m;common=gcd(w,g)
        if r%common:return (a,m,g)
        modulus=g//common
        u=0 if modulus==1 else (-r//common)*pow(w//common,-1,modulus)%modulus
        lower=-r+1;upper=r-1
        if lower+(u-lower)%modulus>upper:return (a,m,g)
    return None

def main():
    profiles=tuple(sorted(profiles_rec(0,10,5399),reverse=True));assert len(profiles)==497
    records=[]
    for index,p in enumerate(profiles):
        counts=Counter(p);aa=sorted(counts,reverse=True);base=squarefree_part(5400*prod(p))
        for parts in product(*(partitions(counts[a]) for a in aa)):
            types=[(a,m,c) for a,part in zip(aa,parts) for m,c in Counter(part).items()]
            rank=1+sum(m*m*c for a,m,c in types);comm=all(m==1 for a,m,c in types)
            low=rank<(12 if comm else 14)
            rational_ten=any(a==10 and c==1 for a,m,c in types)
            fields={1}
            for a,m,c in types:
                if m%2:fields={squarefree_part(x*y) for x in fields for y in orbit_classes(a,m,c)}
            det=base in fields and not rational_ten
            forbidden=counts[24]==counts[200]==1 and all(a in (24,200) or a%225==0 for a in aa)
            residue=residue_failure(types) if det and not low and not forbidden else None
            keep=det and not low and not forbidden and residue is None
            records.append({'index':index,'profile':p,'multiplicities':list(zip(aa,parts)),
                            'rank':rank,'commutative':comm,'types':types,'baseline':base,
                            'odd_component_field_classes':sorted(fields),'determinant_pass':det,
                            'excluded_by_rank':low,'forbidden_24_200':forbidden,
                            'rational_residue_failure':residue,'retained':keep})
    stats={'profiles':len(profiles),'assignments':len(records),
           'after_determinant':sum(r['determinant_pass'] for r in records),
           'after_known_ranks':sum(r['determinant_pass'] and not r['excluded_by_rank'] for r in records),
           'after_forbidden_pattern':sum(r['determinant_pass'] and not r['excluded_by_rank'] and not r['forbidden_24_200'] for r in records),
           'after_rational_residues':sum(r['retained'] for r in records),
           'retained_by_rank':dict(sorted(Counter(r['rank'] for r in records if r['retained']).items())),
           'rank15_candidates':sum(r['retained'] and r['rank']==15 for r in records)}
    (HERE/'length11_probe.json').write_text(json.dumps({'status':'EXPLORATORY_NECESSARY_DATA','summary':stats,'records':records},indent=2)+'\n')
    print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
