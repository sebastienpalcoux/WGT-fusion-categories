"""Necessary exact (a,m)-aggregate source rows at canonical length11.

Repeated nonlinear characters remain Galois-stable collections; no
rationality is inferred from odd representation degree alone.
"""
from functools import lru_cache
from itertools import product,combinations
from math import gcd,isqrt
from collections import Counter
from generic_fields import decompositions
from fixed_field_rows import fixed_options
from power_trace_filter import scalar_power_options
from orbit_pairs import phi
N=5400

def field_degree(label):
    if label=='Q':return 1
    if label=='Q(sqrt(-3))'or label.startswith('quadratic_disc='):return 2
    if label=='real_cubic_conductor9':return 3
    c,h=label.split(':H=');return phi(int(c[4:]))//len(h.split(','))

def real_field(label):
    if label in('Q','rational6','rational_group','real_cubic_conductor9'):return True
    if label.startswith('quadratic_disc='):return int(label.split('=')[1])>0
    if label=='complex6':return False
    c,h=label.split(':H=');return int(c[4:])-1 in tuple(map(int,h.split(',')))

@lru_cache(None)
def scalar_options(a,c,d,sd):
    f=N//a;out=set()
    for assignment in decompositions(f,c):
        labels=assignment[0];q6=assignment[4];pieces=[]
        nr=labels.count('Q')
        if nr:pieces.append((a,nr,'rational6'if f==6 else'Q'if nr==1 else'rational_group'))
        if q6:pieces.append((a,2*q6,'complex6'))
        pieces.extend((a,field_degree(label),label)for label in labels if label not in('Q','Q(sqrt(-3))'))
        lists=[]
        for piece in pieces:
            choices=[];label=piece[2]
            for s,t in fixed_options(piece,d,sd,'orthogonal',q6):
                if real_field(label):choices.append((s,t,0));continue
                for powers in scalar_power_options(piece,(s,t),2,sd,d,True):
                    w=t-powers[2]
                    if 0<=w<=f:choices.append((s,t,w))
            lists.append(sorted(set(choices)))
        states={(0,0,0)}
        for choices in lists:
            states={(s+x,t+y,w+z)for s,t,w in states for x,y,z in choices if t+y<f and w+z<=f}
        out.update(states)
    return tuple(sorted(out))

@lru_cache(None)
def options(group,d,sd):
    a,m,c=group;k=m*c;f=N//a;weight=1 if sd else 2
    cap=min(f-1,(N-d*d)//a,k*d*d-1)
    limit=min(k*d-1,isqrt((k*f-k*k)//weight))
    out={}
    if m==1:
        triples=scalar_options(a,c,d,sd)
    else:
        triples=[]
        for t in range(cap+1):
            for s in range(-min(t,limit),min(t,limit)+1):
                if s*s>k*t:continue
                if sd:
                    if(t-s)%2:continue
                    if c==1 and m==2 and t>=2*d*d-2*d*abs(s)+s*s:continue
                    triples.append((s,t,0))
                else:
                    top=min(f,(2*k*t-2*s*s)//k)
                    triples.extend((s,t,w)for w in range((t-s)%2,top+1,2))
    for s,t,w in triples:
        if t>cap or abs(s)>limit or abs(s)>t:continue
        if 2*s*s>k*(2*t-w)or (w-t+s)%2:continue
        if sd and w:continue
        out.setdefault((s,t),set()).add(w)
    return tuple((s,t,tuple(sorted(ws)))for(s,t),ws in sorted(out.items(),key=lambda v:(v[0][1],v[0][0])))

def skew_feasible(groups,choices,sd):
    if sd:return True
    data=sorted(((a,ws)for(a,m,c),ws in zip(groups,choices)),key=lambda v:len(v[1]))
    n=len(data);lo=[0]*(n+1);hi=[0]*(n+1);gg=[0]*(n+1)
    for i in reversed(range(n)):
        a,ws=data[i];lo[i]=lo[i+1]+a*ws[0];hi[i]=hi[i+1]+a*ws[-1]
        gg[i]=gcd(gg[i+1],gcd(*(a*w for w in ws)))
    @lru_cache(None)
    def visit(i,total):
        if total<lo[i]or total>hi[i]or(gg[i]and total%gg[i]):return False
        if i==n:return total==0
        a,ws=data[i]
        if i==n-1:return total%a==0 and total//a in ws
        return any(visit(i+1,total-a*w)for w in ws)
    return visit(0,N)

def rows_for(groups,rank):
    groups=tuple(tuple(g)for g in groups);n=len(groups)
    for sd in(True,False):
      maximum=isqrt(N-1-9*(rank-2))if sd else isqrt((N-1-9*(rank-3))//2)
      for d in range(3,maximum+1):
        choices=[options(g,d,sd)for g in groups]
        if any(not c for c in choices):continue
        order=sorted(range(n),key=lambda i:len(choices[i]));selected=[None]*n;skew=[None]*n
        maps=[{(s,t):ws for s,t,ws in c}for c in choices]
        ss=[0]*(n+1);st=[0]*(n+1);sm=[0]*(n+1);sg=[[0]*4 for _ in range(n+1)]
        for h in reversed(range(n)):
            i=order[h];a,m,c=groups[i]
            ss[h]=ss[h+1]+a*max(abs(s)for s,t,ws in choices[i]);st[h]=st[h+1]+a*max(t for s,t,ws in choices[i]);sm[h]=sm[h+1]+a*m*c
            gg=sg[h+1].copy()
            for s,t,ws in choices[i]:
                for j,v in enumerate((a*s,a*t,a*(t-s),a*(t+s))):gg[j]=gcd(gg[j],v)
            sg[h]=gg
        def visit(h,linear,square):
            if square<0 or square>st[h]or abs(linear)>min(ss[h],square)or linear*linear>sm[h]*square:return
            for v,g in zip((linear,square,square-linear,square+linear),sg[h]):
                if(g and v%g)or(not g and v):return
            i=order[h];a,m,c=groups[i]
            if h==n-1:
                if linear%a or square%a:return
                s,t=linear//a,square//a;ws=maps[i].get((s,t))
                if ws is None:return
                selected[i]=(s,t);skew[i]=ws
                if all(abs(s)==t for s,t in selected):return
                if skew_feasible(groups,skew,sd):yield(sd,d,tuple(selected))
                return
            for s,t,ws in choices[i]:
                if a*t>square:break
                selected[i]=(s,t);skew[i]=ws
                yield from visit(h+1,linear-a*s,square-a*t)
        yield from visit(0,-d,N-d*d)

def possible_pairs(groups,rank):
    choices={0}
    for a,m,c in groups:
        base=m*c*(m-1)//2
        if m==1:values={len(x[3])for x in decompositions(N//a,c)}
        elif m%2:values={base+m*q for q in range(c//2+1)}
        else:values={base+m*j for j in range(c+1)}
        choices={a+b for a in choices for b in values}
    return tuple(sorted(b for b in choices if 2*b<=rank-3))

def moment_data(groups,rows,rank,b):
    target=[rank-1-2*b,b,N-1]
    for a,m,c in groups:
        k=m*c;f=N//a;target.extend((m*k*f-k,-k,k*f-k*k))
    target.extend(-groups[i][1]*groups[i][2]*groups[j][1]*groups[j][2]for i,j in combinations(range(len(groups)),2))
    vectors=set()
    for sd,d,values in rows:
        v=[d*d]
        for s,t in values:v.extend((t,d*s,s*s))
        v.extend(values[i][0]*values[j][0]for i,j in combinations(range(len(groups)),2))
        vectors.add(((1,0)+tuple(v))if sd else((0,1)+tuple(2*x for x in v)))
    return tuple(target),sorted(vectors)

def cheap_certificate(groups,rows,rank,b=None):
    ds=sorted({d for sd,d,v in rows});required={a-m for a,m,c in groups}
    reach={0};maximum=max(required)
    for n in range(maximum+1):
        if n in reach:reach.update(n+d for d in ds if n+d<=maximum)
    missing=sorted(required-reach)
    if missing:return {'kind':'canonical_remainder','missing_remainders':missing,'eligible_dimensions':ds}
    sd=sorted({d for yes,d,v in rows if yes});pair=sorted({d for yes,d,v in rows if not yes})
    if b is None:return None
    bits=1;mask=(1<<N)-1
    for count,choices,weight in((rank-1-2*b,sd,1),(b,pair,2)):
        for _ in range(count):
            nxt=0
            for d in choices:nxt|=bits<<(weight*d*d)
            bits=nxt&mask
    if not(bits>>(N-1))&1:return{'kind':'duality_dimension_squares','eligible_selfdual':sd,'eligible_pair':pair}
    return None
