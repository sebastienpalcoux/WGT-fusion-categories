"""Word-polynomial refinement of all open length11 assignments."""
from pathlib import Path
from collections import Counter
import json,time
from canonical11_rows import rows_for,moment_data,cheap_certificate
from canonical11_words import word_possible
from propose_certificates import certificate
HERE=Path(__file__).resolve().parent

def main():
    start=time.monotonic();data=[json.loads(s)for s in(HERE/'aggregate_results.jsonl').read_text().splitlines()];counts=Counter()
    with(HERE/'word_results.jsonl').open('w')as out:
        for old in data:
            if old['excluded']:continue
            groups=tuple(tuple(g)for g in old['groups']);rank=old['rank'];ts=time.monotonic()
            print('START',old['assignment_index'],'rank',rank,flush=True)
            rows=list(rows_for(groups,rank));assert len(rows)==old['rows']
            refined=[r for r in rows if word_possible(groups,r,rank)]
            common=cheap_certificate(groups,refined,rank);branches=[]
            if common is None:
                for br in old['branches']:
                    if br['certificate']is not None:continue
                    b=br['pairs'];target,vectors=moment_data(groups,refined,rank,b)
                    cert=cheap_certificate(groups,refined,rank,b)
                    if cert is None:cert=certificate(vectors,target)
                    branches.append({'pairs':b,'vectors':len(vectors),'certificate':cert})
            excluded=common is not None or all(x['certificate']is not None for x in branches)
            record=dict(old);record.update(base_rows=len(rows),rows=len(refined),common_certificate=common,branches=branches,excluded=excluded,seconds=time.monotonic()-ts)
            out.write(json.dumps(record,separators=(',',':'))+'\n');out.flush()
            counts['assignments']+=1;counts['excluded']+=excluded;counts['rows']+=len(refined);counts['branches']+=len(branches);counts['open_branches']+=sum(x['certificate']is None for x in branches)
            print(old['assignment_index'],'rank',rank,len(rows),'->',len(refined),'EXCLUDED'if excluded else'OPEN',dict(counts),'seconds',round(time.monotonic()-start,2),flush=True)
    print('FINAL',dict(counts),'seconds',time.monotonic()-start,flush=True)

if __name__=='__main__':main()
