"""One-CPU producer for the complete length11 aggregate checkpoint."""
from pathlib import Path
from collections import Counter
import json,time,argparse
from canonical11_rows import rows_for,possible_pairs,moment_data,cheap_certificate
from propose_certificates import certificate
HERE=Path(__file__).resolve().parent

def main():
    start=time.monotonic();data=json.loads((HERE/'input4475.json').read_text())['records'];counts=Counter()
    with(HERE/'aggregate_results.jsonl').open('w')as out:
        for idx,r in enumerate(data):
            if not r['retained']or r['rank']==15:continue
            ts=time.monotonic();groups=tuple(tuple(g)for g in r['types']);rank=r['rank']
            pairs=possible_pairs(groups,rank);rowcount=0;branches=[]
            failures=[(a,m,c)for a,m,c in groups if (rank-1)*(5400//a-1)<m*m*c*(5400//a)-m*c]
            if failures:
                common={'kind':'norm_capacity','failing_groups':failures};rows=[]
            elif not pairs:
                common={'kind':'no_source_duality'};rows=[]
            else:
                rows=list(rows_for(groups,rank));rowcount=len(rows)
                common=cheap_certificate(groups,rows,rank)
            if common is None:
                for b in pairs:
                    target,vectors=moment_data(groups,rows,rank,b)
                    cert=cheap_certificate(groups,rows,rank,b)
                    if cert is None:cert=certificate(vectors,target)
                    branches.append({'pairs':b,'vectors':len(vectors),'certificate':cert})
            excluded=common is not None or all(x['certificate']is not None for x in branches)
            record={'assignment_index':idx,'profile_index':r['index'],'profile':r['profile'],'rank':rank,'groups':groups,'rows':rowcount,'possible_pairs':pairs,'common_certificate':common,'branches':branches,'excluded':excluded,'seconds':time.monotonic()-ts}
            out.write(json.dumps(record,separators=(',',':'))+'\n');out.flush()
            counts['assignments']+=1;counts['excluded']+=excluded;counts['rows']+=rowcount;counts['branches']+=len(branches);counts['open_branches']+=sum(x['certificate']is None for x in branches)
            if counts['assignments']%10==0 or not excluded:print(idx,'rank',rank,rowcount,'EXCLUDED'if excluded else'OPEN',dict(counts),'seconds',round(time.monotonic()-start,2),flush=True)
    print('FINAL',dict(counts),'seconds',time.monotonic()-start,flush=True)

if __name__=='__main__':main()
