"""End-to-end standard-library certificate of canonical length >=12.

Regenerates all4475 multiplicity assignments; verifies the exact153-rank15
link, rechecks the27 R33 aggregate exclusions with both independent row
algorithms, and invokes the full126-placement R34 verifier in a separate
Python process. No numerical solver is imported.
"""
from pathlib import Path
from functools import lru_cache
from collections import Counter
from itertools import product
from math import prod,gcd
import hashlib,json,subprocess,sys,time
from verify_two_blocks import PALETTE,squarefree_part,quadratic_discriminants,phi
from verify_length10 import generated_subgroups
from probe_length11 import orbit_classes,residue_failure
import generic_fields
from canonical11_rows import rows_for,possible_pairs,moment_data,cheap_certificate,field_degree
from canonical11_words import word_possible
from exact_certificate_checks import verify_certificate
import r33_aggregate_screen as r33
HERE=Path(__file__).resolve().parent
INPUT_SHA='40fddec652a2c8d41d8ef4fd024a361e13914a7f0d6affe58265e754fdbd80b7'
R33_SHA='3453afd176eedc55bef9f6eaff86025e054772abd2c7d9019f555ba9901df8a2'

@lru_cache(None)
def partitions(left,maximum=None):
    if maximum is None:maximum=left
    if left==0:return((),)
    return tuple((first,)+tail for first in range(min(left,maximum),0,-1)for tail in partitions(left-first,first))

@lru_cache(None)
def profiles(start,slots,total):
    if not slots:return((),)if total==0 else()
    if start==len(PALETTE)or total<slots*10 or total>slots*PALETTE[start]:return()
    out=[]
    for i in range(start,len(PALETTE)):
        a=PALETTE[i]
        if slots*a<total:break
        if a>total:continue
        out.extend((a,)+tail for tail in profiles(i,slots-1,total-a))
    return tuple(out)

def regenerate_input():
    ps=tuple(sorted(profiles(0,10,5399),reverse=True));assert len(ps)==497
    records=[]
    for index,p in enumerate(ps):
        counts=Counter(p);aa=sorted(counts,reverse=True);base=squarefree_part(5400*prod(p))
        for parts in product(*(partitions(counts[a])for a in aa)):
            types=[(a,m,c)for a,part in zip(aa,parts)for m,c in Counter(part).items()]
            rank=1+sum(m*m*c for a,m,c in types);comm=all(m==1 for a,m,c in types)
            assert rank%2==1
            low=rank<(13 if comm else 15)
            rational_ten=any(a==10 and c==1 for a,m,c in types)
            field_classes={1}
            for a,m,c in types:
                if m%2:field_classes={squarefree_part(x*y)for x in field_classes for y in orbit_classes(a,m,c)}
            det=base in field_classes and not rational_ten
            forbidden=counts[24]==counts[200]==1 and all(a in(24,200)or a%225==0 for a in aa)
            residue=residue_failure(types)if det and not low and not forbidden else None
            kept=det and not low and not forbidden and residue is None
            records.append({'index':index,'profile':p,'multiplicities':list(zip(aa,parts)),
                'rank':rank,'commutative':comm,'types':types,'baseline':base,
                'odd_component_field_classes':sorted(field_classes),'determinant_pass':det,
                'excluded_by_rank':low,'forbidden_24_200':forbidden,
                'rational_residue_failure':residue,'retained':kept})
    assert len(records)==4475
    return json.loads(json.dumps(records))

def audit_scalar_catalog(records):
    groups=sorted({(5400//a,c)for r in records if r['retained']for a,m,c in r['types']if m==1})
    output=[]
    for f,k in groups:
        conductor=gcd(2*f,f*f)
        if f==6:expected={'Q'}|({'Q(sqrt(-3))'}if k>=2 else set())
        else:
            expected=set()if f==540 else{'Q'}
            if k>=2:expected|={f'quadratic_disc={D}'for D in quadratic_discriminants(conductor)}
            if k>=3 and conductor%9==0:expected.add('real_cubic_conductor9')
            if k>=4:
                assert conductor==16,(f,k,conductor)
                expected|={f'zeta16:H='+','.join(map(str,h))for h in generated_subgroups(16)if phi(16)//len(h)==4}
            assert k<=5
        actual={x[0]for x in generic_fields.fields(f,k)if field_degree(x[0])<=k}
        assert expected==actual,(f,k,expected,actual)
        output.append({'formal_codegree':f,'number_of_linear_characters':k,'full_field_orbits':sorted(actual)})
    return output

def rank15_key(r):
    degrees=tuple(a for a,m,c in r['types']if m==2 for _ in range(c))
    assert len(degrees)==2 and all(m<=2 for a,m,c in r['types'])
    return tuple(r['profile']),degrees

def replay_rank15(records):
    assert hashlib.sha256((HERE/'rank15_aggregate_input.json').read_bytes()).hexdigest()==R33_SHA
    checkpoint=json.loads((HERE/'rank15_aggregate_input.json').read_text())
    old=checkpoint['records'];assert len(old)==153
    assert {rank15_key(r)for r in records if r['retained']and r['rank']==15}=={(tuple(r['profile']),tuple(r['nonlinear_degrees']))for r in old}
    failed=[r for r in old if not r['retained']];assert len(failed)==27
    grouped={tuple(r['profile'])for r in failed};assert len(grouped)==18
    ds_by_profile={};tests=0
    for profile in sorted(grouped,reverse=True):
        blocks=tuple(sorted(Counter(profile).items()));ds=[]
        for d in range(3,73):
            first=r33.feasible_mitm(blocks,d);second=r33.feasible_norm_first(blocks,d)
            assert first==second;tests+=1
            if first:ds.append(d)
        ds_by_profile[profile]=ds
    for record in failed:
        ds=ds_by_profile[tuple(record['profile'])];assert ds==record['eligible_dimensions']
        required=sorted({a-m for a,m,c in record['types']})
        semigroup=r33.remainder_semigroup(ds,max(required))
        missing=[n for n in required if not semigroup[n]]
        assert required==record['required_remainders']and missing==record['missing_remainders']and missing
    remaining=[r for r in old if r['retained']];assert len(remaining)==126
    folder=HERE.parent/'two_matrix15'
    assert json.loads((folder/'input126.json').read_text())==remaining
    print('rank15 link:153=27+126; independently replayed',tests,'R33 dimension tests',flush=True)
    result=subprocess.run([sys.executable,str(folder/'verify_two_matrix15.py')],cwd=folder,text=True,capture_output=True)
    assert result.returncode==0,result.stdout+'\n'+result.stderr
    verified=json.loads((folder/'verification_result.json').read_text())
    assert verified['status']=='PASS'and verified['counts']['placements']==126
    return {'initial_assignments':153,'r33_remainder_exclusions':27,'r33_profiles':18,'independent_dimension_tests':tests,'r34_complete_placement_exclusions':126,'r34_state_exclusions':verified['counts']['matrix_states']}

def main():
    started=time.monotonic();counts=Counter()
    assert hashlib.sha256((HERE/'input4475.json').read_bytes()).hexdigest()==INPUT_SHA
    regenerated=regenerate_input();old=json.loads((HERE/'input4475.json').read_text())['records'];assert regenerated==old
    assert not any((d**3-d)%5400==0 for d in range(3,73))
    catalog=audit_scalar_catalog(regenerated)
    baseline={'profiles':497,'assignments':4475,
       'after_determinant_and_rational_degree10':sum(r['determinant_pass']for r in regenerated),
       'after_known_rank_bounds':sum(r['determinant_pass']and not r['excluded_by_rank']for r in regenerated),
       'after_forbidden_pattern':sum(r['determinant_pass']and not r['excluded_by_rank']and not r['forbidden_24_200']for r in regenerated),
       'after_rational_residues':sum(r['retained']for r in regenerated)}
    assert list(baseline.values())==[497,4475,1105,676,617,589]
    print('all4475 assignments and scalar fields independently regenerated',flush=True)
    rank15=replay_rank15(regenerated)
    data=[json.loads(s)for s in(HERE/'aggregate_results.jsonl').read_text().splitlines()]
    refinements=[json.loads(s)for s in(HERE/'word_results.jsonl').read_text().splitlines()]
    first={r['assignment_index']:r for r in data};second={r['assignment_index']:r for r in refinements}
    expected={i for i,r in enumerate(regenerated)if r['retained']and r['rank']>15}
    assert set(first)==expected and len(first)==len(data)==436
    assert set(second)=={i for i,r in first.items()if not r['excluded']}and len(second)==12
    for i,rec in sorted(first.items()):
        source=regenerated[i];groups=tuple(tuple(g)for g in source['types']);rank=source['rank']
        assert rec['groups']==source['types']and rec['profile']==source['profile']and rec['rank']==rank
        pairs=possible_pairs(groups,rank);assert list(pairs)==rec['possible_pairs']
        common=rec['common_certificate'];counts['higher_rank_assignments']+=1
        if common is not None and common['kind']=='norm_capacity':
            failing=[[a,m,c]for a,m,c in groups if(rank-1)*(5400//a-1)<m*m*c*(5400//a)-m*c]
            assert failing and common['failing_groups']==failing
            counts['norm_capacity_exclusions']+=1;continue
        assert pairs
        rows=list(rows_for(groups,rank));assert len(rows)==rec['rows'];counts['base_rows']+=len(rows)
        if common is not None:
            assert cheap_certificate(groups,rows,rank)==common
            counts['base_canonical_remainders']+=1
        else:
            assert [r['pairs']for r in rec['branches']]==list(pairs)
            for branch in rec['branches']:
                cert=branch['certificate'];b=branch['pairs'];target,vectors=moment_data(groups,rows,rank,b)
                assert len(vectors)==branch['vectors'];counts['base_pair_branches']+=1
                if cert is None:counts['word_refined_pair_branches']+=1;continue
                if cert['kind']=='duality_dimension_squares':assert cheap_certificate(groups,rows,rank,b)==cert
                else:assert verify_certificate(vectors,target,cert)
                counts['base_'+cert['kind']]+=1
            if not rec['excluded']:
                refined=[r for r in rows if word_possible(groups,r,rank)];extra=second[i]
                assert len(refined)==extra['rows']and extra['base_rows']==len(rows)
                assert extra['common_certificate']==cheap_certificate(groups,refined,rank)
                assert extra['common_certificate']['kind']=='canonical_remainder'and extra['excluded']
                counts['word_refined_assignments']+=1;counts['word_rows']+=len(refined)
        if counts['higher_rank_assignments']%25==0:print('verified higher-rank assignment',counts['higher_rank_assignments'],'of436; seconds',round(time.monotonic()-started,2),flush=True)
    assert counts==Counter({'higher_rank_assignments':436,'norm_capacity_exclusions':2,
       'base_rows':69189,'base_canonical_remainders':146,'base_pair_branches':785,
       'base_integer_separator':548,'base_duality_dimension_squares':198,
       'word_refined_pair_branches':39,'word_refined_assignments':12,'word_rows':51}),counts
    result={'status':'PASS','dimension':5400,'canonical_length_excluded':11,'conclusion':'L>=12 under the standing center hypotheses',
      'baseline':baseline,'rank15_link':rank15,'higher_rank_counts':dict(counts),'scalar_catalog':catalog,
      'input_sha256':INPUT_SHA,'r33_rank15_aggregate_sha256':R33_SHA,'seconds':time.monotonic()-started,
      'scope':'All497 weighted profiles and4475 representation-multiplicity assignments covered; no numerical optimizer used.'}
    (HERE/'canonical11_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='scalar_catalog'},indent=2))

if __name__=='__main__':main()
