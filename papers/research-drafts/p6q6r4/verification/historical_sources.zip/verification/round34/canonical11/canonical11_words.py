"""Complete integral characteristic-polynomial supersets for L11 rows."""
from functools import lru_cache
from itertools import product
from math import comb,isqrt
from fractions import Fraction
from canonical11_rows import options
from field_power_polynomials import powers_of_polynomial
N=5400

def positive_semidefinite(matrix):
    a=[[Fraction(x)for x in row]for row in matrix]
    for k in range(len(a)):
        pivot=a[k][k]
        if pivot<0:return False
        if pivot==0:
            if any(a[k][j]for j in range(k+1,len(a))):return False
            continue
        for i in range(k+1,len(a)):
            for j in range(i,len(a)):
                a[i][j]-=a[k][i]*a[k][j]/pivot;a[j][i]=a[i][j]
    return True

@lru_cache(None)
def polynomial_powers(k,s,t,ws,sd,bound):
    if k==1:
        return (tuple(s**j for j in range(bound+1)),)if t==s*s and 0 in ws else()
    # Every nonzero integral root orbit of degree e contributes at least e
    # to the eigenvalue squared norm.  Hence at least k-t roots are zero.
    e_bounds=[0 if j>t else isqrt(comb(k,j)**2*t**j//k**j)for j in range(3,k+1)]
    out=set();length=max(bound,2*k-2)
    for w in ws:
        if (s*s-t+w)%2:continue
        c2=(s*s-t+w)//2
        if t<2 and c2:continue
        if k*k*c2*c2>comb(k,2)**2*t*t:continue
        for tail in product(*(range(-v,v+1)for v in e_bounds)):
            coefficients=(1,-s,c2)+tail
            seq=powers_of_polynomial(coefficients,length)
            if any(seq[j]*seq[j]>t**j for j in range(2,length+1)):continue
            if sd:
                if any(seq[j]<0 for j in range(2,length+1,2)):continue
                if not positive_semidefinite([[seq[i+j]for j in range(k)]for i in range(k)]):continue
            out.add(seq[:bound+1])
    return tuple(sorted(out))

def word_possible(groups,row,rank,bound=15):
    sd,d,values=row
    if d+sum(m*s for(a,m,c),(s,t)in zip(groups,values))<0:return False
    if d*d+sum(m*t for(a,m,c),(s,t)in zip(groups,values))<rank:return False
    choices=[]
    for g,(s,t)in zip(groups,values):
        a,m,c=g
        ws=next(ws for x,y,ws in options(g,d,sd)if(x,y)==(s,t))
        opts=polynomial_powers(m*c,s,t,ws,sd,bound)
        if not opts:return False
        choices.append(opts)
    base=tuple(d**j for j in range(bound+1))
    # The largest polynomial list is indexed by the exact second moment
    # and the next two trace congruences. This changes only enumeration
    # order, and avoids a large Cartesian product at codegree450.
    last=max(range(len(groups)),key=lambda i:len(choices[i]));others=[i for i in range(len(groups))if i!=last]
    a=groups[last][0];lookup={}
    for seq in choices[last]:lookup.setdefault((a*seq[2],a*seq[3]%N,a*seq[4]%N),[]).append(seq)
    selected=[None]*len(groups)
    for subset in product(*(choices[i]for i in others)):
        for i,seq in zip(others,subset):selected[i]=seq
        key=(N*sd-base[2]-sum(groups[i][0]*selected[i][2]for i in others),
             (-base[3]-sum(groups[i][0]*selected[i][3]for i in others))%N,
             (-base[4]-sum(groups[i][0]*selected[i][4]for i in others))%N)
        for seq in lookup.get(key,()):
            selected[last]=seq;good=True;returned=bool(sd)
            for j in range(2,bound+1):
                value=base[j]+sum(a*seq[j]for(a,m,c),seq in zip(groups,selected))
                if value<0 or value%N:good=False;break
                regular=base[j]+sum(m*seq[j]for(a,m,c),seq in zip(groups,selected))
                if N*regular<rank*value:good=False;break
                if j<=11 and value:returned=True
            if good and returned:return True
    return False

