#!/usr/bin/env python3
"""Exact initial canonical counts at commutative rank 14 / rank 16.

These are inputs to a future enumeration, not surviving rings.  The
generating-function table and the direct nonincreasing-profile generator
are independent implementations.  No numerical package is used.
"""
from collections import Counter
from itertools import combinations_with_replacement
from pathlib import Path
import json
import time

N = 5400
PALETTE = tuple(a for a in range(10, 901)
                if N % a == 0 and sum(a % p == 0 for p in (2, 3, 5)) >= 2)
HERE = Path(__file__).resolve().parent


def profiles(slots, total, cap=900):
    if slots == 0:
        if total == 0:
            yield ()
        return
    if total < 10 * slots:
        return
    for a in reversed(PALETTE):
        if a > cap:
            continue
        if a * slots < total:
            break
        if total - a < 10 * (slots - 1):
            continue
        for tail in profiles(slots - 1, total - a, a):
            yield (a,) + tail


def coefficients():
    dp = [[0] * N for _ in range(14)]
    dp[0][0] = 1
    for a in PALETTE:
        for k in range(1, 14):
            for total in range(a, N):
                dp[k][total] += dp[k - 1][total - a]
    return dp


def main():
    started = time.monotonic()
    dp = coefficients()
    count13 = 0
    placements1 = Counter()
    admitted1 = 0
    for p in profiles(13, N - 1):
        count13 += 1
        mult = Counter(p)
        eligible = [a for a, k in mult.items() if k >= 2]
        admitted1 += bool(eligible)
        placements1.update(eligible)
    assert count13 == dp[13][N - 1]
    for a in PALETTE:
        assert placements1[a] == dp[11][N - 1 - 2*a]

    count11 = 0
    admitted2 = 0
    placements2 = Counter()
    for p in profiles(11, N - 1):
        count11 += 1
        mult = Counter(p)
        eligible = sorted(a for a, k in mult.items() if k >= 2)
        current = [(a, b) for a, b in combinations_with_replacement(eligible, 2)
                   if a != b or mult[a] >= 4]
        admitted2 += bool(current)
        placements2.update(current)
    assert count11 == dp[11][N - 1] == 6547
    for a, b in combinations_with_replacement(PALETTE, 2):
        rest = N - 1 - 2*a - 2*b
        assert placements2[a, b] == (dp[7][rest] if rest >= 0 else 0)

    report = {
        'status': 'PASS', 'dimension': N, 'central_palette': PALETTE,
        'assumptions': 'Standing dimension-5400 center hypotheses; L>=12.',
        'algebra_shape_argument': 'At noncommutative rank 16, r-L is positive even and at most 4; hence only one or two degree-two irreducible representations.',
        'commutative_rank14': {
            'algebra': 'C^14', 'canonical_length': 14,
            'nonunit_weighted_entries': 13, 'weighted_profiles': count13},
        'rank16_one_degree2': {
            'algebra': 'C^12+M2', 'canonical_length': 14,
            'nonunit_weighted_entries': 13, 'weighted_profiles': count13,
            'profiles_admitting_placement': admitted1,
            'placements': sum(placements1.values()),
            'placements_by_nonlinear_degree': dict(sorted(placements1.items()))},
        'rank16_two_degree2': {
            'algebra': 'C^8+M2+M2', 'canonical_length': 12,
            'nonunit_weighted_entries': 11, 'weighted_profiles': count11,
            'profiles_admitting_placement': admitted2,
            'placements': sum(placements2.values()),
            'placements_by_unordered_nonlinear_degrees': [
                {'degrees': [a, b], 'count': count}
                for (a, b), count in sorted(placements2.items())]},
        'independent_check': 'Every total and every per-placement count agrees between direct profile generation and generating-function coefficients.',
        'scope': 'Initial necessary canonical inputs only. No field, trace-form, residue, source-row, fusion-coefficient or categorification test is claimed.',
        'elapsed_seconds': round(time.monotonic() - started, 3)}
    (HERE / 'next_canonical_counts.json').write_text(json.dumps(report, indent=2) + '\n')
    summary = {k: v for k, v in report.items() if k not in ('central_palette',)}
    for name in ('rank16_one_degree2', 'rank16_two_degree2'):
        summary[name] = {k: v for k, v in report[name].items()
                         if not k.startswith('placements_by_')}
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
