#!/usr/bin/env python3
"""Exact independent audit of character-coordinate roots and the f=9 cubic.

Only Python's standard library is used. The script checks field arithmetic,
the coordinate covariance, finite support geometry, duality qualifications,
and the forced projection/matrix identities. The coordinate patterns are
necessary patterns; no sampled pattern is asserted to be a fusion ring.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import time

HERE = Path(__file__).resolve().parent


def transpose(a):
    return [list(row) for row in zip(*a)]


def matmul(a, b):
    return [[sum(x*y for x, y in zip(row, col)) for col in zip(*b)] for row in a]


def identity(n):
    return [[int(i == j) for j in range(n)] for i in range(n)]


def rank(a):
    a = [list(map(Q, row)) for row in a]
    row = 0
    for col in range(len(a[0])):
        pivot = next((i for i in range(row, len(a)) if a[i][col]), None)
        if pivot is None:
            continue
        a[row], a[pivot] = a[pivot], a[row]
        scale = a[row][col]
        a[row] = [x/scale for x in a[row]]
        for i in range(len(a)):
            if i != row:
                scale = a[i][col]
                a[i] = [x-scale*y for x, y in zip(a[i], a[row])]
        row += 1
        if row == len(a):
            break
    return row


def inverse(a):
    n = len(a)
    a = [[Q(x) for x in row]+[Q(i == j) for j in range(n)] for i, row in enumerate(a)]
    for col in range(n):
        pivot = next(i for i in range(col, n) if a[i][col])
        a[col], a[pivot] = a[pivot], a[col]
        scale = a[col][col]
        a[col] = [x/scale for x in a[col]]
        for i in range(n):
            if i != col:
                scale = a[i][col]
                a[i] = [x-scale*y for x, y in zip(a[i], a[col])]
    return [row[n:] for row in a]


def dot(x, y):
    return sum(a*b for a, b in zip(x, y))


def add(x, y):
    return tuple(a+b for a, b in zip(x, y))


def scale(x, s):
    return tuple(s*a for a in x)


def basis_vector(n, i):
    return tuple(int(j == i) for j in range(n))


def root(n, i, j):
    return tuple(int(k == i)-int(k == j) for k in range(n))


def polynomial_product(x, y, modulus):
    n = len(modulus)-1
    coefficients = [Q(0)]*(2*n-1)
    for i, a in enumerate(x):
        for j, b in enumerate(y):
            coefficients[i+j] += a*b
    for degree in range(2*n-2, n-1, -1):
        leading = coefficients[degree]
        for j in range(n+1):
            coefficients[degree-n+j] -= leading*modulus[j]
    return tuple(coefficients[:n])


def multiplication_trace(x, modulus):
    n = len(modulus)-1
    return sum(polynomial_product(x, basis_vector(n, j), modulus)[j] for j in range(n))


CUBIC = (1, -3, 0, 1)
ONE = (Q(1), Q(0), Q(0))
ZERO = (Q(0), Q(0), Q(0))
T = (Q(0), Q(1), Q(0))


def multiply(x, y):
    return polynomial_product(x, y, CUBIC)


def trace(x):
    return multiplication_trace(x, CUBIC)


def sigma(x):
    image_t = (-Q(2), Q(0), Q(1))
    return add(add(scale(ONE, x[0]), scale(image_t, x[1])),
               scale(multiply(image_t, image_t), x[2]))


def field_checks(counts):
    beta = (ONE, (Q(2), Q(0), -Q(1)), (Q(0), -Q(1), Q(0)))
    gram = [[trace(multiply(x, y)) for y in beta] for x in beta]
    assert gram == [[3, 0, 0], [0, 6, -3], [0, -3, 6]]
    covariance = [[9*x for x in row] for row in inverse(gram)]
    assert covariance == [[3, 0, 0], [0, 2, 1], [0, 1, 2]]

    # Independent ambient computation in Q[zeta]/Phi_9.
    cyclotomic = (1, 0, 0, 1, 0, 0, 1)
    zeta = basis_vector(6, 1)
    powers = [basis_vector(6, 0)]
    for _ in range(9):
        powers.append(polynomial_product(powers[-1], zeta, cyclotomic))
    assert powers[9] == powers[0]
    conjugation = transpose([powers[(-j) % 9] for j in range(6)])
    assert matmul(conjugation, conjugation) == identity(6)
    assert rank([[conjugation[i][j]-int(i == j) for j in range(6)] for i in range(6)]) == 3
    ambient_beta = ((1, 0, 0, 0, 0, 0), (0, 1, -1, 0, 1, 0), (0, -1, 1, 0, 0, 1))
    basis_matrix = transpose(ambient_beta)
    select = [basis_vector(6, j) for j in (0, 4, 5)]
    assert matmul(select, basis_matrix) == identity(3)
    assert matmul(conjugation, basis_matrix) == basis_matrix
    projection = matmul(basis_matrix, select)
    symmetrizer = [[conjugation[i][j]+int(i == j) for j in range(6)] for i in range(6)]
    assert matmul(projection, symmetrizer) == symmetrizer
    ambient_gram = [[multiplication_trace(polynomial_product(x, y, cyclotomic), cyclotomic)
                     for y in ambient_beta] for x in ambient_beta]
    assert ambient_gram == [[2*x for x in row] for row in gram]

    eta = (T, (-Q(2), Q(0), Q(1)), (Q(2), -Q(1), -Q(1)))
    assert len(set(eta)) == 3
    assert add(add(*eta[:2]), eta[2]) == ZERO
    for x in eta:
        assert add(add(multiply(multiply(x, x), x), scale(x, -3)), ONE) == ZERO
        assert sigma(sigma(sigma(x))) == x
    assert tuple(sigma(x) for x in eta) == eta[1:]+eta[:1]
    for x, y in product((ONE, T, multiply(T, T)), repeat=2):
        assert sigma(multiply(x, y)) == multiply(sigma(x), sigma(y))
        counts['field_automorphism_product_checks'] += 1
    # A norm <=3 has |a|,|b|,|c|<=1: the form is 3a^2+2(b^2+bc+c^2).
    # Completing the square bounds the latter term below by 3b^2/2 and 3c^2/2.
    short = {}
    for u in product(range(-1, 2), repeat=3):
        norm = dot(u, [dot(row, u) for row in covariance])
        assert norm == 3*u[0]**2+2*(u[1]**2+u[1]*u[2]+u[2]**2)
        short.setdefault(norm, []).append(u)
    expected_roots = {(0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1), (0, 1, -1), (0, -1, 1)}
    assert set(short[2]) == expected_roots
    assert set(short[3]) == {(1, 0, 0), (-1, 0, 0)}
    assert not short.get(1)
    counts['cubic_norm_two_roots'] = 6
    return beta, gram, covariance, eta


def support_checks(counts):
    n = 7
    roots = [root(n, i, j) for i in range(1, n) for j in range(1, n) if i != j]
    canonical = {(1, 1), (-1, 0), (0, -1)}
    q_columns = []
    for i, j in combinations(range(1, n), 2):
        for a, b in product((-1, 1), repeat=2):
            q = list(basis_vector(n, 0))
            q[i], q[j] = a, b
            q_columns.append(tuple(q))
    for v, w in product(roots, repeat=2):
        if dot(v, w) != 1:
            continue
        support = {i for i in range(n) if v[i] or w[i]}
        assert len(support) == 3 and 0 not in support
        pairs = {(v[i], w[i]) for i in support}
        assert pairs == canonical or pairs == {(-a, -b) for a, b in canonical}
        counts['root_pair_support_checks'] += 1
        for q in q_columns:
            if dot(q, v) or dot(q, w):
                continue
            assert all(q[i] == 0 for i in support)
            assert len({i for i in range(1, n) if q[i]}) == 2
            counts['orthogonal_unit_column_support_checks'] += 1
    for e, f, a, b in product(range(3, 73), range(3, 73), (-1, 1), (-1, 1)):
        counts['consecutive_dimension_sign_checks'] += 1
        if 1+a*e+b*f == 0:
            assert a == -b and abs(e-f) == 1
            assert (f == e+1) if a == 1 else (e == f+1)
            counts['admissible_consecutive_sign_instances'] += 1
    for d, e in product(range(3, 73), repeat=2):
        assert (1+3*d*d+e*e+(e+1)**2) % 2 == d % 2
        counts['even_dimension_parity_checks'] += 1


def involutions_fixing_unit(n):
    current = {0: 0}

    def visit(left):
        if not left:
            yield tuple(current[i] for i in range(n))
            return
        i = left[0]
        current[i] = i
        yield from visit(left[1:])
        del current[i]
        for j in left[1:]:
            current[i], current[j] = j, i
            yield from visit(tuple(k for k in left[1:] if k != j))
            del current[i], current[j]
    yield from visit(tuple(range(1, n)))


def coordinate_rows(n, triple=(1, 2, 3), plus=4, minus=5, sign=1):
    rows = [[0, 0, 0] for _ in range(n)]
    rows[0] = [1, 0, 0]
    rows[plus], rows[minus] = [1, 0, 0], [-1, 0, 0]
    for label, pair in zip(triple, ((1, 1), (-1, 0), (0, -1))):
        rows[label] = [0, sign*pair[0], sign*pair[1]]
    return rows


def values_from_rows(rows, beta):
    return [tuple(sum(row[j]*beta[j][i] for j in range(3)) for i in range(3)) for row in rows]


def projection_and_difference(values):
    n = len(values)
    projector = [[trace(multiply(x, y))/9 for y in values] for x in values]
    difference = [[3*projector[i][j]-int(i == j) for j in range(n)] for i in range(n)]
    assert matmul(projector, projector) == projector and rank(projector) == 3
    assert difference == transpose(difference)
    assert all(x.denominator == 1 for row in difference for x in row)
    assert matmul(difference, difference) == [[difference[i][j]+2*int(i == j) for j in range(n)] for i in range(n)]
    assert sum(difference[i][i] for i in range(n)) == 9-n
    return projector, difference


def cubic_pattern_checks(beta, gram, covariance, eta, counts):
    duality_counts = {}
    for n in range(6, 10):
        rows = coordinate_rows(n)
        assert matmul(transpose(rows), rows) == covariance
        admissible = 0
        for permutation in involutions_fixing_unit(n):
            counts['source_involutions_checked'] += 1
            if any(rows[permutation[i]] != rows[i] for i in range(n)):
                continue
            assert all(permutation[i] == i for i in range(6))
            if n % 2:
                assert sum(permutation[i] == i for i in range(1, n)) >= 6
            admissible += 1
        duality_counts[n] = admissible
        assert admissible == {6: 1, 7: 1, 8: 2, 9: 4}[n]
        for sign in (-1, 1):
            rows = coordinate_rows(n, sign=sign)
            values = values_from_rows(rows, beta)
            assert set(values[1:4]) == {scale(x, sign) for x in eta}
            assert values[0] == values[4] == ONE and values[5] == scale(ONE, -1)
            assert all(x == ZERO for x in values[6:])
            orbit = (values, [sigma(x) for x in values], [sigma(sigma(x)) for x in values])
            for i, j in product(range(3), repeat=2):
                total = ZERO
                for x, y in zip(orbit[i], orbit[j]):
                    total = add(total, multiply(x, y))
                assert total == scale(ONE, 9*int(i == j))
                counts['cubic_character_orthogonality_checks'] += 1
            cycle = list(range(n))
            cycle[1], cycle[2], cycle[3] = 3, 1, 2
            assert all(sigma(values[i]) == values[cycle[i]] for i in range(n))
            assert all(cycle[cycle[cycle[i]]] == i for i in range(n))
            assert all(trace(values[i])/9 == Q(rows[i][0], 3) for i in range(n))
            projector, difference = projection_and_difference(values)
            expected_columns = []
            for i in range(n):
                column = [0]*n
                if i == 0:
                    column[4], column[5] = 1, -1
                elif i in (1, 2, 3):
                    for j in (1, 2, 3):
                        column[j] = 2*int(i == j)-1
                elif i == 4:
                    column[0], column[5] = 1, -1
                elif i == 5:
                    column[0], column[4] = -1, -1
                else:
                    column[i] = -1
                expected_columns.append(column)
            assert difference == transpose(expected_columns)
            counts['projection_and_fusion_matrix_patterns'] += 1
    return duality_counts


def nonreal_duality_check(counts):
    # The actual linear character 1,i,-1,-i of the group ring of C4.
    rows = [[1, 0], [0, 1], [-1, 0], [0, -1]]
    conjugation = [[1, 0], [0, -1]]
    duality = (0, 3, 2, 1)
    assert matmul(transpose(rows), rows) == [[2, 0], [0, 2]]
    assert all(matmul(conjugation, [[x] for x in rows[i]]) == [[x] for x in rows[duality[i]]]
               for i in range(4))
    real_root, imaginary_root = transpose(rows)
    assert dot(real_root, real_root) == dot(imaginary_root, imaginary_root) == 2
    assert sum(real_root) == sum(imaginary_root) == 0
    assert [real_root[duality[i]] for i in range(4)] == real_root
    assert [imaginary_root[duality[i]] for i in range(4)] == [-x for x in imaginary_root]
    assert duality[1] == 3 and duality[3] == 1
    counts['nonreal_duality_control'] = 1


def multiple_orbit_checks(beta, covariance, counts):
    n = 10
    rows1 = coordinate_rows(n, (1, 2, 3), 7, 8)
    rows2 = coordinate_rows(n, (4, 5, 6), 8, 9)
    assert matmul(transpose(rows1), rows1) == matmul(transpose(rows2), rows2) == covariance
    assert matmul(transpose(rows1), rows2) == [[0]*3 for _ in range(3)]
    values1, values2 = values_from_rows(rows1, beta), values_from_rows(rows2, beta)
    e1, a1 = projection_and_difference(values1)
    e2, a2 = projection_and_difference(values2)
    assert matmul(e1, e2) == [[0]*n for _ in range(n)]
    assert matmul(a1, a2) == [[-int(i == j)-a1[i][j]-a2[i][j] for j in range(n)] for i in range(n)]
    for d, dd, e in ((3, 4, 5), (7, 7, 7), (12, 17, 3)):
        dimensions = (1, d, d, d, dd, dd, dd, e, e+1, e+2)
        assert all(dot(dimensions, column) == 0 for column in transpose(rows1)+transpose(rows2))
    p = list(range(n));p[1], p[2], p[3] = 3, 1, 2
    q = list(range(n));q[4], q[5], q[6] = 6, 4, 5
    assert all(p[q[i]] == q[p[i]] for i in range(n))
    actions = set()
    for i, j in product(range(3), repeat=2):
        image = list(range(n))
        for _ in range(i):image = [p[x] for x in image]
        for _ in range(j):image = [q[x] for x in image]
        actions.add(tuple(image))
    assert len(actions) == 9
    counts['two_orbit_projection_patterns'] = 1
    counts['commuting_cubic_permutations'] = len(actions)

    roots = [(i, j, root(5, i, j)) for i in range(1, 5) for j in range(1, 5) if i != j]
    for (a, b, v), (c, d, w) in product(roots, repeat=2):
        if dot(v, w) != -1:
            continue
        assert len({a, b, c, d}) == 3
        assert (b == c) != (a == d)
        counts['two_orbit_endpoint_chain_checks'] += 1
    for triple in combinations(roots, 3):
        vv = [item[2] for item in triple]
        if not all(dot(vv[i], vv[j]) == -1 for i, j in combinations(range(3), 2)):
            continue
        assert tuple(sum(v[i] for v in vv) for i in range(5)) == (0,)*5
        counts['three_orbit_nullsum_checks'] += 1


def positive_subtable_checks(eta, counts):
    n = 7
    unit, y, z = basis_vector(n, 0), basis_vector(n, 4), basis_vector(n, 5)
    s = tuple(int(i in (1, 2, 3)) for i in range(n))
    yz = add(y, z)
    w = basis_vector(n, 6)
    templates = ((0,)*n, s, yz, w, add(add(scale(s, 2), scale(yz, 3)), w))
    for sign in (-1, 1):
        values = [ONE]+[scale(x, sign) for x in eta]+[ONE, scale(ONE, -1), ZERO]
        hs = []
        for i in range(3):
            next_label = (i+1) % 3+1
            h = basis_vector(n, next_label) if sign == 1 else add(s, scale(basis_vector(n, next_label), -1))
            hs.append(h)
            h_value = ZERO
            for coefficient, value in zip(h, values):
                h_value = add(h_value, scale(value, coefficient))
            assert h_value == eta[(i+1) % 3]
            assert multiply(values[i+1], values[i+1]) == add(scale(ONE, 2), h_value)
            counts['positive_subtable_field_checks'] += 1
        assert all(min(h[i] for h in hs) == 0 for i in range(n))
        for i, j in combinations(range(3), 2):
            k = ({0, 1, 2}-{i, j}).pop()
            assert multiply(values[i+1], values[j+1]) == add(scale(ONE, -1), eta[(k+1) % 3])
            counts['positive_subtable_field_checks'] += 1
        for t in templates:
            assert all(coefficient >= 0 for coefficient in t) and t[0] == 0
            assert t[1] == t[2] == t[3]
            t_value = ZERO
            for coefficient, value in zip(t, values):
                t_value = add(t_value, scale(value, coefficient))
            assert t_value == ZERO
            b = add(add(unit, y), t)
            squares = [add(b, h) for h in hs]
            for i, j in combinations(range(3), 2):
                k = ({0, 1, 2}-{i, j}).pop()
                offdiagonal = add(add(z, t), hs[k])
                assert offdiagonal == add(squares[k], scale(add(add(unit, y), scale(z, -1)), -1))
                assert all(coefficient >= 0 for coefficient in offdiagonal)
                assert offdiagonal[0] == 0
                assert add(squares[i], scale(squares[j], -1)) == scale(
                    add(basis_vector(n, (i+1) % 3+1), scale(basis_vector(n, (j+1) % 3+1), -1)), sign)
            assert all(square[0] == 1 for square in squares)
            counts['formal_positive_subtable_patterns'] += 1
    # For d=3, nonnegative residual dimension forces dim Z<=6 in the
    # positive case and <=3 in the negative case. The latter contradicts
    # dim Z>=4; the former leaves this finite complete check.
    possible = []
    for sign in (-1, 1):
        for dim_y in range(3, 6):
            dim_z = dim_y+1
            dim_t = (6 if sign == 1 else 3)-dim_z
            if dim_t >= 0 and (dim_t == 0 or dim_t >= 3):
                possible.append((sign, dim_y, dim_z, dim_t))
    assert possible == [(1, 5, 6, 0)]
    counts['dimension_three_local_patterns'] = len(possible)

    # Exact formal trace expansion of (Y-1)^2*(1+Y+X_next).
    # A monomial is indexed by its powers of Y and X_next.
    first = {(2, 0): 1, (1, 0): -2, (0, 0): 1}
    second = {(0, 0): 1, (1, 0): 1, (0, 1): 1}
    expanded = Counter()
    for (a, b), x in first.items():
        for (c, d), y in second.items():
            expanded[a+c, b+d] += x*y
    # Symbolic moment values are triples (constant, coefficient of t,
    # coefficient of h), with t=[Y^2:Y], h=[Y^2:X_next].
    moments = {(0, 0): (1, 0, 0), (1, 0): (0, 0, 0), (2, 0): (1, 0, 0),
               (3, 0): (0, 1, 0), (0, 1): (0, 0, 0), (1, 1): (0, 0, 0),
               (2, 1): (0, 0, 1)}
    total = tuple(sum(coefficient*moments[monomial][i]
                      for monomial, coefficient in expanded.items()) for i in range(3))
    assert total == (0, 1, 1)
    counts['dimension_three_norm_identity'] = 1
    h_cases = [h for h in range(2) if 12-11*h == 0 or 12-11*h >= 3]
    assert h_cases == [0]
    t_cases = [(t, 24-11*t) for t in (1, 2) if 24-11*t == 0 or 24-11*t >= 3]
    assert t_cases == [(1, 13)]
    assert 5*3-3 == 12
    counts['dimension_three_refinement_cases'] = len(t_cases)


def main():
    started = time.monotonic()
    counts = Counter()
    beta, gram, covariance, eta = field_checks(counts)
    support_checks(counts)
    duality_counts = cubic_pattern_checks(beta, gram, covariance, eta, counts)
    nonreal_duality_check(counts)
    multiple_orbit_checks(beta, covariance, counts)
    positive_subtable_checks(eta, counts)
    result = {
        'status': 'PASS', 'arithmetic': 'exact integers and Fraction; Python standard library only',
        'cubic_polynomial': list(CUBIC),
        'basis_in_1_t_t2': [[str(x) for x in row] for row in beta],
        'field_trace_gram': [[int(x) for x in row] for row in gram],
        'codegree_nine_covariance': [[int(x) for x in row] for row in covariance],
        'counts': dict(counts), 'admissible_source_involutions': duality_counts,
        'verified_claims': [
            'Cubic integral coordinates from the real fixed lattice in Q(zeta9)',
            'Trace Gram independently computed in cubic and cyclotomic arithmetic',
            'Exactly six norm-two roots and two norm-three unit functionals',
            'Equal-dimension cubic triple and disjoint consecutive-dimension endpoints',
            'All five support labels selfdual in the real field case',
            'Nonreal antisymmetric roots may instead form one dual pair',
            'Exact five-value character pattern and three-character orthogonality',
            'Cubic order-three permutation fixes every other character value',
            'Central projection and complete forced difference of fusion matrices',
            'Positive cubic subtable with a common nonnegative zero-projection term',
            'Triple dimension3 forces the positive sign, T=0, and endpoint dimensions5,6',
            'At triple dimension3, the Frobenius norm identity forces a further dimension12 simple',
            'Two cubic orbits have orthogonal projections and a consecutive endpoint chain',
            'Three candidate unit columns have zero nonunit sum, contradicting Perron orthogonality',
        ],
        'hypotheses': 'Full non-Perron linear orbit with real cubic conductor-nine field and common codegree9; integral source dimensions only for the stated even-dimension parity refinement.',
        'scope': 'Supplementary exact structural audit. No new endpoint elimination count, fusion-ring existence, categorification, or tensor-autoequivalence claim.',
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'proof_sha256': hashlib.sha256((HERE/'r34_character_type_roots.tex').read_bytes()).hexdigest(),
        'seconds': time.monotonic()-started,
    }
    (HERE/'character_type_roots_verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status': result['status'], 'counts': result['counts'],
                      'admissible_source_involutions': duality_counts,
                      'seconds': result['seconds']}, indent=2))


if __name__ == '__main__':
    main()
