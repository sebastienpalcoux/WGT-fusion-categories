#!/usr/bin/env python3
"""Count raw dimension-equation types at source ranks 13, 14, 15, 16.

Two independent exact coefficient algorithms are compared entry by entry:
  (1) the product of geometric series, processed one allowed dimension at a time;
  (2) Newton's recurrence for complete homogeneous symmetric functions.

No character, divisibility, fusion-rule, or categorification condition is
imposed. The script uses only the Python standard library.
"""
from pathlib import Path
import hashlib
import json
import time

HERE = Path(__file__).resolve().parent
DIMENSION = 5400
NONUNIT_MASS = DIMENSION-1
DIMENSIONS = tuple(range(3, 73))
RANKS = (13, 14, 15, 16)
MAX_LENGTH = max(RANKS)-1
EXPECTED_COUNTS = {
    13: 31245433,
    14: 80770733,
    15: 193198479,
    16: 431154222,
}


def coin_product():
    """Coefficients of product_d (1-u*v^(d*d))^(-1)."""
    rows = [[0]*(NONUNIT_MASS+1) for _ in range(MAX_LENGTH+1)]
    rows[0][0] = 1
    for dimension in DIMENSIONS:
        square = dimension*dimension
        # Increasing length permits any multiplicity of the current square.
        for length in range(1, MAX_LENGTH+1):
            previous, current = rows[length-1], rows[length]
            for mass in range(square+9*(length-1), NONUNIT_MASS+1):
                current[mass] += previous[mass-square]
    return rows


def complete_symmetric_newton():
    """k*h_k(v) = sum_(j=1)^k p_j(v)*h_(k-j)(v).

    Here p_j(v)=sum_d v^(j*d*d). Numerators are formed directly from
    previously computed h-rows; every coefficient is checked divisible by k.
    """
    rows = [[1]+[0]*NONUNIT_MASS]
    divisions_checked = 0
    for length in range(1, MAX_LENGTH+1):
        numerator = [0]*(NONUNIT_MASS+1)
        for power in range(1, length+1):
            previous = rows[length-power]
            minimum_previous_mass = 9*(length-power)
            for dimension in DIMENSIONS:
                shift = power*dimension*dimension
                if shift+minimum_previous_mass > NONUNIT_MASS:
                    break
                for mass in range(minimum_previous_mass, NONUNIT_MASS-shift+1):
                    numerator[mass+shift] += previous[mass]
        quotient = []
        for value in numerator:
            q, remainder = divmod(value, length)
            assert remainder == 0
            quotient.append(q)
            divisions_checked += 1
        rows.append(quotient)
    return rows, divisions_checked


def coefficient_digest(rows):
    return hashlib.sha256(json.dumps(rows, separators=(',', ':')).encode()).hexdigest()


def main():
    started = time.monotonic()
    first_started = time.monotonic()
    product_rows = coin_product()
    product_seconds = time.monotonic()-first_started
    second_started = time.monotonic()
    newton_rows, divisions_checked = complete_symmetric_newton()
    newton_seconds = time.monotonic()-second_started
    assert len(product_rows) == len(newton_rows) == 16
    coefficients_checked = 0
    for length in range(MAX_LENGTH+1):
        assert len(product_rows[length]) == len(newton_rows[length]) == NONUNIT_MASS+1
        for mass in range(NONUNIT_MASS+1):
            assert product_rows[length][mass] == newton_rows[length][mass], (length, mass)
            coefficients_checked += 1
    assert coefficients_checked == 86400
    assert divisions_checked == 81000
    first_digest = coefficient_digest(product_rows)
    second_digest = coefficient_digest(newton_rows)
    assert first_digest == second_digest
    counts = [{'rank': rank, 'nonunit_count': rank-1,
               'raw_dimension_types': product_rows[rank-1][NONUNIT_MASS]}
              for rank in RANKS]
    assert {row['rank']: row['raw_dimension_types'] for row in counts} == EXPECTED_COUNTS
    report = {
        'status': 'PASS', 'arithmetic': 'exact Python integers; standard library only',
        'total_dimension': DIMENSION, 'unit_count': 1, 'unit_dimension': 1,
        'allowed_nonunit_dimensions': list(DIMENSIONS),
        'nonunit_square_sum': NONUNIT_MASS,
        'equations': ['sum_(d=3)^72 n_d = r-1', 'sum_(d=3)^72 d^2*n_d = 5399',
                      'n_d are nonnegative integers'],
        'counts': counts,
        'coin_product': {'seconds': product_seconds, 'coefficient_sha256': first_digest},
        'newton_complete_symmetric': {'seconds': newton_seconds,
                                     'coefficient_sha256': second_digest,
                                     'exact_divisions_checked': divisions_checked},
        'coefficients_compared': coefficients_checked,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'seconds': time.monotonic()-started,
        'scope': 'Raw dimension-equation types only. No assumption that d divides 5400; no character constraints, multiplication tables, categorifiability, or existence claims.',
        'branch_caveat': 'A noncommutative rank-15 exclusion does not exclude the rank-15 dimension vectors from the commutative setting. The counts at ranks 14 and 16 are arithmetic universes, not actual surviving types in the respective branches.',
    }
    (HERE/'source_type_counts.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'status': report['status'], 'counts': counts,
                      'coefficients_compared': coefficients_checked,
                      'coin_product_seconds': product_seconds,
                      'newton_seconds': newton_seconds,
                      'seconds': report['seconds']}, indent=2))


if __name__ == '__main__':
    main()
