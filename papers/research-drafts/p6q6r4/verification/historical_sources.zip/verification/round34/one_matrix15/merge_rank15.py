#!/usr/bin/env python3
"""Select one certificate per state and check complete exact replay coverage.

Preparation is not verification.  The --check mode requires every claimed
exclusion to have exactly one PASS ledger entry with the current proof hash
and the hash of its final selected certificate record.
"""
from collections import Counter
from math import isqrt
from pathlib import Path
import argparse,hashlib,json
from bounded_remainder import states,HERE
from verify_rank15 import proof_digest,digest
from verify_trace15 import trace_digest,input_digests

def universe():
    result={i:(c['index'],c['double_degree'],ai,k,a['q'])
            for i,c,ai,a,k in states(HERE/'rank15_trace_final.jsonl')}
    assert set(result)==set(range(125545))
    return result

def compressed_certificate(cert,b):
    if cert['kind']!='duality_dimension_squares':return cert
    sd=cert['eligible_selfdual'];pair=cert['eligible_pair'];s=14-2*b
    umax=min(sd,default=73);vmax=min(pair,default=52)
    oddmax=min((d for d in sd if d%2),default=73)
    evenmax=min((d for d in sd if not d%2),default=74)
    candidates=[]
    for u in range(3,umax+1):
        rem=5399-s*u*u
        v=max(3,isqrt(rem//(2*b))+1)if rem>=0 else 3
        if v>vmax:continue
        mass=s*u*u+2*b*v*v;assert mass>5399
        c={'kind':'duality_dimension_minimum','source_pairs':b,
           'selfdual_lower_bound':u,'pair_lower_bound':v,
           'nonunit_dimension_square_lower_bound':mass}
        candidates.append(((u-3)+(v-3),0,c))
    for uo in range(3,oddmax+1,2):
      for ue in range(4,evenmax+1,2):
        base=min(uo*uo+(s-1)*ue*ue,(s-1)*uo*uo+ue*ue)
        rem=5399-base
        v=max(3,isqrt(rem//(2*b))+1)if rem>=0 else 3
        if v>vmax:continue
        mass=base+2*b*v*v;assert mass>5399
        c={'kind':'duality_parity_minimum','source_pairs':b,
           'odd_selfdual_lower_bound':uo,'even_selfdual_lower_bound':ue,
           'pair_lower_bound':v,'nonunit_dimension_square_lower_bound':mass}
        candidates.append(((uo-3)//2+(ue-4)//2+(v-3),1,c))
    if not candidates:return cert
    return min(candidates,key=lambda x:(x[0],x[1],json.dumps(x[2],sort_keys=True)))[2]

def score(record):
    c=record['certificate']
    if c is None:return(10**12,0)
    k=c['kind']
    if k in('imaginary_quadratic_skew_norm','real_quadratic_difference_norm_one','real_quadratic_norm_two_supports','linear_field_coordinate_lattice'):n=0
    elif k=='bounded_canonical_remainder':n=2*(c['dimension_bound']-2-len(c['eligible_dimensions']))
    elif k=='source_dimension_density':n=34
    elif k=='duality_dimension_minimum':n=c['selfdual_lower_bound']+c['pair_lower_bound']-6
    elif k=='duality_parity_minimum':n=(c['odd_selfdual_lower_bound']-3)//2+(c['even_selfdual_lower_bound']-4)//2+c['pair_lower_bound']-3
    elif k in('canonical_remainder_with_duality','central_canonical_atom'):
        if k=='central_canonical_atom':missing=range(3,c['minimum_contribution'])
        else:missing=[d for d in range(3,c['contribution_bound']+1)if d not in c['eligible_contributions']]
        n=sum(int(d<=72)+int((d%2==0 and d//2<=51)if c['canonical_selfdual']else d<=51)for d in missing)
        if k=='central_canonical_atom':n+=2
    elif k=='duality_dimension_squares':n=119-len(c['eligible_selfdual'])-len(c['eligible_pair'])
    else:n=1000+record.get('raw_rows',0)//100
    return(n,record.get('level',1))

def check_signature(r,expected):
    i=r['state'];assert i in expected
    assert(r['index'],r['double_degree'],r['assignment_index'],r['kind'])==expected[i][:4]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,nargs='+')
    ap.add_argument('--output',type=Path,default=HERE/'rank15_certificates.jsonl')
    ap.add_argument('--check',type=Path);ap.add_argument('--ledgers',type=Path,nargs='+')
    ap.add_argument('--trace-report',type=Path)
    ap.add_argument('--report',type=Path,required=True);ap.add_argument('--require-closed',action='store_true')
    args=ap.parse_args();expected=universe();selected={};input_rows=0
    if args.check:
        assert not args.inputs
        with args.check.open()as inp:
            for line in inp:
                r=json.loads(line);check_signature(r,expected)
                assert r['state']not in selected;selected[r['state']]=r
        final_path=args.check
    else:
        assert args.inputs and not args.ledgers
        for path in args.inputs:
          with path.open()as inp:
            for line in inp:
                r=json.loads(line);input_rows+=1;check_signature(r,expected)
                r=dict(r);r['selected_from']=path.name
                if r['certificate']is not None:
                    q=expected[r['state']][4];b=q+(3 if r['kind']=='symplectic'else 1)
                    old=r['certificate'];new=compressed_certificate(old,b)
                    if new!=old:
                        r['certificate']=new;r['compressed_from']=old['kind']
                i=r['state']
                if i not in selected or score(r)<score(selected[i]):selected[i]=r
        final_path=args.output
        # Incomplete producer snapshots must not become a final checkpoint.
        assert set(selected)==set(expected),('missing states',len(set(expected)-set(selected)))
        with final_path.open('w')as out:
            for i in range(125545):out.write(json.dumps(selected[i],separators=(',',':'))+'\n')
    assert set(selected)==set(expected)
    closed={i for i,r in selected.items()if r['certificate']is not None}
    if args.require_closed:assert len(closed)==125545,('OPEN states',125545-len(closed))
    histogram=Counter(r['certificate']['kind']if r['certificate']else'OPEN'for r in selected.values())
    proof=proof_digest();replayed=set();ledger_hashes={}
    trace_report=None
    if args.check:
        assert args.ledgers,'Final checking requires explicit replay ledger paths.'
        assert args.trace_report,'Final checking also requires the complete placement replay.'
        trace_report=json.loads(args.trace_report.read_text())
        assert trace_report['status']=='PASS_COMPLETE_TRACE_REPLAY'
        assert trace_report['profiles']==62776
        assert trace_report['counts']['placements']==143657
        assert trace_report['counts']['excluded_placements']==109986
        assert trace_report['counts']['field_duality_states']==125545
        assert trace_report['trace_proof_sha256']==trace_digest()
        assert trace_report['input_sha256']==input_digests()
        for path in args.ledgers:
            ledger_hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
            with path.open()as inp:
                for line in inp:
                    e=json.loads(line);i=e['state']
                    assert i in closed and i not in replayed,('extraneous or duplicate replay',i)
                    assert e['status']=='PASS'and e['proof_sha256']==proof,('stale proof replay',i)
                    assert e['certificate_sha256']==digest(selected[i]),('stale certificate replay',i)
                    replayed.add(i)
        assert replayed==closed,('missing exact replays',len(closed-replayed))
        status='PASS_COMPLETE_EXCLUSION'if len(closed)==125545 else'PASS_COMPLETE_CHECKPOINT'
    else:status='PREPARED_FOR_EXACT_REPLAY'
    report={'status':status,'expected_states':125545,'final_records':len(selected),
            'closed_records':len(closed),'open_records':125545-len(closed),
            'exact_replays_checked':len(replayed),'certificate_histogram':dict(histogram),
            'input_records':input_rows,'proof_sha256':proof,
            'final_certificate_file_sha256':hashlib.sha256(final_path.read_bytes()).hexdigest(),
            'ledger_sha256':ledger_hashes,'trace_replay':trace_report}
    args.report.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
