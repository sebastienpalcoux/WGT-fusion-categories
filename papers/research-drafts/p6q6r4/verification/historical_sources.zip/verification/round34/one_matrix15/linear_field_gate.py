#!/usr/bin/env python3
"""Complete structural pass on the unchanged one-M2 trace-state universe.

The integral source has rational Perron character and no nonunit simple
of dimension one.  The covariance lemma is applied only to linear fields.
"""
from quadratic_character_gate import obstruction as quadratic_obstruction
from linear_field_lattice import assignment_failure,verify_field_lattice

def obstruction(assignment,kind):
    return quadratic_obstruction(assignment,kind)or assignment_failure(assignment)

def main():
    from bounded_remainder import states,HERE
    from collections import Counter
    import json,time
    start=time.monotonic();hist=Counter();duality=Counter();failures=Counter();witnesses={};total=0
    with(HERE/'linear_field_exclusions.jsonl').open('w')as out:
        for ordinal,case,ai,assignment,kind in states(HERE/'rank15_trace_final.jsonl'):
            total+=1;cert=obstruction(assignment,kind)
            if cert is None:continue
            if cert['kind']=='linear_field_coordinate_lattice':
                assert verify_field_lattice(assignment,cert)
                failures[cert['failure']]+=1
                witnesses[(cert['formal_codegree'],cert['field'])]=cert
            record={'state':ordinal,'index':case['index'],'double_degree':case['double_degree'],
                    'assignment_index':ai,'kind':kind,'level':0,
                    'phase':'integral_linear_character_columns','certificate':cert}
            out.write(json.dumps(record,separators=(',',':'))+'\n')
            hist[cert['kind']]+=1;duality[kind]+=1
    assert total==125545
    report={'status':'COMPLETE_EXACT_STRUCTURAL_GATE','universe_states':total,
            'excluded_states':sum(hist.values()),'remaining_states':total-sum(hist.values()),
            'certificate_histogram':dict(hist),'duality_types':dict(duality),
            'coordinate_lattice_failures':dict(failures),
            'coordinate_lattice_witnesses':[witnesses[k]for k in sorted(witnesses)],
            'seconds':time.monotonic()-start}
    (HERE/'linear_field_gate_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='coordinate_lattice_witnesses'},indent=2))

if __name__=='__main__':main()
