#!/usr/bin/env python3
"""Portable exact replay of the rank-fifteen one-M2 necessary-data ledger.

OPEN records are explicitly retained.  No numerical solver is imported.
Earlier certificates may record a safe superset of the final row universe:
every dimension or contribution claimed absent is independently regenerated.
Historical exploratory raw-row counts are deliberately not proof premises.
"""
from collections import Counter
from pathlib import Path
import argparse,hashlib,json,time
from endpoint_core import degree_profiles
from trace_rank15 import analyze as trace_analyze
from fixed_field_rows import fixed_blocks,fixed_rows
from matrix_spectral_filter import context
from norm_word_filter import determinant_options
from bounded_remainder import row_allowed,parity_index,canonical_requirements
from coupled_rows import coupled_moments
from refined_rows import row_moment_vector

HERE=Path(__file__).resolve().parent
PROOF_FILES=('verify_rank15.py','endpoint_core.py','trace_rank15.py',
 'generic_fields.py','r32_trace_forms.py','fixed_field_rows.py','fixed_lattice.py',
 'coupled_rows.py','refined_rows.py','orbit_pairs.py','field_discriminant_profiles.py',
 'gap_filter.py','power_trace_filter.py','mixed_trace_filter.py','norm_word_filter.py',
 'field_power_polynomials.py','matrix_spectral_filter.py','bounded_remainder.py',
 'merge_rank15.py','imaginary_quadratic_gate.py','quadratic_character_gate.py',
 'verify_trace15.py','linear_field_lattice.py','linear_field_gate.py')

def proof_digest():
    h=hashlib.sha256()
    for name in sorted(PROOF_FILES):h.update(name.encode()+b'\0'+(HERE/name).read_bytes()+b'\0')
    return h.hexdigest()

def digest(record):
    return hashlib.sha256(json.dumps(record,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def semigroup(R,coins):
    reachable={0}
    for x in range(R+1):
        if x in reachable:reachable.update(x+c for c in coins if x+c<=R)
    return R in reachable

def dot(x,y):
    assert len(x)==len(y)
    return sum(a*b for a,b in zip(x,y))

def replay(record,case,assignment):
    cert=record['certificate'];assert cert is not None
    kind=record['kind'];level=record.get('level',1)
    if cert['kind']=='linear_field_coordinate_lattice':
        from linear_field_lattice import verify_field_lattice
        assert verify_field_lattice(assignment,cert)
        return 0
    if cert['kind']=='imaginary_quadratic_skew_norm':
        from imaginary_quadratic_gate import discriminant
        f=cert['formal_codegree'];label=cert['field'];D=cert['discriminant']
        assert any(b['formal_codegree']==f and label in b['fields']for b in assignment['fields'])
        assert discriminant(label)==D and D<0
        b=assignment['q']+(3 if kind=='symplectic'else 1);assert cert['source_pairs']==b
        if cert['reason']=='nonintegral_skew_length':assert f%(-D)
        else:
            assert cert['reason']=='integer_square_sum'and f%(-D)==0
            total=f//(-D);squares=[j*j for j in range(total+1)if j*j<=total]
            reachable={0}
            for _ in range(b):reachable={x+y for x in reachable for y in squares if x+y<=total}
            assert total not in reachable
        return 0
    if cert['kind']=='real_quadratic_difference_norm_one':
        from imaginary_quadratic_gate import full_discriminant
        f=cert['formal_codegree'];label=cert['field'];D=cert['discriminant']
        assert any(b['formal_codegree']==f and label in b['fields']for b in assignment['fields'])
        assert full_discriminant(label)==D==2*f and D>0
        return 0
    if cert['kind']=='real_quadratic_norm_two_supports':
        from imaginary_quadratic_gate import full_discriminant
        expected=[{'formal_codegree':block['formal_codegree'],'field':label,
                   'discriminant':full_discriminant(label)}
                  for block in assignment['fields']for label in block['fields']
                  if full_discriminant(label)==block['formal_codegree']]
        b=assignment['q']+(3 if kind=='symplectic'else 1);s=14-2*b
        assert cert['orbits']==expected and cert['orbit_count']==len(expected)>0
        assert cert['source_pairs']==b and cert['selfdual_nonunits']==s and 2*len(expected)>=s
        return 0
    p,mi=fixed_blocks(assignment,case['double_degree'])
    ctx=context(assignment,case['double_degree'],kind);parity=parity_index(assignment,p,kind)
    cache={};examined=0
    def allowed_rows(dimensions,dualities=(True,False)):
        nonlocal examined
        for row in fixed_rows(p,mi,assignment['q6'],assignment['q'],kind,ctx,
                              dimensions=dimensions,source_dualities=dualities):
            examined+=1
            if row_allowed(p,mi,assignment,kind,ctx,parity,row,level):yield row
    def source_exists(d,sd,threshold=0,central=None):
        if d<3 or d>(72 if sd else 51):return False
        key=d,sd,threshold,central
        if key not in cache:
            good=False
            for row in allowed_rows((d,),(sd,)):
                values=row[2]
                regular=d+sum((2 if i==mi else 1)*s for i,(s,t)in enumerate(values))
                if regular<threshold:continue
                s,t=values[mi]
                if central=='single'and(s%2 or 2*t!=s*s):continue
                if central=='pair_sum'and(t%2 or t//2 not in determinant_options(p,d,values,sd,kind,ctx)[1]):continue
                good=True;break
            cache[key]=good
        return cache[key]
    def coin_exists(c,selfdual,m,central=False):
        if source_exists(c,True,m,'single'if central else None):return True
        if selfdual:
            return c%2==0 and source_exists(c//2,False,m,'pair_sum'if central else None)
        return source_exists(c,False,m,'single'if central else None)
    requirements=set(canonical_requirements(assignment,case['double_degree']))
    ck=cert['kind']
    if ck=='bounded_canonical_remainder':
        R=cert['remainder'];assert any(r==R for r,a,m,sd in requirements)
        assert cert['dimension_bound']==min(R,72)
        ds=set(cert['eligible_dimensions']);assert all(type(d)is int and 3<=d<=min(R,72)for d in ds)
        assert not semigroup(R,ds)
        for d in range(3,min(R,72)+1):
            if d not in ds:assert not source_exists(d,True)and not source_exists(d,False),(record['state'],d)
    elif ck=='source_dimension_density':
        assert cert['dimension_bound']==19 and cert['nonunit_count']==14
        assert cert['minimum_forced_dimension']==20 and not cert['eligible_dimensions']
        assert 14*20**2>5399
        for d in range(3,20):assert not source_exists(d,True)and not source_exists(d,False)
    elif ck in('canonical_remainder_with_duality','central_canonical_atom'):
        R=cert['remainder'];a=cert['canonical_degree'];m=cert['multiplicity'];sd=cert['canonical_selfdual']
        assert(R,a,m,sd)in requirements and cert['regular_trace_minimum']==m
        bound=min(R,102 if sd else 72);assert cert['contribution_bound']==bound
        ds=set(cert['eligible_contributions']);assert all(type(c)is int and 3<=c<=bound for c in ds)
        if ck=='canonical_remainder_with_duality':
            assert not semigroup(R,ds)
            for c in range(3,bound+1):
                if c not in ds:assert not coin_exists(c,sd,m),(record['state'],c)
        else:
            minimum=cert['minimum_contribution'];assert ds and minimum==min(ds)and R<2*minimum
            for c in range(3,minimum):assert not coin_exists(c,sd,m),(record['state'],c)
            assert not coin_exists(R,sd,m,True),(record['state'],'central atom')
    elif ck=='duality_dimension_minimum':
        b=assignment['q']+(3 if kind=='symplectic'else 1);s=14-2*b
        u=cert['selfdual_lower_bound'];v=cert['pair_lower_bound']
        assert type(u)is int and type(v)is int and u>=3 and v>=3
        assert cert['source_pairs']==b and s>0 and b>0
        assert s*u*u+2*b*v*v==cert['nonunit_dimension_square_lower_bound']>5399
        for d in range(3,u):assert not source_exists(d,True)
        for d in range(3,v):assert not source_exists(d,False)
    elif ck=='duality_parity_minimum':
        b=assignment['q']+(3 if kind=='symplectic'else 1);s=14-2*b
        uo=cert['odd_selfdual_lower_bound'];ue=cert['even_selfdual_lower_bound'];v=cert['pair_lower_bound']
        assert all(type(x)is int for x in(uo,ue,v))and uo>=3 and uo%2==1 and ue>=4 and ue%2==0 and v>=3
        assert cert['source_pairs']==b and s>0 and s%2==0
        mass=min(j*uo*uo+(s-j)*ue*ue+2*b*v*v for j in range(1,s,2))
        assert mass==cert['nonunit_dimension_square_lower_bound']>5399
        for d in range(3,uo,2):assert not source_exists(d,True)
        for d in range(4,ue,2):assert not source_exists(d,True)
        for d in range(3,v):assert not source_exists(d,False)
    elif ck=='duality_dimension_squares':
        ds=set(cert['eligible_selfdual']);dp=set(cert['eligible_pair'])
        assert all(type(d)is int and 3<=d<=72 for d in ds)
        assert all(type(d)is int and 3<=d<=51 for d in dp)
        for d in range(3,73):
            if d not in ds:assert not source_exists(d,True)
        for d in range(3,52):
            if d not in dp:assert not source_exists(d,False)
        b=assignment['q']+(3 if kind=='symplectic'else 1)
        if 'source_pairs'in cert:assert cert['source_pairs']==b
        reachable={0}
        for count,choices,factor in((14-2*b,ds,1),(b,dp,2)):
            for _ in range(count):
                reachable={x+factor*d*d for x in reachable for d in choices if x+factor*d*d<=5399}
        assert 5399 not in reachable
    else:
        rows=list(allowed_rows(range(3,73)))
        target,vectors=coupled_moments(p,mi,rows,assignment['q'],kind)
        if ck=='empty':assert not vectors
        elif ck=='integer_separator':
            z=cert['coefficients'];assert all(type(x)is int for x in z)
            assert dot(z,target)==cert['target_value']<0
            assert all(dot(z,v)>=0 for v in vectors)
        elif ck=='canonical_support_separator':
            cuts=cert['cuts'];z=cert['separator']['coefficients'];base=len(target)
            assert all(type(x)is int for x in z)and len(z)==base+len(cuts)
            assert all(x<=0 for x in z[base:]) # the nonnegative slack variables
            for c in cuts:
                R=c['remainder'];a=c['canonical_degree'];m=c['multiplicity'];sd=c['canonical_selfdual']
                assert(R,a,m,sd)in requirements
                outside=set()
                for yes,d,values in rows:
                    regular=d+sum((2 if i==mi else 1)*s for i,(s,t)in enumerate(values))
                    coin=d*(2 if sd and not yes else 1)
                    if regular>=m and coin not in c['contributions']:outside.add(coin)
                assert not semigroup(R,outside)
            for yes,d,values in rows:
                v=row_moment_vector(d,values)
                v=((1,0)+v)if yes else((0,1)+tuple(2*x for x in v))
                regular=d+sum((2 if i==mi else 1)*s for i,(s,t)in enumerate(values))
                extra=tuple(int(regular>=c['multiplicity']and
                    d*(2 if c['canonical_selfdual']and not yes else 1)in c['contributions'])for c in cuts)
                assert dot(z,v+extra)>=0
            augmented=tuple(target)+(1,)*len(cuts)
            assert dot(z,augmented)==cert['separator']['target_value']<0
        else:raise AssertionError(('unknown certificate',ck))
    return examined

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--certificates',type=Path,default=HERE/'rank15_certificates.jsonl')
    ap.add_argument('--state-start',type=int,default=0);ap.add_argument('--state-stop',type=int,default=125545)
    ap.add_argument('--profile-start',type=int,default=0);ap.add_argument('--profile-stop',type=int,default=62776)
    ap.add_argument('--skip-trace-replay',action='store_true');ap.add_argument('--coverage-only',action='store_true')
    ap.add_argument('--allow-partial',action='store_true');ap.add_argument('--require-closed',action='store_true')
    ap.add_argument('--ledger',type=Path);ap.add_argument('--output',type=Path)
    ap.add_argument('--resume',action='store_true')
    args=ap.parse_args();start=time.monotonic();profiles=list(degree_profiles(left=12))
    assert len(profiles)==62776 and[list(p)for p in profiles]==json.loads((HERE/'profiles.json').read_text())
    placements=[(i,a)for i,p in enumerate(profiles)for a,n in Counter(p).items()if n>=2]
    assert len(placements)==143657
    records={}
    with args.certificates.open()as inp:
        for line in inp:
            r=json.loads(line);assert r['state']not in records;records[r['state']]=r
    if not args.allow_partial:assert set(records)==set(range(125545))
    else:assert set(records)<=set(range(125545))
    proof=proof_digest();counts=Counter();hist=Counter();ordinal=0;replayed=examined=0
    ledger=args.ledger or HERE/f'row_replay15_{args.state_start}_{args.state_stop}.jsonl'
    already=set()
    if args.resume and ledger.exists():
        for line in ledger.read_text().splitlines():
            entry=json.loads(line);i=entry['state']
            assert i not in already and i in records
            assert args.state_start<=i<args.state_stop and records[i]['certificate']is not None
            assert entry['status']=='PASS'and entry['proof_sha256']==proof
            assert entry['certificate_sha256']==digest(records[i])
            already.add(i);examined+=entry['raw_rows_examined']
        replayed=len(already)
    with ledger.open('a'if args.resume else'w')as log,(HERE/'rank15_trace_final.jsonl').open()as inp:
      for position,line in enumerate(inp):
        case=json.loads(line);i,a=placements[position]
        assert(case['index'],case['double_degree'])==(i,a)and case['profile']==list(profiles[i])
        if not args.skip_trace_replay and args.profile_start<=i<args.profile_stop:
            regenerated=trace_analyze(profiles[i],a)
            assert all(case[k]==v for k,v in regenerated.items()),(i,a)
            counts['trace_placements_replayed']+=1
        counts['placements']+=1;counts['trace_excluded_placements']+=case['excluded']
        if counts['placements']%10000==0:
            print('placement coverage',counts['placements'],'trace replays',counts['trace_placements_replayed'],
                  'row replays',replayed,'seconds',round(time.monotonic()-start,2),flush=True)
        if case['excluded']:continue
        for ai,assignment in enumerate(case['surviving_assignments']):
          for kind in assignment['duality_types']:
            counts['field_duality_states']+=1
            if ordinal in records:
                r=records[ordinal]
                assert(r['index'],r['double_degree'],r['assignment_index'],r['kind'])==(i,a,ai,kind)
                cert=r['certificate'];hist[cert['kind']if cert else'OPEN']+=1
                if cert is None:
                    assert not args.require_closed,('OPEN state',ordinal)
                elif not args.coverage_only and args.state_start<=ordinal<args.state_stop and ordinal not in already:
                    nr=replay(r,case,assignment);examined+=nr;replayed+=1
                    log.write(json.dumps({'state':ordinal,'status':'PASS','proof_sha256':proof,
                              'certificate_sha256':digest(r),'raw_rows_examined':nr},separators=(',',':'))+'\n');log.flush()
            ordinal+=1
    assert counts['placements']==143657 and ordinal==125545
    assert proof==proof_digest(),'Proof files changed during exact replay.'
    report={'status':'PASS','scope':'necessary-data checkpoint; OPEN states are not exclusions',
            'counts':dict(counts),'certificate_records':len(records),'certificate_histogram':dict(hist),
            'closed_records_replayed':replayed,'raw_rows_examined':examined,
            'coverage_only':args.coverage_only,'skip_trace_replay':args.skip_trace_replay,
            'partial_coverage':args.allow_partial,'proof_sha256':proof,'resumed_records':len(already),
            'seconds':time.monotonic()-start}
    path=args.output or HERE/'rank15_verification.json';path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
