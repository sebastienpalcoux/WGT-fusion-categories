#!/usr/bin/env python3
"""Independent direct-quaternion audit of the new row invariants and local gates."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json,time
from matrix_spectral_filter import ramification,allowed_determinants
import r32_trace_forms as forms
HERE=Path(__file__).resolve().parent

def multiply(x,y,a,b):
    x0,x1,x2,x3=x;y0,y1,y2,y3=y
    return (x0*y0+a*x1*y1+b*x2*y2-a*b*x3*y3,
            x0*y1+x1*y0+b*(x3*y2-x2*y3),
            x0*y2+x2*y0+a*(x1*y3-x3*y1),
            x0*y3+x3*y0+x1*y2-x2*y1)

def main():
    start=time.monotonic();orth=classes=symp=scalar=0
    grid=tuple(Q(j,2)for j in range(-2,3))
    for delta,c in product((1,2,3,5,6,10,15,30),range(1,8)):
        a,b=-delta,c;ram=ramification(a,b)
        ctx=('orthogonal',9*delta,delta,(ram,),(0,delta,4*delta,9*delta))
        # Selfdual labels are not among the b dual-pair positions. In
        # particular unit and zero always have K=0, even if a pair cannot.
        ctx_nonzero=('orthogonal',delta,delta,(ram,),(delta,))
        assert 1 in allowed_determinants(2,2,True,ctx_nonzero)
        assert 0 in allowed_determinants(0,0,True,ctx_nonzero)
        scalar+=2
        for x in product(grid,repeat=4):
            dual=(x[0],-x[1],x[2],x[3]);conjugate=(x[0],-x[1],-x[2],-x[3])
            norm=multiply(x,conjugate,a,b);assert not any(norm[1:])
            s=2*x[0];t=2*multiply(x,dual,a,b)[0];n=norm[0]
            if any(z.denominator!=1 for z in(s,t,n)):continue
            s,t,n=map(int,(s,t,n));J=t-2*n;K=t-s*s+2*n
            assert J==4*c*(x[2]**2+delta*x[3]**2)
            assert K==4*delta*x[1]**2
            sd=x[1]==0
            assert n in allowed_determinants(s,t,sd,ctx),(delta,c,x,s,t,n,J,K)
            orth+=1
            if J:
                assert ramification(-delta,J)==ram
                classes+=1
    for a,b in[(-1,-1),(-1,-3),(-2,-5),(-3,-10)]:
        ram=ramification(a,b);ctx=('symplectic',5400,None,(ram,),())
        for x in product(grid,repeat=4):
            dual=(x[0],-x[1],-x[2],-x[3]);norm=multiply(x,dual,a,b)
            assert not any(norm[1:]);s=2*x[0];t=2*norm[0];n=norm[0]
            if any(z.denominator!=1 for z in(s,t,n)):continue
            s,t,n=map(int,(s,t,n));sd=not any(x[1:]);disc=s*s-4*n
            assert n in allowed_determinants(s,t,sd,ctx)
            if disc:assert all(not forms.locally_square(disc,p)for p in ram)
            else:assert sd
            symp+=1
    result={'status':'PASS','orthogonal_integral_spectral_triples':orth,
            'quaternion_class_identities':classes,'symplectic_integral_triples':symp,
            'selfdual_vs_pair_zero_checks':scalar,'seconds':time.monotonic()-start,
            'scope':'Exact direct quaternion multiplication; not a categorification or endpoint enumeration.'}
    (HERE/'matrix_spectral_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
