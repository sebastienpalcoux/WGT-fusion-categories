#!/usr/bin/env python3
"""Run the complete portable rank-fifteen proof using only Python's stdlib.

This orchestration file is not a mathematical proof dependency: the invoked
checkers independently validate their inputs and the final coverage ledger.
"""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import argparse,subprocess,sys

HERE=Path(__file__).resolve().parent

def run(command,log):
    with log.open('w')as out:
        result=subprocess.run(command,cwd=HERE,stdout=out,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError('Exact replay failed; see '+str(log))
    return log

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--output-directory',type=Path,default=HERE/'replay_local')
    ap.add_argument('--resume',action='store_true')
    args=ap.parse_args();assert args.workers>=1
    out=args.output_directory.resolve();out.mkdir(parents=True,exist_ok=True)
    py=sys.executable;trace=out/'complete_trace_replay.json';jobs=[];ledgers=[]
    jobs.append(([py,str(HERE/'verify_trace15.py'),'--output',str(trace)],out/'trace_console.txt'))
    width=(125545+args.workers-1)//args.workers
    for start in range(0,125545,width):
        stop=min(125545,start+width);stem=f'rows_{start}_{stop}'
        ledger=out/(stem+'.jsonl');ledgers.append(ledger)
        command=[py,str(HERE/'verify_rank15.py'),'--certificates',str(HERE/'rank15_certificates.jsonl'),
                 '--require-closed','--skip-trace-replay','--state-start',str(start),
                 '--state-stop',str(stop),'--ledger',str(ledger),'--output',str(out/(stem+'_report.json'))]
        if args.resume:command.append('--resume')
        jobs.append((command,out/(stem+'_console.txt')))
    with ThreadPoolExecutor(max_workers=args.workers)as pool:
        pending=[pool.submit(run,command,log)for command,log in jobs]
        for future in as_completed(pending):print('PASS',future.result().name,flush=True)
    command=[py,str(HERE/'merge_rank15.py'),'--check',str(HERE/'rank15_certificates.jsonl'),
             '--ledgers',*map(str,ledgers),'--trace-report',str(trace),'--require-closed',
             '--report',str(out/'rank15_complete_verification.json')]
    run(command,out/'coverage_console.txt')
    print((out/'rank15_complete_verification.json').read_text())

if __name__=='__main__':main()
