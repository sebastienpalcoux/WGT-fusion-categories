"""Exact spectral and integral-skew restrictions for a rational degree-two block.

No unproved splitting assumption is made. A positive orthogonal component
has a rational skew generator U^2=-delta. Its basis-image skew Gram is
integral, rank one, and satisfies K^2=fK; hence delta|f and K_ii=delta*z_i^2.
For A=sI/2+V+W put J=t-2n and K=t-s^2+2n. If J>0 then B=(-delta,J).
In a symplectic (definite quaternion) block, a nonscalar image's quadratic
field must be nonsplit at every finite ramified prime.
"""
from functools import lru_cache
from fractions import Fraction as Q
from math import gcd,prod
import generic_fields as fields
import r32_trace_forms as forms
from trace_rank15 import orthogonal_forms,skew_diagonal_values
from gap_filter import row_determinants

@lru_cache(None)
def ramification(a,b):
    assert a and b
    primes={2}|forms.prime_factors(a)|forms.prime_factors(b)
    return tuple(p for p in sorted(primes) if forms.hilbert(a,b,p)==-1)


def degree(label):
    if label=='Q':return 1
    if label=='Q(sqrt(-3))'or label.startswith('quadratic_disc='):return 2
    if label=='real_cubic_conductor9':return 3
    cc,hh=label.split(':H=')
    return forms.phi(int(cc[4:]))//len(hh.split(','))


def context(assignment,matrix_degree,kind):
    pieces=[];minus=[]
    for block in assignment['fields']:
        f=block['formal_codegree'];labels=block['fields']
        k=sum(degree(label)for label in labels)
        records={r[0]:r for r in fields.fields(f,k)}
        for label in labels:
            r=records[label]
            pieces.extend(a/f for a in r[1]);minus.extend(a/f for a in r[3])
    whole=(Q(1,5400),)+tuple(pieces);f=5400//matrix_degree;q=assignment['q']
    if kind=='orthogonal':
        b=q+1;delta=forms.squareclass(Q(f,2)*Q(2)**b/prod(minus))
        assert delta==assignment['orthogonal_delta']
        if f==6:
            candidates=[(6,2,1),(3,1,2),(3,2,2),(2,1,3),(1,1,3),(1,6,3)]
            allowed={ramification(-d,c) for d,c,count in candidates
                     if delta==d and count<=b and forms.isometric(
                         whole+tuple(Q(a,3)for a in(1,d,c,d*c)),[1]*15)}
        else:
            targets=[ram for ram in((),(2,3),(2,5),(3,5))
                     if all(f%p==0 and not forms.locally_square(-delta,p)for p in ram)]
            allowed={ram for ram,diag in zip(targets,orthogonal_forms(delta,f))
                     if forms.isometric(whole+diag,[1]*15)}
        assert allowed
        diagonals=skew_diagonal_values(delta,f,b)
        assert list(diagonals)==assignment['orthogonal_skew_diagonals']
        return (kind,f,delta,tuple(sorted(allowed)),diagonals)
    assert kind=='symplectic'
    if f==6:allowed={(3,)}
    else:
        possibilities=[((2,),(1,1,1,1)),((3,),(1,1,3,3)),
                       ((5,),(1,2,5,10)),((2,3,5),(1,3,10,30))]
        allowed={ram for ram,diag in possibilities
                 if all(f%p==0 for p in ram)and forms.isometric(
                     whole+tuple(Q(2*a,f)for a in diag),[1]*15)}
    assert allowed
    return(kind,f,None,tuple(sorted(allowed)),())

@lru_cache(None)
def allowed_determinants(s,t,sd,ctx):
    kind,f,delta,classes,diagonals=ctx
    if sd:
        if(s*s-t)%2:return ()
        candidates=((s*s-t)//2,)
    elif kind=='symplectic':
        if t%2:return ()
        candidates=(t//2,)
    else:candidates=range(-(t//2),t//2+1)
    result=[]
    for n in candidates:
        if 2*abs(n)>t:continue
        if kind=='orthogonal':
            K=t-s*s+2*n;J=t-2*n
            if J<0 or (sd and K!=0) or (not sd and K not in diagonals):continue
            if J and ramification(-delta,J)not in classes:continue
        else:
            discriminant=s*s-4*n
            if discriminant>0:continue
            if discriminant==0:
                if s%2 or t!=s*s//2:continue
            elif not any(all(not forms.locally_square(discriminant,p)for p in ram)
                         for ram in classes):continue
        result.append(n)
    return tuple(result)


def admissible_determinants(pieces,d,values,sd,kind,ctx):
    mi=next(i for i,p in enumerate(pieces)if p[2]=='matrix')
    s,t=values[mi]
    permitted=allowed_determinants(s,t,sd,ctx)
    if not permitted:return ()
    old=row_determinants(pieces,d,values,sd,kind)
    return permitted if old is None else tuple(n for n in permitted if n in old)
