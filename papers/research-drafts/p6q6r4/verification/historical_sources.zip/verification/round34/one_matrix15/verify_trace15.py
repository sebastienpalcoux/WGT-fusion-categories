#!/usr/bin/env python3
"""Independent complete exact replay of all rank-fifteen M2 placements.

The dedicated digest covers only this checker and its mathematical import
closure, so unrelated row-proof edits cannot invalidate this trace replay.
"""
from collections import Counter
from pathlib import Path
import argparse,hashlib,json,time
from endpoint_core import degree_profiles
from trace_rank15 import analyze

HERE=Path(__file__).resolve().parent
TRACE_FILES=('verify_trace15.py','endpoint_core.py','trace_rank15.py',
             'generic_fields.py','r32_trace_forms.py')

def trace_digest():
    h=hashlib.sha256()
    for name in sorted(TRACE_FILES):
        h.update(name.encode()+b'\0'+(HERE/name).read_bytes()+b'\0')
    return h.hexdigest()

def input_digests():
    return {name:hashlib.sha256((HERE/name).read_bytes()).hexdigest()
            for name in ('profiles.json','rank15_trace_final.jsonl')}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'complete_trace_replay.json')
    args=ap.parse_args();start=time.monotonic();proof=trace_digest();inputs=input_digests()
    profiles=list(degree_profiles(left=12))
    assert len(profiles)==62776
    assert [list(p)for p in profiles]==json.loads((HERE/'profiles.json').read_text())
    counts=Counter();reasons=Counter();duality=Counter();placement_iter=iter(
        (i,a)for i,p in enumerate(profiles)for a,n in Counter(p).items()if n>=2)
    with(HERE/'rank15_trace_final.jsonl').open()as inp:
        for line in inp:
            i,a=next(placement_iter);case=json.loads(line)
            assert (case['index'],case['double_degree'])==(i,a)
            assert case['profile']==list(profiles[i])
            answer=analyze(profiles[i],a)
            assert case==dict(answer,index=i,profile=list(profiles[i]),double_degree=a),(i,a)
            counts['placements']+=1;counts['excluded_placements']+=answer['excluded']
            counts['generated_field_assignments']+=answer['total_assignments']
            counts['determinant_compatible_assignments']+=answer['tested_assignments']
            counts['surviving_field_assignments']+=len(answer['surviving_assignments'])
            if answer['excluded']:reasons[answer.get('reason','full-field/trace')]+=1
            for assignment in answer['surviving_assignments']:
                for kind in assignment['duality_types']:
                    counts['field_duality_states']+=1;duality[kind]+=1
            if counts['placements']%10000==0:
                print('replayed',counts['placements'],'states',counts['field_duality_states'],
                      'seconds',round(time.monotonic()-start,2),flush=True)
    assert next(placement_iter,None)is None
    assert counts['placements']==143657 and counts['field_duality_states']==125545
    assert counts['excluded_placements']==109986
    assert proof==trace_digest()and inputs==input_digests(),'Inputs changed during replay.'
    report={'status':'PASS_COMPLETE_TRACE_REPLAY','profiles':62776,'counts':dict(counts),
            'exclusion_reasons':dict(reasons),'duality_types':dict(duality),
            'trace_proof_sha256':proof,'input_sha256':inputs,'seconds':time.monotonic()-start}
    args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
