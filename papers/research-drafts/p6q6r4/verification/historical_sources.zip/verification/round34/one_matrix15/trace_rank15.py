#!/usr/bin/env python3
"""Exact full-field and rational trace-form scan of C^11 + M2(C).

Rank15 uses source and canonical parity to retain q<=4 orthogonal and
q<=3 symplectic. The integral rank-one skew lattice additionally forces
delta|f and f/delta to be a sum of at most q+1 integer squares.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import product
from math import gcd,prod,isqrt
from pathlib import Path
from functools import lru_cache
import json,time,argparse
import generic_fields as fields
import r32_trace_forms as forms

HERE=Path(__file__).resolve().parent

def residue_pass(profile,double,assignment=None):
    c=Counter(profile);c[double]-=2
    entries=[(double,2,True)]
    if assignment is None:
        entries += [(a,1,k==1) for a,k in c.items() for _ in range(k)]
    else:
        for block in assignment:
            a=5400//block['formal_codegree']
            for label in block['fields']:
                if label=='Q':e=1
                elif label in('Q(sqrt(-3))',)or label.startswith('quadratic'):e=2
                elif label=='real_cubic_conductor9':e=3
                else:
                    cc,hh=label.split(':H=');e=forms.phi(int(cc[4:]))//len(hh.split(','))
                entries += [(a,1,label=='Q')]*e
    for i,(a,m,rat)in enumerate(entries):
        if not rat:continue
        r=a-m
        g=0
        for j,(b,n,_)in enumerate(entries):
            if j!=i:g=gcd(g,b*n)
        w=a*m
        if not any((r+w*mu)%g==0 for mu in range(-r+1,r)):
            return False,{'degree':a,'multiplicity':m,'remainder':r,'other_weight_gcd':g}
    return True,None

@lru_cache(None)
def orth_pass(whole,minus,q,f):
    b=q+1
    missing=Q(2)**b/prod(minus)
    if not forms.isometric(minus+(missing,),[2]*b):return False
    delta=forms.squareclass(Q(f,2)*missing)
    if f%delta or not square_sum_possible(f//delta,b):return False
    if f==6:
        candidates=[(6,2,1),(3,1,2),(3,2,2),(2,1,3),(1,1,3),(1,6,3)]
        return any(delta==d and count<=b and forms.isometric(whole+tuple(Q(a,3)for a in(1,d,B,d*B)),[1]*15)for d,B,count in candidates)
    candidates=orthogonal_forms(delta,f)
    return any(forms.isometric(whole+diag,[1]*15) for diag in candidates)

@lru_cache(None)
def orthogonal_forms(delta,f):
    targets=[ram for ram in ((),(2,3),(2,5),(3,5))
             if all(f%p==0 and not forms.locally_square(-delta,p) for p in ram)]
    found={}
    for c in range(1,1001):
        primes={2}|forms.prime_factors(delta)|forms.prime_factors(c)
        ram=tuple(p for p in sorted(primes) if forms.hilbert(-delta,c,p)==-1)
        if ram in targets and ram not in found:
            found[ram]=tuple(Q(2*a,f) for a in (1,delta,c,delta*c))
        if len(found)==len(targets):break
    assert set(found)==set(targets),(delta,f,targets,found)
    return tuple(found[ram] for ram in targets)

@lru_cache(None)
def trace_pass(whole,plus,minus,q,q6,f,kind):
    if kind=='orthogonal':
        if q>4 or q+1<2*q6:return False
        if q==q6==1 and f%2:return False
        if f==6 and q==q6==1:return False # R32 proof has no rank13-only step.
        return orth_pass(whole,minus,q,f)
    if q>3 or q+3<2*q6:return False
    if q==q6:
        if q==2:return False # Round33: this would require16|f, impossible for f|5400.
        if q==0 and f not in(36,100):return False
        if q==1 and f not in(8,72):return False
    b=q+3
    if not forms.isometric(plus+(Q(2,f),),[1]*(15-2*b)+[2]*b):return False
    if f==6:
        if q not in(2,3)or q6:return False
        return forms.isometric(whole+(Q(1,3),Q(1),Q(1,3),Q(1)),[1]*15)
    possibilities=[((2,),(1,1,1,1)),((3,),(1,1,3,3)),((5,),(1,2,5,10)),((2,3,5),(1,3,10,30))]
    return any(all(f%p==0 for p in ram) and forms.isometric(whole+tuple(Q(2*a,f) for a in diag),[1]*15) for ram,diag in possibilities)

@lru_cache(None)
def square_sum_possible(total,count):
    """At most count positive squares, equivalently count nonnegative squares."""
    reachable=1;mask=(1<<(total+1))-1
    squares=[j*j for j in range(isqrt(total)+1)]
    for _ in range(count):
        new=0
        for x in squares:new|=reachable<<x
        reachable=new&mask
    return bool((reachable>>total)&1)

@lru_cache(None)
def skew_diagonal_values(delta,f,b):
    assert f%delta==0
    total=f//delta
    return tuple(delta*j*j for j in range(isqrt(total)+1)
                 if square_sum_possible(total-j*j,b-1))


def rational_counts(profile,double,assignment=None):
    c=Counter(profile);c[double]-=2
    if assignment is None:return tuple((a,1)for a,k in sorted(c.items())if k==1)
    return tuple((5400//block['formal_codegree'],block['fields'].count('Q'))
                 for block in assignment if block['fields'].count('Q'))


def valuation(a,p):
    n=0
    while a%p==0:a//=p;n+=1
    return n


def forced_modulus(a,b,M):
    result=1
    for p in(2,3,5):
        k=valuation(M,p)
        if k:
            alpha=valuation(a,p);beta=valuation(b,p)
            result*=p**min(k,beta+(max(0,k-alpha-beta)+1)//2)
    return result

@lru_cache(None)
def pair_modulus_pass(profile,double,rationals):
    counts=Counter(profile);counts[double]-=2
    rational=dict(rationals);degrees=sorted(a for a,n in rationals if n)
    for i,a in enumerate(degrees):
        for b in degrees[i:]:
            if a==b and rational[a]<2:continue
            M=gcd(5400,double)
            for c,n in counts.items():
                if n-(c==a)-(c==b)>0:M=gcd(M,c)
            if M<=1:continue
            for x,y in((a,b),(b,a)):
                Qxy=forced_modulus(x,y,M)
                if Qxy>=2*(x-1):
                    return False,{'a':x,'b':y,'M':M,'forced_modulus':Qxy,'remainder':x-1}
    return True,None


def analyze(profile,double):
    if double==10:return{'excluded':True,'reason':'rational central degree10','total_assignments':0,'tested_assignments':0,'surviving_assignments':[]}
    ok,why=residue_pass(profile,double)
    if not ok:return{'excluded':True,'reason':'rational residue','residue_obstruction':why,'total_assignments':0,'tested_assignments':0,'surviving_assignments':[]}
    ok,why=pair_modulus_pass(profile,double,rational_counts(profile,double))
    if not ok:return{'excluded':True,'reason':'two-rational canonical modulus','modulus_obstruction':why,'total_assignments':0,'tested_assignments':0,'surviving_assignments':[]}
    counts=Counter(profile);counts[double]-=2
    blocks=[(5400//a,k)for a,k in counts.items()if k]
    alternatives=[fields.decompositions(f,k)for f,k in blocks]
    total=tested=0;kept=[];fE=5400//double
    for assignment in product(*alternatives):
        total+=1;q6=sum(x[4]for x in assignment);q=sum(len(x[3])for x in assignment)
        assert q<=4,(profile,double,assignment,q) # even canonical mass forbids q=5
        if q6>2:continue
        whole=(Q(1,5400),)+tuple(a for x in assignment for a in x[1])
        if forms.squareclass(prod(whole))!=1:continue
        plus=(Q(1,5400),)+tuple(a for x in assignment for a in x[2]);minus=tuple(a for x in assignment for a in x[3])
        tested+=1
        descriptions=[{'formal_codegree':f,'fields':list(x[0])}for(f,k),x in zip(blocks,assignment)]
        ok,_=residue_pass(profile,double,descriptions)
        if not ok:continue
        ok,_=pair_modulus_pass(profile,double,rational_counts(profile,double,descriptions))
        if not ok:continue
        kinds=[kind for kind in('orthogonal','symplectic')if trace_pass(whole,plus,minus,q,q6,fE,kind)]
        # The rank-independent two-pair parity gate applies only with precisely
        # the listed second nonreal field. No other rank13 hypothesis enters.
        if q==2 and q6==1 and any(block['formal_codegree']==8 and 'quadratic_disc=-8' in block['fields'] for block in descriptions):
            if fE%2 or fE==6:kinds=[kind for kind in kinds if kind!='orthogonal']
        if kinds:
            item={'fields':descriptions,'q6':q6,'q':q,'duality_types':kinds}
            if 'orthogonal' in kinds:
                b=q+1;missing=Q(2)**b/prod(minus)
                delta=forms.squareclass(Q(fE,2)*missing)
                item['orthogonal_delta']=delta
                item['orthogonal_skew_diagonals']=list(skew_diagonal_values(delta,fE,b))
            kept.append(item)
    return{'excluded':not kept,'total_assignments':total,'tested_assignments':tested,'surviving_assignments':kept}

def main():
    p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=0);p.add_argument('--end',type=int);p.add_argument('--output',type=Path,default=HERE/'rank15_trace.jsonl');args=p.parse_args()
    profiles=json.loads((HERE/'profiles.json').read_text());end=args.end or len(profiles);start=time.time();counts=Counter()
    with args.output.open('w')as out:
        for index in range(args.start,end):
            profile=profiles[index]
            for double,k in Counter(profile).items():
                if k<2:continue
                r=analyze(tuple(profile),double);r.update({'index':index,'profile':profile,'double_degree':double});out.write(json.dumps(r)+'\n');out.flush();counts['placements']+=1;counts['excluded']+=r['excluded'];counts['assignments']+=len(r['surviving_assignments']);counts['field_duality_states']+=sum(len(a['duality_types'])for a in r['surviving_assignments'])
            if index%250==0:print(index,dict(counts),'seconds',round(time.time()-start,2),flush=True)
    print('FINAL',dict(counts),'seconds',round(time.time()-start,2),flush=True)

if __name__=='__main__':main()
