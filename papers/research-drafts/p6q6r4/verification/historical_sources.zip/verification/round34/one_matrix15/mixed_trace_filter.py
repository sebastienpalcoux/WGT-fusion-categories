"""Exact necessary mixed coefficient traces for a single source simple.

One scalar-value multiset and one matrix determinant must work simultaneously.
Unknown higher fields are retained. Mixed positivity is only checked finitely.
"""
from functools import lru_cache
from itertools import product
from gap_filter import row_determinants
from power_trace_filter import scalar_power_options,quadratic_powers

def field_reality(piece):
    a,k,label=piece
    if label in('Q','rational6','rational_group'):return True
    if label=='complex6':return False
    if label.startswith('quadratic_disc='):return int(label.split('=')[1])>0
    if label.startswith('zeta'):
        from orbit_pairs import phi,quadratic_discriminants
        from field_discriminant_profiles import kronecker
        cc,hh=label.split(':H=');c=int(cc[4:]);h=tuple(map(int,hh.split(',')));e=phi(c)//len(h)
        if e==1:return True
        if e==2:
            ds=[D for D in quadratic_discriminants(c)if all(kronecker(D,z)==1 for z in h)]
            assert len(ds)==1;return ds[0]>0
    return None

@lru_cache(None)
def scalar_mixed_options(piece,value,sd,d,bound):
    a,k,label=piece;s,t=value;real=field_reality(piece)
    if real is None:return None
    pairs=tuple((i,j)for i in range(bound+1)for j in range(i+1))
    if real or sd:
        opts=scalar_power_options(piece,value,2*bound,sd,d)
        if opts is None:return None
        return tuple(tuple(v[i+j]for i,j in pairs)for v in opts)
    if label=='complex6'and k==4:
        if not t:return(tuple(4 if i+j==0 else 0 for i,j in pairs),)
        assert t==2 and abs(s)==1
        v=quadratic_powers(s,1,2*bound)
        return(tuple(4 if i+j==0 else v[i-j]for i,j in pairs),)
    assert k==2,(piece,value)
    n=t//2;assert t%2==0
    v=quadratic_powers(s,n,2*bound)
    return(tuple(n**j*v[i-j]for i,j in pairs),)

@lru_cache(maxsize=32768)
def matrix_mixed(s,t,n,bound):
    uv=[(0,1)]
    for _ in range(bound):
        u,v=uv[-1];uv.append((s*u+v,-n*u))
    return tuple(uv[i][0]*uv[j][0]*t+(uv[i][0]*uv[j][1]+uv[i][1]*uv[j][0])*s+2*uv[i][1]*uv[j][1]for i in range(bound+1)for j in range(i+1))

def mixed_trace_possible(pieces,d,values,sd,kind,bound=12,matrix_context=None):
    matrix=next((i for i,p in enumerate(pieces)if p[2]=='matrix'),None)
    choices=[];weights=[];regular_weights=[]
    for i,(p,v)in enumerate(zip(pieces,values)):
        if i==matrix:continue
        opts=scalar_mixed_options(tuple(p),tuple(v),sd,d,bound)
        if opts is None:return True
        if not opts:return False
        choices.append(opts);weights.append(p[0]);regular_weights.append(1)
    if matrix is not None:
        s,t=values[matrix];dets=row_determinants(pieces,d,values,sd,kind)
        if dets is None:
            if sd:
                if(s*s-t)%2:return False
                dets=((s*s-t)//2,)
            elif kind=='symplectic':
                if t%2:return False
                dets=(t//2,)
            else:dets=range(-(t//2),t//2+1)
        dets=[n for n in dets if 2*abs(n)<=t and(kind!='orthogonal'or 2*n>=s*s-t)]
        if matrix_context is not None:
            from matrix_spectral_filter import allowed_determinants
            permitted=allowed_determinants(s,t,sd,matrix_context)
            dets=[n for n in dets if n in permitted]
        choices.append(tuple(matrix_mixed(s,t,n,bound)for n in dets));weights.append(pieces[matrix][0]);regular_weights.append(2)
    pairs=tuple((i,j)for i in range(bound+1)for j in range(i+1));base=tuple(d**(i+j)for i,j in pairs)
    for selected in product(*choices):
        ok=True
        for idx,((i,j),v)in enumerate(zip(pairs,base)):
            z=v+sum(a*x[idx]for a,x in zip(weights,selected))
            if z<0 or z%5400:ok=False;break
            regular=v+sum(m*x[idx]for m,x in zip(regular_weights,selected))
            if 5400*regular<15*z:ok=False;break
        if ok:return True
    return False
