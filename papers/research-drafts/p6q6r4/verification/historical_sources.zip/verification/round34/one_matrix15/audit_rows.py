#!/usr/bin/env python3
"""Exact comparisons of independent recursion and moment-tail row paths."""
from pathlib import Path
import json,time
import fixed_field_rows as current
import fixed_field_rows_pre_mitm as reference
from bounded_remainder import states,HERE,row_allowed,parity_index
from matrix_spectral_filter import context

def main():
    chosen={0,8,36,75,517,585,646,649,31507,31508,31512,62780}
    extra={};catalog={}
    for ordinal,c,ai,a,kind in states(HERE/'rank15_trace_final.jsonl'):
        labels=[label for b in a['fields']for label in b['fields']]
        feature=[]
        if any(x.startswith('zeta25:')for x in labels):feature.append('quintic25')
        if any(x.startswith('zeta36:')for x in labels):feature.append('sextic36')
        if any(x.startswith('zeta9:')for x in labels):feature.append('sextic9')
        if any(x.startswith('zeta240:')for x in labels):feature.append('ambient240')
        if a['q']==4:feature.append('q4')
        if kind=='symplectic'and a['q']==3:feature.append('symplectic_q3')
        for f in feature:
            if f not in extra:extra[f]=ordinal;chosen.add(ordinal)
        if ordinal in chosen:catalog[ordinal]=(c,ai,a,kind)
    # A newly selected ordinal is always stored at its first encounter.
    assert chosen<=set(catalog)
    t0=time.monotonic();before_total=after_total=0;records=[]
    for ordinal in sorted(chosen):
        c,ai,a,kind=catalog[ordinal];p,mi=current.fixed_blocks(a,c['double_degree'])
        ctx=context(a,c['double_degree'],kind);parity=parity_index(a,p,kind)
        dims=range(3,11)
        old=list(reference.fixed_rows(p,mi,a['q6'],a['q'],kind,ctx,dimensions=dims))
        new=list(current.fixed_rows(p,mi,a['q6'],a['q'],kind,ctx,dimensions=dims))
        plain=list(current.fixed_rows(p,mi,a['q6'],a['q'],kind,ctx,
                                      dimensions=dims,square_budget=False))
        predicate=lambda r:row_allowed(p,mi,a,kind,ctx,parity,r,level=0)
        expected={r for r in old if predicate(r)}
        actual={r for r in new if predicate(r)}
        unsquared={r for r in plain if predicate(r)}
        assert expected==actual==unsquared,(ordinal,len(expected),len(actual),len(unsquared))
        assert len(new)==len(set(new)),ordinal
        for sd,d,values in new:
            assert d+sum(x[0]*v[0]for x,v in zip(p,values))==0
            assert d*d+sum(x[0]*v[1]for x,v in zip(p,values))==5400
            assert all(abs(s)<=t for s,t in values)and any(abs(s)<t for s,t in values)
        before_total+=len(old);after_total+=len(new)
        records.append({'state':ordinal,'reference_rows':len(old),
                        'optimized_rows':len(new),'common_admissible_rows':len(actual)})
    report={'status':'PASS','states':len(records),'dimension_range':[3,10],
            'feature_representatives':extra,'reference_rows':before_total,
            'optimized_rows':after_total,'records':records,
            'seconds':time.monotonic()-t0,
            'scope':'Exact equality after the same necessary predicate; not an endpoint proof.'}
    (HERE/'row_generator_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='records'},indent=2))
if __name__=='__main__':main()
