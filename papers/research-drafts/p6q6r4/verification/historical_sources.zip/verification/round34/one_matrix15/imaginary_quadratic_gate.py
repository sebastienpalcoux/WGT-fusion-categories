#!/usr/bin/env python3
"""Integral skew-column norm for a full imaginary quadratic linear field."""
from functools import lru_cache
from pathlib import Path
import json,time
from trace_rank15 import square_sum_possible

@lru_cache(None)
def full_discriminant(label):
    if label=='Q(sqrt(-3))':return -3
    if label.startswith('quadratic_disc='):
        return int(label.split('=')[1])
    if not label.startswith('zeta'):return None
    from orbit_pairs import phi,quadratic_discriminants
    from field_discriminant_profiles import kronecker
    cc,hh=label.split(':H=');c=int(cc[4:]);h=tuple(map(int,hh.split(',')))
    if phi(c)//len(h)!=2:return None
    ds=[D for D in quadratic_discriminants(c)if all(kronecker(D,x)==1 for x in h)]
    assert len(ds)==1
    return ds[0]

@lru_cache(None)
def discriminant(label):
    D=full_discriminant(label)
    return D if D is not None and D<0 else None

def obstruction(assignment,kind):
    b=assignment['q']+(3 if kind=='symplectic'else 1)
    for block in assignment['fields']:
        f=block['formal_codegree']
        for label in block['fields']:
            D=discriminant(label)
            if D is None:continue
            assert D<0
            if f%(-D):reason='nonintegral_skew_length'
            elif not square_sum_possible(f//(-D),b):reason='integer_square_sum'
            else:continue
            return {'kind':'imaginary_quadratic_skew_norm','formal_codegree':f,
                    'field':label,'discriminant':D,'source_pairs':b,'reason':reason}
    return None

def main():
    from bounded_remainder import states,HERE
    from collections import Counter
    start=time.monotonic();n=0;hist=Counter();duality=Counter()
    outpath=HERE/'imaginary_quadratic_exclusions.jsonl'
    with outpath.open('w')as out:
        for ordinal,case,ai,a,kind in states(HERE/'rank15_trace_final.jsonl'):
            cert=obstruction(a,kind)
            if cert is None:continue
            r={'state':ordinal,'index':case['index'],'double_degree':case['double_degree'],
               'assignment_index':ai,'kind':kind,'level':0,'phase':'integral_skew_column',
               'certificate':cert}
            out.write(json.dumps(r,separators=(',',':'))+'\n')
            n+=1;hist[cert['reason']]+=1;duality[kind]+=1
    report={'status':'COMPLETE_EXACT_STRUCTURAL_GATE','universe_states':125545,
            'excluded_states':n,'remaining_states':125545-n,
            'reasons':dict(hist),'duality_types':dict(duality),'seconds':time.monotonic()-start}
    (HERE/'imaginary_quadratic_gate_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
