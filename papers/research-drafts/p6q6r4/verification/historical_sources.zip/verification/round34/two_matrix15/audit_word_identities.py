"""Independently multiply 2x2 matrices to audit the word recurrences.

This is a supplementary exact arithmetic audit, not the exclusion proof.
It uses no numerical or third-party library.
"""
from itertools import product
from two_matrix_rows import add,scale,mul,conj,trace
from two_matrix_words import rational_words,quadratic_words

def matrices(field):
    z=(0,0);o=(1,0)
    def matmul(A,B):
        return tuple(tuple(add(mul(A[i][0],B[0][j],field),mul(A[i][1],B[1][j],field))for j in range(2))for i in range(2))
    def star(A):
        return tuple(tuple(conj(A[j][i],field)if field<0 else A[j][i]for j in range(2))for i in range(2))
    def tr(A):return add(A[0][0],A[1][1])
    def det(A):return add(mul(A[0][0],A[1][1],field),scale(mul(A[0][1],A[1][0],field),-1))
    I=((o,z),(z,o))
    return matmul,star,tr,det,I

def run():
    count=0;bound=7
    for D in (-4,-3,8,12):
        mm,star,tr,det,I=matrices(D)
        # Exhaust all 81 matrices on a fixed three-element integral set.
        # The third element has nontrivial quadratic coordinate.
        for entries in product(((0,0),(1,0),(-1,1)),repeat=4):
            A=(entries[:2],entries[2:]);B=star(A);C=mm(A,B)
            ps=[I];qs=[I];ns=[I]
            for k in range(2*bound):ps.append(mm(ps[-1],A));qs.append(mm(qs[-1],B))
            for k in range(bound):ns.append(mm(ns[-1],C))
            alpha,beta,gamma=tr(A),det(A),tr(C)
            got=quadratic_words(D,alpha,beta,gamma,bound)
            assert got[0]==tuple(trace(tr(M),D)for M in ps)
            assert got[1]==tuple(trace(tr(M),D)for M in ns)
            mixed=tuple(trace(tr(mm(ps[k],qs[l])),D)for k in range(bound+1)for l in range(k+1))
            assert got[2]==mixed
            assert got[3]==trace(tr(ns[2]),D)-trace(tr(mm(ps[2],qs[2])),D)
            count+=1
        # Rational matrices also check the separately coded rational path.
        for entries in product((-1,0,1),repeat=4):
            A=tuple(tuple((entries[2*i+j],0)for j in range(2))for i in range(2))
            B=star(A);C=mm(A,B);ps=[I];qs=[I];ns=[I]
            for k in range(2*bound):ps.append(mm(ps[-1],A));qs.append(mm(qs[-1],B))
            for k in range(bound):ns.append(mm(ns[-1],C))
            got=rational_words(tr(A)[0],tr(C)[0],det(A)[0],bound)
            assert got[0]==tuple(tr(M)[0]for M in ps)
            assert got[1]==tuple(tr(M)[0]for M in ns)
            assert got[2]==tuple(tr(mm(ps[k],qs[l]))[0]for k in range(bound+1)for l in range(k+1))
            assert got[3]==tr(ns[2])[0]-tr(mm(ps[2],qs[2]))[0]
            count+=1
    return {'status':'PASS','direct_matrix_cases':count,'power_degree':2*bound,'mixed_word_exponent_bound':bound}

if __name__=='__main__':
    import json
    print(json.dumps(run(),sort_keys=True))
