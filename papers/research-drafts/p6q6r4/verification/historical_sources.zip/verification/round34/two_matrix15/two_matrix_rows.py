"""Exact necessary source rows for C^7+M2+M2, including quadratic orbits."""
from collections import Counter
from functools import lru_cache
from fractions import Fraction as Q
from itertools import combinations,product
from math import gcd,isqrt
from fixed_field_rows import fixed_options
from orbit_pairs import phi
N=5400

# Integral quadratic arithmetic in the maximal order basis 1,w.
def field_constants(D):return(1,(1-D)//4)if D%4==1 else(0,-D//4)
def add(x,y):return(x[0]+y[0],x[1]+y[1])
def scale(x,n):return(x[0]*n,x[1]*n)
def mul(x,y,D):
    tr,n=field_constants(D);a,b=x;c,e=y
    return(a*c-n*b*e,a*e+b*c+tr*b*e)
def conj(x,D):
    tr,n=field_constants(D);a,b=x
    return(a+tr*b,-b)
def trace(x,D):return 2*x[0]+field_constants(D)[0]*x[1]
def norm(x,D):return mul(x,conj(x,D),D)[0]
def from_trace(s,b,D):
    if D%4==1:
        if(s-b)%2:return None
        return((s-b)//2,b)
    if s%2:return None
    return(s//2,b)
def totally_nonnegative(x,D):
    assert D>0
    s=trace(x,D);b=x[1]
    return s>=0 and s*s>=D*b*b

def positive_norm(x,D):
    if D<0:return 2*norm(x,D)
    return trace(mul(x,x,D),D)

@lru_cache(None)
def norm_box(D,cap):
    out=[]
    for b in range(-isqrt(max(0,2*cap//abs(D)))-1,isqrt(max(0,2*cap//abs(D)))+2):
        for s in range(-isqrt(max(0,2*cap))-1,isqrt(max(0,2*cap))+2):
            x=from_trace(s,b,D)
            if x is not None and positive_norm(x,D)<=cap:out.append(x)
    return tuple(out)

@lru_cache(None)
def quadratic_matrix_choices(f,D,kind,sd):
    """Map (Tr_K alpha,Tr_K gamma,b_alpha) to possible(alpha,beta,gamma).

    alpha=Tr(A), beta=det(A), gamma=Tr(AA*). Each is integral in K;
    gamma is rational for CM K. All retained inequalities are necessary.
    """
    out={};weight=1 if sd else 2
    for alpha in norm_box(D,2*(f-1)):
        s=trace(alpha,D);b=alpha[1];u=positive_norm(alpha,D)
        if sd and D<0 and b:continue
        if D<0 and b<0:continue # Choosing the other member of a source pair.
        if weight*s*s>4*f-16 or weight*u>4*f-8:continue
        if D<0:
            gammas=[(v,0)for v in range((f-1)//2+1)]
        else:
            gammas=[]
            for t in range(f):
                for bb in range(-isqrt(t*t//D)-1,isqrt(t*t//D)+2):
                    g=from_trace(t,bb,D)
                    if g is not None and totally_nonnegative(g,D):gammas.append(g)
        for gamma in gammas:
            t=trace(gamma,D)
            if 2*t<u or t>=f:continue
            if D>0 and not totally_nonnegative(add(scale(gamma,2),scale(mul(alpha,alpha,D),-1)),D):continue
            if D<0 and gamma[0]*2<norm(alpha,D):continue
            if sd:
                numerator=add(mul(alpha,alpha,D),scale(gamma,-1))
                if any(x%2 for x in numerator):continue
                betas=[tuple(x//2 for x in numerator)]
            elif kind=='S':
                if any(x%2 for x in gamma):continue
                betas=[tuple(x//2 for x in gamma)]
            else:
                cap=t*t//(8 if D<0 else 4)
                betas=norm_box(D,cap)
            for beta in betas:
                if D>0:
                    if not totally_nonnegative(add(gamma,scale(beta,-2)),D):continue
                    if not totally_nonnegative(add(gamma,scale(beta,2)),D):continue
                    if kind=='O' and not totally_nonnegative(add(add(gamma,scale(beta,2)),scale(mul(alpha,alpha,D),-1)),D):continue
                    if kind=='S':
                        if gamma!=scale(beta,2):continue
                        if sd:
                            if any(x%2 for x in alpha):continue
                            half=tuple(x//2 for x in alpha)
                            if beta!=mul(half,half,D):continue
                else:
                    if 4*norm(beta,D)>gamma[0]*gamma[0]:continue
                    if sd and beta[1]:continue
                    aa=mul(alpha,alpha,D)
                    F=gamma[0]**2-gamma[0]*norm(alpha,D)+trace(mul(aa,conj(beta,D),D),D)-4*norm(beta,D)
                    if F<0:continue
                out.setdefault((s,t,b),set()).add((alpha,beta,gamma))
    return {key:tuple(sorted(value))for key,value in out.items()}

def build_pieces(assignment,degrees,matrix):
    pieces=[]
    if matrix['field']=='Q+Q':
        pieces += [(a,2,'matrix'+kind)for a,kind in zip(degrees,matrix['kind'])]
    else:
        D=int(matrix['field'].split('=')[1]);assert degrees[0]==degrees[1]
        pieces.append((degrees[0],4,f'matrixquad:{D}:{matrix["kind"]}'))
    for block in assignment['fields']:
        f=block['formal_codegree'];a=N//f;labels=block['fields']
        rational=sum(label=='Q'for label in labels);q6=sum(label=='Q(sqrt(-3))'for label in labels)if f==6 else 0
        if rational:
            pieces.append((a,1,'rational6'if f==6 else'Q'))
            if rational>1:pieces.append((a,rational-1,'rational6'if f==6 else'rational_group'))
        if q6:pieces.append((a,2*q6,'complex6'))
        for label in labels:
            if label=='Q'or(f==6 and label=='Q(sqrt(-3))'):continue
            if label.startswith('quadratic'):e=2
            elif label=='real_cubic_conductor9':e=3
            else:
                c,h=label.split(':H=');e=phi(int(c[4:]))//len(h.split(','))
            pieces.append((a,e,label))
    pieces.sort(key=lambda x:(x[1]>1,-x[0],x[2]))
    assert sum(k for a,k,label in pieces)==10
    return tuple(pieces)

def pair_count(assignment,matrix):
    if matrix['field']=='Q+Q':return assignment['q']+sum(1 if k=='O'else 3 for k in matrix['kind'])
    return assignment['q']+{'O':2,'S':6,'U':4}[matrix['kind']]

@lru_cache(None)
def options(piece,d,sd,q6):
    a,k,label=piece;f=N//a;weight=1 if sd else 2
    cap=min((N-d*d)//a,k*d*d-1,f-1)
    if label.startswith('matrixquad:'):
        _,DD,kind=label.split(':');D=int(DD)
        return tuple(sorted((s,t,b)for s,t,b in quadratic_matrix_choices(f,D,kind,sd)
                            if t<=cap and abs(s)<k*d))
    if label.startswith('matrix'):
        kind='orthogonal'if label=='matrixO'else'symplectic'
        return tuple((s,t,0)for s,t in fixed_options((a,2,'matrix'),d,sd,kind,q6)
                     if weight*s*s<=2*f-4)
    return tuple((s,t,0)for s,t in fixed_options(piece,d,sd,'orthogonal',q6))


def rows_for(pieces,q6):
    for sd in (True,False):
      for d in range(3,73):
        choices=[sorted(options(p,d,sd,q6),key=lambda x:(x[1],x[0],x[2]))for p in pieces]
        if any(not c for c in choices):continue
        order=sorted(range(len(pieces)),key=lambda i:len(choices[i]));length=len(order)
        lookup=[set((s,t)for s,t,b in c)for c in choices]
        lastmaps=[{}for _ in pieces]
        for i,c in enumerate(choices):
            for s,t,b in c:lastmaps[i].setdefault((s,t),[]).append(b)
        selected=[None]*length;ss=[0]*(length+1);st=[0]*(length+1);sm=[0]*(length+1);sg=[[0]*4 for _ in range(length+1)]
        for h in reversed(range(length)):
            i=order[h];a,k,label=pieces[i]
            ss[h]=ss[h+1]+a*max(abs(s)for s,t,b in choices[i]);st[h]=st[h+1]+a*max(t for s,t,b in choices[i]);sm[h]=sm[h+1]+a*k
            gg=sg[h+1].copy()
            for s,t,b in choices[i]:
                for j,v in enumerate((a*s,a*t,a*(t-s),a*(t+s))):gg[j]=gcd(gg[j],v)
            sg[h]=gg
        def visit(h,linear,square):
            if square<0 or square>st[h]or abs(linear)>ss[h]or linear*linear>sm[h]*square:return
            # Every integral trace satisfies |s| <= 2t for these pieces.
            if abs(linear)>2*square:return
            for v,g in zip((linear,square,square-linear,square+linear),sg[h]):
                if(g and v%g)or(not g and v):return
            i=order[h];a,k,label=pieces[i]
            if h==length-1:
                if linear%a or square%a:return
                pair=linear//a,square//a
                for b in lastmaps[i].get(pair,()):
                    selected[i]=pair+(b,);yield(sd,d,tuple(selected))
                return
            for s,t,b in choices[i]:
                if a*t>square:break
                selected[i]=(s,t,b);yield from visit(h+1,linear-a*s,square-a*t)
        yield from visit(0,-d,N-d*d)


def moment_data(pieces,rows,b):
    target=[14-2*b,b,N-1]
    for a,k,label in pieces:
        f=N//a;degree2=(4 if label.startswith('matrixquad:')else 2 if label.startswith('matrix')else 0)
        target.extend(((k+degree2)*f-k,-k,k*f-k*k))
    target.extend(-pieces[i][1]*pieces[j][1]for i,j in combinations(range(len(pieces)),2))
    quad=next((i for i,p in enumerate(pieces)if p[2].startswith('matrixquad:')),None)
    if quad is not None:
        D=int(pieces[quad][2].split(':')[1]);f=N//pieces[quad][0]
        assert 4*f%abs(D)==0
        target.append(4*f//abs(D))
        if D>0:target.extend([0]*(len(pieces)+1))
    vectors=set()
    for sd,d,values in rows:
        v=[d*d]
        for s,t,bb in values:v.extend((t,d*s,s*s))
        v.extend(values[i][0]*values[j][0]for i,j in combinations(range(len(pieces)),2))
        if quad is not None:
            bb=values[quad][2];v.append(bb*bb)
            if D>0:v.extend([d*bb]+[value[0]*bb for value in values])
        vectors.add(((1,0)+tuple(v))if sd else((0,1)+tuple(2*x for x in v)))
    return tuple(target),sorted(vectors)


def cheap_certificate(profile,degrees,rows,b):
    ds=sorted({d for sd,d,v in rows});c=Counter(profile)
    for a in degrees:c[a]-=2
    required={a-1 for a,k in c.items()if k}|{a-2 for a in degrees}
    reach={0}
    for n in range(max(profile)+1):
        if n in reach:reach.update(n+d for d in ds if n+d<=max(profile))
    missing=sorted(required-reach)
    if missing:return {'kind':'canonical_remainder','missing_remainders':missing,'eligible_dimensions':ds}
    sd=sorted({d for yes,d,v in rows if yes});pair=sorted({d for yes,d,v in rows if not yes})
    bits=1;mask=(1<<N)-1
    for count,choices,weight in ((14-2*b,sd,1),(b,pair,2)):
        assert count>=0
        for _ in range(count):
            out=0
            for d in choices:out|=bits<<(weight*d*d)
            bits=out&mask
    if not(bits>>(N-1))&1:return {'kind':'duality_dimension_squares','eligible_selfdual':sd,'eligible_pair':pair}
    return None
