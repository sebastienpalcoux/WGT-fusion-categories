"""Pure-standard-library replay of the full rank15 two-M2 exclusion.

No numerical optimizer is imported. Each certificate is checked against
all rows regenerated from the exact input, field and duality choices.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,time
from trace_two_matrix import analyze
from two_matrix_rows import build_pieces,pair_count,rows_for,moment_data,cheap_certificate
from two_matrix_words import word_possible
from exact_certificate_checks import verify_certificate
HERE=Path(__file__).resolve().parent
INPUT_SHA256='22365dd700a8c84264dbac973266230918ce1e2c9c3d24b94230374e1bfd15dc'

def key(r):return tuple(r[k]for k in('placement_index','assignment_index','matrix_index'))
def read_jsonl(name):return[json.loads(s)for s in(HERE/name).read_text().splitlines()]

def main():
    start=time.monotonic();counts=Counter()
    assert not any((d**3-d)%5400==0 for d in range(3,73))
    assert hashlib.sha256((HERE/'input126.json').read_bytes()).hexdigest()==INPUT_SHA256
    inputs=json.loads((HERE/'input126.json').read_text());assert len(inputs)==126
    fixed=read_jsonl('rows_0_63.jsonl')+read_jsonl('rows_63_126.jsonl')
    refined=read_jsonl('word_results.jsonl')
    first={key(r):r for r in fixed};second={key(r):r for r in refined}
    assert len(first)==len(fixed)==484 and len(second)==len(refined)==38
    assert set(second)=={k for k,r in first.items()if r['certificate'] is None}
    seen=set();placement_results=[]
    for index,record in enumerate(inputs):
        case=analyze(record);assert case['profile']==record['profile']
        counts['placements']+=1;counts['form_excluded_placements']+=not case['assignments']
        counts.update(case['statistics']);state_count=0
        for ai,assignment in enumerate(case['assignments']):
            for mi,matrix in enumerate(assignment['matrix_options']):
                k=(index,ai,mi);assert k not in seen;seen.add(k);state_count+=1
                old=first[k];b=pair_count(assignment,matrix);cert=old['certificate']
                if old['method']=='analytic_support':
                    assert matrix['field']=='Q+Q'
                    assert any(a==900 and kind=='S'for a,kind in zip(case['nonlinear_degrees'],matrix['kind']))
                    assert b<5 and cert=={'kind':'symplectic_six_support','pairs':b}
                    counts['symplectic_support_certificates']+=1
                    continue
                assert old['method']=='fixed_fields'
                pieces=build_pieces(assignment,case['nonlinear_degrees'],matrix)
                assert old['pieces']==[list(p)for p in pieces] and old['pairs']==b
                rows=list(rows_for(pieces,assignment['q6']));assert len(rows)==old['rows']
                target,vectors=moment_data(pieces,rows,b);assert len(vectors)==old['vectors']
                counts['base_rows']+=len(rows)
                if cert is not None:
                    if cert['kind']in('canonical_remainder','duality_dimension_squares'):
                        assert cheap_certificate(case['profile'],case['nonlinear_degrees'],rows,b)==cert
                    else:assert verify_certificate(vectors,target,cert)
                    counts['base_'+cert['kind']]+=1
                else:
                    r=second[k]
                    assert r['method']=='word_refinement'and r['base_rows']==len(rows)
                    rows=[row for row in rows if word_possible(pieces,row)]
                    assert len(rows)==r['rows'];counts['word_rows']+=len(rows)
                    target,vectors=moment_data(pieces,rows,b);assert len(vectors)==r['vectors']
                    cert=r['certificate'];assert cert is not None
                    if cert['kind']in('canonical_remainder','duality_dimension_squares'):
                        assert cheap_certificate(case['profile'],case['nonlinear_degrees'],rows,b)==cert
                    else:assert verify_certificate(vectors,target,cert)
                    counts['word_'+cert['kind']]+=1
        placement_results.append({'placement_index':index,'profile_index':record['profile_index'],'nonlinear_degrees':record['nonlinear_degrees'],'states':state_count,'excluded':True})
        if index%10==0:print('verified placement',index,'states',len(seen),'seconds',round(time.monotonic()-start,2),flush=True)
    assert seen==set(first) and len(seen)==484
    assert counts['placements']==126 and counts['form_excluded_placements']==10
    assert counts['base_rows']==160099 and counts['word_rows']==90
    output={'status':'PASS','complex_algebra':'C^7+M2+M2','dimension':5400,'rank':15,'counts':dict(counts),'input_sha256':INPUT_SHA256,'placements':placement_results,'seconds':time.monotonic()-start,'scope':'All126 R33 retained two-M2 placements excluded; no existence or higher-rank assertion.'}
    (HERE/'verification_result.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items()if k!='placements'},indent=2))

if __name__=='__main__':main()
