"""Propose exact exclusions for all surviving two-matrix states."""
from pathlib import Path
from collections import Counter
import argparse,json,time
from two_matrix_rows import build_pieces,pair_count,rows_for,moment_data,cheap_certificate
from propose_certificates import certificate
HERE=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=126);args=ap.parse_args()
    data=[json.loads(s)for s in (HERE/'trace_two_matrix.jsonl').read_text().splitlines()]
    start=time.monotonic();counts=Counter()
    with(HERE/f'rows_{args.start}_{args.stop}.jsonl').open('w')as out:
        for case in data:
            index=case['placement_index']
            if not args.start<=index<args.stop:continue
            for ai,assignment in enumerate(case['assignments']):
                for mi,matrix in enumerate(assignment['matrix_options']):
                    ts=time.monotonic();b=pair_count(assignment,matrix)
                    # Universal rational symplectic f6 support requires five source pairs.
                    if matrix['field']=='Q+Q'and any(k=='S'and a==900 for a,k in zip(case['nonlinear_degrees'],matrix['kind']))and b<5:
                        rec={'placement_index':index,'assignment_index':ai,'matrix_index':mi,'certificate':{'kind':'symplectic_six_support','pairs':b},'method':'analytic_support','rows':0,'vectors':0}
                    else:
                        pieces=build_pieces(assignment,case['nonlinear_degrees'],matrix)
                        rows=list(rows_for(pieces,assignment['q6']));cert=cheap_certificate(case['profile'],case['nonlinear_degrees'],rows,b)
                        target,vectors=moment_data(pieces,rows,b)
                        if cert is None:cert=certificate(vectors,target)
                        rec={'placement_index':index,'assignment_index':ai,'matrix_index':mi,'profile_index':case['profile_index'],'nonlinear_degrees':case['nonlinear_degrees'],'fields':assignment['fields'],'q':assignment['q'],'q6':assignment['q6'],'matrix':matrix,'pieces':pieces,'pairs':b,'rows':len(rows),'vectors':len(vectors),'certificate':cert,'method':'fixed_fields'}
                    rec['seconds']=time.monotonic()-ts;out.write(json.dumps(rec,separators=(',',':'))+'\n');out.flush()
                    counts['states']+=1;counts['excluded']+=rec['certificate']is not None;counts['rows']+=rec['rows']
                    if counts['states']%10==0 or rec['certificate']is None:print(index,ai,mi,matrix['field'],matrix['kind'],rec['rows'],'OPEN'if rec['certificate']is None else rec['certificate']['kind'],dict(counts),'seconds',round(time.monotonic()-start,2),flush=True)
    print('FINAL',dict(counts),'seconds',time.monotonic()-start,flush=True)

if __name__=='__main__':main()
