"""Propose exact certificates on the word-refined open states."""
from pathlib import Path
from collections import Counter
import json,time
from two_matrix_rows import rows_for,moment_data,cheap_certificate
from two_matrix_words import word_possible
from propose_certificates import certificate
HERE=Path(__file__).resolve().parent

def main():
    data=[json.loads(s)for s in(HERE/'trace_two_matrix.jsonl').read_text().splitlines()]
    previous=[json.loads(s)for name in('rows_0_63.jsonl','rows_63_126.jsonl')for s in(HERE/name).read_text().splitlines()]
    start=time.monotonic();counts=Counter()
    with(HERE/'word_results.jsonl').open('w')as out:
        for old in previous:
            if old['certificate'] is not None:continue
            ts=time.monotonic();case=data[old['placement_index']]
            pieces=tuple(tuple(p)for p in old['pieces'])
            rows=list(rows_for(pieces,old['q6']))
            assert len(rows)==old['rows']
            refined=[r for r in rows if word_possible(pieces,r)]
            target,vectors=moment_data(pieces,refined,old['pairs'])
            cert=cheap_certificate(case['profile'],case['nonlinear_degrees'],refined,old['pairs'])
            if cert is None:cert=certificate(vectors,target)
            rec=dict(old);rec.update(base_rows=len(rows),rows=len(refined),vectors=len(vectors),certificate=cert,method='word_refinement',seconds=time.monotonic()-ts)
            out.write(json.dumps(rec,separators=(',',':'))+'\n');out.flush()
            counts['states']+=1;counts['excluded']+=cert is not None;counts['rows']+=len(refined)
            print(old['placement_index'],old['assignment_index'],old['matrix_index'],len(rows),'->',len(refined),'OPEN'if cert is None else cert['kind'],dict(counts),'seconds',round(time.monotonic()-start,2),flush=True)
    print('FINAL',dict(counts),'seconds',time.monotonic()-start,flush=True)

if __name__=='__main__':main()
