"""Exact positive powers, coupled commutators and norm/mixed words."""
from functools import lru_cache
from itertools import product
from fractions import Fraction
from two_matrix_rows import quadratic_matrix_choices,mul,add,scale,conj,trace,norm
from power_trace_filter import scalar_power_options,quadratic_powers
N=5400

@lru_cache(None)
def rational_determinants(s,t,sd,kind):
    if sd:
        if(s*s-t)%2:return ()
        ns=((s*s-t)//2,)
    elif kind=='S':
        if t%2:return ()
        ns=(t//2,)
    else:ns=range(-(t//2),t//2+1)
    return tuple(n for n in ns if 2*abs(n)<=t and(kind!='O'or 2*n>=s*s-t))

@lru_cache(None)
def rational_words(s,t,n,bound):
    powers=quadratic_powers(s,n,2*bound)
    norms=quadratic_powers(t,n*n,bound)
    us=[0];vs=[1]
    for k in range(bound):us.append(s*us[-1]+vs[-1]);vs.append(-n*us[-2])
    mixed=tuple(us[k]*us[l]*t+(us[k]*vs[l]+vs[k]*us[l])*s+2*vs[k]*vs[l]
                for k in range(bound+1)for l in range(k+1))
    F=(t-2*n)*(t+2*n-s*s)
    assert F>=0
    return powers,norms,mixed,F

@lru_cache(None)
def quadratic_words(D,alpha,beta,gamma,bound):
    powers=[(2,0),alpha]
    for k in range(2,2*bound+1):powers.append(add(mul(alpha,powers[-1],D),scale(mul(beta,powers[-2],D),-1)))
    nu=mul(beta,conj(beta,D),D)if D<0 else mul(beta,beta,D)
    norms=[(2,0),gamma]
    for k in range(2,bound+1):norms.append(add(mul(gamma,norms[-1],D),scale(mul(nu,norms[-2],D),-1)))
    us=[(0,0)];vs=[(1,0)]
    for k in range(bound):us.append(add(mul(alpha,us[-1],D),vs[-1]));vs.append(scale(mul(beta,us[-2],D),-1))
    star=lambda x:conj(x,D)if D<0 else x
    mixed=[]
    for k in range(bound+1):
        for l in range(k+1):
            z=mul(mul(us[k],star(us[l]),D),gamma,D)
            z=add(z,mul(mul(us[k],star(vs[l]),D),alpha,D))
            z=add(z,mul(mul(vs[k],star(us[l]),D),star(alpha),D))
            z=add(z,scale(mul(vs[k],star(vs[l]),D),2))
            mixed.append(trace(z,D))
    # Difference Tr((AA*)^2)-Tr(A^2(A*)^2), summed over the field orbit.
    F=trace(norms[2],D)-mixed[2*3//2+2]
    assert F>=0,(D,alpha,beta,gamma,F)
    return tuple(trace(x,D)for x in powers),tuple(trace(x,D)for x in norms),tuple(mixed),F


def scalar_real(label):
    if label in('Q','rational6','rational_group','real_cubic_conductor9'):return True
    if label.startswith('quadratic_disc='):return int(label.split('=')[1])>0
    if label.startswith('zeta'):
        c,h=label.split(':H=');return int(c[4:])-1 in tuple(map(int,h.split(',')))
    return False


def scalar_mixed(piece,value,powers,k,l,sd):
    a,e,label=piece;s,t,bb=value
    if scalar_real(label):return powers[k+l]
    if label=='complex6':
        if e==2:return (t//2)**l*powers[k-l]
        if k+l==0:return e
        if t==0:return 0
        if sd:return powers[k+l]
        return quadratic_powers(s,1,k-l)[k-l]
    if label.startswith('quadratic_disc='):
        return (t//2)**l*powers[k-l]
    return None


def word_possible(pieces,row,max_power=15,mixed_bound=10):
    sd,d,values=row;bound=max(max_power,mixed_bound)
    # Every piece is Galois stable; its nonzero characteristic-root orbits
    # have integral norm.  AM-GM and Cauchy give |trace| <= Frobenius norm.
    if any(abs(s)>t for s,t,b in values):return False
    # Equality in every piece forces every nonzero eigenvalue to be +/-1,
    # and hence tau(X^3)-tau(X)=(d^3-d)/5400, never integral for 3<=d<=72.
    if all(abs(s)==t for s,t,b in values):return False
    scalar_indices=[];scalar_choices=[];matrix_indices=[];matrix_choices=[]
    for i,(p,v)in enumerate(zip(pieces,values)):
        a,k,label=p;s,t,b=v
        if label.startswith('matrixquad:'):
            _,DD,kind=label.split(':');D=int(DD)
            opts=quadratic_matrix_choices(N//a,D,kind,sd).get((s,t,b),())
            words=tuple(quadratic_words(D,*x,bound)for x in opts)
            matrix_indices.append(i);matrix_choices.append(words)
        elif label.startswith('matrix'):
            ns=rational_determinants(s,t,sd,label[-1])
            words=tuple(rational_words(s,t,n,bound)for n in ns)
            matrix_indices.append(i);matrix_choices.append(words)
        else:
            opts=scalar_power_options(p,(s,t),2*bound,sd,d,True)
            assert opts is not None
            if not opts:return False
            scalar_indices.append(i);scalar_choices.append(opts)
    if any(not x for x in matrix_choices):return False
    base=[d**k for k in range(2*bound+1)]
    for selected in product(*scalar_choices):
        nums=[base[k]+sum(pieces[i][0]*seq[k]for i,seq in zip(scalar_indices,selected))for k in range(2*bound+1)]
        for mats in product(*matrix_choices):
            pp=[nums[k]+sum(pieces[i][0]*m[0][k]for i,m in zip(matrix_indices,mats))for k in range(max_power+1)]
            if pp[0]!=N or pp[1]!=0 or pp[2]!=N*sd:continue
            if any(x<0 or x%N for x in pp):continue
            if not any(pp[1:12]):continue # L=11 is proved for this algebra shape.
            delta=sum(pieces[i][0]*m[3]for i,m in zip(matrix_indices,mats))
            if delta%N:continue
            good=True
            for k in range(1,max_power+1):
                vals=[scalar_mixed(pieces[i],values[i],seq,k,k,sd)for i,seq in zip(scalar_indices,selected)]
                if any(x is None for x in vals):break # Safe higher-CM relaxation.
                value=d**(2*k)+sum(pieces[i][0]*x for i,x in zip(scalar_indices,vals))+sum(pieces[i][0]*m[1][k]for i,m in zip(matrix_indices,mats))
                if value<0 or value%N:good=False;break
            if not good:continue
            for k in range(mixed_bound+1):
                for l in range(k+1):
                    vals=[scalar_mixed(pieces[i],values[i],seq,k,l,sd)for i,seq in zip(scalar_indices,selected)]
                    if any(x is None for x in vals):continue
                    pos=k*(k+1)//2+l
                    value=d**(k+l)+sum(pieces[i][0]*x for i,x in zip(scalar_indices,vals))+sum(pieces[i][0]*m[2][pos]for i,m in zip(matrix_indices,mats))
                    if value<0 or value%N:good=False;break
                if not good:break
            if good:return True
    return False
