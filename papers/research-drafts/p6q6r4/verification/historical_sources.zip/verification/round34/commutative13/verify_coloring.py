#!/usr/bin/env python3
"""Produce and independently check a compact integer coloring certificate."""
from pathlib import Path
from itertools import combinations
import hashlib,json,time
from verify_frame import expanded_rows,adjacency

HERE=Path(__file__).resolve().parent

def color_classes(P,adj):
    groups=[]
    while P:
        available=P;group=[]
        while available:
            bit=available&-available;v=bit.bit_length()-1
            group.append(v);P^=bit;available^=bit;available&=~adj[v]
        groups.append(group)
    return groups

def produce(data):
    weights,rows=expanded_rows(data);adj=adjacency(weights,rows)
    remaining=(1<<len(rows))-1;steps=[]
    while True:
        classes=color_classes(remaining,adj)
        if len(classes)<=11:break
        v=classes[-1][-1]
        neighbors=remaining&adj[v]
        local=color_classes(neighbors,adj)
        assert len(local)<=10,(v,len(local))
        steps.append({"removed_vertex":v,"neighborhood_colors":local})
        remaining&=~(1<<v)
    return {"status":"CERTIFICATE","rank":13,"target_clique":12,
            "aggregate_rows":len(data["rows"]),"expanded_rows":len(rows),
            "steps":steps,"residual_colors":classes}

def check(data,cert):
    """No adjacency matrix or clique-search routine is used by this checker."""
    weights,rows=expanded_rows(data);n=len(rows)
    assert cert["rank"]==13 and cert["target_clique"]==12
    assert cert["expanded_rows"]==n
    assert len(data["rows"])==cert["aggregate_rows"]
    def dot(i,j):return sum(a*x*y for a,x,y in zip(weights,rows[i],rows[j]))
    def colors(classes,expected,maximum):
        assert len(classes)<=maximum
        flat=[v for group in classes for v in group]
        assert len(flat)==len(set(flat)) and set(flat)==expected
        for group in classes:
            for i,j in combinations(group,2):assert dot(i,j)!=0
    remaining=set(range(n))
    for step in cert["steps"]:
        v=step["removed_vertex"];assert v in remaining
        neighbors={u for u in remaining if u!=v and dot(u,v)==0}
        colors(step["neighborhood_colors"],neighbors,10)
        # Every12-clique containing v would need11 mutually adjacent neighbors.
        remaining.remove(v)
    colors(cert["residual_colors"],remaining,11)
    return {"status":"PASS","aggregate_rows":len(data["rows"]),"expanded_rows":n,
            "removed_vertices":len(cert["steps"]),
            "neighborhood_color_counts":[len(x["neighborhood_colors"]) for x in cert["steps"]],
            "residual_colors":len(cert["residual_colors"]),
            "conclusion":"The entire candidate row graph has clique number at most11."}

def main():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("--produce",action="store_true")
    args=ap.parse_args();raw=(HERE/"open8370_scalar_rows.json").read_bytes()
    data=json.loads(raw);path=HERE/"frame_coloring_certificate.json"
    if args.produce:
        cert=produce(data);cert["input_sha256"]=hashlib.sha256(raw).hexdigest()
        path.write_text(json.dumps(cert,separators=(",",":"))+"\n")
    cert=json.loads(path.read_text())
    assert cert["input_sha256"]==hashlib.sha256(raw).hexdigest()
    result=check(data,cert)
    (HERE/"frame_coloring_verification.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__":
    main()

