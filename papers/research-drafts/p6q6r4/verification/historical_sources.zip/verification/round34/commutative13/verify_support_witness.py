#!/usr/bin/env python3
"""Exact replay that the profile-7649 old moment cone was feasible.

This auxiliary proof establishes the strictness of the new support-cover
constraint. The main endpoint replay separately verifies its exclusion.
"""
from fractions import Fraction
from pathlib import Path
import hashlib,json,time
from fixed_field_rows import fixed_blocks,fixed_rows
from gap_filter import row_determinants,gap_possible
from power_trace_filter import power_trace_possible
from coupled_rows import coupled_moments
HERE=Path(__file__).resolve().parent

def main():
    started=time.monotonic()
    data=json.loads((HERE/'open7649_rows.json').read_text())
    witness=json.loads((HERE/'open7649_rational_moment_witness.json').read_text())
    record=data['record']
    assert record['index']==witness['profile_index']==7649
    assert record['assignment_index']==witness['assignment_index']==0
    assignment={k:record[k] for k in ('fields','q6','q')}
    assert assignment['q6']==assignment['q']==0
    pieces,double=fixed_blocks(assignment,None)
    assert double is None and [list(p)for p in pieces]==data['pieces']==record['pieces']
    rows=[row for row in fixed_rows(pieces,None,0,0,None)
          if row_determinants(pieces,row[1],row[2],row[0],None)!=()
          and gap_possible(pieces,row[1],row[2])
          and power_trace_possible(pieces,row[1],row[2],row[0],max_power=13,higher_fields=True)]
    frozen={(sd,d,tuple(tuple(v)for v in values))for sd,d,values in data['rows']}
    assert set(rows)==frozen and len(rows)==len(frozen)==witness['aggregate_rows']==198
    target,vectors=coupled_moments(pieces,None,rows,0,None)
    assert list(target)==data['target'] and [list(v)for v in vectors]==data['vectors']
    support=witness['support']
    assert len(support)==56 and len({index for index,num,den in support})==56
    assert all(type(x)is int for item in support for x in item)
    assert all(0<=index<len(vectors)and num>0 and den>0 for index,num,den in support)
    for j,t in enumerate(target):
        assert sum(Fraction(num,den)*vectors[index][j]for index,num,den in support)==t
    assert min(d for sd,d,values in rows)==11
    names=('open7649_rows.json','open7649_rational_moment_witness.json','verify_support_witness.py')
    report={'status':'EXACT_RATIONAL_FEASIBILITY_PASS','profile_index':7649,'assignment_index':0,
            'aggregate_rows':198,'positive_support_size':56,'moment_coordinates':len(target),
            'minimum_dimension':11,'input_sha256':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest()for n in names},
            'seconds':time.monotonic()-started}
    (HERE/'support_witness_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
