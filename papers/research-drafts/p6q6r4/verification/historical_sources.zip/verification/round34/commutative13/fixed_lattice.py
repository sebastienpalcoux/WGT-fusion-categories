"""Exact fixed-field integral enumeration through a rational nullspace.

The free coordinates are coordinates in the ambient cyclotomic integral
power basis, so every algebraic integer is included. Pivot integrality is
checked after enumeration; no unproved integral-basis claim is used.
"""
from fractions import Fraction as F
from functools import lru_cache
from orbit_pairs import phi,powers,ramanujan,lattice_vectors

def nullspace(rows,n):
    a=[[F(x) for x in row] for row in rows if any(row)];pivots=[];h=0
    for j in range(n):
        pivot=next((k for k in range(h,len(a)) if a[k][j]),None)
        if pivot is None:continue
        a[h],a[pivot]=a[pivot],a[h];q=a[h][j];a[h]=[x/q for x in a[h]]
        for k in range(len(a)):
            if k!=h and a[k][j]:
                q=a[k][j];a[k]=[x-q*y for x,y in zip(a[k],a[h])]
        pivots.append(j);h+=1
        if h==len(a):break
    free=[j for j in range(n) if j not in pivots];basis=[]
    for j in free:
        x=[F(0)]*n;x[j]=F(1)
        for row,p in zip(a,pivots):x[p]=-row[j]
        basis.append(tuple(x))
    assert all(sum(row[j]*v[j] for j in range(n))==0 for row in rows for v in basis)
    return tuple(basis)

def group_generators(c,elements):
    """Generators of the supplied multiplicative subgroup, by exact closure."""
    closed={1};generators=[]
    for a in elements:
        if a in closed:continue
        generators.append(a);old=tuple(closed);power=a
        while power not in closed:
            closed.update(power*b%c for b in old);power=power*a%c
    assert closed==set(elements)
    return tuple(generators)

@lru_cache(None)
def fixed_lattice(c,h,sd):
    n=phi(c);pp=powers(c);required=group_generators(c,h)+((c-1,) if sd and c-1 not in h else ())
    equations=[]
    for a in required:
        if a==1:continue
        for i in range(n):equations.append([pp[(a*j)%c][i]-(i==j) for j in range(n)])
    basis=nullspace(equations,n)
    gram0=[[ramanujan(c,i-j) for j in range(n)]for i in range(n)]
    sparse=[tuple((i,a)for i,a in enumerate(x)if a)for x in basis]
    gram=[[sum(a*b*gram0[i][j]for i,a in x for j,b in y)for y in sparse]for x in sparse]
    traces=[sum(a*ramanujan(c,j)for j,a in x)for x in sparse]
    return basis,gram,traces

@lru_cache(None)
def fixed_pairs(f,c,h,sd):
    basis,gram,traces=fixed_lattice(c,h,sd);n=phi(c);out=set();cap=f-1
    for z,q in lattice_vectors(gram,len(h)*cap):
        x=[sum(z[j]*basis[j][i] for j in range(len(basis)))for i in range(n)]
        if any(a.denominator!=1 for a in x):continue
        tr=sum(a*b for a,b in zip(z,traces))
        assert tr.denominator==q.denominator==1
        tr,q=int(tr),int(q)
        assert tr%len(h)==q%len(h)==0
        out.add((tr//len(h),q//len(h)))
    return frozenset(out)
