#!/usr/bin/env python3
"""Portable standard-library replay of the rank-thirteen necessary checkpoint.

Unvisited or unresolved states are retained, never silently excluded.
A complete exclusion is reported only when the retained state list is empty.
"""
from pathlib import Path
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import argparse,json,time,hashlib
from endpoint_core import degree_profiles
from trace_rank13 import analyze as analyze_trace
from fixed_field_rows import fixed_blocks,fixed_rows
from gap_filter import gap_possible,row_determinants
from power_trace_filter import power_trace_possible
from cheap_screen import semigroup
from coupled_rows import coupled_moments
from exact_filters import verify_simple_certificate,dimension_possible
from exact_certificate_checks import verify_certificate
from canonical_support import canonical_columns,regular_trace,canonical_row_failure,extended_moments,verify_cut_data
from forgetful_transport import verify_transport
from integer_carry import verify_carry
from quadratic_skew import verify_quadratic
from real_quadratic_unit import verify_real_unit
from linear_field_lattice import verify_field_lattice
HERE=Path(__file__).resolve().parent

def trace_replay(record):
 actual=analyze_trace((record['index'],tuple(record['profile'])))
 for key in set(actual)|set(record):
  if key in('seconds','profile'):continue
  assert actual.get(key)==record.get(key),(record['index'],key)
 return record['gate']

def row_allowed(pieces,row,higher,regular=None):
 sd,d,values=row
 return row_determinants(pieces,d,values,sd,None)!=()and gap_possible(pieces,d,values)and power_trace_possible(pieces,d,values,sd,max_power=13,higher_fields=higher,regular_rank=regular)

def verify_prefix(pieces,assignment,certificate):
 kind=certificate['kind'];q6,q=assignment['q6'],assignment['q'];higher=certificate['higher_fields'];tested=0
 if kind=='refined_prefix_dimension_squares':
  declared_sd=set(certificate['eligible_selfdual']);declared_pair=set(certificate['eligible_pair']);actual={True:set(),False:set()}
  assert all(type(d)is int and 3<=d<=72 for d in declared_sd|declared_pair)
  for sd in([True]if q==0 else[True,False]):
   for d in range(3,73):
    tested+=1
    for row in fixed_rows(pieces,None,q6,q,None,dimensions=(d,),selfdualities=(sd,)):
     if row_allowed(pieces,row,higher,13):actual[sd].add(d);break
  assert actual[True]<=declared_sd and actual[False]<=declared_pair
  abstract=[(True,d,())for d in declared_sd]+[(False,d,())for d in declared_pair]
  assert not dimension_possible(abstract,q,rank=13)
 elif kind=='refined_prefix_canonical_remainder':
  column=certificate['column'];assert column in canonical_columns(assignment);r=column['degree']-column['multiplicity'];assert r==certificate['remainder'];assert certificate['regular_rank']==13
  coins=set()
  for sd in([True]if q==0 else[True,False]):
   weight=2 if column['selfdual']and not sd else 1
   for d in range(3,min(72,r//weight)+1):
    tested+=1
    for row in fixed_rows(pieces,None,q6,q,None,dimensions=(d,),selfdualities=(sd,)):
     if regular_trace(pieces,row)>=column['multiplicity']and row_allowed(pieces,row,higher,13):coins.add(weight*d);break
  declared=set(certificate['eligible_coins']);assert coins<=declared
  assert all(type(c)is int and 3<=c<=r for c in declared)
  assert not semigroup(r,sorted(declared))[r]
 else:
  cutoff=certificate['dimension_cutoff']if kind=='source_dimension_density'else certificate['cutoff'];dims=set()
  assert cutoff==21 if kind=='source_dimension_density'else cutoff==min(certificate['remainder'],72)
  for d in range(3,cutoff+1):
   tested+=1
   for row in fixed_rows(pieces,None,q6,q,None,dimensions=(d,)):
    if row_allowed(pieces,row,higher):dims.add(d);break
  declared=set(certificate['eligible_dimensions']);assert dims<=declared
  assert all(type(d)is int and 3<=d<=cutoff for d in declared)
  if kind=='source_dimension_density':
   assert not declared and certificate['nonunit_count']==12 and certificate['nonunit_square_sum']==5399 and 12*(cutoff+1)**2>5399
  else:
   assert kind=='prefix_canonical_remainder'
   assert certificate['remainder']in{c['degree']-c['multiplicity']for c in canonical_columns(assignment)}
   assert not semigroup(certificate['remainder'],sorted(declared))[certificate['remainder']]
 return tested

def verify_one(record):
 start=time.monotonic();assignment={k:record[k]for k in('fields','q6','q')};pieces,double=fixed_blocks(assignment,None);assert double is None
 assert pieces==[tuple(p)for p in record['pieces']]
 cert=record['certificate'];kind=cert['kind'];stage=record['stage']
 if kind=='linear_field_coordinate_lattice':
  assert verify_field_lattice(assignment,cert)
  return {'index':record['index'],'assignment_index':record['assignment_index'],'kind':kind,'seconds':time.monotonic()-start}
 if kind=='real_quadratic_unit_norm':
  assert verify_real_unit(assignment,cert)
  return {'index':record['index'],'assignment_index':record['assignment_index'],'kind':kind,'seconds':time.monotonic()-start}
 if kind=='quadratic_skew_square_budget':
  assert verify_quadratic(assignment,cert)
  return {'index':record['index'],'assignment_index':record['assignment_index'],'kind':kind,'seconds':time.monotonic()-start}
 if kind in('prefix_canonical_remainder','source_dimension_density','refined_prefix_canonical_remainder','refined_prefix_dimension_squares'):
  tested=verify_prefix(pieces,assignment,cert)
  return {'index':record['index'],'assignment_index':record['assignment_index'],'kind':kind,'dimension_tests':tested,'seconds':time.monotonic()-start}
 rows=list(fixed_rows(pieces,None,assignment['q6'],assignment['q'],None));initial=len(rows)
 if stage!='fixed_fields':rows=[r for r in rows if row_determinants(pieces,r[1],r[2],r[0],None)!=()and gap_possible(pieces,r[1],r[2])]
 if stage in('powers','higher_powers')or stage.startswith('regular_powers'):
  higher=stage!='powers';regular=13 if stage.startswith('regular_powers')else None
  rows=[r for r in rows if power_trace_possible(pieces,r[1],r[2],r[0],max_power=13,higher_fields=higher,regular_rank=regular)]
 assert stage in('fixed_fields','annihilator','powers','higher_powers','regular_powers_and_canonical_cuts','regular_powers_and_transport','regular_powers_and_carry','regular_powers_and_orthogonal_frame')
 assert len(rows)==record['rows'],(record['index'],stage,len(rows),record['rows'])
 target,vectors=coupled_moments(pieces,None,rows,assignment['q'],None);assert len(vectors)==record['vectors']
 columns=canonical_columns(assignment)
 if verify_simple_certificate(record['profile'],rows,assignment['q'],cert):pass
 elif kind=='canonical_regular_remainder':
  assert cert['column']in columns;column=cert['column']
  assert cert['remainder']==column['degree']-column['multiplicity']
  from canonical_support import coin_options
  coins=sorted({value for d,value,w in coin_options(pieces,rows,column)})
  assert coins==cert['eligible_coins']and not semigroup(cert['remainder'],coins)[cert['remainder']]
 elif kind=='canonical_cut_separator':
  assert verify_cut_data(pieces,rows,columns,cert['cuts'],13)
  goal,extended=extended_moments(pieces,vectors,target,cert['cuts']);assert verify_certificate(extended,goal,cert['separator'])
 elif kind=='rational_orthogonal_frame':
  from verify_coloring import check as check_coloring
  from power_trace_filter import rational_multisets
  from math import isqrt
  data=json.loads((HERE/cert['scalar_input']).read_text());coloring=json.loads((HERE/cert['coloring_certificate']).read_text())
  assert data['profile_index']==record['index']and data['assignment_index']==record['assignment_index']
  assert data['profile']==record['profile']and data['fields']==record['fields']and data['pieces']==[list(p)for p in pieces]
  actual={}
  for sd,d,values in rows:
   assert sd;options=[]
   for(a,k,label),(ss,tt)in zip(pieces,values):
    assert label in('Q','rational6','rational_group')
    bound=min(d-1,isqrt(5400//a-1))
    options.append([list(v)for v in rational_multisets(k,ss,tt)if all(abs(x)<=bound for x in v)])
   actual[(sd,d,tuple(values))]=options
  declared={(r['selfdual'],r['dimension'],tuple(tuple(v)for v in r['aggregate_values'])):r['scalar_multiset_options']for r in data['rows']}
  assert actual==declared
  assert data['expanded_column_weights']==[1]+[a for a,k,label in pieces for _ in range(k)]
  assert hashlib.sha256((HERE/cert['scalar_input']).read_bytes()).hexdigest()==coloring['input_sha256']
  assert check_coloring(data,coloring)['status']=='PASS'
 elif kind=='forgetful_transport_separator':assert verify_transport(pieces,rows,vectors,target,columns,cert)
 elif kind=='canonical_carry_separator':
  assert verify_cut_data(pieces,rows,columns,cert['moment_cuts'],13)
  goal,extended=extended_moments(pieces,vectors,target,cert['moment_cuts']);assert verify_carry(extended,goal,cert['carry'])
 else:assert verify_certificate(vectors,target,cert)
 return {'index':record['index'],'assignment_index':record['assignment_index'],'kind':kind,'initial_rows':initial,'verified_rows':len(rows),'seconds':time.monotonic()-start}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--certificate',type=Path,default=HERE/'rank13_certificates.json');ap.add_argument('--workers',type=int,default=1);ap.add_argument('--skip-field-replay',action='store_true');ap.add_argument('--only-fields',action='store_true');ap.add_argument('--record-start',type=int,default=0);ap.add_argument('--record-stop',type=int);ap.add_argument('--output',type=Path,default=HERE/'rank13_verification.json');args=ap.parse_args();started=time.monotonic()
 profiles=list(degree_profiles(left=12));assert len(profiles)==62776
 assert [tuple(p)for p in json.loads((HERE/'profiles_rank13.json').read_text())]==profiles
 traces=[json.loads(line)for line in(HERE/'trace_rank13.jsonl').read_text().splitlines()];assert len(traces)==len(profiles)
 for i,r in enumerate(traces):assert r['index']==i and tuple(r['profile'])==profiles[i]
 if not args.skip_field_replay:
  with ProcessPoolExecutor(max_workers=args.workers)as pool:
   gates=Counter(pool.map(trace_replay,traces,chunksize=25))
  print('FIELDS PASS',len(traces),dict(gates),'seconds',time.monotonic()-started,flush=True)
 if args.only_fields:
  args.output.write_text(json.dumps({'status':'FIELDS_PASS','profiles':len(profiles),'seconds':time.monotonic()-started},indent=2)+'\n');return
 package=json.loads(args.certificate.read_text());records={(r['index'],r['assignment_index']):r for r in package['records']};assert len(records)==len(package['records'])
 expected={};solved=set()
 for r in traces:
  for i,a in enumerate(r['surviving_assignments']):expected[(r['index'],i)]=(r,a)
 assert set(records)<=set(expected)
 for key,r in records.items():
  tr,a=expected[key];assert r['profile']==tr['profile']and r['fields']==a['fields']and(r['q6'],r['q'])==(a['q6'],a['q'])
  if r['certificate']is not None:solved.add(key)
 retained=sorted(set(expected)-solved);assert [list(k)for k in retained]==package['retained_states']
 todo=[records[key]for key in sorted(solved)];stop=len(todo)if args.record_stop is None else min(args.record_stop,len(todo));todo=todo[args.record_start:stop]
 results=[]
 for offset in range(0,len(todo),1500):
  with ProcessPoolExecutor(max_workers=args.workers)as pool:
   for result in pool.map(verify_one,todo[offset:offset+1500],chunksize=1):
    results.append(result)
    if len(results)%100==0:print('ROWS PASS',len(results),'/',len(todo),'seconds',round(time.monotonic()-started,2),flush=True)
 status='EXCLUSION_PASS'if not retained else'NECESSARY_CHECKPOINT_PASS'
 if args.record_start or stop<len(solved):status='ROW_SHARD_PASS'
 report={'status':status,'profiles':len(profiles),'field_assignments':len(expected),'excluded_assignments':len(solved),'retained_assignments':len(retained),'retained_profiles':len({i for i,a in retained}),'record_range':[args.record_start,stop],'records_checked':len(results),'field_replayed':not args.skip_field_replay,'certificate_kinds':dict(Counter(r['kind']for r in results)),'certificate_sha256':hashlib.sha256(args.certificate.read_bytes()).hexdigest(),'seconds':time.monotonic()-started}
 args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
