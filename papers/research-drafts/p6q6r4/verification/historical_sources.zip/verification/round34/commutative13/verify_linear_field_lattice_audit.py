#!/usr/bin/env python3
"""Independent exact audit of the linear-field covariance gate.

The implementation under audit and its inputs are read without modification.
Every actual (formal codegree, full field) pair is checked. For cyclotomic
fixed fields, traces are recomputed as traces of multiplication matrices
after direct polynomial reduction, independently of the Ramanujan-sum Gram
formula used by fixed_lattice. Every stored exclusion is then replayed using
its explicit integral-functional witness.

This file uses only the Python standard library and the adjacent frozen
endpoint modules. Its sole output file is linear_field_lattice_audit.json.
"""
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import json
import time

import linear_field_lattice as gate
from fixed_lattice import fixed_lattice
from generic_fields import cyclotomic_polynomial

HERE = Path(__file__).resolve().parent
EXPECTED_KINDS = {
    'unit_norm': 8789,
    'odd_skew_norm': 3825,
    'unit_coordinate_root': 621,
}


def independent_pair(f, label):
    """Check the coordinate metric and conjugation without its trace routine."""
    covariance, conjugation, unit = gate.coordinate_covariance(f, label)
    e = len(covariance)
    fixed_field = False
    if label == 'Q':
        gram = ((Q(1),),)
        conjugation_direct = ((Q(1),),)
    elif label.startswith('quadratic_disc=') or label == 'Q(sqrt(-3))':
        delta = -3 if label == 'Q(sqrt(-3))' else int(label.split('=')[1])
        odd = delta % 4 == 1
        # Integral basis 1,omega, with omega^2=A+B*omega.
        aa = Q(delta-1, 4) if odd else Q(delta, 4)
        bb = Q(1) if odd else Q(0)

        def multiply(x, y):
            return (x[0]*y[0]+aa*x[1]*y[1],
                    x[0]*y[1]+x[1]*y[0]+bb*x[1]*y[1])

        def trace(x):
            return 2*x[0]+bb*x[1]

        basis = ((Q(1), Q(0)), (Q(0), Q(1)))
        conjugates = basis if delta > 0 else (basis[0], (bb, Q(-1)))
        conjugation_direct = tuple(tuple(conjugates[j][i] for j in range(2))
                                   for i in range(2))
        gram = tuple(tuple(trace(multiply(x, y)) for y in conjugates)
                     for x in basis)
    else:
        if label == 'real_cubic_conductor9':
            modulus, subgroup = 9, (1, 8)
        else:
            conductor, subgroup_string = label.split(':H=')
            modulus = int(conductor[4:])
            subgroup = tuple(map(int, subgroup_string.split(',')))
        polynomial = cyclotomic_polynomial(modulus)
        n = len(polynomial)-1

        # Reduce each monomial directly by the monic polynomial. This does
        # not call orbit_pairs.powers or its Ramanujan trace function.
        reduced_powers = []
        for exponent in range(modulus+n):
            value = [0]*exponent+[1]
            for j in range(exponent, n-1, -1):
                leading = value[j]
                for k in range(n+1):
                    value[j-n+k] -= leading*polynomial[k]
            reduced_powers.append(tuple(value[i] if i < len(value) else 0
                                        for i in range(n)))
        assert reduced_powers[modulus] == reduced_powers[0]

        # The coefficient of zeta^j in zeta^(exponent+j) is the j-th
        # diagonal entry of the ambient multiplication matrix.
        power_traces = [sum(reduced_powers[exponent+j][j] for j in range(n))
                        for exponent in range(modulus)]
        basis, ambient_gram, unused_traces = fixed_lattice(modulus, subgroup, False)
        assert len(basis) == n//len(subgroup) == e
        free_coordinates = [
            next(j for j in range(n)
                 if all(basis[k][j] == int(i == k) for k in range(e)))
            for i in range(e)
        ]
        assert len(set(free_coordinates)) == e
        assert basis[0] == (Q(1),)+(Q(0),)*(n-1)

        def automorphism(x, a):
            return tuple(sum(x[j]*reduced_powers[(a*j) % modulus][i]
                             for j in range(n)) for i in range(n))

        assert all(automorphism(x, a) == x for x in basis for a in subgroup)
        conjugates = [automorphism(x, modulus-1) for x in basis]
        conjugation_direct = tuple(
            tuple(conjugates[j][free_coordinates[i]] for j in range(e))
            for i in range(e))
        # Reconstruct complete ambient conjugates, not merely selected entries.
        assert all(tuple(sum(conjugation_direct[k][j]*basis[k][i] for k in range(e))
                         for i in range(n)) == conjugates[j] for j in range(e))
        gram = tuple(tuple(
            sum(x[i]*y[j]*power_traces[(i-j) % modulus]
                for i in range(n) for j in range(n))/len(subgroup)
            for y in basis) for x in basis)
        assert all(gram[i][j]*len(subgroup) == ambient_gram[i][j]
                   for i in range(e) for j in range(e))
        fixed_field = True

    assert conjugation == conjugation_direct
    assert unit == (1,)+(0,)*(e-1)
    assert all(sum(gram[i][k]*covariance[k][j] for k in range(e)) == f*int(i == j)
               for i in range(e) for j in range(e))
    assert all(sum(conjugation[i][k]*conjugation[k][j] for k in range(e)) == int(i == j)
               for i in range(e) for j in range(e))
    assert all(sum(conjugation[i][k]*unit[k] for k in range(e)) == unit[i]
               for i in range(e))
    return gram, covariance, conjugation, unit, fixed_field


def verify_witness(assignment, certificate, metrics):
    assert certificate['kind'] == 'linear_field_coordinate_lattice'
    f, label = certificate['formal_codegree'], certificate['field']
    assert any(block['formal_codegree'] == f and label in block['fields']
               for block in assignment['fields'])
    gram, covariance, conjugation, unit, fixed_field = metrics[f, label]
    failure = certificate['failure']
    if failure == 'nonintegral_covariance':
        i, j = certificate['entry']
        assert covariance[i][j].denominator != 1
        return
    functional = certificate['functional']
    assert len(functional) == len(covariance)
    assert all(type(x) is int for x in functional)
    squared_norm = sum(functional[i]*covariance[i][j]*functional[j]
                       for i in range(len(functional)) for j in range(len(functional)))
    assert squared_norm == certificate['norm']
    if failure == 'unit_norm':
        assert squared_norm == 1
    elif failure == 'unit_coordinate_root':
        assert squared_norm == 2
        assert sum(functional[i]*unit[i] for i in range(len(functional))) != 0
    elif failure == 'odd_skew_norm':
        assert squared_norm.denominator == 1 and squared_norm % 2 == 1
        assert all(sum(functional[j]*conjugation[j][i] for j in range(len(functional)))
                   == -functional[i] for i in range(len(functional)))
    else:
        raise AssertionError(failure)


def main():
    started = time.monotonic()
    traces = [json.loads(line) for line in (HERE/'trace_rank13.jsonl').read_text().splitlines()]
    assert len(traces) == 62776
    actual = {}
    for expected_index, record in enumerate(traces):
        assert record['index'] == expected_index
        for assignment_index, assignment in enumerate(record['surviving_assignments']):
            key = record['index'], assignment_index
            assert key not in actual
            actual[key] = assignment
    assert len(actual) == 40476
    pairs = sorted({(block['formal_codegree'], label)
                    for assignment in actual.values() for block in assignment['fields']
                    for label in block['fields']})
    assert len(pairs) == 277
    assert all(f != 5400 for f, label in pairs)
    metrics = {(f, label): independent_pair(f, label) for f, label in pairs}
    fixed_field_pairs = sum(data[-1] for data in metrics.values())
    assert fixed_field_pairs == 47

    certificates = {}
    failure_kinds = Counter()
    lines = (HERE/'linear_field_lattice_pass.jsonl').read_text().splitlines()
    for line in lines:
        record = json.loads(line)
        key = record['index'], record['assignment_index']
        assert key in actual and key not in certificates
        assignment = actual[key]
        assert record['fields'] == assignment['fields']
        assert (record['q6'], record['q']) == (assignment['q6'], assignment['q'])
        certificate = record['certificate']
        # Check both the production verifier and the independent witness replay.
        assert gate.verify_field_lattice(assignment, certificate)
        verify_witness(assignment, certificate, metrics)
        certificates[key] = certificate
        failure_kinds[certificate['failure']] += 1
    assert len(certificates) == 13235
    assert failure_kinds == EXPECTED_KINDS
    assert {key for key, assignment in actual.items()
            if gate.assignment_failure(assignment) is not None} == set(certificates)

    fully_excluded = sum(
        bool(record['surviving_assignments'])
        and all((record['index'], i) in certificates
                for i in range(len(record['surviving_assignments'])))
        for record in traces)
    assert fully_excluded == 1301
    summary = json.loads((HERE/'linear_field_lattice_pass.summary.json').read_text())
    for key, value in {
        'status': 'PASS', 'field_assignments': len(actual),
        'excluded_assignments': len(certificates),
        'remaining_assignments': len(actual)-len(certificates),
        'failure_kinds': dict(failure_kinds),
        'fully_excluded_profiles': fully_excluded,
    }.items():
        assert summary[key] == value
    for witness in summary['field_witnesses']:
        candidates = [assignment for assignment in actual.values()
                      if any(block['formal_codegree'] == witness['formal_codegree']
                             and witness['field'] in block['fields']
                             for block in assignment['fields'])]
        assert candidates
        verify_witness(candidates[0], witness, metrics)

    inputs = (
        'trace_rank13.jsonl', 'linear_field_lattice_pass.jsonl',
        'linear_field_lattice_pass.summary.json', 'linear_field_lattice.py',
        'fixed_lattice.py', 'orbit_pairs.py', 'fixed_field_rows.py', 'generic_fields.py',
    )
    result = {
        'status': 'PASS',
        'arithmetic': 'exact integers and Fraction; Python standard library only',
        'actual_profiles': len(traces), 'actual_assignments': len(actual),
        'actual_field_codegree_pairs': len(pairs),
        'independent_cyclotomic_pair_checks': fixed_field_pairs,
        'certificates_replayed': len(certificates),
        'failure_kinds': dict(failure_kinds),
        'remaining_assignments': len(actual)-len(certificates),
        'fully_excluded_profiles': fully_excluded,
        'summary_field_witnesses_replayed': len(summary['field_witnesses']),
        'checks': [
            'Free ambient coordinate identity submatrix and exact fixed-field dimension',
            'Every fixed-field basis vector invariant under every subgroup element',
            'Independent multiplication traces after cyclotomic polynomial reduction',
            'Ambient trace divided by subgroup order equals field trace Gram',
            'Full conjugation reconstruction, involution square, and unit coordinates',
            'Covariance is exactly f times inverse field trace Gram',
            'Every stored exclusion has a valid explicit integral-functional witness',
            'Excluded state set and summary counts match exactly',
        ],
        'required_mathematical_hypotheses': {
            'orbits': 'Full Galois orbits of linear characters of common rational codegree',
            'Perron': 'Orbits disjoint from Perron, for the norm-one and norm-two-unit exclusions',
            'dimension_one': 'No nonunit source simple of dimension one, for norm-two-unit exclusions',
            'duality': 'Character of the dual is the complex conjugate, for odd-skew exclusions',
        },
        'input_sha256': {name: hashlib.sha256((HERE/name).read_bytes()).hexdigest()
                         for name in inputs},
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'seconds': time.monotonic()-started,
        'scope': 'Read-only independent audit of the frozen rank-13 linear-field covariance pass; not a claim that surviving assignments are realizable.',
    }
    (HERE/'linear_field_lattice_audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({key: result[key] for key in (
        'status', 'actual_assignments', 'actual_field_codegree_pairs',
        'independent_cyclotomic_pair_checks', 'certificates_replayed',
        'failure_kinds', 'fully_excluded_profiles', 'seconds')}, indent=2))


if __name__ == '__main__':
    main()
