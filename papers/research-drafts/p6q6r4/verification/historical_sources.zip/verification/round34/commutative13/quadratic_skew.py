"""Rank-one imaginary-quadratic skew budgets, exactly and without row search."""
from functools import lru_cache
from math import isqrt
from pathlib import Path
import json,time
from fixed_field_rows import fixed_blocks
HERE=Path(__file__).resolve().parent

@lru_cache(None)
def sum_of_squares_possible(n,q):
    if n<0 or q<0:return False
    choices=[b*b for b in range(isqrt(n)+1)];bits=1;mask=(1<<(n+1))-1
    for _ in range(q):
        next_bits=0
        for value in choices:next_bits|=bits<<value
        bits=next_bits&mask
    return bool(bits>>n&1)

def imaginary_quadratic_fields(assignment):
    for block in assignment['fields']:
        f=block['formal_codegree']
        for label in block['fields']:
            if label=='Q(sqrt(-3))':yield f,-3
            elif label.startswith('quadratic_disc='):
                delta=int(label.split('=')[1])
                if delta<0:yield f,delta

def quadratic_failure(assignment):
    q=assignment['q']
    for f,delta in imaginary_quadratic_fields(assignment):
        if f%abs(delta):return {'kind':'quadratic_skew_square_budget','formal_codegree':f,'discriminant':delta,'source_pairs':q,'failure':'nondivisibility'}
        n=f//abs(delta)
        if not sum_of_squares_possible(n,q):return {'kind':'quadratic_skew_square_budget','formal_codegree':f,'discriminant':delta,'source_pairs':q,'failure':'sum_of_squares','square_budget':n}
    return None

def verify_quadratic(assignment,cert):
    assert cert['kind']=='quadratic_skew_square_budget'
    f,delta,q=cert['formal_codegree'],cert['discriminant'],cert['source_pairs']
    assert(f,delta)in set(imaginary_quadratic_fields(assignment))and q==assignment['q']
    if cert['failure']=='nondivisibility':assert f%abs(delta)
    else:
        assert cert['failure']=='sum_of_squares'and f%abs(delta)==0
        assert cert['square_budget']==f//abs(delta)and not sum_of_squares_possible(cert['square_budget'],q)
    return True

def main():
    from collections import Counter
    traces=[json.loads(line)for line in(HERE/'trace_rank13.jsonl').read_text().splitlines()];start=time.monotonic();counts=Counter();profiles=0;total=0
    path=HERE/'quadratic_skew_pass.jsonl';assert not path.exists()
    with path.open('w')as out:
        for r in traces:
            rejected=0
            for ai,a in enumerate(r['surviving_assignments']):
                total+=1;cert=quadratic_failure(a)
                if cert is None:continue
                assert verify_quadratic(a,cert);pieces,double=fixed_blocks(a,None)
                record={'index':r['index'],'assignment_index':ai,'profile':r['profile'],'fields':a['fields'],'q6':a['q6'],'q':a['q'],'pieces':pieces,'double':None,'stage':'quadratic_skew_budget','initial_rows':0,'rows':None,'vectors':None,'certificate':cert}
                out.write(json.dumps(record,separators=(',',':'))+'\n');counts[cert['failure']]+=1;rejected+=1
            if r['surviving_assignments']and rejected==len(r['surviving_assignments']):profiles+=1
    report={'status':'PASS','field_assignments':total,'excluded_assignments':sum(counts.values()),'failure_kinds':dict(counts),'remaining_assignments':total-sum(counts.values()),'fully_excluded_profiles':profiles,'seconds':time.monotonic()-start}
    path.with_suffix('.summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
