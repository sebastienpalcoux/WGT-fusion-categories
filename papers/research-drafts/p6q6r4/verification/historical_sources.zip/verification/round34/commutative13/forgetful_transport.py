"""Signed row-type costs separate all forgetful-column configurations.

The optional proposer uses SciPy; reconstruction and checking use integers
only. No numerical infeasibility declaration is accepted as a proof.
"""
from collections import Counter
from canonical_support import decode_vector,extended_moments,verify_cut_data
from exact_certificate_checks import verify_certificate

def source_groups(pieces,vectors):
    decoded=[decode_vector(pieces,v)for v in vectors]
    groups=sorted({(weight==1,d,t)for weight,d,t in decoded if t>0})
    return groups,decoded

def best_configuration(groups,column,cost):
    """Maximum signed integral cost and one maximizer, exactly."""
    r=column['degree']-column['multiplicity'];m=column['multiplicity'];options={}
    for i,(sd,d,t)in enumerate(groups):
        if t<m:continue
        weight=2 if column['selfdual']and not sd else 1
        value=weight*d;gain=weight*cost[i]
        if value>r:continue
        if value not in options or gain>options[value][0]:options[value]=(gain,i,weight)
    dp=[0]+[None]*r;previous=[None]*(r+1)
    for n in range(1,r+1):
        for value,(gain,i,weight)in options.items():
            if value<=n and dp[n-value]is not None:
                score=dp[n-value]+gain
                if dp[n]is None or score>dp[n]:dp[n]=score;previous[n]=(value,i,weight)
    if dp[r]is None:return None,None
    configuration=[0]*len(groups);n=r
    while n:
        value,i,weight=previous[n];configuration[i]+=weight;n-=value
    assert sum(group[1]*n for group,n in zip(groups,configuration))==r
    return dp[r],tuple(configuration)

def transport_data(pieces,vectors,target,columns,moment_cuts,costs):
    groups,decoded=source_groups(pieces,vectors);assert len(costs)==len(groups)
    index={group:i for i,group in enumerate(groups)}
    moment_target,moment_vectors=extended_moments(pieces,vectors,target,moment_cuts)
    cap_target=0
    for column in columns:
        maximum,_=best_configuration(groups,column,[-c for c in costs]);assert maximum is not None
        cap_target-=column['count']*column['multiplicity']*maximum
    extended=[]
    for v,(weight,d,t)in zip(moment_vectors,decoded):
        value=weight*t*costs[index[(weight==1,d,t)]]if t>0 else 0
        extended.append(tuple(v)+(value,))
    for v in moment_vectors[len(vectors):]:extended.append(tuple(v)+(0,))
    extended.append((0,)*len(moment_target)+(-1,))
    return tuple(moment_target)+(cap_target,),extended,groups

def verify_transport(pieces,rows,vectors,target,columns,certificate):
    cuts=certificate['moment_cuts'];assert verify_cut_data(pieces,rows,columns,cuts,13)
    groups,_=source_groups(pieces,vectors);assert certificate['groups']==[list(g)for g in groups]
    costs=certificate['costs'];assert all(type(c)is int for c in costs)
    goal,extended,_=transport_data(pieces,vectors,target,columns,cuts,costs)
    assert verify_certificate(extended,goal,certificate['separator']);return True

def propose_transport(pieces,rows,vectors,target,columns,moment_cuts,max_iterations=200,verbose=False):
    import numpy as np
    from scipy.optimize import linprog
    groups,decoded=source_groups(pieces,vectors);index={g:i for i,g in enumerate(groups)}
    mt,mv=extended_moments(pieces,vectors,target,moment_cuts);M,G,C=len(mt),len(groups),len(columns)
    source=[]
    for v,(weight,d,t)in zip(mv,decoded):
        capacities=[0]*G
        if t>0:capacities[index[(weight==1,d,t)]]=weight*t
        source.append(tuple(v)+tuple(capacities)+(0,)*C)
    for v in mv[len(vectors):]:source.append(tuple(v)+(0,)*(G+C))
    configs=[set()for c in columns]
    for j,c in enumerate(columns):
        maximum,config=best_configuration(groups,c,[0]*G)
        if config is None:return None
        configs[j].add(config)
    goal=tuple(mt)+(0,)*G+tuple(c['count']for c in columns)
    for iteration in range(max_iterations):
        atoms=list(source)
        for j,c in enumerate(columns):
            for config in sorted(configs[j]):atoms.append((0,)*M+tuple(-c['multiplicity']*x for x in config)+tuple(int(k==j)for k in range(C)))
        mat=np.asarray(atoms,dtype=float);scales=np.maximum(np.maximum(np.max(np.abs(mat),axis=0),np.abs(goal)),1)
        result=linprog(np.asarray(goal)/scales,A_ub=-mat/scales,b_ub=np.zeros(len(mat)),bounds=[(-1,1)]*len(goal),method='highs')
        if not result.success or result.fun>=-1e-8:
            if verbose:print('TRANSPORT NO SEPARATOR',iteration,len(atoms),flush=True)
            return None
        z=None
        for common in(1000,10000,100000,1000000,10000000,1000000000,1000000000000):
            candidate=[round(float(v/s)*common)for v,s in zip(result.x,scales)]
            low=min(sum(a*b for a,b in zip(candidate,row))for row in source[:len(vectors)])
            if low<0:candidate[0]-=low;candidate[1]-=low
            for j,c in enumerate(columns):
                required=max(c['multiplicity']*sum(candidate[M+i]*x for i,x in enumerate(config))for config in configs[j])
                candidate[M+G+j]=max(candidate[M+G+j],required)
            if all(sum(a*b for a,b in zip(candidate,row))>=0 for row in atoms)and sum(a*b for a,b in zip(candidate,goal))<0:z=candidate;break
        if z is None:return None
        added=0
        for j,c in enumerate(columns):
            maximum,config=best_configuration(groups,c,z[M:M+G]);assert maximum is not None
            if c['multiplicity']*maximum>z[M+G+j]:
                assert config not in configs[j];configs[j].add(config);added+=1
        if verbose:print('TRANSPORT',iteration,'atoms',len(atoms),'added',added,flush=True)
        if not added:
            costs=[-x for x in z[M:M+G]];new_goal,new_vectors,_=transport_data(pieces,vectors,target,columns,moment_cuts,costs)
            functional=z[:M]+[-1];values=[sum(a*b for a,b in zip(functional,v))for v in new_vectors];value=sum(a*b for a,b in zip(functional,new_goal))
            sep={'kind':'integer_separator','coefficients':functional,'minimum_row_value':min(values),'target_value':value}
            cert={'kind':'forgetful_transport_separator','moment_cuts':moment_cuts,'groups':[list(g)for g in groups],'costs':costs,'separator':sep,'iterations':iteration+1,'generated_configurations':sum(map(len,configs))}
            assert verify_transport(pieces,rows,vectors,target,columns,cert);return cert
    return None
