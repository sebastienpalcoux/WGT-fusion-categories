"""Dependency-free canonical-remainder and integral dimension-type checks."""
from cheap_screen import semigroup,residue_fail

def dimension_possible(rows,q,rank=13):
    sd={d for yes,d,v in rows if yes};paired={d for yes,d,v in rows if not yes};bits=1;mask=(1<<5400)-1
    for count,choices,factor in [(rank-1-2*q,sd,1),(q,paired,2)]:
        assert count>=0
        for _ in range(count):
            nxt=0
            for d in choices:nxt|=bits<<(factor*d*d)
            bits=nxt&mask
    return bool(bits>>5399&1)

def verify_simple_certificate(profile,rows,q,certificate):
    kind=certificate['kind']
    if kind=='canonical_remainder':
        ds=sorted({d for sd,d,values in rows});reached=semigroup(max(profile),ds)
        missing=sorted(a-1 for a in set(profile)if not reached[a-1])
        assert ds==certificate['eligible_dimensions'] and missing==certificate['missing_remainders'] and missing
        return True
    if kind=='duality_dimension_squares':
        assert sorted({d for sd,d,v in rows if sd})==certificate['eligible_selfdual']
        assert sorted({d for sd,d,v in rows if not sd})==certificate['eligible_pair']
        assert not dimension_possible(rows,q)
        return True
    return False
