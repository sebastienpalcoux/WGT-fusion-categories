"""Exact canonical support covers and global forgetful-capacity cuts.

This module is standard library only. A field label denotes the FULL
character field; an entry lying in its real subfield is not substituted.
"""
from math import isqrt
from collections import Counter
from cheap_screen import semigroup
from orbit_pairs import phi

def field_degree_real(label):
    if label=='Q':return 1,True
    if label=='Q(sqrt(-3))':return 2,False
    if label.startswith('quadratic_disc='):return 2,int(label.split('=')[1])>0
    if label=='real_cubic_conductor9':return 3,True
    cstr,hstr=label.split(':H=');c=int(cstr[4:]);h=tuple(map(int,hstr.split(',')))
    return phi(c)//len(h),c-1 in h

def canonical_columns(assignment):
    counts=Counter()
    for block in assignment['fields']:
        a=5400//block['formal_codegree']
        for label in block['fields']:
            e,real=field_degree_real(label);counts[(a,1,real)]+=e
    return [{'degree':a,'multiplicity':m,'selfdual':real,'count':k}for(a,m,real),k in sorted(counts.items())]

def regular_trace(pieces,row):
    sd,d,values=row
    return d+sum((2 if p[2]=='matrix'else 1)*value[0]for p,value in zip(pieces,values))

def coin_options(pieces,rows,column):
    m=column['multiplicity'];real=column['selfdual'];out=set()
    for row in rows:
        sd,d,values=row
        if regular_trace(pieces,row)<m:continue
        weight=2 if real and not sd else 1
        out.add((d,weight*d,weight))
    return sorted(out)

def coin_minimum(remainder,options,costs):
    unreachable=10**100;dp=[0]+[unreachable]*remainder
    for n in range(1,remainder+1):
        for d,value,weight in options:
            if value<=n and dp[n-value]!=unreachable:dp[n]=min(dp[n],dp[n-value]+weight*costs.get(d,0))
    return None if dp[remainder]==unreachable else dp[remainder]

def cover_valid(remainder,options,dimensions):
    h=set(dimensions);coins=sorted({value for d,value,weight in options if d not in h})
    return not semigroup(remainder,coins)[remainder]

def canonical_row_failure(pieces,rows,columns):
    for column in columns:
        r=column['degree']-column['multiplicity'];options=coin_options(pieces,rows,column)
        if not semigroup(r,sorted({value for d,value,w in options}))[r]:
            return {'kind':'canonical_regular_remainder','column':column,'remainder':r,'eligible_coins':sorted({value for d,value,w in options})}
    return None

def cover_cuts(pieces,rows,columns):
    """A finite useful family; completeness of this optional cut list is not claimed."""
    out=[];seen=set()
    for column in sorted(columns,key=lambda c:(c['degree']-c['multiplicity'],not c['selfdual']))[:6]:
        r=column['degree']-column['multiplicity'];options=coin_options(pieces,rows,column)
        dims=sorted({d for d,value,w in options if value<=r})
        if not dims:continue
        candidates=[dims]
        # Mandatory individual dimensions and several minimal cover choices.
        candidates.extend([d]for d in dims if cover_valid(r,options,[d]))
        orders=[dims,list(reversed(dims)),sorted(dims,key=lambda d:(d%2,d)),sorted(dims,key=lambda d:(d%3,d))]
        for order in orders:
            h=set(dims)
            for d in order:
                test=h-{d}
                if cover_valid(r,options,test):h=test
            candidates.append(sorted(h))
        for h in candidates:
            key=(tuple(h),column['multiplicity'])
            if key in seen:continue
            assert cover_valid(r,options,h);seen.add(key)
            out.append({'kind':'canonical_support','dimensions':h,'column':column,'lower_bound':1})
    return out

def density_cuts(rows,rank=13):
    dims=sorted({row[1]for row in rows});out=[]
    if not dims:return out
    n=rank-1;minimum=dims[0]**2
    for i,d in enumerate(dims[:-1]):
        outside=dims[i+1]**2
        lower=max(0,-((5399-n*outside)//(outside-minimum)))
        if lower:
            out.append({'kind':'source_density','dimensions':dims[:i+1],'lower_bound':lower,'nonunit_count':n,'square_sum':5399})
    return out

def capacity_cuts(pieces,rows,columns,covers):
    dims=sorted({row[1]for row in rows});cost_options=[{d:1 for d in dims},{d:d*d for d in dims}]
    seen=set();out=[]
    for cut in covers:cost_options.append({d:int(d in cut['dimensions'])for d in dims})
    for costs in cost_options:
        key=tuple(costs[d]for d in dims)
        if key in seen:continue
        seen.add(key);lower=0
        for column in columns:
            options=coin_options(pieces,rows,column);r=column['degree']-column['multiplicity'];minimum=coin_minimum(r,options,costs)
            if minimum is None:continue # separately certified as a remainder failure
            lower+=column['count']*column['multiplicity']*minimum
        if lower:out.append({'kind':'forgetful_capacity','costs':[[d,costs[d]]for d in dims],'lower_bound':lower})
    return out

def decode_vector(pieces,vector):
    weight=1 if vector[0]else 2
    assert (vector[0],vector[1])in((1,0),(0,1))
    d=isqrt(vector[2]//weight);assert weight*d*d==vector[2]
    values=[]
    for i,p in enumerate(pieces):
        assert vector[4+3*i]%(weight*d)==0
        values.append(vector[4+3*i]//(weight*d))
    trace=d+sum((2 if p[2]=='matrix'else 1)*s for p,s in zip(pieces,values))
    return weight,d,trace

def cut_value(cut,weight,d,trace):
    kind=cut['kind']
    if kind=='canonical_support':return int(d in cut['dimensions']and trace>=cut['column']['multiplicity'])
    if kind=='source_density':return weight*int(d in cut['dimensions'])
    if kind=='forgetful_capacity':return weight*dict(cut['costs']).get(d,0)*trace
    raise AssertionError(kind)

def extended_moments(pieces,vectors,target,cuts):
    extended=[tuple(v)+tuple(cut_value(cut,*decode_vector(pieces,v))for cut in cuts)for v in vectors]
    for j in range(len(cuts)):
        extended.append((0,)*len(target)+tuple(-int(i==j)for i in range(len(cuts))))
    return tuple(target)+tuple(cut['lower_bound']for cut in cuts),extended

def verify_cut_data(pieces,rows,columns,cuts,rank=13):
    dims=sorted({row[1]for row in rows})
    for cut in cuts:
        if cut['kind']=='canonical_support':
            assert cut['column']in columns and cut['lower_bound']==1
            column=cut['column'];assert cover_valid(column['degree']-column['multiplicity'],coin_options(pieces,rows,column),cut['dimensions'])
        elif cut['kind']=='source_density':
            assert cut in density_cuts(rows,rank)
        elif cut['kind']=='forgetful_capacity':
            costs=dict(cut['costs']);assert all(type(c)is int and c>=0 for c in costs.values())
            lower=0
            for column in columns:
                minimum=coin_minimum(column['degree']-column['multiplicity'],coin_options(pieces,rows,column),costs)
                assert minimum is not None
                lower+=column['count']*column['multiplicity']*minimum
            assert lower==cut['lower_bound']
        else:raise AssertionError(cut['kind'])
    return True
