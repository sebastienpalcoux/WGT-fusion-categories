#!/usr/bin/env python3
"""Exact rational trace-form obstructions for the Round 31 endpoints.

All arithmetic uses Python's standard library.  No numerical solver is used.
Field assignments are full number fields, not only discriminant squareclasses.
The positive coefficient trace must recover the orthonormal simple basis.
"""
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from itertools import combinations, product
from math import gcd, prod
from pathlib import Path
import argparse
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
DEFAULT_BASE = HERE.parents[1] / "round31/deliverable/p6q6r4_Round31/verification/round31/endpoints"


def squareclass(a):
    a = Q(a)
    assert a > 0
    n = a.numerator * a.denominator
    out = 1
    p = 2
    while p*p <= n:
        odd = 0
        while n % p == 0:
            n //= p
            odd ^= 1
        if odd:
            out *= p
        p += 1
    return out*n


def prime_factors(n):
    n = abs(n)
    out = set()
    p = 2
    while p*p <= n:
        while n % p == 0:
            out.add(p)
            n //= p
        p += 1
    if n > 1:
        out.add(n)
    return out


def valuation_unit(a, p):
    a = Q(a)
    v = 0
    x, y = a.numerator, a.denominator
    while x % p == 0:
        x //= p
        v += 1
    while y % p == 0:
        y //= p
        v -= 1
    modulus = 8 if p == 2 else p
    return v, (x * pow(y, -1, modulus)) % modulus


@lru_cache(None)
def hilbert(a, b, p):
    a, b = Q(a), Q(b)
    assert a and b
    av, au = valuation_unit(a, p)
    bv, bu = valuation_unit(b, p)
    if p == 2:
        exponent = ((au-1)*(bu-1)//4 + av*(bu*bu-1)//8
                    + bv*(au*au-1)//8)
        return -1 if exponent % 2 else 1
    result = -1 if (av*bv*((p-1)//2)) % 2 else 1
    if bv % 2 and pow(au, (p-1)//2, p) == p-1:
        result = -result
    if av % 2 and pow(bu, (p-1)//2, p) == p-1:
        result = -result
    return result


def hasse(diagonal, p):
    return prod(hilbert(a, b, p) for a, b in combinations(diagonal, 2))


def invariants(diagonal):
    diagonal = tuple(Q(a) for a in diagonal)
    assert all(a > 0 for a in diagonal)
    primes = {2}
    for a in diagonal:
        primes |= prime_factors(a.numerator) | prime_factors(a.denominator)
    bad = tuple(p for p in sorted(primes) if hasse(diagonal, p) == -1)
    # Hilbert reciprocity; the real symbol is +1 since the form is positive.
    assert len(bad) % 2 == 0
    return len(diagonal), squareclass(prod(diagonal)), bad


def isometric(a, b):
    """Hasse--Minkowski for positive rational diagonal forms."""
    return invariants(a) == invariants(b)


def locally_square(a, p):
    av, au = valuation_unit(a, p)
    return av % 2 == 0 and (au == 1 if p == 2
                            else pow(au, (p-1)//2, p) == 1)


def orthogonal_matrix_possible(whole, minus, q, f):
    """Skew-space isometry and the quaternion norm-form local obstruction.

    The matrix form is (2/f)<1,delta,B,delta*B>, with delta,B>0.
    The skew line determines delta modulo rational squares.  Its Hilbert
    symbol (-delta,B) must match the whole-form Hasse invariant.
    """
    b = q+1
    missing = Q(2)**b/prod(minus)
    if not isometric(minus+(missing,), [2]*b):
        return False
    delta = squareclass(Q(f,2)*missing)
    if f == 6:
        # The six possibilities in the Round32 orthogonal f=6 theorem.
        # (delta, B, nonzero source dual-pair differences).
        candidates = [(6,2,1), (3,1,2), (3,2,2),
                      (2,1,3), (1,1,3), (1,6,3)]
        return any(delta == d and count <= b and isometric(
            whole+tuple(Q(a,3) for a in (1,d,B,d*B)), [1]*13)
                   for d,B,count in candidates)
    primes = {2} | prime_factors(delta)
    for a in whole:
        primes |= prime_factors(a.numerator) | prime_factors(a.denominator)
    for p in primes:
        required = hasse(whole, p)*hilbert(delta, -1, p)
        if required == -1 and locally_square(-delta, p):
            return False
    return True


@lru_cache(None)
def phi(n):
    return sum(gcd(i, n) == 1 for i in range(1, n+1))


@lru_cache(None)
def mu(n):
    out = 1
    for p in sorted(prime_factors(n)):
        if n % (p*p) == 0:
            return 0
        out = -out
    return out


@lru_cache(None)
def ramanujan(c, j):
    k = c // gcd(c, j)
    return mu(k) * (phi(c) // phi(k))


POLY = {
    9: [1,0,0,1,0,0,1],
    12: [1,0,-1,0,1],
    16: [1,0,0,0,0,0,0,0,1],
    20: [1,0,-1,0,1,0,-1,0,1],
    24: [1,0,0,0,-1,0,0,0,1],
}


@lru_cache(None)
def powers(c):
    polynomial = POLY[c]
    n = len(polynomial)-1
    v = [1]+[0]*(n-1)
    out = []
    for _ in range(c):
        out.append(tuple(v))
        carry = v[-1]
        v = [0]+v[:-1]
        for j in range(n):
            v[j] -= carry*polynomial[j]
    assert v == [1]+[0]*(n-1)
    return out


def independent_exponent_vectors(c, vectors):
    reduced = []
    selected = []
    pp = powers(c)
    for v in vectors:
        nonzero = [(j,a) for j,a in enumerate(v) if a]
        x = [Q(sum(a*pp[j][i] for j,a in nonzero))
             for i in range(phi(c))]
        for pivot, old in reduced:
            factor = x[pivot]
            x = [a-factor*b for a, b in zip(x, old)]
        pivot = next((i for i, a in enumerate(x) if a), None)
        if pivot is None:
            continue
        a = x[pivot]
        x = [b/a for b in x]
        reduced.append((pivot, x))
        selected.append(v)
    return selected


def diagonalize(g):
    g = [[Q(a) for a in row] for row in g]
    n = len(g)
    out = []
    for i in range(n):
        pivot = g[i][i]
        assert pivot > 0
        out.append(pivot)
        for j in range(i+1, n):
            for k in range(j, n):
                g[j][k] -= g[i][j]*g[i][k]/pivot
                g[k][j] = g[j][k]
    return tuple(out)


@lru_cache(None)
def fixed_forms(c, h):
    """Trace_K(x bar(x)) on K and its duality-fixed/skew subspaces.

    K=Q(zeta_c)^H; exponent vectors have rational coefficients.  The trace
    upstairs divided by |H| is the trace on K, also on its proper subspaces.
    """
    h = tuple(h)
    basis_candidates = []
    plus_candidates = []
    minus_candidates = []
    for i in range(c):
        v = [0]*c
        for a in h:
            v[(a*i) % c] += 1
        cv = [v[(-j) % c] for j in range(c)]
        basis_candidates.append(v)
        plus_candidates.append([a+b for a, b in zip(v, cv)])
        minus_candidates.append([a-b for a, b in zip(v, cv)])
    result = []
    for candidates in (basis_candidates, plus_candidates, minus_candidates):
        basis = independent_exponent_vectors(c, candidates)
        sparse = [[(i,a) for i,a in enumerate(x) if a] for x in basis]
        gram = [[Q(sum(a*b*ramanujan(c,i-j) for i,a in x for j,b in y),len(h))
                 for y in sparse] for x in sparse]
        result.append(diagonalize(gram))
    assert len(result[0]) == phi(c)//len(h)
    assert len(result[1])+len(result[2]) == len(result[0])
    assert isometric(result[0], result[1]+result[2])
    return tuple(result)


def quadratic_discriminants(c):
    answer = []
    for m in [-30,-15,-10,-6,-5,-3,-2,-1,2,3,5,6,10,15,30]:
        delta = m if m % 4 == 1 else 4*m
        if c % abs(delta) == 0:
            answer.append(delta)
    return answer


def field_record(label, diagonal, plus, minus, q6=0):
    return (label, tuple(Q(x) for x in diagonal),
            tuple(Q(x) for x in plus), tuple(Q(x) for x in minus), q6)


@lru_cache(None)
def field_options(f, k):
    c = gcd(2*f, f*f)
    if f == 6:
        return (field_record("Q", [1], [1], []),
                field_record("Q(sqrt(-3))", [2,6], [2], [6], 1))
    if k >= 4:
        assert c in POLY, (f, k, c)
        units = [a for a in range(c) if gcd(a,c) == 1]
        records = []
        for size in range(1, len(units)+1):
            if len(units) % size or len(units)//size > k:
                continue
            for tail in combinations(units[1:], size-1):
                h = {1, *tail}
                if any(a*b % c not in h for a in h for b in h):
                    continue
                forms = fixed_forms(c, tuple(sorted(h)))
                records.append(field_record(
                    f"zeta{c}:H={','.join(map(str,sorted(h)))}", *forms))
        return tuple(records)
    records = [] if f == 540 else [field_record("Q", [1], [1], [])]
    if k >= 2:
        for delta in quadratic_discriminants(c):
            d = abs(delta if delta % 4 == 1 else delta//4)
            diagonal = [2, 2*d]
            plus, minus = (diagonal, []) if delta > 0 else ([2], [2*d])
            records.append(field_record(f"quadratic_disc={delta}", diagonal, plus, minus))
    if k >= 3 and c % 9 == 0:
        assert c % 27 != 0, (f,k,c)
        records.append(field_record("real_cubic_conductor9", [3,6,Q(9,2)],
                                    [3,6,Q(9,2)], []))
    return tuple(records)


@lru_cache(None)
def block_decompositions(f, k):
    options = field_options(f, k)
    result = []
    def visit(left, start, chosen):
        if left == 0:
            result.append(tuple(chosen))
            return
        for i in range(start, len(options)):
            e = len(options[i][1])
            if e <= left:
                visit(left-e, i, chosen+[i])
    visit(k, 0, [])
    out = []
    for choice in result:
        labels = tuple(options[i][0] for i in choice)
        whole = tuple(x/f for i in choice for x in options[i][1])
        plus = tuple(x/f for i in choice for x in options[i][2])
        minus = tuple(x/f for i in choice for x in options[i][3])
        q6 = sum(options[i][4] for i in choice)
        out.append((labels, whole, plus, minus, q6))
    return tuple(out)


def analyze(profile, double_degree, allowed_states):
    counts = Counter(profile)
    if double_degree is not None:
        counts[double_degree] -= 2
    blocks = [(5400//a, k) for a, k in sorted(counts.items(), reverse=True) if k]
    alternatives = [block_decompositions(f, k) for f, k in blocks]
    allowed = {(s[1],s[2]): (['commutative'] if double_degree is None else s[3])
               for s in allowed_states}
    surviving = []
    tested = 0
    kinds_tried = Counter()
    kinds_passed = Counter()
    for assignment in product(*alternatives):
        q6 = sum(x[4] for x in assignment)
        q = sum(len(x[3]) for x in assignment)
        if (q6,q) not in allowed:
            continue
        whole = (Q(1,5400),)+tuple(a for x in assignment for a in x[1])
        plus = (Q(1,5400),)+tuple(a for x in assignment for a in x[2])
        minus = tuple(a for x in assignment for a in x[3])
        # The full discriminant squareclass is independent of the matrix block.
        if squareclass(prod(whole)) != 1:
            continue
        tested += 1
        kept = []
        for kind in allowed[q6,q]:
            kinds_tried[kind] += 1
            if kind == 'commutative':
                passes = (isometric(whole, [1]*11)
                          and isometric(minus, [2]*q)
                          and isometric(plus, [1]*(11-2*q)+[2]*q))
            elif kind == 'symplectic':
                f = 5400//double_degree
                b = q+3
                passes = isometric(plus+(Q(2,f),), [1]*(13-2*b)+[2]*b)
                if f == 6:
                    # Round32 codegree-six matrix theorem: exactly five dual
                    # pairs, with rational quaternion block (-3,-1).
                    passes = (passes and q == 2 and q6 == 0 and isometric(
                        whole+(Q(1,3),Q(1),Q(1,3),Q(1)), [1]*13))
            else:
                assert kind == 'orthogonal'
                passes = orthogonal_matrix_possible(whole,minus,q,5400//double_degree)
            if passes:
                kept.append(kind)
                kinds_passed[kind] += 1
        if kept:
            surviving.append({
                'fields': [{'formal_codegree': f, 'fields': list(a[0])}
                           for (f,k),a in zip(blocks,assignment)],
                'q6': q6, 'q': q, 'duality_types': kept,
                'whole_form': [str(a) for a in whole],
                'fixed_linear_form': [str(a) for a in plus],
                'skew_linear_form': [str(a) for a in minus],
            })
    return {'tested_assignments': tested, 'duality_tests': dict(kinds_tried),
            'surviving_duality_tests': dict(kinds_passed),
            'surviving_assignments': surviving, 'excluded': not surviving}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', type=Path, default=DEFAULT_BASE)
    parser.add_argument('--output', type=Path, default=HERE/'trace_form_results.json')
    args = parser.parse_args()
    base = args.baseline.resolve()
    sys.path.insert(0, str(base))
    from endpoint_core import degree_profiles
    from field_discriminant_profiles import profile_states, placement_states
    summary = json.loads((base/'endpoint_verification.json').read_text())
    comm = summary['field_and_certificate_summary']['11']['unresolved_cases']
    noncomm = summary['field_and_certificate_summary']['13']['unresolved_cases']
    profiles = list(degree_profiles())
    records = []
    for index, double_degree in comm+noncomm:
        p = profiles[index]
        target, states = (profile_states(p) if double_degree is None
                          else placement_states(p,double_degree))
        result = analyze(p,double_degree,states)
        result.update({'index': index, 'double_degree': double_degree,
                       'profile': p})
        records.append(result)
        if result['excluded']:
            print('EXCLUDED', index, double_degree, 'tested', result['tested_assignments'], flush=True)
    result = {'status': 'PASS', 'method': 'exact positive rational trace forms',
              'input_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in [base/'endpoint_verification.json', Path(__file__)]},
              'records': records,
              'commutative_excluded': [r['index'] for r in records if r['double_degree'] is None and r['excluded']],
              'noncommutative_excluded': [[r['index'],r['double_degree']] for r in records if r['double_degree'] is not None and r['excluded']]}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print({k:result[k] for k in ['commutative_excluded','noncommutative_excluded']})


if __name__ == '__main__':
    main()
