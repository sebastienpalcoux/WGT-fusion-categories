"""Complete exact rank-thirteen canonical/full-field trace-form enumeration."""
from pathlib import Path
from collections import Counter
from functools import lru_cache
from itertools import combinations
from concurrent.futures import ProcessPoolExecutor
from math import gcd
import argparse,json,time,hashlib
from endpoint_core import degree_profiles
from generic_fields import commutative_assignments
from cheap_screen import residue_fail
HERE=Path(__file__).resolve().parent

def valuation(a,p):
    n=0
    while a%p==0:n+=1;a//=p
    return n

def forced_modulus(a,b,m):
    ans=1
    for p in(2,3,5):
        k=valuation(m,p);alpha=valuation(a,p);beta=valuation(b,p)
        ans*=p**min(k,beta+(max(0,k-alpha-beta)+1)//2)
    return ans

def modulus_failure(profile):
    counts=Counter(profile)
    for a,b in combinations([a for a,k in counts.items() if k==1],2):
        m=5400
        for c in counts:
            if c not in(a,b):m=gcd(m,c)
        if m<=1:continue
        for aa,bb in((a,b),(b,a)):
            q=forced_modulus(aa,bb,m)
            if q>=2*(aa-1):return {'a':aa,'b':bb,'modulus':m,'forced_modulus':q}
    return None

def analyze(task):
    index,profile=task;start=time.monotonic();base={'index':index,'profile':profile}
    if Counter(profile)[10]==1:
        return dict(base,excluded=True,gate='rational_ten',total_assignments=0,tested_assignments=0,surviving_assignments=[])
    residue=residue_fail(profile)
    if residue:
        return dict(base,excluded=True,gate='rational_residue',residue_fail=residue,total_assignments=0,tested_assignments=0,surviving_assignments=[])
    modulus=modulus_failure(profile)
    if modulus:
        return dict(base,excluded=True,gate='two_character_modulus',modulus_certificate=modulus,total_assignments=0,tested_assignments=0,surviving_assignments=[])
    data=commutative_assignments(profile,rank=13)
    return dict(base,**data,gate='trace_forms' if data['excluded'] else 'rows_required',seconds=time.monotonic()-start)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=62776);ap.add_argument('--workers',type=int,default=4);ap.add_argument('--output',type=Path,default=HERE/'trace_rank13.jsonl');args=ap.parse_args()
    assert not args.output.exists(),'Use a fresh output file.'
    start=time.monotonic();profiles=list(degree_profiles(left=12));assert len(profiles)==62776
    tasks=((i,profiles[i]) for i in range(args.start,min(args.stop,len(profiles))))
    counts=Counter();totals=Counter()
    with ProcessPoolExecutor(max_workers=args.workers) as pool,args.output.open('w') as out:
        for r in pool.map(analyze,tasks,chunksize=25):
            out.write(json.dumps(r,separators=(',',':'))+'\n');out.flush()
            counts[r['gate']]+=1;totals['all_assignments']+=r['total_assignments'];totals['determinant_compatible']+=r['tested_assignments'];totals['retained_assignments']+=len(r['surviving_assignments'])
            if r['index']%1000==0:print(r['index'],dict(counts),dict(totals),'seconds',round(time.monotonic()-start,2),flush=True)
    report={'status':'PASS','range':[args.start,args.stop],'profiles':sum(counts.values()),'gates':dict(counts),'field_totals':dict(totals),'seconds':time.monotonic()-start}
    args.output.with_suffix('.summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
