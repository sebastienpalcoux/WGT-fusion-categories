"""Collect immutable exact certificates and retain all unexcluded states."""
from pathlib import Path
from collections import Counter
import argparse,json,hashlib
HERE=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('inputs',nargs='+',type=Path);args=ap.parse_args();records={}
 for path in args.inputs:
  for line in path.read_text().splitlines():
   r=json.loads(line);key=(r['index'],r['assignment_index'])
   if key not in records or records[key]['certificate']is None or(r['certificate']is not None and r['certificate']['kind']=='linear_field_coordinate_lattice'):records[key]=r
 traces=[json.loads(line)for line in(HERE/'trace_rank13.jsonl').read_text().splitlines()]
 expected={(r['index'],i)for r in traces for i,a in enumerate(r['surviving_assignments'])}
 assert set(records)<=expected
 retained=sorted(key for key in expected if key not in records or records[key]['certificate']is None)
 solved={key for key,r in records.items()if r['certificate']is not None};complete_profiles=[r['index']for r in traces if not r['excluded']and all((r['index'],i)in solved for i in range(len(r['surviving_assignments'])))]
 report={'status':'EXCLUSION'if not retained else'COMPLETE_NECESSARY_CHECKPOINT','profiles':len(traces),'trace_retained_profiles':sum(not r['excluded']for r in traces),'trace_retained_field_assignments':len(expected),'row_records':len(records),'excluded_field_assignments':len(solved),'retained_field_assignments':len(retained),'fully_excluded_additional_profiles':len(complete_profiles),'retained_profiles':len({i for i,a in retained}),'unvisited_assignments':len(expected-set(records)),'visited_open_assignments':sum(r['certificate']is None for r in records.values()),'certificate_kinds':dict(Counter(r['certificate']['kind']for r in records.values()if r['certificate'])),'retained_states':[list(k)for k in retained],'records':[records[key]for key in sorted(records)],'input_sha256':{str(p.name):hashlib.sha256(p.read_bytes()).hexdigest()for p in args.inputs}}
 args.output.write_text(json.dumps(report,separators=(',',':'))+'\n')
 print(json.dumps({k:v for k,v in report.items()if k not in('records','retained_states','input_sha256')},indent=2),flush=True)
if __name__=='__main__':main()
