"""Exactly verified modular carry cuts for integer source multiplicities."""
from math import gcd,lcm
from fractions import Fraction
from exact_certificate_checks import verify_certificate

def span_modular_functional(active,target):
    n=len(target)
    for p in(2,3,5,7,11,13,17,19,23,29,31):
        basis=[]
        for row in active:
            r=[x%p for x in row]
            for j,b in basis:
                if r[j]:
                    a=r[j];r=[(x-a*y)%p for x,y in zip(r,b)]
            j=next((i for i,x in enumerate(r)if x),None)
            if j is not None:
                a=pow(r[j],-1,p);basis.append((j,[a*x%p for x in r]))
        pivots={j for j,b in basis}
        for free in range(n):
            if free in pivots:continue
            z=[0]*n;z[free]=1
            for j,b in reversed(basis):z[j]=-sum(x*y for x,y in zip(b,z))%p
            if sum(a*b for a,b in zip(z,target))%p:return z,p
    # Exact HNF fallback; the resulting single modular functional is all
    # that the portable checker needs. SymPy is proposer-only.
    from sympy import Matrix
    from sympy.matrices.normalforms import hermite_normal_form
    p=65521;basis=[];chosen=[]
    for index,row in enumerate(active):
        r=[x%p for x in row]
        for j,b in basis:
            if r[j]:
                a=r[j];r=[(x-a*y)%p for x,y in zip(r,b)]
        j=next((i for i,x in enumerate(r)if x),None)
        if j is not None:
            a=pow(r[j],-1,p);basis.append((j,[a*x%p for x in r]));chosen.append(index)
    coords=[j for j,b in basis];matrix=Matrix([[v[j]for v in active]for j in coords]);determinant=abs(int(matrix[:,chosen].det(method='domain-ge')))
    if not determinant:return None
    h=hermite_normal_form(matrix,D=determinant);n=len(coords);values=[Fraction(0)]*n
    for i in reversed(range(n)):values[i]=(Fraction(target[coords[i]])-sum(int(h[i,j])*values[j]for j in range(i+1,n)))/int(h[i,i])
    index=next((i for i,y in enumerate(values)if y.denominator>1),None)
    if index is None:return None
    functional=[]
    for j in range(n):functional.append((Fraction(j==index)-sum(functional[k]*int(h[k,j])for k in range(j)))/int(h[j,j]))
    modulus=lcm(*(x.denominator for x in functional));z=[0]*len(target)
    for j,x in zip(coords,functional):z[j]=int(x*modulus)%modulus
    goal=sum(a*b for a,b in zip(z,target))
    # Small prime powers often provide the same obstruction much more compactly.
    for p in(2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97):
        power=p
        while modulus%power==0:
            if goal%power:return [a%power for a in z],power
            power*=p
    assert goal%modulus and all(sum(a*b for a,b in zip(z,v))%modulus==0 for v in active)
    return z,modulus

def append_cut(vectors,target,cut):
    z=cut['coefficients'];q=cut['modulus'];assert type(q)is int and q>=2 and len(z)==len(target)
    assert all(type(a)is int for a in z)and type(cut['target_residue'])is int
    residue=sum(a*b for a,b in zip(z,target))%q;assert residue==cut['target_residue']
    rows=[tuple(v)+(sum(a*b for a,b in zip(z,v))%q,)for v in vectors]
    rows.append((0,)*len(target)+(-1,))
    return rows,tuple(target)+(residue,)

def verify_carry(vectors,target,certificate):
    current=[tuple(v)for v in vectors];goal=tuple(target)
    for cut in certificate['cuts']:current,goal=append_cut(current,goal,cut)
    return verify_certificate(current,goal,certificate['separator'])

def propose_carry(vectors,target,max_cuts=100,verbose=False):
    import numpy as np
    from scipy.optimize import linprog
    from scan_coupled import certificate
    current=[tuple(v)for v in vectors];goal=tuple(target);cuts=[]
    for iteration in range(max_cuts+1):
        mat=np.asarray(current,dtype=float).T;scales=np.maximum(np.max(np.abs(mat),axis=1),np.abs(goal));scales=np.maximum(scales,1)
        sol=linprog(np.zeros(len(current)),A_eq=mat/scales[:,None],b_eq=np.asarray(goal)/scales,bounds=(0,None),method='highs')
        if not sol.success:
            sep=certificate(current,goal)
            if sep is None:return None
            cert={'kind':'integer_carry_separator','cuts':cuts,'separator':sep};assert verify_carry(vectors,target,cert);return cert
        if iteration==max_cuts:return None
        support=[v for v,x in zip(current,sol.x)if x>1e-7]
        found=span_modular_functional(support,goal)
        if found is None:
            if verbose:print('NO MODULAR SUPPORT CUT',iteration,flush=True)
            return None
        z,q=found;residue=sum(a*b for a,b in zip(z,goal))%q;assert residue
        assert all(sum(a*b for a,b in zip(z,v))%q==0 for v in support)
        cut={'coefficients':z,'modulus':q,'target_residue':residue};cuts.append(cut);current,goal=append_cut(current,goal,cut)
        if verbose:print('CARRY',iteration+1,'modulus',q,'support',len(support),'rows',len(current),flush=True)
    return None
