"""Integer coordinate covariance for a full orbit of linear characters.

The rational fixed-field basis uses free ambient integral coordinates.
Thus every integral field entry has integral coordinates in this basis,
even when not every integral coordinate vector is an algebraic integer.
Only explicit short-vector/parity witnesses are used as exclusions.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations,product
from math import gcd
from pathlib import Path
import json,time
from fixed_lattice import fixed_lattice
from fixed_field_rows import fixed_blocks
from orbit_pairs import powers,lattice_vectors

HERE=Path(__file__).resolve().parent

def inverse(matrix):
    n=len(matrix);a=[[F(x)for x in row]+[F(i==j)for j in range(n)]for i,row in enumerate(matrix)]
    for j in range(n):
        k=next(k for k in range(j,n)if a[k][j]);a[j],a[k]=a[k],a[j];p=a[j][j];a[j]=[x/p for x in a[j]]
        for k in range(n):
            if k!=j and a[k][j]:
                q=a[k][j];a[k]=[x-q*y for x,y in zip(a[k],a[j])]
    return tuple(tuple(row[n:])for row in a)

@lru_cache(None)
def coordinate_covariance(f,label):
    if label=='Q':return ((F(f),),),((F(1),),),(1,)
    if label=='Q(sqrt(-3))':label='quadratic_disc=-3'
    if label.startswith('quadratic_disc='):
        delta=int(label.split('=')[1]);odd=delta%4==1
        g=((F(2),F(1)),(F(1),F((1+abs(delta))//2)))if odd else((F(2),F(0)),(F(0),F(abs(delta),2)))
        conjugation=((F(1),F(0)),(F(0),F(1)))if delta>0 else(((F(1),F(1)),(F(0),F(-1)))if odd else((F(1),F(0)),(F(0),F(-1))))
        unit=(1,0)
    else:
        if label=='real_cubic_conductor9':c,h=9,(1,8)
        else:
            cstr,hstr=label.split(':H=');c=int(cstr[4:]);h=tuple(map(int,hstr.split(',')))
        basis,ambient_gram,traces=fixed_lattice(c,h,False);e=len(basis);n=len(basis[0]);pp=powers(c)
        assert basis[0]==(F(1),)+(F(0),)*(n-1)
        free=[]
        for i in range(e):
            free.append(next(j for j in range(n)if all(basis[k][j]==int(i==k)for k in range(e))))
        conjugates=[]
        for x in basis:
            nz=[(j,a)for j,a in enumerate(x)if a]
            conjugates.append(tuple(sum(a*pp[(-j)%c][i]for j,a in nz)for i in range(n)))
        conjugation=tuple(tuple(conjugates[j][free[i]]for j in range(e))for i in range(e))
        g=tuple(tuple(x/len(h)for x in row)for row in ambient_gram);unit=(1,)+(0,)*(e-1)
    inv=inverse(g);return tuple(tuple(f*x for x in row)for row in inv),conjugation,unit

def norm(h,u):return sum(u[i]*u[j]*h[i][j]for i in range(len(u))for j in range(len(u)))
def skew(c,u):return all(sum(c[j][i]*u[j]for j in range(len(u)))==-u[i]for i in range(len(u)))

@lru_cache(None)
def field_lattice_failure(f,label):
    h,c,unit=coordinate_covariance(f,label);e=len(h)
    for i in range(e):
        for j in range(e):
            if h[i][j].denominator!=1:return {'kind':'linear_field_coordinate_lattice','formal_codegree':f,'field':label,'failure':'nonintegral_covariance','entry':[i,j]}
    for u,n in lattice_vectors(h,2):
        if n==1 or(n==2 and sum(a*b for a,b in zip(u,unit))):
            return {'kind':'linear_field_coordinate_lattice','formal_codegree':f,'field':label,'failure':'unit_norm'if n==1 else'unit_coordinate_root','functional':list(u),'norm':int(n)}
    # A finite witness search; absence is not an exclusion claim.
    for support in range(1,min(3,e)+1):
        for positions in combinations(range(e),support):
            for signs in product((-1,1),repeat=support):
                u=[0]*e
                for i,s in zip(positions,signs):u[i]=s
                if skew(c,u):
                    n=norm(h,u);assert n.denominator==1
                    if n%2:return {'kind':'linear_field_coordinate_lattice','formal_codegree':f,'field':label,'failure':'odd_skew_norm','functional':u,'norm':int(n)}
    return None

def assignment_failure(assignment):
    for block in assignment['fields']:
        for label in block['fields']:
            cert=field_lattice_failure(block['formal_codegree'],label)
            if cert:return cert
    return None

def verify_field_lattice(assignment,cert):
    assert cert['kind']=='linear_field_coordinate_lattice';f,label=cert['formal_codegree'],cert['field']
    assert any(b['formal_codegree']==f and label in b['fields']for b in assignment['fields'])
    h,c,unit=coordinate_covariance(f,label);failure=cert['failure']
    if failure=='nonintegral_covariance':
        i,j=cert['entry'];assert h[i][j].denominator!=1;return True
    u=cert['functional'];assert len(u)==len(h)and all(type(x)is int for x in u)
    n=norm(h,u);assert n==cert['norm']
    if failure=='unit_norm':assert n==1
    elif failure=='unit_coordinate_root':assert n==2 and sum(a*b for a,b in zip(u,unit))!=0
    else:assert failure=='odd_skew_norm'and n.denominator==1 and n%2==1 and skew(c,u)
    return True

def main():
    from collections import Counter
    traces=[json.loads(line)for line in(HERE/'trace_rank13.jsonl').read_text().splitlines()];start=time.monotonic();counts=Counter();fields={};total=profiles=0
    path=HERE/'linear_field_lattice_pass.jsonl';assert not path.exists()
    with path.open('w')as out:
        for r in traces:
            rejected=0
            for ai,a in enumerate(r['surviving_assignments']):
                total+=1;cert=assignment_failure(a)
                if cert is None:continue
                assert verify_field_lattice(a,cert);pieces,double=fixed_blocks(a,None)
                record={'index':r['index'],'assignment_index':ai,'profile':r['profile'],'fields':a['fields'],'q6':a['q6'],'q':a['q'],'pieces':pieces,'double':None,'stage':'linear_field_coordinate_lattice','initial_rows':0,'rows':None,'vectors':None,'certificate':cert}
                out.write(json.dumps(record,separators=(',',':'))+'\n');counts[cert['failure']]+=1;rejected+=1;fields[(cert['formal_codegree'],cert['field'])]=cert
            if r['surviving_assignments']and rejected==len(r['surviving_assignments']):profiles+=1
    report={'status':'PASS','field_assignments':total,'excluded_assignments':sum(counts.values()),'failure_kinds':dict(counts),'remaining_assignments':total-sum(counts.values()),'fully_excluded_profiles':profiles,'field_witnesses':[fields[k]for k in sorted(fields)],'seconds':time.monotonic()-start}
    path.with_suffix('.summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='field_witnesses'},indent=2),flush=True)
if __name__=='__main__':main()
