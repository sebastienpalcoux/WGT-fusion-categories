#!/usr/bin/env python3
"""Exact orthogonal-frame obstruction for a commutative rational character table.

The supplied scalar multisets are necessary row data. The upstream rank-13
checker regenerates those data; this script independently expands all column
permutations, verifies integer row norms, and searches the exact orthogonality
graph for the required 12-clique. It uses only the Python standard library.
"""
from pathlib import Path
from itertools import permutations,product
import argparse,json,hashlib,time

HERE=Path(__file__).resolve().parent

def expanded_rows(data):
    weights=tuple(data["expanded_column_weights"])
    assert len(weights)==data["rank"]==13 and weights[0]==1
    assert sum(weights)==data["dimension"]==5400
    rows=set()
    for row in data["rows"]:
        assert row["selfdual"]
        choices=[]
        for opts in row["scalar_multiset_options"]:
            values=set()
            for xs in opts: values.update(permutations(xs))
            choices.append(tuple(sorted(values)))
        for pieces in product(*choices):
            v=(row["dimension"],)+tuple(x for p in pieces for x in p)
            assert len(v)==13
            assert sum(a*x for a,x in zip(weights,v))==0
            assert sum(a*x*x for a,x in zip(weights,v))==5400
            rows.add(v)
    return weights,tuple(sorted(rows))

def adjacency(weights,rows):
    weighted=[tuple(a*x for a,x in zip(weights,row)) for row in rows]
    adj=[0]*len(rows)
    for i,row in enumerate(rows):
        for j in range(i):
            if sum(x*y for x,y in zip(row,weighted[j]))==0:
                adj[i]|=1<<j; adj[j]|=1<<i
    return tuple(adj)

def clique_search(adj,target,node_limit=0):
    n=len(adj);stats={"nodes":0,"color_prunes":0,"cardinality_prunes":0,
                     "largest_partial":0,"largest_root_color":0}
    witness=None
    def colors(P):
        order=[];bounds=[];c=0
        while P:
            c+=1;available=P
            while available:
                bit=available&-available;v=bit.bit_length()-1
                order.append(v);bounds.append(c)
                P^=bit;available^=bit;available&=~adj[v]
        return order,bounds
    def visit(P,chosen):
        nonlocal witness
        stats["nodes"]+=1
        stats["largest_partial"]=max(stats["largest_partial"],len(chosen))
        if node_limit and stats["nodes"]>node_limit:
            raise RuntimeError("UNRESOLVED: optional producer node limit reached")
        if len(chosen)+P.bit_count()<target:
            stats["cardinality_prunes"]+=1;return False
        order,bounds=colors(P)
        if not chosen:stats["largest_root_color"]=max(bounds,default=0)
        for i in range(len(order)-1,-1,-1):
            if len(chosen)+bounds[i]<target:
                stats["color_prunes"]+=1;return False
            v=order[i];next_chosen=chosen+(v,)
            if len(next_chosen)==target:
                witness=next_chosen;return True
            if visit(P&adj[v],next_chosen):return True
            P&=~(1<<v)
        return False
    found=visit((1<<n)-1,())
    if found:
        assert witness and len(witness)==target
        assert all((adj[v]>>u)&1 for i,v in enumerate(witness) for u in witness[:i])
    return found,witness,stats

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",type=Path,default=HERE/"open8370_scalar_rows.json")
    ap.add_argument("--output",type=Path,default=HERE/"orthogonal_frame_result.json")
    ap.add_argument("--node-limit",type=int,default=0)
    args=ap.parse_args();start=time.monotonic()
    raw=args.input.read_bytes();data=json.loads(raw)
    weights,rows=expanded_rows(data)
    print("Expanded rows",len(rows),flush=True)
    adj=adjacency(weights,rows)
    edges=sum(x.bit_count() for x in adj)//2
    print("Orthogonality edges",edges,"seconds",round(time.monotonic()-start,2),flush=True)
    found,witness,stats=clique_search(adj,data["rank"]-1,args.node_limit)
    out={"status":"OPEN" if found else "PASS_EXCLUSION",
         "profile_index":data["profile_index"],"assignment_index":data["assignment_index"],
         "input_sha256":hashlib.sha256(raw).hexdigest(),
         "aggregate_rows":len(data["rows"]),"expanded_rows":len(rows),"edges":edges,
         "target_frame_size":data["rank"]-1,"search":stats,
         "witness":None if witness is None else [list(rows[i]) for i in witness],
         "seconds":time.monotonic()-start,
         "scope":"Only this fixed rational field assignment; upstream row coverage must also be verified."}
    args.output.write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out,indent=2),flush=True)

if __name__=="__main__":
    main()

