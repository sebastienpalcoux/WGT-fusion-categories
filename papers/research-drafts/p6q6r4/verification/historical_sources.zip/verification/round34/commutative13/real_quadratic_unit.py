"""The real quadratic traceless norm cannot equal one."""
from pathlib import Path
import json,time
from fixed_field_rows import fixed_blocks
HERE=Path(__file__).resolve().parent

def real_unit_failure(assignment):
    for block in assignment['fields']:
        f=block['formal_codegree']
        for label in block['fields']:
            if label.startswith('quadratic_disc='):
                delta=int(label.split('=')[1])
                if delta==2*f:return {'kind':'real_quadratic_unit_norm','formal_codegree':f,'discriminant':delta}
    return None

def verify_real_unit(assignment,certificate):
    assert certificate['kind']=='real_quadratic_unit_norm'
    f,delta=certificate['formal_codegree'],certificate['discriminant']
    assert type(f)is int and type(delta)is int and delta==2*f>0
    assert any(block['formal_codegree']==f and f'quadratic_disc={delta}'in block['fields']for block in assignment['fields'])
    return True

def main():
    traces=[json.loads(line)for line in(HERE/'trace_rank13.jsonl').read_text().splitlines()];start=time.monotonic();excluded=total=profiles=0
    path=HERE/'real_quadratic_unit_pass.jsonl';assert not path.exists()
    with path.open('w')as out:
        for r in traces:
            rejected=0
            for ai,a in enumerate(r['surviving_assignments']):
                total+=1;cert=real_unit_failure(a)
                if cert is None:continue
                assert verify_real_unit(a,cert);pieces,double=fixed_blocks(a,None)
                record={'index':r['index'],'assignment_index':ai,'profile':r['profile'],'fields':a['fields'],'q6':a['q6'],'q':a['q'],'pieces':pieces,'double':None,'stage':'real_quadratic_unit_norm','initial_rows':0,'rows':None,'vectors':None,'certificate':cert}
                out.write(json.dumps(record,separators=(',',':'))+'\n');excluded+=1;rejected+=1
            if r['surviving_assignments']and rejected==len(r['surviving_assignments']):profiles+=1
    report={'status':'PASS','field_assignments':total,'excluded_assignments':excluded,'remaining_assignments':total-excluded,'fully_excluded_profiles':profiles,'seconds':time.monotonic()-start}
    path.with_suffix('.summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
