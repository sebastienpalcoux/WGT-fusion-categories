#!/usr/bin/env python3
"""Independent exact arithmetic audit of the one-M2 reconstruction formulas.

Only the Python standard library is used. Quaternion products are computed
from the basis multiplication table; separate 2x2 matrix multiplication
over rational/quadratic arithmetic checks the splitting representations.
The finite audit supplements the manuscript's algebraic proof. It does
not assert that any sampled element or table is fusion-ring data.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import permutations, product
from math import isqrt
from pathlib import Path
from random import Random
import hashlib
import json
import time

HERE = Path(__file__).resolve().parent
SEED = 5400342026


def determinant3(a):
    return (a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
            - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
            + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]))


def permutation_sign(p):
    return -1 if sum(p[i] > p[j] for i in range(3)
                     for j in range(i + 1, 3)) % 2 else 1


def solve3(a, b):
    """Rational elimination, independent of quaternion coordinates."""
    rows = [[Q(x) for x in row] + [Q(y)] for row, y in zip(a, b)]
    for col in range(3):
        pivot = next(i for i in range(col, 3) if rows[i][col])
        rows[col], rows[pivot] = rows[pivot], rows[col]
        scale = rows[col][col]
        rows[col] = [x / scale for x in rows[col]]
        for i in range(3):
            if i != col:
                scale = rows[i][col]
                rows[i] = [x - scale * y for x, y in zip(rows[i], rows[col])]
    return tuple(row[-1] for row in rows)


def rational_square_root(a):
    if a <= 0:
        return None
    n, d = isqrt(a.numerator), isqrt(a.denominator)
    return Q(n, d) if n * n == a.numerator and d * d == a.denominator else None


class QuadraticArithmetic:
    """Exact u+v*sqrt(rad); rad=None restricts all inputs to Q."""
    def __init__(self, rad=None):
        self.rad = Q(rad) if rad is not None else None
        self.zero = (Q(0), Q(0))
        self.one = (Q(1), Q(0))

    def rational(self, x):
        return Q(x), Q(0)

    def add(self, x, y):
        return x[0] + y[0], x[1] + y[1]

    def scale(self, x, c):
        return x[0] * c, x[1] * c

    def neg(self, x):
        return -x[0], -x[1]

    def mul(self, x, y):
        if self.rad is None:
            assert x[1] == y[1] == 0
            return x[0] * y[0], Q(0)
        return (x[0] * y[0] + self.rad * x[1] * y[1],
                x[0] * y[1] + x[1] * y[0])

    def conjugate(self, x):
        return x[0], -x[1]

    def trace_matrix(self, a):
        return self.add(a[0][0], a[1][1])

    def multiply_matrices(self, a, b):
        return tuple(tuple(self.add(self.mul(a[i][0], b[0][j]),
                                    self.mul(a[i][1], b[1][j]))
                           for j in range(2)) for i in range(2))

    def transpose(self, a):
        return tuple(tuple(a[j][i] for j in range(2)) for i in range(2))

    def pure_matrix(self, a):
        half_trace = self.scale(self.trace_matrix(a), Q(1, 2))
        return tuple(tuple(self.add(a[i][j], self.neg(half_trace))
                           if i == j else a[i][j]
                           for j in range(2)) for i in range(2))

    def gram(self, a, b):
        return self.scale(self.trace_matrix(self.multiply_matrices(a, b)), 2)

    def volume(self, a, b, c):
        abc = self.multiply_matrices(self.multiply_matrices(a, b), c)
        return self.scale(self.trace_matrix(abc), 4)

    def determinant3(self, a):
        ans = self.zero
        for p in permutations(range(3)):
            term = self.one
            for i in range(3):
                term = self.mul(term, a[i][p[i]])
            ans = self.add(ans, self.scale(term, permutation_sign(p)))
        return ans


class QuaternionArithmetic:
    """Q-basis 1,i,j,k, with i^2=a, j^2=b and k=ij=-ji."""
    def __init__(self, a, b):
        self.a, self.b = Q(a), Q(b)
        assert self.a and self.b
        a, b = self.a, self.b
        self.basis = tuple(tuple(Q(i == j) for i in range(4)) for j in range(4))
        self.one = self.basis[0]
        self.zero = (Q(0),) * 4
        self.table = {
            (1, 1): (a, 0), (2, 2): (b, 0), (3, 3): (-a * b, 0),
            (1, 2): (Q(1), 3), (2, 1): (Q(-1), 3),
            (1, 3): (a, 2), (3, 1): (-a, 2),
            (2, 3): (-b, 1), (3, 2): (b, 1),
        }
        for i in range(4):
            self.table[0, i] = Q(1), i
            self.table[i, 0] = Q(1), i
        # A positive rational involution in all four real sign cases.
        if a < 0 and b < 0:
            self.star_signs = (1, -1, -1, -1)
            self.involution_type = 'symplectic'
        elif a < 0:
            self.star_signs = (1, -1, 1, 1)
            self.involution_type = 'orthogonal'
        elif b < 0:
            self.star_signs = (1, 1, -1, 1)
            self.involution_type = 'orthogonal'
        else:
            self.star_signs = (1, 1, 1, -1)
            self.involution_type = 'orthogonal'

    def add(self, x, y):
        return tuple(a + b for a, b in zip(x, y))

    def scale(self, x, c):
        return tuple(c * a for a in x)

    def mul(self, x, y):
        out = [Q(0)] * 4
        for i, a in enumerate(x):
            for j, b in enumerate(y):
                coefficient, position = self.table[i, j]
                out[position] += a * b * coefficient
        return tuple(out)

    def trace(self, x):
        return 2 * x[0]

    def pure(self, x):
        return (Q(0),) + x[1:]

    def conjugate(self, x):
        return (x[0],) + tuple(-y for y in x[1:])

    def star(self, x):
        return tuple(s * y for s, y in zip(self.star_signs, x))

    def gram(self, u, v):
        return 2 * self.trace(self.mul(u, v))

    def volume(self, u, v, w):
        return 4 * self.trace(self.mul(self.mul(u, v), w))

    def splitting_representation(self, witness=None):
        """Independent explicit matrices; norm witnesses give rational ones."""
        a, b = self.a, self.b
        square_root = rational_square_root(a)
        if witness is not None:
            u, v = map(Q, witness)
            assert u * u - a * v * v == b
            field = QuadraticArithmetic()
            r, z = field.rational, field.zero
            i = ((z, r(a)), (r(1), z))
            j = ((r(u), r(-a * v)), (r(v), r(-u)))
        elif square_root is not None:
            field = QuadraticArithmetic()
            r, z = field.rational, field.zero
            i = ((r(square_root), z), (z, r(-square_root)))
            j = ((z, r(b)), (r(1), z))
        else:
            field = QuadraticArithmetic(a)
            r, z = field.rational, field.zero
            alpha = Q(0), Q(1)
            i = ((alpha, z), (z, field.neg(alpha)))
            j = ((z, r(b)), (r(1), z))
        identity = ((field.one, field.zero), (field.zero, field.one))
        basis = identity, i, j, field.multiply_matrices(i, j)

        def embed(x):
            return tuple(tuple(sum_field(field,
                    (field.scale(base[row][col], coefficient)
                     for base, coefficient in zip(basis, x)))
                    for col in range(2)) for row in range(2))
        return field, embed


def sum_field(field, values):
    out = field.zero
    for value in values:
        out = field.add(out, value)
    return out


def matrix_triple_checks(field, matrices, counts):
    s = tuple(field.trace_matrix(a) for a in matrices)
    u = tuple(field.pure_matrix(a) for a in matrices)
    h = tuple(tuple(field.gram(x, y) for y in u) for x in u)
    omega = field.volume(*u)
    assert field.mul(omega, omega) == field.neg(field.determinant3(h))
    for p in permutations(range(3)):
        assert field.volume(*(u[i] for i in p)) == field.scale(omega, permutation_sign(p))
        counts['matrix_alternation_checks'] += 1
    symmetric = sum_field(field, (
        field.mul(field.mul(s[0], s[1]), s[2]),
        field.mul(s[0], h[1][2]), field.mul(s[1], h[0][2]),
        field.mul(s[2], h[0][1])))
    direct = field.trace_matrix(field.multiply_matrices(
        field.multiply_matrices(matrices[0], matrices[1]), matrices[2]))
    assert direct == field.scale(field.add(symmetric, omega), Q(1, 4))
    transposed = tuple(field.transpose(a) for a in matrices)
    tu = tuple(field.pure_matrix(a) for a in transposed)
    assert tuple(tuple(field.gram(x, y) for y in tu) for x in tu) == h
    assert field.volume(*tu) == field.neg(omega)
    opposite = field.trace_matrix(field.multiply_matrices(
        field.multiply_matrices(matrices[1], matrices[0]), matrices[2]))
    transposed_trace = field.trace_matrix(field.multiply_matrices(
        field.multiply_matrices(transposed[0], transposed[1]), transposed[2]))
    assert opposite == transposed_trace
    assert opposite == field.scale(field.add(symmetric, field.neg(omega)), Q(1, 4))
    counts['direct_matrix_triples'] += 1
    counts['matrix_transpose_opposite_checks'] += 1
    counts['matrix_volume_determinant_checks'] += 1
    counts['matrix_trace_expansion_checks'] += 1


def valuation(a, p):
    n, d, value = abs(a.numerator), a.denominator, 0
    while n % p == 0:
        n //= p
        value += 1
    while d % p == 0:
        d //= p
        value -= 1
    return value


def cases():
    split = [
        (Q(1), Q(1), None), (Q(4), Q(-3), None),
        (Q(1, 4), Q(5, 7), None),
        (Q(-1), Q(2), (1, 1)), (Q(2), Q(7), (3, 1)),
        (Q(3), Q(13), (4, 1)), (Q(-2), Q(9), (1, 2)),
        (Q(-5), Q(6), (1, 1)),
        (Q(2), Q(7, 4), (Q(3, 2), Q(1, 2))),
        (Q(-3, 2), Q(11, 8), (1, Q(1, 2))),
        (Q(5), Q(4), (3, 1)), (Q(-7), Q(8), (1, 1)),
    ]
    definite = [(-1, -1), (-1, -3), (-2, -5), (-3, -10),
                (-2, -7), (-3, -5), (-5, -7),
                (Q(-1, 2), Q(-3, 5)),
                (Q(-7, 3), Q(-11, 2)), (Q(-5, 4), Q(-3, 7))]
    indefinite = [(-1, 3, 3), (-2, 5, 5), (-3, 5, 5),
                  (-1, Q(3, 2), 3), (-2, Q(5, 3), 5), (-1, 7, 7)]
    for a, b, witness in split:
        if witness is None:
            assert rational_square_root(a) is not None
        else:
            u, v = map(Q, witness)
            assert u * u - a * v * v == b
        yield a, b, 'split', witness, {'type': 'rational_matrix_embedding'}
    for a, b in definite:
        a, b = Q(a), Q(b)
        assert a < 0 and b < 0
        # Reduced norm <1,-a,-b,ab> is positive definite, hence anisotropic.
        yield a, b, 'division', None, {'type': 'positive_definite_reduced_norm'}
    for a, b, p in indefinite:
        a, b = Q(a), Q(b)
        assert valuation(a, p) == 0 and valuation(b, p) % 2 == 1
        residue = a.numerator * pow(a.denominator, -1, p) % p
        assert pow(residue, (p - 1) // 2, p) == p - 1
        # Odd-prime Hilbert formula gives (a,b)_p=-1.
        yield a, b, 'division', None, {'type': 'odd_prime_Hilbert_minus_one', 'prime': p}


def quaternion_checks(rng, counts):
    descriptions = []
    denominators = (1, 2, 3, 4, 5, 7)
    for a, b, kind, witness, certificate in cases():
        algebra = QuaternionArithmetic(a, b)
        one, i, j, k = algebra.basis
        assert tuple(tuple(algebra.gram(x, y) for y in (i, j, k))
                     for x in (i, j, k)) == ((4*a, 0, 0), (0, 4*b, 0), (0, 0, -4*a*b))
        assert algebra.volume(i, j, k) == -8*a*b
        positive_gram = tuple(tuple(algebra.trace(algebra.mul(x, algebra.star(y)))
                                    for y in algebra.basis) for x in algebra.basis)
        assert all(positive_gram[u][v] == 0 for u in range(4)
                   for v in range(4) if u != v)
        assert all(positive_gram[u][u] > 0 for u in range(4))
        for x, y, z in product(algebra.basis, repeat=3):
            assert algebra.mul(algebra.mul(x, y), z) == algebra.mul(x, algebra.mul(y, z))
            counts['quaternion_basis_associativity_checks'] += 1
        field, embed = algebra.splitting_representation(witness)
        pool = [algebra.zero, one, i, j, k,
                (Q(1, 2), Q(1), Q(-1, 3), Q(2, 5)),
                (Q(-2), Q(3, 4), Q(5, 6), Q(-7, 8)),
                (Q(3, 7), Q(-1, 2), Q(4, 3), Q(5, 4))]
        pool += [tuple(Q(rng.randrange(-5, 6), rng.choice(denominators))
                       for _ in range(4)) for _ in range(24)]
        dependent = algebra.add(algebra.add(pool[5], algebra.scale(pool[6], 2)),
                                algebra.scale(one, 3))
        triples = [(i, j, k), (one, i, j), (i, i, j),
                   (pool[5], pool[6], pool[7]),
                   (pool[5], pool[6], dependent), (one, one, one),
                   (algebra.zero, pool[5], pool[6]), (k, j, i)]
        triples += [tuple(rng.choice(pool) for _ in range(3)) for _ in range(24)]
        anchor = (algebra.add(i, algebra.scale(j, Q(1, 2))),
                  algebra.add(j, algebra.scale(k, Q(1, 3))),
                  algebra.add(algebra.scale(i, Q(1, 5)), k))
        anchor_h = tuple(tuple(algebra.gram(x, y) for y in anchor) for x in anchor)
        assert determinant3(anchor_h) != 0
        anchor_volume = algebra.volume(*anchor)
        coordinate_cache = {}

        def coordinates(u):
            if u not in coordinate_cache:
                co = solve3(anchor_h, [algebra.gram(x, u) for x in anchor])
                reconstructed = algebra.zero
                for coefficient, vector in zip(co, anchor):
                    reconstructed = algebra.add(reconstructed, algebra.scale(vector, coefficient))
                assert reconstructed == u
                coordinate_cache[u] = co
            return coordinate_cache[u]

        for number, triple in enumerate(triples):
            s = tuple(algebra.trace(x) for x in triple)
            u = tuple(algebra.pure(x) for x in triple)
            h = tuple(tuple(algebra.gram(x, y) for y in u) for x in u)
            omega = algebra.volume(*u)
            assert omega * omega == -determinant3(h)
            for p in permutations(range(3)):
                assert algebra.volume(*(u[index] for index in p)) == permutation_sign(p) * omega
                counts['quaternion_alternation_checks'] += 1
            symmetric = (s[0]*s[1]*s[2] + s[0]*h[1][2]
                         + s[1]*h[0][2] + s[2]*h[0][1])
            direct = algebra.trace(algebra.mul(algebra.mul(triple[0], triple[1]), triple[2]))
            assert direct == (symmetric + omega) / 4
            opposite = algebra.trace(algebra.mul(triple[2], algebra.mul(triple[1], triple[0])))
            assert opposite == (symmetric - omega) / 4
            assert opposite == algebra.trace(algebra.mul(algebra.mul(triple[1], triple[0]), triple[2]))
            assert algebra.volume(*(algebra.star(x) for x in u)) == -omega
            assert determinant3(tuple(coordinates(x) for x in u)) * anchor_volume == omega
            for x, y in ((triple[0], triple[1]), (triple[1], triple[2]), (triple[2], triple[0])):
                assert algebra.star(algebra.mul(x, y)) == algebra.mul(algebra.star(y), algebra.star(x))
                assert algebra.conjugate(algebra.mul(x, y)) == algebra.mul(algebra.conjugate(y), algebra.conjugate(x))
                assert embed(algebra.mul(x, y)) == field.multiply_matrices(embed(x), embed(y))
                assert field.trace_matrix(embed(x)) == field.rational(algebra.trace(x))
                gram_from_k = (2 * algebra.trace(algebra.mul(x, algebra.star(algebra.star(y))))
                               - algebra.trace(x) * algebra.trace(y))
                assert gram_from_k == algebra.gram(algebra.pure(x), algebra.pure(y))
                positive_norm = algebra.trace(algebra.mul(x, algebra.star(x)))
                assert positive_norm >= 0 and (positive_norm == 0) == (x == algebra.zero)
                assert algebra.trace(algebra.mul(x, one)) == algebra.trace(x)
                counts['quaternion_to_matrix_product_checks'] += 1
                counts['positive_involution_checks'] += 1
                counts['K_to_H_normalization_checks'] += 1
            if number < 8:
                matrix_triple_checks(field, tuple(embed(x) for x in triple), counts)
                counts['splitting_matrix_triples'] += 1
            counts['quaternion_triples'] += 1
            counts['quaternion_trace_expansion_checks'] += 1
            counts['quaternion_volume_determinant_checks'] += 1
            counts['quaternion_opposite_checks'] += 1
            counts['rational_gram_coordinate_volume_checks'] += 1
        descriptions.append({'a': str(a), 'b': str(b), 'algebra_type': kind,
            'classification_witness': certificate,
            'positive_involution': algebra.involution_type,
            'splitting_arithmetic': 'Q' if field.rad is None else 'Q(sqrt('+str(field.rad)+'))',
            'triples': len(triples)})
    return descriptions


def direct_matrix_checks(rng, counts):
    descriptions = []
    for rad in (None, -1, -3, 2, 3, 5):
        field = QuadraticArithmetic(rad)
        for _ in range(32):
            matrices = []
            for _ in range(3):
                matrices.append(tuple(tuple((Q(rng.randrange(-4, 5), rng.randrange(1, 5)),
                    Q(0) if rad is None else Q(rng.randrange(-3, 4), rng.randrange(1, 5)))
                    for _ in range(2)) for _ in range(2)))
            matrix_triple_checks(field, tuple(matrices), counts)
            counts['arbitrary_matrix_triples'] += 1
        descriptions.append({'field': 'Q' if rad is None else 'Q(sqrt('+str(rad)+'))', 'triples': 32})
    return descriptions


def quadratic_linear_normalization_checks(counts):
    """Check the fundamental-discriminant basis factors directly.

    This verifies the algebraic pair contribution. The global identities
    additionally use character orthogonality, as explained in the report.
    """
    tested = []
    for discriminant in (-3, -4, -7, -8, -11, -15, -19, -20, -23, -24, -40, -120):
        rad = discriminant if discriminant % 4 == 1 else discriminant // 4
        field = QuadraticArithmetic(rad)
        for u, b in product(range(-3, 4), repeat=2):
            if discriminant % 4 == 1:
                s = 2*u+b
                alpha = Q(s, 2), Q(b, 2)
                assert (s-b) % 2 == 0
            else:
                s = 2*u
                alpha = Q(u), Q(b)
                assert s % 2 == 0
            conjugate = field.conjugate(alpha)
            norm = field.mul(alpha, conjugate)
            square_sum = field.add(field.mul(alpha, alpha), field.mul(conjugate, conjugate))
            pair_defect = field.add(field.scale(norm, 2), field.neg(square_sum))
            assert pair_defect == field.rational(abs(discriminant)*b*b)
            counts['imaginary_quadratic_integral_basis_checks'] += 1
        tested.append(discriminant)
    return tested


def main():
    started = time.monotonic()
    counts = Counter()
    rng = Random(SEED)
    quaternions = quaternion_checks(rng, counts)
    matrices = direct_matrix_checks(rng, counts)
    discriminants = quadratic_linear_normalization_checks(counts)
    assert len(quaternions) == 28
    assert Counter(q['algebra_type'] for q in quaternions) == {'split': 12, 'division': 16}
    assert counts['quaternion_triples'] == 896
    assert counts['direct_matrix_triples'] == 416
    assert counts['arbitrary_matrix_triples'] == 192
    result = {
        'status': 'PASS', 'arithmetic': 'exact Fraction arithmetic; Python standard library only',
        'seed': SEED, 'quaternion_algebras': quaternions,
        'arbitrary_matrix_fields': matrices, 'counts': dict(counts),
        'verified_formulas': [
            'K(X,Y)=Tr(A_X sigma(A_Y)); s_X=K(X,1)=Tr(A_X)',
            'H(X,Y)=2K(X,sigma(Y))-s_X s_Y=2Tr(U_X U_Y)',
            'Omega(X,Y,Z)=4Tr(U_X U_Y U_Z) is alternating',
            'Omega(X,Y,Z)^2=-det(H on X,Y,Z)',
            'Tr(A_X A_Y A_Z)=(sss+sH+sH+sH+Omega)/4',
            'Transpose, positive involution and opposite multiplication reverse Omega',
            'Rational Gram coordinates recover every volume from one nonsingular triple',
        ],
        'imaginary_quadratic_normalization': {
            'fundamental_discriminants_checked': discriminants,
            'coordinate': 'h=(s+b sqrt(Delta))/2; b is the second integral-basis coefficient',
            'per_pair_identity': '2 Norm(h)-(h^2+conjugate(h)^2)=abs(Delta)*b^2',
            'orthogonality_consequence': 'f=abs(Delta)*sum_source_pairs b_i^2',
        },
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'theorem_file_sha256': hashlib.sha256((HERE/'r34_one_matrix_reconstruction.tex').read_bytes()).hexdigest(),
        'seconds': time.monotonic()-started,
        'scope': 'Supplementary finite exact identity audit; the manuscript gives the general proof. No fusion-ring existence, positivity of multiplication coefficients, or categorification is asserted.',
    }
    (HERE/'reconstruction_identity_verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('quaternion_algebras', 'arbitrary_matrix_fields')}, indent=2))


if __name__ == '__main__':
    main()
