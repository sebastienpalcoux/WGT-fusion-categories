#!/usr/bin/env python3
"""Exact independent group-ring audit of the integral commutator volume.

Python standard library only. Group multiplication, identity coefficients,
character Gram matrices, principal minors and primitive lattice bases are
computed directly. No candidate fusion ring is postulated or constructed.
"""
from fractions import Fraction as Q
from functools import reduce
from itertools import combinations, permutations, product
from math import gcd
from pathlib import Path
import hashlib
import json
import time

HERE = Path(__file__).resolve().parent


def det3(a):
    return (a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])
            - a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
            + a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]))


def rank(a):
    a = [list(map(Q, row)) for row in a]
    row = 0
    for col in range(len(a[0])):
        pivot = next((i for i in range(row, len(a)) if a[i][col]), None)
        if pivot is None:
            continue
        a[pivot], a[row] = a[row], a[pivot]
        scale = a[row][col]
        a[row] = [x/scale for x in a[row]]
        for i in range(len(a)):
            if i != row:
                scale = a[i][col]
                a[i] = [x-scale*y for x, y in zip(a[i], a[row])]
        row += 1
        if row == len(a):
            break
    return row


def solve3(a, b):
    a = [[Q(x) for x in row]+[Q(y)] for row, y in zip(a, b)]
    for col in range(3):
        pivot = next(i for i in range(col, 3) if a[i][col])
        a[pivot], a[col] = a[col], a[pivot]
        scale = a[col][col]
        a[col] = [x/scale for x in a[col]]
        for i in range(3):
            if i != col:
                scale = a[i][col]
                a[i] = [x-scale*y for x, y in zip(a[i], a[col])]
    return tuple(row[-1] for row in a)


def matmul(a, b):
    return [[sum(x*y for x, y in zip(row, col)) for col in zip(*b)] for row in a]


def perm_sign(p):
    return (-1)**sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1, len(p)))


def permutation_group(n, even=False):
    elements = [p for p in permutations(range(n)) if not even or perm_sign(p) == 1]
    return elements, lambda p, q: tuple(p[q[i]] for i in range(n))


def groups():
    s3, compose3 = permutation_group(3)
    yield {'name': 'S3', 'elements': s3, 'multiply': compose3,
           'identity': tuple(range(3)), 'degrees': [1, 1, 2],
           'character': lambda p: sum(i == p[i] for i in range(3))-1,
           'expected': 6, 'f': 3}
    d8 = list(product(range(4), range(2)))
    yield {'name': 'D8', 'elements': d8,
           'multiply': lambda x, y: ((x[0]+(-1)**x[1]*y[0]) % 4, (x[1]+y[1]) % 2),
           'identity': (0, 0), 'degrees': [1, 1, 1, 1, 2],
           'character': lambda x: (2 if x[0] == 0 else -2 if x[0] == 2 else 0) if x[1] == 0 else 0,
           'expected': 8, 'f': 4}
    # Basis order 1,i,j,k with i^2=j^2=k^2=-1 and ij=k.
    qt = (((1, 0), (1, 1), (1, 2), (1, 3)),
          ((1, 1), (-1, 0), (1, 3), (-1, 2)),
          ((1, 2), (-1, 3), (-1, 0), (1, 1)),
          ((1, 3), (1, 2), (-1, 1), (-1, 0)))

    def quaternion_product(x, y):
        sign, basis = qt[x[1]][y[1]]
        return x[0]*y[0]*sign, basis

    yield {'name': 'Q8', 'elements': list(product((1, -1), range(4))),
           'multiply': quaternion_product, 'identity': (1, 0),
           'degrees': [1, 1, 1, 1, 2],
           'character': lambda x: 2*x[0] if x[1] == 0 else 0,
           'expected': 8, 'f': 4}
    a4, compose4 = permutation_group(4, even=True)
    yield {'name': 'A4', 'elements': a4, 'multiply': compose4,
           'identity': tuple(range(4)), 'degrees': [1, 1, 1, 3],
           'expected': 32}
    s4, compose4 = permutation_group(4)
    yield {'name': 'S4', 'elements': s4, 'multiply': compose4,
           'identity': tuple(range(4)), 'degrees': [1, 1, 2, 3, 3],
           'expected': 152}
    yield {'name': 'C4', 'elements': list(range(4)), 'multiply': lambda x, y: (x+y) % 4,
           'identity': 0, 'degrees': [1, 1, 1, 1], 'expected': 0}


def verify_group(spec):
    elements, multiply = spec['elements'], spec['multiply']
    n = len(elements)
    index = {x: i for i, x in enumerate(elements)}
    identity = index[spec['identity']]
    table = [[index[multiply(x, y)] for y in elements] for x in elements]
    assert len(index) == n
    for x, y, z in product(range(n), repeat=3):
        assert table[table[x][y]][z] == table[x][table[y][z]]
    for x in range(n):
        assert table[x][identity] == table[identity][x] == x
    inverse = []
    for x in range(n):
        choices = [y for y in range(n) if table[x][y] == table[y][x] == identity]
        assert len(choices) == 1
        inverse.append(choices[0])
    classes = {tuple(sorted(table[table[g][x]][inverse[g]] for g in range(n))) for x in range(n)}
    assert sum(m*m for m in spec['degrees']) == n
    assert len(classes) == len(spec['degrees'])
    codegrees = [Q(n, m) for m in spec['degrees']]
    assert all(f.denominator == 1 for f in codegrees)

    def c(x, y, z):
        return int(table[table[x][y]][z] == identity)-int(table[table[y][x]][z] == identity)

    coefficient_items = []
    total = 0
    for x, y, z in product(range(n), repeat=3):
        v = c(x, y, z)
        assert v == -c(y, x, z) == c(y, z, x)
        if len({x, y, z}) < 3:
            assert v == 0
        total += v*v
    for triple in combinations(range(n), 3):
        coefficient_items.append((triple, c(*triple)))
    square_sum = sum(v*v for _, v in coefficient_items)
    assert total == 6*square_sum
    direct_ordered_norm = sum(0 if table[x][y] == table[y][x] else 2 for x, y in product(range(n), repeat=2))
    theoretical = sum(f*m*(m*m-1) for m, f in zip(spec['degrees'], codegrees))/3
    assert total == direct_ordered_norm == 2*n*(n-len(classes))
    assert square_sum == theoretical == spec['expected']
    out = {'group': spec['name'], 'order': n, 'conjugacy_classes': len(classes),
           'irreducible_degrees': spec['degrees'], 'formal_codegrees': [int(f) for f in codegrees],
           'unordered_commutator_square_sum': square_sum,
           'ordered_commutator_norm': direct_ordered_norm,
           'nonzero_unordered_coefficients': sum(v != 0 for _, v in coefficient_items),
           'multiplication_table_sha256': hashlib.sha256(json.dumps(table).encode()).hexdigest()}
    if 'f' not in spec:
        return out

    f = spec['f']
    character = [spec['character'](x) for x in elements]
    k = [[character[table[x][inverse[y]]] for y in range(n)] for x in range(n)]
    s = [k[x][identity] for x in range(n)]
    assert s == character and s[identity] == 2
    assert rank(k) == 4
    assert matmul(k, k) == [[f*v for v in row] for row in k]
    assert sum(v*v for v in s) == 2*f
    g = [[2*k[x][y]-s[x]*s[y] for y in range(n)] for x in range(n)]
    h = [[2*k[x][inverse[y]]-s[x]*s[y] for y in range(n)] for x in range(n)]
    assert rank(g) == rank(h) == 3
    assert matmul(g, g) == [[2*f*v for v in row] for row in g]
    assert all(g[x][y] == g[y][x] for x in range(n) for y in range(n))
    assert all(g[x][identity] == 0 for x in range(n))
    assert all(sum(row) == 0 for row in g)
    for x, y, z in product(range(n), repeat=3):
        omega = (4*character[table[table[x][y]][z]]
                 - (s[x]*s[y]*s[z]+s[x]*h[y][z]+s[y]*h[x][z]+s[z]*h[x][y]))
        assert omega == 2*f*c(x, y, z)
    principal_sum = 0
    for triple, coefficient in coefficient_items:
        dg = det3([[g[x][y] for y in triple] for x in triple])
        dh = det3([[h[x][y] for y in triple] for x in triple])
        assert dg == -dh == (2*f*coefficient)**2
        principal_sum += dg
    assert principal_sum == (2*f)**3
    assert square_sum == 2*f

    # A nonzero unit Plucker coordinate makes saturation directly testable.
    anchor, anchor_coefficient = next((t, v) for t, v in coefficient_items if v)
    assert abs(anchor_coefficient) == 1
    anchor_gram = [[g[x][y] for y in anchor] for x in anchor]
    rows = [solve3(anchor_gram, [g[x][y] for y in anchor]) for x in range(n)]
    assert all(v.denominator == 1 for row in rows for v in row)
    rows = [[int(v) for v in row] for row in rows]
    assert [rows[x] for x in anchor] == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    for triple, coefficient in coefficient_items:
        assert det3([rows[x] for x in triple]) == Q(coefficient, anchor_coefficient)
    assert rank(rows) == 3
    assert matmul(g, rows) == [[2*f*v for v in row] for row in rows]
    lattice_gram = [[sum(row[a]*row[b] for row in rows) for b in range(3)] for a in range(3)]
    determinant = det3(lattice_gram)
    content = reduce(gcd, (abs(v) for _, v in coefficient_items))
    assert content == 1
    assert content*content*determinant == 2*f
    out['one_matrix'] = {'f': f, 'K_rank': 4, 'G_rank': 3,
        'G_nonzero_eigenvalue': 2*f, 'sum_principal_three_minors': principal_sum,
        'commutator_content': content, 'saturated_lattice_gram_determinant': determinant,
        'source_elements': [str(x) for x in elements], 'character': character,
        'lattice_basis_columns': rows, 'lattice_gram': lattice_gram,
        'coordinate_identity_rows': list(anchor),
        'nonzero_commutator_coefficients': [[*t, v] for t, v in coefficient_items if v]}
    return out


def main():
    started = time.monotonic()
    results = [verify_group(spec) for spec in groups()]
    report = {'status': 'PASS', 'arithmetic': 'exact integers and Fraction; Python standard library only',
        'groups': results,
        'identities': [
            'c_XYZ=tau([X,Y]Z) is integral and alternating',
            'sum_unordered c_XYZ^2=(1/3)*sum_E f_E*m_E*(m_E^2-1)',
            'unique M2: Omega=2*f*c and -det(H_I)=(2*f*c_I)^2',
            'unique M2: G=2*K-s*s^T, G^2=2*f*G, rank G=3',
            'unique M2: sum principal 3-minors G=(2*f)^3 and sum c_I^2=2*f',
            'unique M2: c is decomposable and content(c)^2*det(saturated image lattice)=2*f',
        ],
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'proof_sha256': hashlib.sha256((HERE/'r34_commutator_volume_audit.tex').read_bytes()).hexdigest(),
        'seconds': time.monotonic()-started,
        'scope': 'Finite exact group-ring checks supplement the separate general algebraic proof.'}
    (HERE/'commutator_volume_verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'status': report['status'], 'seconds': report['seconds'],
                     'results': [{'group': r['group'], 'sum_c_squared': r['unordered_commutator_square_sum'],
                                  'lattice_determinant': r.get('one_matrix', {}).get('saturated_lattice_gram_determinant')}
                                 for r in results]}, indent=2))


if __name__ == '__main__':
    main()
