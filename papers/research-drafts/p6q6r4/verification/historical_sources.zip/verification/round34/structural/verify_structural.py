#!/usr/bin/env python3
"""Independent exact checks for the Round 34 structural lemmas.

No floating point, symbolic-algebra library, optimization solver or search
cutoff is used as an exclusion.  The proofs cover the general statements;
this file replays every finite substitution and small-graph case used there.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
Z = (F(0), F(0))
ONE = (F(1), F(0))

def z(a=0,b=0): return F(a),F(b)
def add(x,y): return x[0]+y[0],x[1]+y[1]
def neg(x): return -x[0],-x[1]
def sub(x,y): return add(x,neg(y))
def scale(x,a): return x[0]*a,x[1]*a
def mul(x,y,D): return x[0]*y[0]+D*x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def star(x): return x[0],-x[1]
def abs2(x,D): return x[0]*x[0]-D*x[1]*x[1]
def sq(x,D): return mul(x,x,D)
def tr(x): return 2*x[0]
def qjson(x): return [str(x[0]),str(x[1])]

def integers_in_imaginary_unit_disk(D):
    # For D=-1 the order is Z[sqrt(D)]; for D=-3 use parity numerator basis.
    if D==-1:
        xs=[z(a,b) for a,b in product(range(-2,3),repeat=2)]
    else:
        xs=[z(F(a,2),F(b,2)) for a,b in product(range(-4,5),repeat=2)
            if (a-b)%2==0]
    out=sorted(x for x in xs if abs2(x,D)<=1)
    assert len(out)==(5 if D==-1 else 7)
    assert all(x==Z or abs2(x,D)==1 for x in out)
    return out

def complex_rows(D,alpha):
    out=[]
    for t in range(3):
        if abs2(alpha,D)>2*t: continue
        for n in integers_in_imaginary_unit_disk(D):
            if 4*abs2(n,D)>t*t: continue
            G=F(t*t)-abs2(alpha,D)*t+2*mul(sq(alpha,D),star(n),D)[0]-4*abs2(n,D)
            K=2*t-2*sq(alpha,D)[0]+4*n[0]
            if G<0 or G%3 or K<0 or K>6: continue
            assert G.denominator==K.denominator==1
            out.append((t,n,int(G),int(K)))
    return out

def cycle_checks():
    output={}
    for n in range(3,7):
        valid=[]
        for ds in product((1,2),repeat=n):
            for signs in product((-1,1),repeat=n):
                H=[[0]*n for _ in range(n)]
                for i in range(n):
                    H[i][i]=ds[i]
                    j=(i+1)%n
                    H[i][j]=H[j][i]=signs[i]
                if not all(sum(H[i][k]*H[k][j] for k in range(n))==3*H[i][j]
                           for i in range(n) for j in range(n)): continue
                rank=sum(ds)//3
                assert sum(ds)%3==0
                if n==3:
                    assert ds in ((1,1,1),(2,2,2))
                    assert rank in (1,2)
                elif n==4:
                    assert ds in ((1,2,1,2),(2,1,2,1)) and rank==2
                    assert signs[0]*signs[1]*signs[2]*signs[3]==-1
                else: raise AssertionError((n,ds,signs))
                valid.append((ds,signs,rank))
        output[str(n)]=len(valid)
    assert output=={"3":8,"4":16,"5":0,"6":0}
    parts=[(3,1),(3,2),(4,2)]
    rank3=[]
    for length in range(1,4):
        for ps in product(parts,repeat=length):
            if sum(x[1] for x in ps)==3 and sum(x[0] for x in ps)<=6:
                rank3.append(ps)
                assert sorted(ps)==[(3,1),(3,2)]
    for zz,vv in product(product((-1,1),repeat=3),repeat=2):
        assert sum(a*b for a,b in zip(zz,vv))!=0
    return output

def nonnegative_real(x,D=3):
    return x[0]>=0 and x[0]*x[0]>=D*x[1]*x[1]

def real_sqrt3_rows():
    gammas=sorted(z(a,b) for a in range(3) for b in range(-2,3)
                  if nonnegative_real(z(a,b)))
    assert set(gammas)=={z(),z(1),z(2),z(2,1),z(2,-1)}
    allowed=[]; candidates=[]
    for g in gammas:
        for n in (z(a,b) for a,b in product(range(-2,3),repeat=2)):
            if not nonnegative_real(add(g,scale(n,2))):continue
            if not nonnegative_real(sub(g,scale(n,2))):continue
            GG=tr(sub(sq(g,3),scale(sq(n,3),4)))
            K=tr(add(g,scale(n,2)))
            candidates.append({"gamma":qjson(g),"beta":qjson(n),"G_trace":str(GG),"K":str(K)})
            if GG<0 or GG%6 or not 0<=K<=6:continue
            allowed.append((g,n,int(K)))
    assert set(allowed)=={(z(),z(),0),(z(2),z(-1),0)}
    return candidates,allowed

def madd(A,B): return tuple(add(a,b) for a,b in zip(A,B))
def msub(A,B): return tuple(sub(a,b) for a,b in zip(A,B))
def mmul(A,B,D):
    return tuple(add(mul(A[2*i],B[j],D),mul(A[2*i+1],B[2+j],D))
                 for i in range(2) for j in range(2))
def mstar(A): return star(A[0]),star(A[2]),star(A[1]),star(A[3])
def mtr(A): return add(A[0],A[3])
def mdet(A,D): return sub(mul(A[0],A[3],D),mul(A[1],A[2],D))

def direct_matrix_checks():
    count=0
    for D in (-1,-3):
        root=z(0,1) if D==-1 else z(F(1,2),F(1,2))
        alphabet=(Z,ONE,root,add(ONE,root))
        for A in product(alphabet,repeat=4):
            adj=mstar(A)
            aa=mmul(A,adj,D)
            alpha=mtr(A); beta=mdet(A,D); gamma=mtr(aa)
            assert gamma[1]==0 and gamma[0]>=0
            direct=sub(mtr(mmul(aa,aa,D)),
                       mtr(mmul(mmul(A,A,D),mmul(adj,adj,D),D)))
            formula=gamma[0]**2-abs2(alpha,D)*gamma[0]+2*mul(sq(alpha,D),star(beta),D)[0]-4*abs2(beta,D)
            comm=msub(aa,mmul(adj,A,D))
            assert direct==scale(mtr(mmul(comm,comm,D)),F(1,2))==z(formula)
            assert formula>=0
            count+=1
    return count

def main():
    result={"status":"PASS","arithmetic":"Python standard library; exact integers and fractions"}
    gaussian=[]
    for v in (-1,0,1):
        for t,n,G,K in complex_rows(-1,z(0,v)):
            H=K//2-v*v
            assert K%2==0 and H in (0,1,2)
            if H==1: assert v!=0 and t==1 and n==Z
            if H==2: assert v==0 and t==2 and n in (z(0,1),z(0,-1))
            gaussian.append({"v":v,"gamma":t,"beta":qjson(n),"G":G,"K":K,"H":H})
    result["gaussian_rows"]=gaussian
    result["cycle_counts"]=cycle_checks()
    eis={}
    for name,alpha in [("zero",Z),("exceptional",z(0,1))]+[
        ("unit_"+str(a)+"_"+str(b),z(F(a,2),F(b,2)))
        for a,b in product((-1,1),repeat=2)]:
        rows=complex_rows(-3,alpha)
        if name=="exceptional": assert rows==[(2,z(-1),0,6)]
        elif name=="zero":
            assert {r[3] for r in rows}=={0,2,6}
            assert all(t==2 and abs2(n,-3)==1 and n[0]==F(1,2)
                       for t,n,G,K in rows if K==6)
        else:
            assert {r[3] for r in rows}=={3}
            assert all((t==1 and n==Z) or (t==2 and n==sq(alpha,-3))
                       for t,n,G,K in rows)
        eis[name]=[{"gamma":t,"beta":qjson(n),"G":G,"K":K} for t,n,G,K in rows]
    result["eisenstein_rows"]=eis
    partitions=[xs for k in range(4) for xs in product((0,2,6),repeat=k) if sum(xs)==12]
    assert partitions and all(xs.count(6)>=2 for xs in partitions)
    result["eisenstein_case_b_diagonals"]=partitions
    # At most four off-diagonal positions, each square 0,1,4.
    square_patterns=[xs for xs in product((0,1,4),repeat=4) if sum(xs)==8]
    assert all(sorted(xs)==[0,0,4,4] for xs in square_patterns)
    result["eisenstein_case_a_offsquare_patterns"]=len(square_patterns)
    # Rank-one triangles use three coordinates, isolated eigenvalue6 one.
    components=[(a,c) for a,c in product(range(4),repeat=2)
                if a+c==3 and 3*a+c<=5]
    assert components and all(c>=2 for a,c in components)
    result["eisenstein_case_a_components"]=components
    rr,allowed=real_sqrt3_rows()
    result["real_sqrt3_candidates"]=rr
    result["real_sqrt3_survivors"]=[{"gamma":qjson(g),"beta":qjson(n),"K":K}
                                  for g,n,K in allowed]
    assert [d for d in range(3,73) if (d**3-d)%25==0 and (d**3-d)%27==0]==[26]
    assert not any((d**3-d)%5400==0 for d in range(3,73))
    result["cubic_defect_dimensions_checked"]=70
    result["direct_matrix_commutator_checks"]=direct_matrix_checks()
    result["threshold_hypotheses"] = (
        "The source is integral with no nonunit invertible; the two conjugate "
        "degree-two representations of codegree six are all nonlinear "
        "representations. These finite checks supplement the general proofs.")
    result["proved_thresholds"]={"Gaussian":17,"Eisenstein":17,"real_sqrt3":"impossible at every rank"}
    (HERE/"structural_verification.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if not isinstance(v,(list,dict))},indent=2))
    print("All finite substitutions and projection-graph checks PASS.")

if __name__=="__main__":
    main()

